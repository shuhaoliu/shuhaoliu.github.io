"""Controlled end-to-end fixtures; no real datasets or GPU are needed."""

from __future__ import annotations

import importlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import torch

from experiments.check_trim_run import check_run, replay_states
from prototype.experiment_hooks import ALL_ROWS_AT_MAX_GENERALIZATION, AblationActions
from prototype.greedy_selection import SelectionState
from prototype.state_history import TestSplitGuard as HoldoutGuard, retained_ids_sha256

core = importlib.import_module("prototype.TRIM_prototype_pipeline")


class ChainGeneralization:
    def __init__(self, levels, forbid_holdout=False):
        self.generalization_level = dict(levels)
        self.forbid_holdout = forbid_holdout

    def encode(self, frame):
        if self.forbid_holdout and any(str(rid).startswith("h") for rid in frame.index):
            raise AssertionError("Holdout was encoded.")
        return frame[["q"]].astype(float) * ((3 - self.generalization_level["q"]) / 3)

    def change_level(self, levels):
        return ChainGeneralization(levels, self.forbid_holdout)


class DeterministicModel:
    """A fixed logistic predictor; fitting never introduces random variation."""
    def __init__(self, weight=1.0):
        self.weight = weight

    def set_classes(self, classes):
        self.classes_ = np.asarray(classes)

    def fit(self, encode, labels):
        self.coef_tensor_ = torch.tensor([self.weight], device=encode.device, dtype=encode.dtype)
        self.intercept_tensor_ = torch.zeros(1, device=encode.device, dtype=encode.dtype)
        return self

    def predict_proba_tensor(self, encode):
        probability = torch.sigmoid(encode[:, 0] * self.weight)
        return torch.stack((1 - probability, probability), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)


@pytest.fixture
def controlled(tmp_path, monkeypatch):
    row_ids = [f"t{i}" for i in range(8)] + ["v0", "v1", "h0", "h1"]
    frame = pd.DataFrame({"q": [-1, 1] * 6}, index=row_ids)
    labels = pd.Series([0, 1] * 6, index=row_ids)
    tree = tmp_path / "tree.yaml"
    tree.write_text("trees:\n  q:\n    nodes:\n      - height_from_leaf: 3\n")
    loader = SimpleNamespace(
        task_type="classification", qi_attributes=("q",), feature_columns=("q",),
        load=lambda nrows=None: (frame.copy(), labels.copy()))
    forbid_holdout = {"enabled": False}
    import sklearn.model_selection
    from prototype import dataloader

    def split(X, y, **kwargs):
        if any(str(rid).startswith("h") for rid in X.index):
            held_out = ["h0", "h1"]
        else:
            held_out = ["v0", "v1"]
        remainder = [rid for rid in row_ids if rid in X.index and rid not in held_out]
        return X.loc[remainder], X.loc[held_out], y.loc[remainder], y.loc[held_out]

    monkeypatch.setattr(sklearn.model_selection, "train_test_split", split)
    monkeypatch.setattr(dataloader, "load_generalization_rules_from_file",
                        lambda file_path, data_loader, generalization_level:
                        ChainGeneralization(generalization_level, forbid_holdout["enabled"]))
    monkeypatch.setattr(core, "stratified_sample_row_ids", lambda *args: ["t0", "t1"])
    options = {
        "generalization_tree_path": tree, "privacy_cost_floor": 0.05, "initial_sample_size": 2,
        "model_factory": DeterministicModel,
        "proxy_model_factory": DeterministicModel,
        "estimator_model_factory": DeterministicModel,
        "device": "cpu", "dtype": "float64", "rank_top_k": 2,
        "results_dir": tmp_path / "runs",
    }
    return loader, tree, options, forbid_holdout


def test_initial_state_satisfies_threshold(controlled):
    loader, tree, options, _ = controlled
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9)
    assert result.iteration_count == 0
    assert result.termination_condition == "loss_threshold_met"
    assert not result.infeasible
    assert result.generalization_level == {"q": 3}
    assert sorted(result.state.selected_row_ids) == ["t0", "t1"]
    assert check_run(result.run_dir, loader, tree)["states_checked"] == 1


@pytest.mark.parametrize("max_iterations", [0, 5])
def test_provably_infeasible_returns_training_data(controlled, max_iterations):
    loader, tree, options, _ = controlled
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6,
                                    max_iterations=max_iterations)
    assert result.infeasible
    assert result.generalization_level == {"q": 0}
    assert set(result.selected_row_ids) == {f"t{i}" for i in range(8)}
    assert result.original_leak_k == result.final_leak_k == 4
    assert result.validation_utility_constraint_met is False
    for release in result.output_comparisons.values():
        assert release["infeasible"] and release["fallback_original_training_data"]
        assert release["delta_u"] == pytest.approx(0, abs=1e-14)
        assert release["validation_delta_u"] == pytest.approx(0, abs=1e-14)
        assert release["validation_utility_constraint_met"] is False
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"


def test_no_positive_proxy_gain(controlled):
    loader, _, options, _ = controlled
    options["proxy_model_factory"] = lambda: DeterministicModel(weight=0)
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6, max_iterations=5)
    assert result.iteration_count == 0
    assert result.termination_condition == "no_action_available"
    assert result.infeasible


def test_multi_level_refinement_skips_levels(controlled):
    # Every refined level splits the rows into the same two classes, so all
    # targets cost the same and the leaf, with the strongest signal, wins.
    loader, tree, options, _ = controlled
    options["ablation_actions"] = AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION)
    baseline = math.log1p(math.exp(-1))
    threshold = (math.log1p(math.exp(-1 / 3)) + math.log1p(math.exp(-2 / 3))) / 2
    result = core.run_trim_pipeline(loader, **options, tolerance=threshold - baseline,
                                    max_iterations=5)
    assert result.iteration_count == 1
    assert result.termination_condition == "loss_threshold_met"
    assert result.generalization_level == {"q": 0}
    run_dir = Path(result.run_dir)
    records = [json.loads(line) for line in (run_dir / "state_history.jsonl").read_text().splitlines()]
    assert [record["generalization_level"]["q"] for record in records] == [3, 0]
    actions = [json.loads(line) for line in next(run_dir.glob(
        "pipeline_selection_actions_*.jsonl")).read_text().splitlines()]
    swaps = [a for a in actions if a.get("event") == "swap_candidate" and a["iteration"] == 0]
    assert [(a["candidate_id"], a["target_level"]) for a in swaps] == [
        ("q@2", 2), ("q@1", 1), ("q@0", 0)]
    chosen = [a for a in actions if a.get("event") == "candidate_evaluation" and a["selected"]]
    assert [(a["candidate_id"], a["attribute"]) for a in chosen] == [("q@0", "q")]
    assert check_run(result.run_dir, loader, tree)["commits_checked"] == 1


@pytest.mark.parametrize("stop_k,rounds,condition", [
    (4, 1, "release_min_k_reached"),
    (3, 1, "no_action_available"),
])
def test_stop_at_release_min_k(controlled, stop_k, rounds, condition):
    # Every refined release has min-K 4: a bound of 4 stops after the first
    # round, and a bound of 3 is never reached (round 0 refines q to the leaf,
    # after which no action remains).
    loader, tree, options, _ = controlled
    options["ablation_actions"] = AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION)
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=5,
                                    stop_on_utility=False, stop_at_release_min_k=stop_k)
    assert result.iteration_count == rounds
    assert result.termination_condition == condition
    records = [json.loads(line) for line in (Path(result.run_dir)
               / "state_history.jsonl").read_text().splitlines()]
    assert [record["mixed_min_k"] for record in records[1:]] == [4] * rounds
    assert check_run(result.run_dir, loader, tree)["commits_checked"] == rounds


@pytest.mark.parametrize("options_update,message", [
    ({"stop_at_release_min_k": 0, "stop_on_utility": False}, "positive integer"),
    ({"stop_at_release_min_k": True, "stop_on_utility": False}, "positive integer"),
    ({"stop_at_release_min_k": 1}, "trajectories"),
])
def test_stop_options_are_validated(controlled, options_update, message):
    loader, _, options, _ = controlled
    with pytest.raises(ValueError, match=message):
        core.run_trim_pipeline(loader, **options, tolerance=1e9, **options_update)


def test_refinement_shortlist_ranks_all_target_levels_together(controlled):
    # With top-k 1 the shortlist proxy-checks one of q@2, q@1, q@0.
    loader, tree, options, _ = controlled
    options["ablation_actions"] = AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION)
    options["rank_top_k"] = 1
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=1,
                                    stop_on_utility=False)
    run_dir = Path(result.run_dir)
    actions = [json.loads(line) for line in next(run_dir.glob(
        "pipeline_selection_actions_*.jsonl")).read_text().splitlines()]
    checked_ids = [a["candidate_id"] for a in actions if a.get("event") == "candidate_evaluation"
                   and a["iteration"] == 0 and a["action"] == "vertical_refinement"]
    assert len(checked_ids) == 1
    assert check_run(result.run_dir, loader, tree)["commits_checked"] == 1


def test_fast_path_usage_reports_fallback_without_cache(controlled):
    # The chain fixture is not a DatasetGeneralization, so no cache is built.
    loader, _, options, _ = controlled
    options["ablation_actions"] = AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION)
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=1,
                                    stop_on_utility=False)
    usage = json.loads((Path(result.run_dir) / "metrics.json").read_text())["fast_path_usage"]
    assert usage["selection_cache_active"] is False and usage["all_fast"] is False
    assert usage["refinement_rank_privacy"] == {"used": 0, "fallback": 3}
    assert usage["release_rank_privacy"]["used"] == 0 and usage["release_rank_privacy"]["fallback"] > 0


def test_validation_only_guards_all_holdout_uses(controlled):
    loader, tree, options, forbid_holdout = controlled
    forbid_holdout["enabled"] = True
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6, max_iterations=2,
                                    validation_only=True)
    assert result.infeasible and not result.test_evaluated
    assert result.baseline_test_loss is None and result.final_actual_model_loss is None
    for release in result.output_comparisons.values():
        assert release["test_evaluated"] is False
        assert release.get("test_loss") is None
        assert release["utility_split"] == "validation"
        assert release["validation_loss"] == pytest.approx(result.baseline_val_loss)
    assert check_run(result.run_dir, loader, tree)["test_evaluated"] is False


def test_target_validation_logged_without_utility_stop(controlled):
    loader, tree, options, forbid_holdout = controlled
    forbid_holdout["enabled"] = True
    options["ablation_actions"] = AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION)
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=2,
                                    stop_on_utility=False, validation_only=True,
                                    record_iteration_validation_metrics=True)
    # Round 0 refines q to the leaf; no action remains after it.
    assert result.iteration_count == 1
    assert result.termination_condition == "no_action_available"
    records = [json.loads(line) for line in (Path(result.run_dir)
                                            / "state_history.jsonl").read_text().splitlines()]
    assert [record["generalization_level"]["q"] for record in records] == [3, 0]
    for record in records:
        expected_loss = math.log1p(math.exp(-(3 - record["generalization_level"]["q"]) / 3))
        assert record["target_validation_loss"] == pytest.approx(expected_loss)
        assert record["target_validation_delta_u"] == pytest.approx(expected_loss - result.baseline_val_loss)
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"


def test_test_guard_rejects_access():
    guard = HoldoutGuard()
    for access in (lambda: len(guard), lambda: guard[0],
                   lambda: guard.index, lambda: iter(guard), lambda: np.asarray(guard)):
        with pytest.raises(RuntimeError, match="Test split access"):
            access()


def test_replay_rejects_tampered_ids():
    record = {"round": 0, "iteration": -1, "retained_row_ids": ["a", "b"],
              "retained_count": 2, "retained_ids_sha256": retained_ids_sha256(["a", "c"])}
    with pytest.raises(ValueError, match="count/hash"):
        list(replay_states([record], ["a", "b", "c"]))


@pytest.mark.parametrize("cap,expected_ids,reason", [
    (3000, {"t1", "t2", "t3", "t5"}, "converged"),
    (1, {"t1", "t2", "t3", "t5"}, "max_iterations"),
])
def test_example_four_swap_can_evict_seed(monkeypatch, cap, expected_ids, reason):
    monkeypatch.setattr(core, "VERTICAL_SWAP_MAX_ITERATIONS", cap)
    # Refined classes: {t1,t2}, {t3,t5}, {t4}; selected seed includes t4.
    encoded = pd.DataFrame({"q": [0, 0, 1, 2, 1]}, index=["t1", "t2", "t3", "t4", "t5"])
    state = SelectionState(
        selected_row_ids=["t3", "t4", "t5"], current_train_encode=encoded.copy(),
        current_train_tensor=torch.tensor(encoded.to_numpy(), dtype=torch.float64))
    stats = core._apply_vertical_swap_inplace(
        state, encoded, ("q",), swap_level_encode=encoded)
    assert set(state.selected_row_ids) == expected_ids
    assert stats["swap_iterations"] == 1
    assert stats["break_reason"] == reason
    next_k = int(encoded.loc[state.selected_row_ids].value_counts().min())
    assert next_k == 2
    cost, delta = core._operation_privacy_cost(3, next_k, 0.05)
    assert cost == pytest.approx(math.log(3 / 2))
    assert delta == pytest.approx(math.log(3 / 2))


def test_swap_cap_is_persisted_and_audited(controlled, monkeypatch):
    loader, tree, options, _ = controlled
    frame = pd.DataFrame(
        {"q": [0, 0, 1, 2, 1, 0, 1, 0, 1]},
        index=["t1", "t2", "t3", "t4", "t5", "v0", "v1", "h0", "h1"])
    labels = pd.Series([0, 0, 1, 0, 1, 0, 1, 0, 1], index=frame.index)
    loader.load = lambda nrows=None: (frame.copy(), labels.copy())
    tree.write_text("trees:\n  q:\n    nodes:\n      - height_from_leaf: 1\n")
    monkeypatch.setattr(ChainGeneralization, "encode", lambda self, X:
                        X[["q"]].astype(float) * (1 - self.generalization_level["q"]))
    monkeypatch.setattr(core, "VERTICAL_SWAP_MAX_ITERATIONS", 1)
    monkeypatch.setattr(core, "stratified_sample_row_ids", lambda *args: ["t3", "t4", "t5"])
    options["initial_sample_size"] = 3
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6, max_iterations=1)
    records = [json.loads(line) for line in (Path(result.run_dir)
               / "state_history.jsonl").read_text().splitlines()]
    assert result.iteration_count == 1
    assert records[1]["swap_cap_hit"] is True
    assert records[1]["evicted_row_ids"] == ["t4"]
    assert records[1]["admitted_row_ids"] == ["t1", "t2"]
    assert check_run(result.run_dir, loader, tree)["swap_cap_hit_rounds"] == [1]
