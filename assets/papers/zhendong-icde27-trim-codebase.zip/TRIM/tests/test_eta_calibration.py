"""Independent eta fit, positivity/tie policy, and frozen evaluation fixtures."""

import copy

import pytest

from experiments.exp6_estimation.calibrate import apply_eta, fit_eta


def test_weighted_median_not_least_squares_and_lower_tie():
    rows = [{"seed": seed, "method": "lga", "raw_lga_score": 1, "actual_utility_delta": b}
            for seed in (47, 48, 49) for b in (2, 10)]
    result = fit_eta(rows)
    assert result["status"] == "ok"
    assert result["eta"] == 2  # The entire [2,10] interval minimizes MAE.


@pytest.mark.parametrize("pairs,reason", [
    ([(1, -2)], "nonpositive_lower_minimizer"),
    ([(1, 0)], "nonpositive_lower_minimizer"),
    ([(0, 3)], "all_raw_lga_scores_zero"),
    ([(1, -1), (1, 1)], "nonpositive_lower_minimizer"),
])
def test_unusable_lower_median_is_flagged_without_clipping(pairs, reason):
    rows = [{"seed": seed, "method": "lga", "raw_lga_score": a, "actual_utility_delta": b}
            for seed in (47, 48, 49) for a, b in pairs]
    result = fit_eta(rows)
    assert result["status"] == "failed"
    assert result["eta"] is None
    assert result["reason"] == reason


def test_zero_scores_do_not_change_eta():
    result = fit_eta([
        {"seed": seed, "method": method, "raw_lga_score": a, "actual_utility_delta": b}
        for seed in (47, 48, 49)
        for method, a, b in (("lga", -2, -6), ("lga", 0, 999), ("if", 100, -999))
    ])
    assert result["eta"] == 3
    assert result["zero_score_count"] == 3
    assert result["calibration_utility_mae"] == pytest.approx(999 / 2)


def test_fit_rejects_evaluation_records():
    with pytest.raises(ValueError, match="47--49"):
        fit_eta([{"seed": 42, "method": "lga", "raw_lga_score": 1, "actual_utility_delta": 2}])


@pytest.fixture
def paired_evaluation():
    rows, summaries = [], []
    for seed in range(42, 47):
        for method in ("trim", "if", "lga", "retrain"):
            # Evaluation target gains imply eta=100. The supplied frozen eta=2
            # must remain unchanged and have a utility error of 98.
            estimate = 100 if method == "retrain" else 1
            rows.append({
                "seed": seed, "iteration": 0, "method": method,
                "candidate_type": "vertical_refinement", "candidate_id": "q",
                "raw_lga_score": 1, "actual_utility_delta": 100, "actual_rho": 400,
                "privacy_cost": 0.25, "estimated_utility_delta": estimate,
                "estimated_rho": estimate / 0.25,
                "utility_abs_error": abs(estimate - 100),
                "score_abs_error": abs(estimate / 0.25 - 400),
            })
            summaries.append({
                "seed": seed, "iteration": 0, "method": method,
                "evaluated_candidate_count": 1,
                "selected_candidate_type": "vertical_refinement", "selected_candidate_id": "q",
                "time_seconds": 1,
            })
    return rows, summaries


def test_apply_never_refits_on_evaluation_and_uses_same_eta_for_both_panels(paired_evaluation):
    rows, summaries = paired_evaluation
    original = copy.deepcopy(rows)
    calibration = {"status": "ok", "eta": 2, "calibration_seeds": [47, 48, 49]}
    candidates, summary = apply_eta(rows, summaries, calibration)
    assert rows == original
    for row in candidates:
        if row["method"] == "lga":
            assert row["estimated_utility_delta"] == 2
            assert row["utility_abs_error"] == 98
            assert row["score_abs_error"] == 392
    for row in summary:
        if row["method"] == "lga":
            assert row["eta"] == 2
            assert row["utility_mae"] == 98
            assert row["score_mae"] == 392
            assert row["calibration_status"] == "independent_seeds"


def test_evaluation_seed_leakage_is_rejected(paired_evaluation):
    rows, summaries = paired_evaluation
    rows[0]["seed"] = 47
    with pytest.raises(ValueError, match="42--46"):
        apply_eta(rows, summaries, {"status": "ok", "eta": 2, "calibration_seeds": [47, 48, 49]})


def test_calibration_using_evaluation_seeds_is_rejected(paired_evaluation):
    rows, summaries = paired_evaluation
    with pytest.raises(ValueError, match="independently"):
        apply_eta(rows, summaries, {"status": "ok", "eta": 2, "calibration_seeds": [42, 43, 44]})


def test_failed_calibration_cannot_produce_errors(paired_evaluation):
    rows, summaries = paired_evaluation
    with pytest.raises(ValueError, match="Calibration failed"):
        apply_eta(rows, summaries, {"status": "failed", "eta": None, "calibration_seeds": [47, 48, 49]})
