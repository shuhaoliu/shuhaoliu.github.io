"""Stall rule (widening) of the TRIM core and the full-rule shortlists of the Fig. 5l ablation."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest
import torch

from experiments.check_trim_run import check_run
from experiments.exp6_ablation.policies import (
    PrivacyOnlyShortlist,
    SeededRandomShortlist,
    utility_only_shortlist,
)
from prototype.experiment_hooks import CandidateShortlistContext, RankedCandidate

from test_candidate_scoring import core, scoring  # noqa: F401  (fixture)


class ConstantHalfModel:
    """Proxy whose validation loss never changes, so it never sees a positive gain."""

    def set_classes(self, classes):
        self.classes_ = classes

    def fit(self, encode, labels):
        return self

    def predict_proba_tensor(self, encode):
        half = torch.full((encode.shape[0],), 0.5, device=encode.device, dtype=encode.dtype)
        return torch.stack((1 - half, half), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)


def _stall_events(run_dir):
    (action_log,) = Path(run_dir).glob("pipeline_selection_actions_*.jsonl")
    return [record for record in map(json.loads, action_log.read_text().splitlines())
            if record.get("event") == "candidate_evaluation_before_stall_stage"]


def test_widen_stage_that_finds_no_gain_ends_the_run(scoring):
    loader, tree, options = scoring
    # The proxy's validation loss never changes, so round 0 stalls before and after widening.
    options = {**options, "proxy_model_factory": ConstantHalfModel}
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6, max_iterations=2,
                                    stall_rule="widen", stall_widen_top_k=3)
    assert result.iteration_count == 0
    assert result.termination_condition == "no_action_available"
    config = json.loads((Path(result.run_dir) / "config.json").read_text())
    assert config["stall_rule"] == "widen"
    assert config["stall_rule_rounds"] == [{"iteration": 0, "stage": 1, "action": None}]
    assert {record["iteration"] for record in _stall_events(result.run_dir)} == {0}
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"


def test_unknown_stall_rule_is_rejected(scoring):
    loader, _, options = scoring
    with pytest.raises(ValueError, match="stall_rule"):
        core.run_trim_pipeline(loader, **options, stall_rule="backtrack")


def _level_peak_model(shift_by_scale):
    """Proxy whose validation loss depends only on the QI level of its training rows.

    ChainGeneralization encodes q at level l as q * (3 - l) / 3, so the largest absolute
    training value gives 3 - l; the model moves 1/2 by the shift for that scale towards
    the label that sign(q) predicts (level 3 predicts 1/2).
    """
    class LevelPeakModel:
        def set_classes(self, classes):
            self.classes_ = np.asarray(classes)

        def fit(self, encode, labels):
            self.shift_ = shift_by_scale[round(float(encode.abs().max()) * 3)]
            return self

        def predict_proba_tensor(self, encode):
            rate = 0.5 + self.shift_ * torch.sign(encode[:, 0])
            return torch.stack((1 - rate, rate), dim=1)

        def predict_tensor(self, encode):
            return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)

    return LevelPeakModel


# LGA ranks the refinements q@0, q@1, q@2 (top-1: q@0). The proxy sees a positive gain at
# q@2 (shift 0.2) and, in the second table, a smaller one at q@1 (shift 0.05).
ONLY_THIRD = {0: 0.0, 1: 0.2, 2: -0.05, 3: -0.1}
SECOND_AND_THIRD = {0: 0.0, 1: 0.2, 2: 0.05, 3: -0.1}


def _cap_run(scoring, shift_by_scale, **extra):
    loader, tree, options = scoring
    options = {**options, "proxy_model_factory": _level_peak_model(shift_by_scale), "rank_top_k": 1}
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6, max_iterations=1,
                                    stall_rule="widen", **extra)
    run_dir = Path(result.run_dir)
    config = json.loads((run_dir / "config.json").read_text())
    history = [(record["round"], record["retained_ids_sha256"], record["generalization_level"])
               for record in map(json.loads, (run_dir / "state_history.jsonl").read_text().splitlines())]
    (action_log,) = run_dir.glob("pipeline_selection_actions_*.jsonl")
    checked = [record for record in map(json.loads, action_log.read_text().splitlines())
               if record.get("event") == "candidate_evaluation"]
    return result, config, history, checked


def test_widen_cap_at_least_the_largest_pool_checks_every_candidate(scoring):
    loader, tree, _ = scoring
    capped, config, history, checked = _cap_run(scoring, ONLY_THIRD, stall_widen_top_k=3)
    assert config["stall_rule_rounds"] == [{"iteration": 0, "stage": 1, "action": "vertical_refinement",
                                            "attribute": "q"}]
    assert history[-1][2] == {"q": 2}
    assert capped.iteration_count == 1
    assert config["stall_widen_top_k"] == 3
    assert sorted(c["candidate_id"] for c in checked if c["candidate_type"] == "vertical_refinement") == [
        "q@0", "q@1", "q@2"]
    assert check_run(capped.run_dir, loader, tree)["status"] == "ok"


def test_widen_cap_checks_the_top_m_of_each_pool_and_commits_their_best(scoring):
    loader, tree, _ = scoring
    capped, config, history, checked = _cap_run(scoring, SECOND_AND_THIRD, stall_widen_top_k=2)
    # q@2 is outside the top 2, so the capped stage commits the best gain among q@0 and q@1.
    assert [c["candidate_id"] for c in checked if c["candidate_type"] == "vertical_refinement"] == ["q@0", "q@1"]
    assert [c["candidate_id"] for c in checked if c["selected"]] == ["q@1"]
    assert history[-1][2] == {"q": 1}
    assert config["stall_rule_rounds"] == [{"iteration": 0, "stage": 1, "action": "vertical_refinement",
                                            "attribute": "q"}]
    assert check_run(capped.run_dir, loader, tree)["status"] == "ok"
    # The audit enforces the cap: with M = 1 recorded, two checked refinements are too many.
    config_path = Path(capped.run_dir) / "config.json"
    config_path.write_text(json.dumps({**config, "stall_widen_top_k": 1}))
    with pytest.raises(ValueError, match="top-k"):
        check_run(capped.run_dir, loader, tree)


def test_widen_cap_that_hides_every_gain_ends_the_run(scoring):
    loader, tree, _ = scoring
    result, config, history, checked = _cap_run(scoring, ONLY_THIRD, stall_widen_top_k=2)
    assert result.iteration_count == 0
    assert result.termination_condition == "no_action_available"
    assert config["stall_rule_rounds"] == [{"iteration": 0, "stage": 1, "action": None}]
    assert [c["candidate_id"] for c in checked if c["candidate_type"] == "vertical_refinement"] == ["q@0", "q@1"]
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"
    config_path = Path(result.run_dir) / "config.json"
    config_path.write_text(json.dumps({**config, "stall_widen_top_k": 1}))
    with pytest.raises(ValueError, match="top-k"):
        check_run(result.run_dir, loader, tree)


@pytest.mark.parametrize("cap, rule, message", [
    (True, "widen", "larger than rank_top_k"), (2.5, "widen", "larger than rank_top_k"),
    ("140", "widen", "larger than rank_top_k"), (2, "widen", "larger than rank_top_k"),
    (None, "widen", "larger than rank_top_k"), (5, None, "requires stall_rule"),
])
def test_widen_cap_refuses_invalid_settings(scoring, cap, rule, message):
    loader, _, options = scoring  # rank_top_k 2
    with pytest.raises(ValueError, match=message):
        core.run_trim_pipeline(loader, **options, stall_rule=rule, stall_widen_top_k=cap)


def test_unmet_run_stops_at_the_release_min_k_and_returns_d(scoring):
    loader, tree, _ = scoring
    # tolerance -1e6 is never met; every release has min-K <= 10**6, so the first committed round ends the search.
    result, config, history, _ = _cap_run(scoring, ONLY_THIRD, stall_widen_top_k=3,
                                          stop_unmet_at_release_min_k=10**6)
    assert result.termination_condition == "release_min_k_reached_unmet"
    assert result.iteration_count == 1 and len(history) == 2
    assert config["stop_unmet_at_release_min_k"] == 10**6
    metrics = json.loads((Path(result.run_dir) / "metrics.json").read_text())
    assert metrics["infeasible"] is True
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"


@pytest.mark.parametrize("value, stop_on_utility, message", [
    (True, True, "positive integer"), (0, True, "positive integer"), (1.5, True, "positive integer"),
    (1, False, "stop_on_utility"),
])
def test_unmet_stop_refuses_invalid_settings(scoring, value, stop_on_utility, message):
    loader, _, options = scoring
    with pytest.raises(ValueError, match=message):
        core.run_trim_pipeline(loader, **options, stop_on_utility=stop_on_utility, stop_unmet_at_release_min_k=value)


def _context(rank_top_k=1):
    rows = [  # pool, lga, privacy cost, raw leak change
        (0, 0.9, 0.05, -0.2), (0, 0.1, 0.05, -0.5), (0, 0.5, 1.0, 1.0),
        (1, 0.2, 0.3, 0.3), (1, 0.8, 2.0, 2.0),
    ]
    return CandidateShortlistContext(iteration=0, rank_top_k=rank_top_k, candidates=tuple(
        RankedCandidate(position=i, candidate_type="x", candidate_id=i, rank_score=lga / cost,
                        lga_score=lga, privacy_cost=cost, leakage_delta=delta, pool=pool)
        for i, (pool, lga, cost, delta) in enumerate(rows)))


def test_utility_shortlist_takes_the_largest_lga_of_each_pool():
    assert utility_only_shortlist(_context()) == (0, 4)


def test_privacy_shortlist_takes_the_cheapest_and_breaks_floor_ties_by_leak():
    # Positions 0 and 1 share the floor cost; 1 lowers the leak more.
    assert PrivacyOnlyShortlist(seed=1)(_context()) == (1, 3)
    assert PrivacyOnlyShortlist(seed=1)(_context(rank_top_k=2)) == (1, 0, 3, 4)


def test_random_shortlist_draws_k_valid_positions_per_pool():
    positions = SeededRandomShortlist(seed=3)(_context(rank_top_k=2))
    assert len(positions) == len(set(positions)) == 4
    assert sum(p in (0, 1, 2) for p in positions) == 2 and sum(p in (3, 4) for p in positions) == 2
    assert positions == SeededRandomShortlist(seed=3)(_context(rank_top_k=2))
