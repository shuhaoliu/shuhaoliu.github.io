"""TRIM's final check (Section IV): the target model is retrained and checked on validation only when the proxy's
validation Delta U on D_t is within the tolerance; the run stops when that check passes."""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import pytest
import torch

from experiments.check_trim_run import check_run
from experiments.exp3_runtime._metrics import extract_runtime_to_stop
from plotting.paper._common import seconds_to_stop

from test_candidate_scoring import core, scoring  # noqa: F401  (fixture)

TRAINING_ROWS = 8  # t0..t7 in the scoring fixture


class FullSplitProxy:
    """Proxy that fits well only on the full training split, so its Delta U on any smaller D_t is about 0.83."""

    def set_classes(self, classes):
        self.classes_ = np.asarray(classes)

    def fit(self, encode, labels):
        self.rate_ = 0.5 if len(labels) == TRAINING_ROWS else 0.95
        return self

    def predict_proba_tensor(self, encode):
        rate = torch.full((encode.shape[0],), self.rate_, device=encode.device, dtype=encode.dtype)
        return torch.stack((1 - rate, rate), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)


def _states(result):
    path = Path(result.run_dir) / "state_history.jsonl"
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def _rows(result):
    return json.loads((Path(result.run_dir) / "trim_iterations.json").read_text())["iterations"]


def _runtime(result, tolerance):
    """paper_runtime.json written by the Fig. 5c time extractor."""
    summary = extract_runtime_to_stop({"report_tolerance": tolerance},
                                      {"run_id": "test", "run_dir": str(result.run_dir)}, None)
    runtime = json.loads((Path(result.run_dir) / "paper_runtime.json").read_text())
    assert summary["paper_algorithm_time_seconds"] == runtime["algorithm_time_seconds"]
    assert summary["runtime_stopped"] == runtime["stopped"]
    return runtime


def test_final_check_passes_in_the_initial_state(scoring):
    loader, tree, options = scoring
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=3, stop_on_utility=True)
    assert result.iteration_count == 0 and result.termination_condition == "loss_threshold_met"
    run_dir = Path(result.run_dir)
    metrics = json.loads((run_dir / "metrics.json").read_text())
    assert metrics["baseline_proxy_val_loss"] is not None and not metrics["infeasible"]
    timings = metrics["timings"]
    assert timings["proxy_reference_fit_time_seconds"] > 0 and timings["initial_stop_check_time_seconds"] > 0
    assert _states(result)[0]["final_check"] is True
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"
    seconds, tolerance = seconds_to_stop(run_dir)
    runtime = _runtime(result, 1e9)
    assert tolerance == 1e9 and runtime["stopped"] and runtime["stop_iteration"] == -1
    assert seconds == pytest.approx(runtime["algorithm_time_seconds"]) and seconds > 0


def test_no_final_check_while_the_proxy_misses_the_tolerance(scoring):
    loader, tree, options = scoring
    options = {**options, "proxy_model_factory": FullSplitProxy}
    # Every target Delta U here is at most log(2) - log(1 + e^-1) < 0.5, so a final check would pass at once;
    # the proxy's Delta U on D_0 is about 0.83, so TRIM must not check (or stop) in the initial state.
    result = core.run_trim_pipeline(loader, **options, tolerance=0.5, max_iterations=4, stop_on_utility=True,
                                    record_iteration_validation_metrics=True)
    initial = _states(result)[0]
    assert initial["final_check"] is False and initial["proxy_delta_u"] > 0.5
    assert initial["target_validation_delta_u"] <= 0.5
    # Round 0 admits the whole training split, the proxy then meets the tolerance, and the check passes.
    (row,) = _rows(result)
    assert row["final_check"] is True and row["search_proxy_delta_u"] <= 0.5
    assert row["target_validation_utility_constraint_met"] is True
    assert result.termination_condition == "loss_threshold_met" and result.iteration_count == 1
    metrics = json.loads((Path(result.run_dir) / "metrics.json").read_text())
    assert metrics["timings"]["initial_stop_check_time_seconds"] == 0.0 and not metrics["infeasible"]
    runtime = _runtime(result, 0.5)
    assert runtime["stop_iteration"] == 0
    assert seconds_to_stop(result.run_dir)[0] == pytest.approx(runtime["algorithm_time_seconds"])
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"


@pytest.mark.parametrize("tolerance", [0.02, 0.05, 0.1, 0.2])
def test_run_stops_at_its_first_passed_final_check(scoring, tolerance):
    loader, tree, options = scoring
    result = core.run_trim_pipeline(loader, **options, tolerance=tolerance, max_iterations=4, stop_on_utility=True,
                                    record_iteration_validation_metrics=True)
    states = _states(result)
    checked = [state["final_check"] for state in states[:1]] + [row["final_check"] for row in _rows(result)]
    passed = [state["final_check"] and state["target_validation_delta_u"] <= tolerance for state in states[:1]] + [
        row["final_check"] and row["target_validation_utility_constraint_met"] for row in _rows(result)]
    assert checked[0] == (states[0]["proxy_delta_u"] <= tolerance)
    if result.termination_condition == "loss_threshold_met":
        assert passed[-1] and not any(passed[:-1])
        runtime = _runtime(result, tolerance)
        assert runtime["stop_iteration"] == result.iteration_count - 1
        assert seconds_to_stop(result.run_dir)[0] == pytest.approx(runtime["algorithm_time_seconds"])
    else:
        assert not any(passed)
    assert check_run(result.run_dir, loader, tree)["status"] == "ok"


def test_checker_rejects_a_wrong_initial_decision(scoring):
    loader, tree, options = scoring
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=3, stop_on_utility=True)
    path = Path(result.run_dir) / "state_history.jsonl"
    lines = path.read_text().splitlines()
    initial = json.loads(lines[0])
    assert initial["final_check"] is True and initial["target_validation_utility_constraint_met"] is True
    initial["final_check"] = False  # the proxy passed, so a skipped check is inconsistent
    path.write_text("\n".join([json.dumps(initial)] + lines[1:]) + "\n")
    with pytest.raises(ValueError, match="initial final check"):
        check_run(result.run_dir, loader, tree)


def test_algorithm_time_is_the_run_totals(scoring):
    loader, _, options = scoring
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=3, stop_on_utility=True)
    timings = json.loads((Path(result.run_dir) / "metrics.json").read_text())["timings"]
    parts = ("initial_model_fit_time_seconds", "initial_scoring_time_seconds", "proxy_reference_fit_time_seconds",
             "initial_stop_check_time_seconds")
    assert all(timings[p] > 0 for p in parts)
    assert timings["backend_retraining_certification_time_seconds"] == pytest.approx(sum(timings[p] for p in parts))
    totals = sum(timings[f] for f in ("candidate_enumeration_total_time_seconds", "selection_time_seconds",
                                      "privacy_accounting_time_seconds",
                                      "backend_retraining_certification_time_seconds"))
    assert seconds_to_stop(result.run_dir)[0] == pytest.approx(totals)
