"""Fig. 4 drawing (plotting/paper/style/privacy_utility.py) on small synthetic runs."""

import csv
import math

import pytest

from experiments.exp1_baselines.results import EvaluationStore, write_tables
from plotting.paper.style import privacy_utility

REFERENCE = {42: 0.21, 43: 0.22}
METHODS = ["TRIM", "FeatSel", "FIDO"]


def write_trajectory(path, rounds):
    """rounds[seed] = [(test Delta U, min-K), ...], one per TRIM round."""
    fields = ["dataset", "model_name", "seed", "iteration", "test_loss", "test_delta_u", "min_k", "original_leak_k",
              "tail_risk_p99"]
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for seed, points in rounds.items():
            for iteration, (du, k) in enumerate(points):
                writer.writerow({"dataset": "bm", "model_name": "xgboost", "seed": seed, "iteration": iteration,
                                 "test_loss": REFERENCE[seed] + du, "test_delta_u": du, "min_k": k,
                                 "original_leak_k": 1, "tail_risk_p99": -math.log(k)})


def baseline_table(tmp_path, method, points, reference=REFERENCE):
    """A long table of the baseline harness; points = [(point, test Delta U, min-K, tail leak)] for every seed."""
    store = EvaluationStore(tmp_path / f"{method}.jsonl", resume=False)
    for seed in (42, 43):
        for point, du, k, tail in points:
            store.append({"record_type": "point", "experiment": "exp1_privacy_utility", "method": method,
                          "dataset": "bm", "model": "xgboost", "seed": seed, "point": point, "test_delta_u": du,
                          "validation_delta_u": du, "test_loss": reference[seed] + du,
                          "baseline_test_loss": reference[seed], "min_k": k, "original_leak_k": 1,
                          "tail_risk_p99": tail, "original_tail_risk_p99": 0.0})
    return write_tables(store, tmp_path, method)["long"]


@pytest.fixture
def inputs(tmp_path):
    trajectory = tmp_path / "trajectory.csv"
    # Round 3 exists only for seed 43, so it is not drawn.
    write_trajectory(trajectory, {42: [(0.02, 4), (0.01, 64), (0.05, 4096)],
                                  43: [(0.04, 4), (0.03, 64), (0.07, 4096), (0.09, 8192)]})
    featsel = baseline_table(tmp_path, "FeatSel", [("keep_10", -0.01, 32, -3.0), ("keep_00", 0.05, 2048, -7.0)])
    fido = baseline_table(tmp_path, "FIDO", [("n500", 0.02, 1, 0.0), ("n100", 0.06, 1, -math.inf)])
    return trajectory, [featsel, fido]


def test_delta_u_over_each_method_best_output(inputs):
    trajectory, tables = inputs
    curves = privacy_utility.curves([trajectory], tables, "bm", "xgboost", (42, 43), METHODS)
    trim = curves["TRIM"]["leak"]
    # TRIM's best output is round 1 (mean Delta U 0.02); round 0 (0.03) keeps round 1's lower leak; round 3 is dropped.
    assert [point for _, _, point in trim] == ["origin", "1", "0", "2"]
    assert [x for x, _, _ in trim] == pytest.approx([0.0, 0.0, 0.01, 0.04])
    assert [y for _, y, _ in trim] == pytest.approx([0.0, -math.log(64), -math.log(64), -math.log(4096)])
    # FeatSel's best output (Delta U -0.01 from the full-data model) is its zero; its full-split output follows.
    featsel = curves["FeatSel"]["leak"]
    assert [point for _, _, point in featsel] == ["keep_10", "full-data", "keep_00"]
    assert [x for x, _, _ in featsel] == pytest.approx([0.0, 0.01, 0.06])
    assert [y for _, y, _ in featsel] == pytest.approx([-math.log(32), -math.log(32), -math.log(2048)])
    assert [y for _, y, _ in curves["FeatSel"]["tail"]] == pytest.approx([-3.0, -3.0, -7.0])
    # FIDO's points are its own runs; its full-split output is its best one, so the zero stays at full data.
    fido = curves["FIDO"]
    assert [point for _, _, point in fido["leak"]] == ["full-data", "n500", "n100"]
    assert [x for x, _, _ in fido["leak"]] == pytest.approx([0.0, 0.02, 0.06])
    assert [y for _, y, _ in fido["leak"]] == [0.0, 0.0, 0.0]
    assert [y for _, y, _ in fido["tail"]] == [0.0, 0.0, -math.inf]


def test_panel_files(inputs, tmp_path):
    trajectory, tables = inputs
    curves = privacy_utility.curves([trajectory], tables, "bm", "xgboost", (42, 43), METHODS)
    out = tmp_path / "figures"
    out.mkdir()
    privacy_utility.draw(curves, out, "fig4h", xmax=0.05)
    privacy_utility.draw_legend(METHODS, out, "fig4_legend")
    privacy_utility.write_points(curves, "bm", "xgboost", (42, 43), out / "fig4h_points.csv")
    assert all((out / name).exists() for name in ("fig4h.pdf", "fig4h.png", "fig4_legend.pdf", "fig4_legend.png"))
    with (out / "fig4h_points.csv").open(newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert {row["method"] for row in rows} == set(METHODS)
    assert {row["panel"] for row in rows} == {"leak", "tail"}


def test_different_full_data_models_are_refused(inputs, tmp_path):
    trajectory, _ = inputs
    (tmp_path / "other").mkdir()
    other = baseline_table(tmp_path / "other", "FeatSel", [("keep_10", 0.01, 32, -3.0)], reference={42: 0.3, 43: 0.22})
    with pytest.raises(ValueError, match="different full-data test losses"):
        privacy_utility.curves([trajectory], [other], "bm", "xgboost", (42, 43), ["TRIM", "FeatSel"])
