"""The removal view's class-size counting must match regrouping all rows.

Coarsening and exchange candidates count min-K from class sizes instead of
regrouping every next active row (REGROUP_CANDIDATE_CLASSES switches to the
regroup). Both runs must write the same action log, apart from timings.
"""

from __future__ import annotations

import json

import pytest

from experiments.appendix_removal_view import pipeline
from experiments.perf.synthetic_income import INCOME_TREE, write_income_like_csvs
from prototype import dataloader

FEATURES = ("AGEP", "SCHL", "MAR", "RAC1P", "SEX", "WKHP")
QI = ("MAR", "RAC1P", "SEX")
TIMING_FIELDS = (
    "enumeration_seconds_total",
    "iteration_seconds",
    "timings",
    "run_dir",
)


def _run(monkeypatch, data_dir, results_dir, *, regroup):
    monkeypatch.setattr(pipeline, "REGROUP_CANDIDATE_CLASSES", regroup)
    loader = dataloader.ACSIncomeDataLoader(
        data_dir=data_dir,
        state="CA",
        year=2014,
        feature_columns=FEATURES,
        numeric_attributes=("AGEP", "WKHP"),
        qi_attributes=QI,
    )
    pipeline.run_removal_view(
        loader,
        INCOME_TREE,
        results_dir=results_dir,
        tolerance=0.05,
        random_state=42,
        max_iterations=12,
        model_max_iter=30,
        rank_top_k=None,
        exchange_pool_size=4,
        device="cpu",
    )
    events = []
    for line in (results_dir / "removal_actions.jsonl").read_text().splitlines():
        event = json.loads(line)
        for field in TIMING_FIELDS:
            event.pop(field, None)
        events.append(event)
    return events


@pytest.fixture(scope="module")
def data_dir(tmp_path_factory):
    return write_income_like_csvs(
        tmp_path_factory.mktemp("income"), rows=600, seed=5,
    )


def test_counted_and_regrouped_runs_write_the_same_log(
    monkeypatch, data_dir, tmp_path,
):
    counted = _run(monkeypatch, data_dir, tmp_path / "counted", regroup=False)
    regrouped = _run(monkeypatch, data_dir, tmp_path / "regrouped", regroup=True)
    assert counted == regrouped

    # The run must reach the cases the counting replaces: coarsening and
    # exchange candidates, and an exchange whose incoming class joins an active
    # class of the same key (one class fewer), which needs a coarsening after a
    # removal.
    evaluated = [event for event in counted if event["event"] == "removal_candidate"]
    actions = {event["action"] for event in evaluated}
    assert {"attribute_coarsen", "k_safe_class_exchange"} <= actions
    joined = [
        event
        for event in evaluated
        if event["action"] == "k_safe_class_exchange"
        and event["next_privacy_stats"]["class_count"]
        == event["current_privacy_stats"]["class_count"] - 1
    ]
    assert joined
