"""Refinement eviction ceilings on a controlled fixture; no real datasets or GPU are needed."""

from __future__ import annotations

import importlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import torch

from experiments.check_trim_run import check_run
from prototype.experiment_hooks import ALL_ROWS_AT_MAX_GENERALIZATION, AblationActions

core = importlib.import_module("prototype.TRIM_prototype_pipeline")


class ChainGeneralization:
    """Level L scales q by (3 - L) / 3, so every refined level keeps the classes of q."""
    def __init__(self, levels):
        self.generalization_level = dict(levels)

    def encode(self, frame):
        return frame[["q"]].astype(float) * ((3 - self.generalization_level["q"]) / 3)

    def change_level(self, levels):
        return ChainGeneralization(levels)


class DeterministicModel:
    """A fixed logistic predictor; fitting never introduces random variation."""
    def set_classes(self, classes):
        self.classes_ = np.asarray(classes)

    def fit(self, encode, labels):
        self.coef_tensor_ = torch.ones(1, device=encode.device, dtype=encode.dtype)
        self.intercept_tensor_ = torch.zeros(1, device=encode.device, dtype=encode.dtype)
        return self

    def predict_proba_tensor(self, encode):
        probability = torch.sigmoid(encode[:, 0])
        return torch.stack((1 - probability, probability), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)

# Twelve training rows: every refined level splits them into classes of 5, 5,
# 1 and 1, so a refinement without eviction publishes min-K 1.
TRAIN_Q = [-1] * 5 + [1] * 5 + [2, -2]


@pytest.fixture
def fixture(tmp_path, monkeypatch):
    train_ids = [f"t{i}" for i in range(len(TRAIN_Q))]
    row_ids = train_ids + ["v0", "v1", "h0", "h1"]
    frame = pd.DataFrame({"q": TRAIN_Q + [-1, 1, -1, 1]}, index=row_ids)
    labels = pd.Series([int(q > 0) for q in frame["q"]], index=row_ids)
    tree = tmp_path / "tree.yaml"
    tree.write_text("trees:\n  q:\n    nodes:\n      - height_from_leaf: 3\n")
    loader = SimpleNamespace(
        task_type="classification", qi_attributes=("q",), feature_columns=("q",),
        load=lambda nrows=None: (frame.copy(), labels.copy()))
    import sklearn.model_selection
    from prototype import dataloader

    def split(X, y, **kwargs):
        held_out = ["h0", "h1"] if any(str(rid).startswith("h") for rid in X.index) else ["v0", "v1"]
        remainder = [rid for rid in row_ids if rid in X.index and rid not in held_out]
        return X.loc[remainder], X.loc[held_out], y.loc[remainder], y.loc[held_out]

    monkeypatch.setattr(sklearn.model_selection, "train_test_split", split)
    monkeypatch.setattr(dataloader, "load_generalization_rules_from_file",
                        lambda file_path, data_loader, generalization_level:
                        ChainGeneralization(generalization_level))
    monkeypatch.setattr(core, "stratified_sample_row_ids", lambda *args: ["t0", "t5"])
    options = {
        "generalization_tree_path": tree, "privacy_cost_floor": 0.05, "initial_sample_size": 2,
        "model_factory": DeterministicModel, "proxy_model_factory": DeterministicModel,
        "estimator_model_factory": DeterministicModel,
        "device": "cpu", "dtype": "float64", "rank_top_k": 3,
        "results_dir": tmp_path / "runs", "tolerance": 1e9, "max_iterations": 1,
        "stop_on_utility": False,
        "ablation_actions": AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION),
    }
    return loader, tree, options


def _records(result):
    return [json.loads(line) for line in (Path(result.run_dir) / "state_history.jsonl").read_text().splitlines()]


def test_eviction_variant_caps_the_privacy_drop(fixture):
    # All twelve rows start in one class (min-K 12). Ratio 4 gives ceiling 3:
    # the variant evicts the two singletons and publishes min-K 5 at the same
    # proxy gain, so it beats every un-evicted refinement (min-K 1).
    loader, tree, options = fixture
    result = core.run_trim_pipeline(loader, **options, refinement_eviction_ratios=[4])
    record = _records(result)[1]
    assert record["operation"] == "vertical_refinement"
    assert (record["current_k"], record["next_k"], record["mixed_min_k"]) == (12, 5, 5)
    assert record["eviction_ceiling"] == 3
    assert record["ceiling_evicted_row_ids"] == ["t10", "t11"]
    assert record["retained_count"] == 10
    actions = [json.loads(line) for line in next(Path(result.run_dir).glob(
        "pipeline_selection_actions_*.jsonl")).read_text().splitlines()]
    chosen = [a for a in actions if a.get("event") == "candidate_evaluation" and a["selected"]]
    assert [(a["candidate_id"], a["eviction_ceiling"]) for a in chosen] == [("q@0~k3", 3)]
    config = json.loads((Path(result.run_dir) / "config.json").read_text())
    assert config["refinement_eviction_ratios"] == [4.0]
    assert check_run(result.run_dir, loader, tree)["commits_checked"] == 1


def test_eviction_variants_have_their_own_shortlist_pool(fixture):
    # With top-k 1 the un-evicted refinement that the swap-only search checks
    # is still checked, next to the best eviction variant.
    loader, tree, options = fixture
    options["rank_top_k"] = 1
    result = core.run_trim_pipeline(loader, **options, refinement_eviction_ratios=[4])
    actions = [json.loads(line) for line in next(Path(result.run_dir).glob(
        "pipeline_selection_actions_*.jsonl")).read_text().splitlines()]
    checked = [(a["candidate_id"], a.get("eviction_ceiling")) for a in actions
               if a.get("event") == "candidate_evaluation" and a["action"] == "vertical_refinement"]
    assert len(checked) == 2
    assert sum(ceiling is None for _, ceiling in checked) == 1
    assert check_run(result.run_dir, loader, tree)["commits_checked"] == 1


def test_without_ratios_refinement_is_unchanged(fixture):
    loader, tree, options = fixture
    result = core.run_trim_pipeline(loader, **options)
    record = _records(result)[1]
    assert (record["current_k"], record["next_k"]) == (12, 1)
    assert "eviction_ceiling" not in record and "ceiling_evicted_row_ids" not in record
    assert "refinement_eviction_ratios" not in json.loads((Path(result.run_dir) / "config.json").read_text())
    assert check_run(result.run_dir, loader, tree)["commits_checked"] == 1


def test_audit_rejects_a_ceiling_that_no_ratio_gives(fixture):
    loader, tree, options = fixture
    result = core.run_trim_pipeline(loader, **options, refinement_eviction_ratios=[4])
    path = Path(result.run_dir) / "state_history.jsonl"
    records = _records(result)
    records[1]["eviction_ceiling"] = 2
    path.write_text("".join(json.dumps(record) + "\n" for record in records))
    with pytest.raises(ValueError, match="configured ratio"):
        check_run(result.run_dir, loader, tree)


@pytest.mark.parametrize("ratios", [[], [1], [0.5], ["4"], [True], "4", [float("inf")]])
def test_ratios_are_validated(fixture, ratios):
    loader, _, options = fixture
    with pytest.raises(ValueError, match="refinement_eviction_ratios"):
        core.run_trim_pipeline(loader, **options, refinement_eviction_ratios=ratios)

