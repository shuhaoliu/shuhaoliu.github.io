"""Focused checks for TDS with a suppression budget (TDS + MaxSup). Run explicitly with pytest when authorized."""

from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from experiments.exp1_kanon.hierarchy import HierarchySchema
from experiments.exp1_kanon_global.tds import FittedTDS
from experiments.exp1_kanon_global.tds_maxsup import FittedTDSMaxSup
from prototype.dataloader import load_generalization_rules


@pytest.fixture
def schema():
    loader = SimpleNamespace(
        feature_columns=("age", "kind", "aux"), qi_attributes=("age", "kind"),
        numeric_attributes=("age", "aux"), categorical_attributes=("kind",),
        category_maps={"kind": {"a": 0, "b": 1, "c": 2}},
    )
    trees = {
        "age": {"nodes": [
            {"id": "age_root", "parent": None, "kind": "root", "height_from_leaf": 1},
            *[{"id": f"age_{i}", "value": i, "parent": "age_root", "kind": "leaf", "height_from_leaf": 0}
              for i in range(8)],
        ]},
        "kind": {"nodes": [
            {"id": "kind_root", "parent": None, "kind": "root", "height_from_leaf": 2},
            {"id": "ab", "parent": "kind_root", "kind": "internal", "height_from_leaf": 1},
            {"id": "a", "value": "a", "parent": "ab", "kind": "leaf", "height_from_leaf": 0},
            {"id": "b", "value": "b", "parent": "ab", "kind": "leaf", "height_from_leaf": 0},
            {"id": "c", "value": "c", "parent": "kind_root", "kind": "leaf", "height_from_leaf": 0},
        ]},
    }
    return HierarchySchema(load_generalization_rules(trees, loader, generalization_level=0))


@pytest.fixture
def random_data():
    rng = np.random.default_rng(0)
    index = pd.RangeIndex(100, 160)
    X = pd.DataFrame({
        "age": rng.integers(0, 8, 60), "kind": rng.choice(["a", "b", "c"], 60), "aux": range(60),
    }, index=index)
    return X, pd.Series(rng.integers(0, 2, 60), index=index)


@pytest.mark.parametrize("k", [2, 5, 8])
def test_zero_budget_equals_tds(schema, random_data, k):
    X, y = random_data
    plain = FittedTDS(schema, k=k).fit(X, y)
    capped = FittedTDSMaxSup(schema, k=k, max_suppressed_fraction=0.0).fit(X, y)
    assert capped.cut == plain.cut
    assert capped.suppressed_positions == []
    assert sorted(g["size"] for g in capped.published_partitions) == sorted(g["size"] for g in plain.partitions)


@pytest.mark.parametrize("k,fraction", [(5, 0.1), (8, 0.2), (12, 0.3)])
def test_budget_and_k_hold(schema, random_data, k, fraction):
    X, y = random_data
    fitted = FittedTDSMaxSup(schema, k=k, max_suppressed_fraction=fraction).fit(X, y)
    published = [p for group in fitted.published_partitions for p in group["positions"]]
    assert len(fitted.suppressed_positions) <= int(np.floor(fraction * len(X)))
    assert all(group["size"] >= k for group in fitted.published_partitions)
    assert sorted(published + fitted.suppressed_positions) == list(range(len(X)))


def test_budget_must_be_a_fraction(schema):
    with pytest.raises(ValueError):
        FittedTDSMaxSup(schema, k=2, max_suppressed_fraction=1.0)
