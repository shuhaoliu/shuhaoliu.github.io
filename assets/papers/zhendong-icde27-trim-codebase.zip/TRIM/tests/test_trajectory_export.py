"""The Exp-1 trajectory export names proxy and target validation values apart."""

from __future__ import annotations

import csv
import json

from experiments.exp1_privacy_utility.run import _require_trajectory_artifacts


def test_trajectory_reports_target_validation_delta_u(tmp_path):
    run_dir = tmp_path / "run"
    run_dir.mkdir()
    leak = {f"original_leak_k_p{i}": 9 for i in range(1, 6)}
    iteration = {
        "iteration": 0, "action": "vertical_refinement", "attribute": "q",
        # Proxy release loss and its difference to the target's full-data loss.
        "validation_loss": 0.24, "delta_u": 0.034,
        "target_validation_loss": 0.205, "target_validation_delta_u": -0.0007,
        "test_loss": 0.214, "test_delta_u": 0.0009, "target_k": 3, "min_k": 3,
        "original_leak_k": 9, **leak, "tail_risk_p99": -1.0,
        "tail_risk_population_size": 10, "tail_risk_semantics": "s",
    }
    (run_dir / "trim_iterations.json").write_text(json.dumps({"iterations": [iteration]}))
    summary = {"run_dir": str(run_dir), "run_id": "r", "dataset": "bm",
               "random_state": 42, "experiment_observation_time_seconds": 0.0}
    _require_trajectory_artifacts(None, summary, tmp_path)
    row = next(csv.DictReader((run_dir / "trajectory.csv").open()))
    assert "validation_delta_u" not in row and "validation_loss" not in row
    assert float(row["proxy_validation_loss"]) == 0.24
    assert float(row["target_validation_loss"]) == 0.205
    assert float(row["target_validation_delta_u"]) == -0.0007
    assert float(row["test_delta_u"]) == 0.0009
