"""run_trim_pipeline(exact_speedups=True) must reproduce every output bit for bit.

Each fast path is checked against the code it replaces: the device gather of
encodings against encode_array / _encode_device_tensor, the memoized value
codes against fresh lookups, the numpy class index against the pandas one, and
the CUDA-graph L-BFGS against torch.optim.LBFGS (CUDA only). Whole runs with
refine-and-evict options are compared with experiments.perf.compare_runs.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest
import torch

from experiments.perf.compare_runs import compare_runs
from experiments.perf.synthetic_income import INCOME_TREE, write_income_like_csvs
from prototype import dataloader
from prototype import TRIM_prototype_pipeline as pipeline_module
from prototype.enumeration_horizontal import (
    build_retention_class_position_index,
    build_retention_class_position_index_numpy,
)
from prototype.greedy_selection import _load_max_generalization_level
from prototype.selection_cache import SelectionCache

CUDA = torch.cuda.is_available()
QI_SUBSET = ("AGEP", "SCHL", "MAR", "OCCP", "POBP", "SEX")


@pytest.fixture(scope="module")
def income(tmp_path_factory):
    directory = write_income_like_csvs(tmp_path_factory.mktemp("income"), rows=1500, seed=3)
    loader = dataloader.ACSIncomeDataLoader(data_dir=directory, state="CA", year=2014)
    X, _y = loader.load()
    base = dataloader.load_generalization_rules_from_file(
        INCOME_TREE, loader, {attribute: 0 for attribute in loader.feature_columns})
    train, val = X.iloc[:1000], X.iloc[1000:]
    qi = tuple(loader.qi_attributes)
    cache = SelectionCache(base, loader, [train, val], qi)
    heights = _load_max_generalization_level(INCOME_TREE, qi)
    generator = np.random.default_rng(7)
    levels = [{attribute: 0 for attribute in qi}, dict(heights)] + [
        {attribute: int(generator.integers(0, heights[attribute] + 1)) for attribute in qi}
        for _ in range(5)
    ]
    return cache, qi, levels, train, val


def _devices():
    return ["cpu"] + (["cuda"] if CUDA else [])


@pytest.mark.parametrize("device", _devices())
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_device_gather_equals_encode_array_bitwise(income, device, dtype):
    cache, _qi, levels, train, val = income
    generator = np.random.default_rng(11)
    np_dtype = np.float32 if dtype == torch.float32 else np.float64
    for memo in (False, True):
        cache.memo_codes = memo
        for level in levels:
            generalization = cache.generalization(level)
            for frame, positions in (
                    (train, None), (val, None),
                    (train, generator.permutation(len(train))[:333]),
                    (train, np.asarray([5, 5, 0, 999])),  # repeated rows and both ends
                    (val, np.asarray([7]))):
                gathered = generalization.encode_rows_tensor(frame, positions, device=device, dtype=dtype)
                subset = frame if positions is None else frame.iloc[positions]
                expected = torch.as_tensor(generalization.encode_array(subset, np_dtype))
                assert gathered is not None and gathered.dtype == dtype
                assert gathered.is_contiguous() and gathered.shape == expected.shape
                assert gathered.cpu().numpy().tobytes() == expected.numpy().tobytes()
    cache.memo_codes = False


def test_device_gather_declines_where_encode_array_would(income):
    cache, _qi, levels, train, _val = income
    generalization = cache.generalization(levels[2])
    # A frame the cache did not index, no rows, positions outside the frame, other dtypes.
    assert generalization.encode_rows_tensor(train.copy(), None, device="cpu", dtype=torch.float32) is None
    assert generalization.encode_rows_tensor(train, np.asarray([], dtype=np.int64),
                                             device="cpu", dtype=torch.float32) is None
    assert generalization.encode_rows_tensor(train, np.asarray([0, len(train)]),
                                             device="cpu", dtype=torch.float32) is None
    assert generalization.encode_rows_tensor(train, np.asarray([-1]), device="cpu", dtype=torch.float32) is None
    assert generalization.encode_rows_tensor(train, None, device="cpu", dtype=torch.float16) is None


@pytest.mark.parametrize("device", _devices())
def test_encode_split_rows_equals_encode_device_tensor(income, device):
    cache, _qi, levels, train, val = income
    generator = np.random.default_rng(5)
    for level in levels:
        generalization = cache.generalization(level)
        ids = list(train.index[generator.permutation(len(train))[:400]])
        positions = list(generator.permutation(len(val))[:50])
        for frame, kwargs, subset in (
                (train, {"row_ids": ids}, train.loc[ids]),
                (val, {"positions": positions}, val.iloc[positions]),
                (val, {}, val)):
            expected = pipeline_module._encode_device_tensor(
                generalization, subset, device=device, dtype=torch.float32)
            for gather in (False, True):
                got = pipeline_module._encode_split_rows(
                    generalization, frame, **kwargs, device=device, dtype=torch.float32,
                    device_gather=gather)
                assert got.cpu().numpy().tobytes() == expected.cpu().numpy().tobytes()
    with pytest.raises(KeyError):
        pipeline_module._encode_split_rows(cache.generalization(levels[0]), train, ["missing"],
                                           device="cpu", dtype=torch.float32, device_gather=True)


def test_encode_frame_from_tables_equals_encode(income):
    cache, _qi, levels, train, val = income
    for level in levels:
        generalization = cache.generalization(level)
        for frame in (train, val, train.iloc[::5]):
            expected = generalization.encode(frame)
            got = pipeline_module._encode_frame_from_tables(generalization, frame)
            pd.testing.assert_frame_equal(got, expected, check_exact=True)
            assert list(got.dtypes) == list(expected.dtypes)
            assert got.to_numpy().tobytes() == expected.to_numpy().tobytes()


def test_leak_snapshot_from_rank_columns_equals_encoded(income):
    from prototype.enumeration_horizontal import select_encoded_attributes

    cache, qi, levels, train, _val = income
    generator = np.random.default_rng(9)
    for level in levels:
        generalization = cache.generalization(level)
        for size in (1000, 600, 37):
            selected = list(train.index[generator.permutation(len(train))[:size]])
            expected = pipeline_module._published_leak_snapshot(
                select_encoded_attributes(generalization.encode(train), qi), selected)
            got = pipeline_module._published_leak_snapshot(
                generalization.privacy_frame(train, qi), selected)
            assert got[0] == expected[0] and got[1] == expected[1]
            assert sorted(got[2]) == sorted(expected[2])


def test_memoized_codes_give_the_same_privacy_frames(income):
    cache, qi, levels, train, val = income
    for level in levels:
        generalization = cache.generalization(level)
        cache.memo_codes = False
        expected = [generalization.privacy_frame(frame, qi) for frame in (train, val, train.iloc[::7])]
        cache.memo_codes = True
        for _repeat in range(2):
            got = [generalization.privacy_frame(frame, qi) for frame in (train, val, train.iloc[::7])]
            for left, right in zip(expected, got):
                pd.testing.assert_frame_equal(left, right, check_exact=True)
    cache.memo_codes = False


def _assert_same_position_index(left, right):
    assert list(left) == list(right)
    np.testing.assert_array_equal(left["row_ids"], right["row_ids"])
    assert left["row_ids"].dtype == right["row_ids"].dtype
    assert left["row_id_to_position"] == right["row_id_to_position"]
    np.testing.assert_array_equal(left["row_class_ids"], right["row_class_ids"])
    assert left["row_class_ids"].dtype == right["row_class_ids"].dtype
    np.testing.assert_array_equal(left["class_total_sizes"], right["class_total_sizes"])
    assert left["class_total_sizes"].dtype == right["class_total_sizes"].dtype
    assert len(left["class_member_positions"]) == len(right["class_member_positions"])
    for a, b in zip(left["class_member_positions"], right["class_member_positions"]):
        np.testing.assert_array_equal(a, b)
    assert repr(left["class_keys"]) == repr(right["class_keys"])  # repr: NaN keys never compare equal
    assert [type(value) for key in left["class_keys"] for value in key] == [
        type(value) for key in right["class_keys"] for value in key]


def test_unique_rows_equal_numpy_unique_axis0():
    from prototype.enumeration_horizontal import _unique_rows

    generator = np.random.default_rng(4)
    for rows, widths in ((1, (3,)), (500, (2, 3, 4)), (3000, (5, 1, 70, 9, 300, 300, 300, 40, 12, 12, 12, 12)),
                         (2000, (2 ** 20, 2 ** 20, 2 ** 20, 2 ** 20)), (800, (7,) * 30)):
        values = np.stack([generator.integers(-3, width, size=rows) for width in widths], axis=1)
        values[rows // 2:] = values[: rows - rows // 2]  # repeated rows
        _unique, expected_first, expected_inverse = np.unique(
            values, axis=0, return_index=True, return_inverse=True)
        first, inverse = _unique_rows(values)
        np.testing.assert_array_equal(first, expected_first)
        np.testing.assert_array_equal(inverse, np.asarray(expected_inverse).reshape(-1))


def test_numpy_class_index_equals_pandas(income):
    cache, qi, levels, train, _val = income
    for level in levels:
        ranks = cache.generalization(level).privacy_frame(train, qi)
        for columns in (qi, qi[:1], qi[2:4]):
            _assert_same_position_index(
                build_retention_class_position_index(ranks, selected_attributes=columns, sort_keys=False),
                build_retention_class_position_index_numpy(ranks, selected_attributes=columns))
        # The refinement path's variant: no keys, shared row tables, the rest identical.
        light = build_retention_class_position_index_numpy(ranks, selected_attributes=qi, with_class_keys=False,
                                                           share_row_tables=True)
        full = build_retention_class_position_index_numpy(ranks, selected_attributes=qi)
        assert light["class_keys"] is None
        _assert_same_position_index({**light, "class_keys": full["class_keys"]}, full)
        again = build_retention_class_position_index_numpy(ranks, selected_attributes=qi, share_row_tables=True)
        assert again["row_id_to_position"] is light["row_id_to_position"]
    generator = np.random.default_rng(1)
    frame = pd.DataFrame(generator.integers(0, 3, size=(500, 3)), columns=["a", "b", "c"],
                         index=[f"r{i}" for i in generator.permutation(500)])
    _assert_same_position_index(build_retention_class_position_index(frame, sort_keys=False),
                                build_retention_class_position_index_numpy(frame))
    # Float columns with NaN go to the pandas version.
    floats = frame.astype(float)
    floats.iloc[::9, 1] = np.nan
    _assert_same_position_index(build_retention_class_position_index(floats, sort_keys=False),
                                build_retention_class_position_index_numpy(floats))


def test_code_groups_equal_pandas_retention_classes(income):
    from prototype.enumeration_horizontal import (
        build_retention_class_groups, build_retention_class_row_groups_from_codes)

    cache, qi, levels, train, _val = income
    generator = np.random.default_rng(3)
    for level in levels:
        swap = pipeline_module._build_swap_encode_cache(cache.generalization(level), train, qi)
        for rows in (list(train.index), list(train.index[np.sort(generator.permutation(len(train))[:400])]),
                     list(train.index[generator.permutation(len(train))[:250]])):
            expected = [(key, list(group.index)) for key, group in build_retention_class_groups(
                swap.encoded.loc[rows], selected_attributes=qi).items()]
            got = build_retention_class_row_groups_from_codes(swap.encoded, swap.codes, rows, qi)
            assert got is not None and len(got) == len(expected)
            for (key, ids), (expected_key, expected_ids) in zip(got, expected):
                assert repr(key) == repr(expected_key) and ids == expected_ids
                assert [type(value) for value in key] == [type(value) for value in expected_key]
    # Codes that do not match the encoding (two classes with one key) go to pandas.
    swap = pipeline_module._build_swap_encode_cache(cache.generalization(levels[1]), train, qi)
    split_codes = swap.codes.copy()
    split_codes.iloc[::2, 0] += 1000
    assert build_retention_class_row_groups_from_codes(swap.encoded, split_codes, list(train.index), qi) is None


def _run(tmp_path, name, *, exact_speedups, device, dtype, max_iterations=4, qi_attributes=QI_SUBSET):
    from prototype.model_factory import build_model_factory

    directory = write_income_like_csvs(tmp_path / "data", rows=700, seed=5)
    loader = dataloader.ACSIncomeDataLoader(
        data_dir=directory, state="CA", year=2014, qi_attributes=qi_attributes)
    spec = {"family": "torch_logistic", "max_iter": 100}
    factory = build_model_factory(spec, device=device, dtype=dtype, random_state=42)
    result = pipeline_module.run_trim_pipeline(
        loader, generalization_tree_path=INCOME_TREE, model_factory=factory,
        proxy_model_factory=factory,
        estimator_model_factory=build_model_factory(
            spec, device=device, dtype=dtype, random_state=42, role="estimator"),
        results_dir=tmp_path / name, device=device, dtype=dtype,
        privacy_cost_floor=math.log1p(0.1), stop_on_utility=False,
        record_iteration_validation_metrics=True, record_iteration_test_metrics=True,
        max_iterations=max_iterations, initial_sample_fraction=0.1, random_state=42, rank_top_k=3,
        refinement_eviction_ratios=[4], eviction_shortlist="union", eviction_scoring="published_check",
        max_privacy_step=4, stall_rule="widen", stall_widen_top_k=5, exact_speedups=exact_speedups,
    )
    return result.run_dir


def _lga_noise(reference, candidate):
    """Candidate types of action-log records whose LGA rank scores differ.

    On CUDA, cal_lga_batch sums retention-class gradients with index_add_
    (atomic adds in varying order), so these scores of retention-class
    candidates can differ in the last bits between two runs of the same code.
    """
    from experiments.perf.compare_runs import _action_log

    types = set()
    for left, right in zip(_action_log(reference), _action_log(candidate)):
        if any(left.get(key) != right.get(key) for key in ("lga_score", "rank_score")):
            types.add(left.get("candidate_type"))
    return types


@pytest.mark.parametrize("device,dtype", [("cpu", "float64")] + ([("cuda", "float32")] if CUDA else []))
@pytest.mark.parametrize("qi_attributes", [QI_SUBSET, None], ids=["non_qi_features", "all_qi"])
def test_refine_and_evict_run_identical_with_exact_speedups(tmp_path, device, dtype, qi_attributes):
    # QI_SUBSET leaves non-QI features (Diabetes, Bank Marketing: pandas retention classes);
    # None makes every feature a QI (Income: class-id retention classes).
    reference = _run(tmp_path, "reference", exact_speedups=False, device=device, dtype=dtype,
                     qi_attributes=qi_attributes)
    fast = _run(tmp_path, "fast", exact_speedups=True, device=device, dtype=dtype,
                qi_attributes=qi_attributes)
    if device == "cpu":
        assert compare_runs(reference, fast, ignore_keys=("exact_speedups",)) == []
        return
    # Everything but the retention-class LGA scores must match bit for bit; those
    # differ between two runs of the reference code too (see _lga_noise).
    assert compare_runs(reference, fast, ignore_keys=("exact_speedups", "lga_score", "rank_score")) == []
    assert _lga_noise(reference, fast) <= {"retention_class"}


def test_exact_speedups_is_validated(tmp_path):
    kappa = {"privacy_cost_floor": math.log1p(0.1)}
    with pytest.raises(TypeError, match="exact_speedups must be bool"):
        pipeline_module.run_trim_pipeline(None, None, exact_speedups="yes", **kappa)
    with pytest.raises(ValueError, match="requires selection_cache"):
        pipeline_module.run_trim_pipeline(None, None, exact_speedups=True, selection_cache=False, **kappa)


# --- CUDA-graph L-BFGS --------------------------------------------------------

requires_cuda = pytest.mark.skipif(not CUDA, reason="the graph L-BFGS runs on CUDA only")


@requires_cuda
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
def test_fma_kernel_equals_add_with_tensor_alpha(dtype):
    from prototype.fast_lbfgs import _state, graph_lbfgs_class

    assert graph_lbfgs_class() is not None
    fma = _state["fma"]
    generator = torch.Generator(device="cuda").manual_seed(0)
    tiny = torch.finfo(dtype).tiny
    for round_index in range(60):
        # Every third round works near the smallest normal number, so products and
        # sums include subnormals (a flush-to-zero kernel would differ there).
        scale = tiny * 10 if round_index % 3 == 0 else 1.0
        q = torch.randn(4099, device="cuda", dtype=dtype, generator=generator) * scale * 10
        x = torch.randn(4099, device="cuda", dtype=dtype, generator=generator)
        a = torch.randn((), device="cuda", dtype=dtype, generator=generator) * scale
        expected = q.clone().add_(x, alpha=-a)
        assert torch.equal(fma(q, x, a.neg()), expected)
        b = torch.randn((), device="cuda", dtype=dtype, generator=generator)
        assert torch.equal(fma(q, x, a - b), q.clone().add_(x, alpha=a - b))


@requires_cuda
def test_fused_float32_updates_equal_the_separate_kernels():
    from prototype.fast_lbfgs import _state, graph_lbfgs_class

    assert graph_lbfgs_class() is not None
    update_q, update_r = _state["fused"]
    generator = torch.Generator(device="cuda").manual_seed(1)
    # Products stay finite; scale 1e-20 gives subnormal products (below 1.2e-38).
    for scale in (1e-20, 1e-15, 1e-3, 1.0, 1e3, 1e15):
        for _ in range(20):
            q = torch.randn(4099, device="cuda", generator=generator) * scale ** 2
            x = torch.randn(4099, device="cuda", generator=generator)
            dot_q, dot_r, rho = (torch.randn((), device="cuda", generator=generator) * scale
                                 for _ in range(3))
            al, be = dot_q * rho, dot_r * rho
            assert torch.equal(update_q(q, x, dot_q, rho), q.clone().add_(x, alpha=-al))
            assert torch.equal(update_r(q, x, dot_q, dot_r, rho), q.clone().add_(x, alpha=al - be))


def _logistic_problem(rows, columns, seed, dtype):
    generator = torch.Generator(device="cpu").manual_seed(seed)
    X = (torch.rand((rows, columns), generator=generator) < 0.05).to(dtype)
    X[:, :3] = torch.randn((rows, 3), generator=generator, dtype=dtype)
    y = (torch.rand(rows, generator=generator) < torch.sigmoid(X[:, 0] - X[:, 5])).to(torch.int64)
    return X.cuda(), y.cuda()


@requires_cuda
@pytest.mark.parametrize("dtype", [torch.float32, torch.float64])
@pytest.mark.parametrize("history,track_path", [(100, False), (4, False), (7, True)])
@pytest.mark.parametrize("fused", [True, False])
def test_graph_lbfgs_fits_bitwise_equal(dtype, history, track_path, fused, monkeypatch):
    from prototype import fast_lbfgs
    from prototype.gpu_logistic import TorchLogisticRegression

    # Fresh workspaces, with or without the fused float32 updates.
    monkeypatch.setattr(fast_lbfgs, "_workspaces", {})
    monkeypatch.setitem(fast_lbfgs._state, "use_fused", fused)

    for seed, (rows, columns) in enumerate(((3000, 301), (1200, 1001), (5000, 64))):
        X, y = _logistic_problem(rows, columns, seed, dtype)
        fitted = []
        for graph in (False, True, True):  # twice: the second run reuses the captured graphs
            model = TorchLogisticRegression(
                max_iter=60, device="cuda", dtype=dtype, allow_cpu_fallback=False,
                lbfgs_history_size=history, track_path=track_path, lbfgs_graph=graph)
            model.fit(X, y)
            fitted.append(model)
        reference = fitted[0]
        for model in fitted[1:]:
            assert int(model.n_iter_[0]) == int(reference.n_iter_[0])
            assert torch.equal(model.coef_tensor_, reference.coef_tensor_)
            assert torch.equal(model.intercept_tensor_, reference.intercept_tensor_)
            if track_path:
                assert torch.equal(model.path_thetas_, reference.path_thetas_)


@requires_cuda
def test_graph_lbfgs_is_used_only_where_it_applies():
    from prototype.fast_lbfgs import graph_lbfgs_class
    from prototype.gpu_logistic import TorchLogisticRegression

    cuda_model = TorchLogisticRegression(device="cuda", dtype=torch.float32, lbfgs_graph=True)
    cpu_model = TorchLogisticRegression(device="cpu", dtype=torch.float32, lbfgs_graph=True)
    plain = TorchLogisticRegression(device="cuda", dtype=torch.float32)
    assert cuda_model._lbfgs_class(torch.zeros((2, 2), device="cuda")) is graph_lbfgs_class()
    assert cpu_model._lbfgs_class(torch.zeros((2, 2))) is torch.optim.LBFGS
    assert plain._lbfgs_class(torch.zeros((2, 2), device="cuda")) is torch.optim.LBFGS
