"""The selection cache must reproduce the original rules, encodings and groups."""

from __future__ import annotations

import math

import numpy as np
import pandas as pd
import pytest

from experiments.perf.compare_runs import compare_runs
from experiments.perf.synthetic_income import INCOME_TREE, write_income_like_csvs
from prototype import dataloader
from prototype.enumeration_horizontal import (
    build_retention_class_position_index,
    select_encoded_attributes,
)
from prototype.greedy_selection import _load_max_generalization_level
from prototype.selection_cache import SelectionCache


def _load(directory):
    loader = dataloader.ACSIncomeDataLoader(data_dir=directory, state="CA", year=2014)
    X, _y = loader.load()
    base = dataloader.load_generalization_rules_from_file(
        INCOME_TREE, loader, {attribute: 0 for attribute in loader.feature_columns})
    return loader, X, base


@pytest.fixture(scope="module")
def income(tmp_path_factory):
    loader, X, base = _load(write_income_like_csvs(
        tmp_path_factory.mktemp("income"), rows=1500, seed=3))
    train, val = X.iloc[:1000], X.iloc[1000:]
    qi = tuple(loader.qi_attributes)
    cache = SelectionCache(base, loader, [train, val], qi)
    heights = _load_max_generalization_level(INCOME_TREE, qi)
    generator = np.random.default_rng(7)
    levels = [{attribute: 0 for attribute in qi}, dict(heights)] + [
        {attribute: int(generator.integers(0, heights[attribute] + 1)) for attribute in qi}
        for _ in range(6)
    ]
    subsets = {
        "train": train, "validation": val,
        "shuffled_third": train.loc[generator.permutation(train.index)[:333]],
        "single_row": val.iloc[[5]],
    }
    return loader, base, cache, qi, levels, subsets, train


def test_rules_match_full_rebuild(income):
    _loader, base, cache, _qi, levels, _subsets, _train = income
    for level in levels:
        cached, original = cache.generalization(level), base.change_level(level)
        assert cached.generalization_level == original.generalization_level
        assert cached.generalization_rules == original.generalization_rules
        assert cached.category_maps == original.category_maps
        assert cached.change_level(level).generalization_rules == original.generalization_rules


def test_encodings_match_exactly(income):
    _loader, base, cache, _qi, levels, subsets, _train = income
    for level in levels:
        cached, original = cache.generalization(level), base.change_level(level)
        for frame in subsets.values():
            pd.testing.assert_frame_equal(cached.encode(frame), original.encode(frame),
                                          check_exact=True)
            pd.testing.assert_frame_equal(cached.encode_xgboost_model_input(frame),
                                          original.encode_xgboost_model_input(frame),
                                          check_exact=True)
            np.testing.assert_array_equal(
                np.asarray(cached.encode_xgboost_leaf_space(frame).todense()),
                np.asarray(original.encode_xgboost_leaf_space(frame).todense()))


def test_encode_array_matches_encoded_frame_exactly(income):
    _loader, base, cache, _qi, levels, subsets, _train = income
    for level in levels:
        cached, original = cache.generalization(level), base.change_level(level)
        for frame in subsets.values():
            for dtype in (np.float32, np.float64):
                array = cached.encode_array(frame, dtype)
                assert array is not None and array.dtype == dtype
                expected = np.asarray(original.encode(frame), dtype=dtype)
                assert array.shape == expected.shape
                assert np.array_equal(array, expected)
                assert array.tobytes() == expected.tobytes()
    assert cache.generalization(levels[0]).encode_array(subsets["train"].iloc[:0], np.float32) is None


def _assert_same_groups(dense, ranks):
    columns_dense, columns_ranks = list(dense.columns), list(ranks.columns)
    pd.testing.assert_series_equal(
        dense.groupby(columns_dense, sort=False, dropna=False, observed=True).transform("size"),
        ranks.groupby(columns_ranks, sort=False, dropna=False, observed=True).transform("size"),
        check_names=False)
    np.testing.assert_array_equal(dense.value_counts(sort=False).to_numpy(),
                                  ranks.value_counts(sort=False).to_numpy())
    assert dense.value_counts(sort=False).min() == ranks.value_counts(sort=False).min()
    assert list(dense.drop_duplicates().index) == list(ranks.drop_duplicates().index)
    left = build_retention_class_position_index(dense, sort_keys=False)
    right = build_retention_class_position_index(ranks, sort_keys=False)
    np.testing.assert_array_equal(left["row_class_ids"], right["row_class_ids"])
    np.testing.assert_array_equal(left["class_total_sizes"], right["class_total_sizes"])
    for a, b in zip(left["class_member_positions"], right["class_member_positions"]):
        np.testing.assert_array_equal(a, b)


def test_rank_columns_group_like_encoded_qis(income):
    _loader, base, cache, qi, levels, subsets, train = income
    for level in levels:
        cached, original = cache.generalization(level), base.change_level(level)
        for frame in subsets.values():
            dense = select_encoded_attributes(original.encode(frame), qi)
            ranks = cached.privacy_frame(frame, qi)
            assert ranks is not None and list(ranks.index) == list(dense.index)
            _assert_same_groups(dense, ranks)
        # Routing: the same accepted groups match the same validation rows.
        accepted = train.iloc[::3]
        dense_groups = select_encoded_attributes(original.encode(accepted), qi).drop_duplicates()
        rank_groups = cached.privacy_frame(accepted, qi).drop_duplicates()
        probe = subsets["validation"]
        dense_probe = select_encoded_attributes(original.encode(probe), qi)
        rank_probe = cached.privacy_frame(probe, qi)
        np.testing.assert_array_equal(
            pd.MultiIndex.from_frame(dense_probe).isin(pd.MultiIndex.from_frame(dense_groups)),
            pd.MultiIndex.from_frame(rank_probe).isin(pd.MultiIndex.from_frame(rank_groups)))
    # A release concatenates rows encoded at different snapshots.
    pairs = list(zip(levels[:4], levels[1:5]))
    for older, newer in pairs:
        halves = (train.iloc[:500], train.iloc[500:])
        dense = pd.concat([
            select_encoded_attributes(base.change_level(newer).encode(halves[0]), qi),
            select_encoded_attributes(base.change_level(older).encode(halves[1]), qi)])
        ranks = pd.concat([
            cache.generalization(newer).privacy_frame(halves[0], qi),
            cache.generalization(older).privacy_frame(halves[1], qi)])
        _assert_same_groups(dense, ranks)


def test_missing_categorical_values_keep_ranks_exact(tmp_path):
    directory = write_income_like_csvs(tmp_path, rows=600, seed=5)
    path = directory / "ACSIncome_CA_2014_X.csv"
    frame = pd.read_csv(path)
    frame.loc[::7, "COW"] = np.nan
    frame.loc[::5, "RAC1P"] = np.nan
    frame.to_csv(path, index=False)
    loader, X, base = _load(directory)
    qi = tuple(loader.qi_attributes)
    cache = SelectionCache(base, loader, [X], qi)
    assert cache.privacy_enabled
    heights = _load_max_generalization_level(INCOME_TREE, qi)
    for level in ({attribute: 0 for attribute in qi}, dict(heights),
                  {**dict(heights), "COW": 0, "RAC1P": 1}):
        cached, original = cache.generalization(level), base.change_level(level)
        pd.testing.assert_frame_equal(cached.encode(X), original.encode(X), check_exact=True)
        array = cached.encode_array(X, np.float32)
        assert array is not None
        assert array.tobytes() == np.asarray(original.encode(X), dtype=np.float32).tobytes()
        _assert_same_groups(select_encoded_attributes(original.encode(X), qi),
                            cached.privacy_frame(X, qi))


def test_missing_numeric_values_disable_ranks_but_encode_exactly(tmp_path):
    directory = write_income_like_csvs(tmp_path, rows=600, seed=5)
    path = directory / "ACSIncome_CA_2014_X.csv"
    frame = pd.read_csv(path)
    frame.loc[::7, "COW"] = np.nan
    frame.loc[::11, "WKHP"] = np.nan
    frame.to_csv(path, index=False)
    loader, X, base = _load(directory)
    qi = tuple(loader.qi_attributes)
    cache = SelectionCache(base, loader, [X], qi)
    assert not cache.privacy_enabled
    heights = _load_max_generalization_level(INCOME_TREE, qi)
    for level in ({attribute: 0 for attribute in qi}, dict(heights)):
        cached, original = cache.generalization(level), base.change_level(level)
        assert cached.privacy_frame(X, qi) is None
        pd.testing.assert_frame_equal(cached.encode(X), original.encode(X), check_exact=True)
        array = cached.encode_array(X, np.float64)
        expected = np.asarray(original.encode(X), dtype=np.float64)
        assert array is None or array.tobytes() == expected.tobytes()


def test_pipeline_outputs_identical_with_and_without_cache(tmp_path):
    from prototype.model_factory import build_model_factory
    from prototype.TRIM_prototype_pipeline import run_trim_pipeline

    directory = write_income_like_csvs(tmp_path / "data", rows=500, seed=11)
    runs = {}
    for enabled in (False, True):
        loader = dataloader.ACSIncomeDataLoader(data_dir=directory, state="CA", year=2014)
        spec = {"family": "torch_logistic", "max_iter": 100}
        factory = build_model_factory(spec, device="cpu", dtype="float64", random_state=42)
        result = run_trim_pipeline(
            loader, generalization_tree_path=INCOME_TREE, model_factory=factory,
            proxy_model_factory=factory,
            estimator_model_factory=build_model_factory(
                spec, device="cpu", dtype="float64", random_state=42, role="estimator"),
            results_dir=tmp_path / f"runs_{enabled}", device="cpu", dtype="float64",
            privacy_cost_floor=math.log1p(0.1), validation_only=True,
            record_iteration_validation_metrics=True, stop_on_utility=False,
            max_iterations=2, initial_sample_fraction=0.1, random_state=42,
            selection_cache=enabled,
        )
        runs[enabled] = result.run_dir
    assert compare_runs(runs[False], runs[True]) == []
