"""The QI inference attacker knows the same fifth of the published records as the reconstruction attacker."""
import numpy as np
import pandas as pd

from experiments.exp2_attacks.attacks import _fold, run_strong_linkage_attack
from prototype.release_artifacts import MaterializedTRIMRelease


def _release(n_train=200, n_test=50, seed=0):
    rng = np.random.default_rng(seed)
    a = rng.integers(0, 4, size=n_train + n_test)
    b = (a + rng.integers(0, 2, size=n_train + n_test)) % 4
    frame = pd.DataFrame({"A=0": (a == 0) * 1.0, "A=1": (a == 1) * 1.0, "A=2": (a == 2) * 1.0, "A=3": (a == 3) * 1.0})
    raw = pd.DataFrame({"A": a, "B": b})
    train_ids = [f"r{i}" for i in range(n_train)]
    test_ids = [f"t{i}" for i in range(n_test)]
    frame.index = raw.index = train_ids + test_ids
    y = pd.Series(np.zeros(n_train + n_test), index=frame.index)
    return MaterializedTRIMRelease(
        published_frame=frame.loc[train_ids], published_y=y.loc[train_ids],
        evaluation_frame=frame.loc[test_ids], evaluation_y=y.loc[test_ids],
        published_raw=raw.loc[train_ids], evaluation_raw=raw.loc[test_ids], evaluation_split="test",
        release={"status": "ok"})


def _config(**fold):
    return {"strategy": "mlp_raw_b", "query_size": 50, "a_attributes": ["A"], "b_attributes": ["B"],
            "model": {"family": "mlp", "hidden_sizes": [4], "epochs": 5, "lr": 0.01, "weight_decay": 0.0}, **fold}


def test_linkage_trains_on_the_reconstruction_fold():
    release = _release()
    result = run_strong_linkage_attack(release, _config(fold_count=5, fold_index=0), random_state=42,
                                       device="cpu", dtype="float32", allow_cpu_fallback=True)
    known = _fold(release.published_frame.index, fold_count=5, fold_index=0, random_state=42)
    assert result["training_row_count"] == len(known) == 40
    assert "fold 0 of 5" in result["training_row_semantics"]


def test_linkage_without_fold_uses_every_published_record():
    release = _release()
    result = run_strong_linkage_attack(release, _config(), random_state=42,
                                       device="cpu", dtype="float32", allow_cpu_fallback=True)
    assert result["training_row_count"] == 200


def test_fold_options_must_come_together():
    import pytest
    with pytest.raises(ValueError):
        run_strong_linkage_attack(_release(), _config(fold_count=5), random_state=42,
                                  device="cpu", dtype="float32", allow_cpu_fallback=True)
