"""Checks of the data-minimization baseline harness on small synthetic data (CPU only).

Run explicitly: python -m pytest -q tests/test_exp1_baselines.py
"""

import csv
import importlib.util
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import yaml

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from experiments.exp1_baselines import entrywise, featsel, fido, pat  # noqa: E402
from experiments.exp1_baselines import run as runner  # noqa: E402
from experiments.exp1_baselines.encoding import ReleaseEncoder  # noqa: E402
from experiments.exp1_baselines.evaluator import DatasetContext, ModelEvaluator  # noqa: E402
from experiments.exp1_baselines.privacy import (  # noqa: E402
    raw_value_codes, original_privacy, release_privacy, released_class_sizes,
)
from experiments.exp1_baselines.release import (  # noqa: E402
    ROOT, DomainColumn, Release, content_sha256, domain_key, load_release, read_json_gz, release_identity,
    release_payload, released_qi_frame, split_hash, write_json_gz,
)
from experiments.exp1_baselines.results import EvaluationStore, write_tables  # noqa: E402
from experiments.exp1_baselines.upstream import verify_upstream_copies  # noqa: E402
from experiments.exp1_baselines.upstream.entrywise import personalized_random_subsampling  # noqa: E402
from experiments.exp1_kanon.hierarchy import HierarchySchema  # noqa: E402
from prototype.dataloader import load_generalization_rules  # noqa: E402
from prototype.release_artifacts import DatasetSplit  # noqa: E402

ROOT_DIR = Path(__file__).resolve().parents[1]
QIS = ("age", "kind", "size")
TREES = {
    "age": {"nodes": [
        {"id": "age.root", "parent": None, "kind": "root", "height_from_leaf": 2},
        {"id": "age.young", "parent": "age.root", "kind": "internal", "height_from_leaf": 1},
        {"id": "age.old", "parent": "age.root", "kind": "internal", "height_from_leaf": 1},
        {"id": "age.0", "value": "0 ~ 9", "parent": "age.young", "kind": "leaf", "height_from_leaf": 0},
        {"id": "age.1", "value": "10 ~ 19", "parent": "age.young", "kind": "leaf", "height_from_leaf": 0},
        {"id": "age.2", "value": "20 ~ 39", "parent": "age.old", "kind": "leaf", "height_from_leaf": 0},
        {"id": "age.3", "value": "40 ~ 59", "parent": "age.old", "kind": "leaf", "height_from_leaf": 0},
    ]},
    "kind": {"nodes": [
        {"id": "kind.root", "parent": None, "kind": "root", "height_from_leaf": 2},
        {"id": "kind.ab", "parent": "kind.root", "kind": "internal", "height_from_leaf": 1},
        {"id": "kind.cd", "parent": "kind.root", "kind": "internal", "height_from_leaf": 1},
        {"id": "kind.a", "value": "a", "parent": "kind.ab", "kind": "leaf", "height_from_leaf": 0},
        {"id": "kind.b", "value": "b", "parent": "kind.ab", "kind": "leaf", "height_from_leaf": 0},
        {"id": "kind.c", "value": "c", "parent": "kind.cd", "kind": "leaf", "height_from_leaf": 0},
        {"id": "kind.d", "value": "d", "parent": "kind.cd", "kind": "leaf", "height_from_leaf": 0},
        {"id": "kind.e", "value": "e", "parent": "kind.root", "kind": "leaf", "height_from_leaf": 0},
    ]},
    "size": {"nodes": [
        {"id": "size.root", "parent": None, "kind": "root", "height_from_leaf": 1},
        *[{"id": f"size.{value}", "value": value, "parent": "size.root", "kind": "leaf", "height_from_leaf": 0}
          for value in range(1, 7)],
    ]},
}
MLP_SPEC = {"family": "mlp", "hidden_sizes": [8], "epochs": 25, "lr": 0.01, "weight_decay": 0.001}
XGB_SPEC = {"family": "xgboost", "n_estimators": 6, "max_depth": 2, "learning_rate": 0.3, "n_jobs": 1}


def make_loader():
    return SimpleNamespace(
        feature_columns=("age", "kind", "aux", "size", "tag"), qi_attributes=QIS,
        numeric_attributes=("age", "aux", "size"), categorical_attributes=("kind", "tag"),
        category_maps={"kind": {"a": 0, "b": 1, "c": 2, "d": 3, "e": 4}, "tag": {"x": 0, "y": 1}},
    )


def make_frame(rng, count, start, kinds=("a", "b", "c", "d", "e")):
    index = pd.RangeIndex(start, start + count)
    X = pd.DataFrame({
        "age": rng.integers(0, 60, count).astype(float), "kind": rng.choice(list(kinds), count),
        "aux": rng.normal(size=count), "size": rng.integers(1, 7, count).astype(float),
        "tag": rng.choice(["x", "y"], count),
    }, index=index)
    signal = 0.06 * X["age"] - 1.5 * (X["kind"] == "a") + 0.8 * X["aux"] + 0.3 * X["size"] - 2.0
    y = pd.Series((signal + rng.logistic(size=count) > 0).astype(int), index=index)
    return X, y


def make_context(n=300, seed=7, dataset="synthetic", train_kinds=("a", "b", "c", "d", "e")):
    rng = np.random.default_rng(seed)
    X_train, y_train = make_frame(rng, n, 1000, train_kinds)
    X_val, y_val = make_frame(rng, n // 2, 5000)
    X_test, y_test = make_frame(rng, n // 2, 9000)
    loader = make_loader()
    generalization = load_generalization_rules(TREES, loader, generalization_level=0)
    split = DatasetSplit(X_train, X_val, X_test, y_train, y_val, y_test)
    ids = [X_train.index.tolist(), X_val.index.tolist(), X_test.index.tolist()]
    return DatasetContext(
        dataset=dataset, seed=seed, task={"pipeline": {"random_state": seed}}, loader=loader, split=split,
        tree_path=Path("synthetic"), tree_sha256="synthetic-tree", generalization=generalization,
        loaded_input_sha256="synthetic-input", training_data_sha256="synthetic-training",
        split_sha256=split_hash(*ids), original=original_privacy(X_train, QIS),
        raw_codes=raw_value_codes(X_train, QIS),
    )


@pytest.fixture(scope="module")
def context():
    return make_context()


@pytest.fixture(scope="module")
def evaluators(context):
    return {
        name: ModelEvaluator(context, model_name=name, model_spec=spec, device="cpu", allow_cpu_fallback=True)
        for name, spec in (("mlp", MLP_SPEC), ("xgboost", XGB_SPEC))
    }


# Privacy counter (rule B) -------------------------------------------------------------
def brute_force_k(frame, positions, columns, qis):
    tokens = []
    for row, position in enumerate(positions):
        token = []
        for qi in qis:
            code = columns[qi].codes[row]
            if code < 0:
                value = frame.iloc[position][qi]
                token.append(("raw", "missing" if pd.isna(value) else repr(value)))
            else:
                token.append(("domain", domain_key(columns[qi].table[code])))
        tokens.append(tuple(token))
    return np.asarray([sum(other == token for other in tokens) for token in tokens])


def random_column(rng, qi, length):
    if qi == "age":
        table = [ROOT, {"kind": "node", "node": "age.young"}, {"kind": "interval", "low": 15, "high": 45}]
    elif qi == "kind":
        table = [ROOT, {"kind": "node", "node": "kind.ab"}, {"kind": "leaves", "values": ["a", "c"]}]
    else:
        table = [ROOT]
    codes = rng.integers(-1, len(table), length)
    return DomainColumn.from_codes(codes, table)


def test_counter_matches_brute_force_with_roots_missing_values_and_removed_rows():
    rng = np.random.default_rng(3)
    frame = pd.DataFrame({
        "age": rng.integers(0, 4, 80).astype(float), "kind": rng.choice(["a", "b", "c"], 80),
        "size": rng.integers(1, 3, 80).astype(float),
    }, index=pd.RangeIndex(500, 580))
    frame.loc[frame.index[::7], "age"] = np.nan
    frame.loc[frame.index[::11], "kind"] = None
    codes = raw_value_codes(frame, QIS)
    for trial in range(12):
        positions = np.sort(rng.choice(len(frame), int(rng.integers(1, len(frame) + 1)), replace=False))
        columns = {qi: random_column(rng, qi, len(positions)) for qi in QIS}
        expected = brute_force_k(frame, positions, columns, QIS)
        assert np.array_equal(released_class_sizes(positions, columns, codes, QIS), expected)
    # Missing values form classes of their own instead of being dropped.
    exact = {qi: DomainColumn.exact(len(frame)) for qi in QIS}
    sizes = released_class_sizes(np.arange(len(frame)), exact, codes, QIS)
    assert np.array_equal(sizes, brute_force_k(frame, np.arange(len(frame)), exact, QIS))
    assert sizes.sum() >= len(frame)


def test_counter_edge_cases_all_roots_and_no_qis(context):
    n = context.training_row_count
    release = featsel.featsel_release(context, ())
    sizes = released_class_sizes(release.positions, release.columns, context.raw_codes, QIS)
    assert np.all(sizes == n)
    assert np.all(released_class_sizes(np.arange(5), {}, {}, ()) == 5)
    with pytest.raises(ValueError):
        released_class_sizes(np.arange(0), {}, {}, ())


def test_tail_uses_minus_infinity_for_unpublished_rows(context):
    order = fido.prefix_order(context.training_row_count, context.seed)
    small = release_privacy(fido.prefix_release(context, order, 2), context.train_ids, context.raw_codes,
                            context.original)
    assert small["tail_risk_p99"] == -math.inf and small["suppressed_row_count"] == context.training_row_count - 2
    full = release_privacy(fido.prefix_release(context, order, context.training_row_count), context.train_ids,
                           context.raw_codes, context.original)
    assert full["min_k"] == context.original["original_leak_k"]
    assert full["tail_risk_p99"] == context.original["original_tail_risk_p99"]


# Identity points ----------------------------------------------------------------------
def test_featsel_full_set_and_fido_full_prefix_reproduce_the_reference(context, evaluators):
    full = featsel.featsel_release(context, QIS)
    privacy = release_privacy(full, context.train_ids, context.raw_codes, context.original)
    assert privacy["min_k"] == context.original["original_leak_k"] and privacy["privacy_delta_h"] == 0.0
    order = fido.prefix_order(context.training_row_count, context.seed)
    whole = fido.prefix_release(context, order, context.training_row_count)
    for evaluator in evaluators.values():
        for release in (full, whole):
            result = evaluator.evaluate(release)
            assert result["validation_delta_u"] == 0.0 and result["test_delta_u"] == 0.0
    empty = featsel.featsel_release(context, ())
    assert release_privacy(empty, context.train_ids, context.raw_codes, context.original)["min_k"] == (
        context.training_row_count
    )


def test_featsel_removed_columns_are_root_for_evaluation_records(context, evaluators):
    kept = ("age", "size")
    release = featsel.featsel_release(context, kept)
    n_val, n_test = len(context.split.X_val_raw), len(context.split.X_test_raw)
    # XGBoost never splits on a column that is constant in training; the MLP reads it.
    with_root = evaluators["mlp"].evaluate(
        release, {"kind": DomainColumn.constant(n_val, ROOT)}, {"kind": DomainColumn.constant(n_test, ROOT)},
    )
    without = evaluators["mlp"].evaluate(release)
    assert with_root["validation_loss"] != without["validation_loss"]


# Encoding -----------------------------------------------------------------------------
def block(encoder, matrix, qi):
    start, width = encoder.blocks[qi]["start"], encoder.blocks[qi]["width"]
    return matrix[:, start:start + width]


@pytest.mark.parametrize("family", ["mlp", "xgboost"])
def test_hierarchy_nodes_encode_like_trim(context, family):
    loader = context.loader
    encoder = ReleaseEncoder(context.generalization, family=family)
    X = context.split.X_train_raw
    for qi, value, node, height in [
        ("kind", "a", "kind.ab", 1), ("kind", "d", "kind.root", 2), ("age", 5.0, "age.young", 1),
        ("age", 45.0, "age.root", 2), ("size", 3.0, "size.root", 1),
    ]:
        rows = X[X[qi] == value].head(3)
        trim = load_generalization_rules(TREES, loader, generalization_level={qi: height})
        expected = (trim.encode(rows).to_numpy(dtype=np.float32) if family == "mlp"
                    else trim.encode_xgboost_leaf_space(rows).toarray().astype(np.float32))
        level0 = encoder.level0(rows)
        domain = ROOT if node.endswith(".root") else {"kind": "node", "node": node}
        released = encoder.apply(level0, {qi: DomainColumn.constant(len(rows), domain)})
        assert np.array_equal(released, expected), (qi, node)
        assert np.array_equal(encoder.apply(level0, {qi: DomainColumn.exact(len(rows))}), level0)


def test_leaf_sets_and_intervals_use_member_leaves_and_smallest_node(context):
    mlp = ReleaseEncoder(context.generalization, family="mlp")
    xgb = ReleaseEncoder(context.generalization, family="xgboost")
    categories = context.loader.category_maps["kind"]
    vector = mlp.representation("kind", {"kind": "leaves", "values": ["a", "c"]})
    expected = np.zeros(5, dtype=np.float32)
    expected[[categories["a"], categories["c"]]] = 0.5
    assert np.array_equal(vector, expected)
    assert xgb.representation("kind", {"kind": "leaves", "values": ["a", "c"]})[-1] == 2
    assert xgb.representation("kind", {"kind": "leaves", "values": ["a", "b"]})[-1] == 1
    assert xgb.representation("kind", {"kind": "leaves", "values": ["e"]})[-1] == 0
    # [5, 15) overlaps the leaves 0-9 and 10-19, whose integers average 9.5.
    assert mlp.representation("age", {"kind": "interval", "low": 5, "high": 15})[0] == np.float32(9.5)
    young = xgb.representation("age", {"kind": "interval", "low": 5, "high": 15})
    assert np.array_equal(young, np.asarray([0.5, 0.5, 0, 0, 1], dtype=np.float32))
    wide = xgb.representation("age", {"kind": "interval", "low": 15, "high": 25})
    assert wide[-1] == 2 and mlp.representation("age", {"kind": "interval", "low": 15, "high": 25})[0] == 24.5
    with pytest.raises(ValueError):
        xgb.representation("kind", {"kind": "leaves", "values": ["z"]})


def test_mask_columns_change_only_suppressed_cells(context):
    encoder = ReleaseEncoder(context.generalization, family="xgboost")
    level0 = encoder.level0(context.split.X_train_raw)
    mask = np.zeros(len(level0), dtype=bool)
    mask[::3] = True
    released = encoder.apply(level0, {"kind": DomainColumn.from_mask(mask, ROOT)})
    assert np.array_equal(released[~mask], level0[~mask])
    assert np.all(block(encoder, released[mask], "kind") == encoder.representation("kind", ROOT))


def test_identical_releases_share_content_and_evaluate_identically(context, evaluators):
    scores = entrywise.score_matrix(context.split.X_train_raw, QIS, context.loader.numeric_attributes)
    config = entrywise.configurations(len(QIS))[3]
    first = entrywise.entrywise_release(context, scores, config)
    renamed = Release("Other", first.dataset, first.seed, {"different": True}, first.qi_attributes,
                      first.training_row_count, first.positions, first.columns)
    n_val = len(context.split.X_val_raw)
    assert content_sha256(first) == content_sha256(renamed) == content_sha256(
        first, {qi: DomainColumn.exact(n_val) for qi in QIS})
    assert content_sha256(first) != content_sha256(first, {"kind": DomainColumn.constant(n_val, ROOT)})
    changed = dict(first.columns)
    changed["size"] = DomainColumn.constant(first.row_count, ROOT)
    assert content_sha256(first) != content_sha256(Release(
        first.method, first.dataset, first.seed, first.parameters, first.qi_attributes, first.training_row_count,
        first.positions, changed))
    # The runner reuses losses of identical content; that relies on deterministic evaluation.
    for evaluator in evaluators.values():
        a, b = evaluator.evaluate(first), evaluator.evaluate(renamed)
        assert (a["validation_loss"], a["test_loss"]) == (b["validation_loss"], b["test_loss"])


# Storage ------------------------------------------------------------------------------
def test_release_storage_round_trip(tmp_path, context):
    rng = np.random.default_rng(11)
    positions = np.sort(rng.choice(context.training_row_count, 120, replace=False))
    columns = {
        "age": DomainColumn.from_codes(rng.integers(-1, 3, 120), [
            ROOT, {"kind": "node", "node": "age.old"}, {"kind": "interval", "low": None, "high": 12.5}]),
        "kind": DomainColumn.from_mask(rng.random(120) < 0.4, ROOT),
        "size": DomainColumn.exact(120),
    }
    release = Release("Test", context.dataset, context.seed, {"note": "round trip"}, QIS,
                      context.training_row_count, positions, columns)
    identity = release_identity(release, context.hashes("code"))
    split_path = tmp_path / "split.json.gz"
    write_json_gz(split_path, context.split_payload())
    release_path = tmp_path / "release.json.gz"
    write_json_gz(release_path, release_payload(release, identity, context.train_ids.tolist()))
    loaded, payload, split = load_release(release_path, split_path)
    assert loaded.equals(release) and payload["columns"]["kind"]["kind"] == "mask"
    assert payload["columns"]["age"]["kind"] == "codes" and payload["columns"]["size"]["kind"] == "exact"
    frame = released_qi_frame(loaded, context.split.X_train_raw)
    assert list(frame.index) == [context.train_ids[p] for p in positions]
    assert set(frame["kind"][columns["kind"].codes == 0]) == {"*"}
    constant = featsel.featsel_release(context, ("age",))
    payload = release_payload(constant, release_identity(constant, context.hashes("code")), context.train_ids.tolist())
    assert payload["published"] == {"kind": "all"} and payload["columns"]["kind"] == {"kind": "constant", "domain": ROOT}


# Methods ------------------------------------------------------------------------------
def test_featsel_enumeration_counts_and_order():
    subsets = featsel.enumerate_kept_sets(QIS, mode="all")
    assert len(subsets) == 8 and subsets[0] == QIS and subsets[-1] == ()
    assert len(featsel.enumerate_kept_sets(range(6), mode="bounded", m=2)) == 44
    assert len(featsel.enumerate_kept_sets(range(19), mode="bounded", m=3)) == 2320
    assert len(featsel.enumerate_kept_sets(range(18), mode="bounded", m=2)) == 344
    assert len(featsel.enumerate_kept_sets(range(10), mode="all")) == 1024


def test_entrywise_masks_follow_upstream(context):
    scores = entrywise.score_matrix(context.split.X_train_raw, QIS, context.loader.numeric_attributes)
    cells = scores.size
    for fraction in entrywise.fraction_grid(len(QIS)):
        base = entrywise.suppression_mask(scores, fraction=fraction, adjustment="none", mult=None, seed=5)
        assert base.sum() == cells - int(fraction * cells)
        upstream, _ = personalized_random_subsampling(scores, None, fraction, seed=5)
        assert np.array_equal(base, np.isnan(upstream))
        for adjustment in ("reid", "recon"):
            adjusted = entrywise.suppression_mask(scores, fraction=fraction, adjustment=adjustment, mult=10.0, seed=5)
            assert adjusted.sum() == int((1 - fraction) * cells)
    strong = entrywise.suppression_mask(scores, fraction=1 / 3, adjustment="reid", mult=10.0, seed=5)
    # reid scores columns by their number of distinct values: age (60) >> size (6) > kind (5).
    # With mult 10, age is removed first; for size and kind the -Bu term dominates their
    # small score difference, so base-suppressed size cells go before base-suppressed kind cells.
    assert strong[:, 0].all() and strong[:, 2].sum() > strong[:, 1].sum() > 0
    configs = entrywise.configurations(7)
    assert len(configs) == 42 and len({entrywise.point_label(c) for c in configs}) == 42
    assert not np.array_equal(
        entrywise.suppression_mask(scores, fraction=0.5, adjustment="none", mult=None, seed=5),
        entrywise.suppression_mask(scores, fraction=0.5, adjustment="none", mult=None, seed=6),
    )


def test_fido_stop_sizes_are_monotone_and_capped():
    sizes = fido.grid_sizes(20000, start_fraction=0.005, end_fraction=1.0, points=16)
    assert sizes[0] == 100 and sizes[-1] == 20000 and len(sizes) == 16
    losses = [0.3 + 3.0 * size ** -0.5 for size in sizes]
    model = fido.fit_curve(sizes, losses)
    reference = losses[-1]
    stops = fido.stop_sizes(model, [reference + epsilon for epsilon in (0.005, 0.01, 0.05, 0.1)],
                            smallest=sizes[0], largest=sizes[-1])
    found = [stop["size"] for stop in stops]
    assert found == sorted(found, reverse=True) and all(stop["bound_reached"] for stop in stops)
    for stop in stops:
        assert stop["forecast_validation_loss"] <= stop["bound"]
        if stop["size"] > sizes[0]:
            assert float(model.pred(stop["size"] - 1)) > stop["bound"]
    unreachable = fido.stop_sizes(model, [0.0], smallest=sizes[0], largest=sizes[-1])[0]
    assert unreachable["size"] == 20000 and not unreachable["bound_reached"]


def pat_payload(context, **overrides):
    payload = {
        "schema_version": pat.PAT_SCHEMA, "dataset": context.dataset, "seed": context.seed,
        "split_sha256": context.split_sha256, "parameters": {"alpha": 0.5, "max_leaf_nodes": 50},
        "buckets": {
            "age": {"type": "numeric", "buckets": [[None, 15], [15, None]]},
            "kind": {"type": "categorical", "buckets": [["a", "c"], ["b", "d", "e"]]},
            "size": {"type": "numeric", "buckets": [[None, None]]},
        },
    }
    payload.update(overrides)
    return payload


def test_pat_bucketization_release_and_evaluation_mapping():
    context = make_context(train_kinds=("a", "b", "c", "d"))
    schema = HierarchySchema(context.generalization)
    bucketization = pat.PatBucketization(pat_payload(context), context, schema)
    release = bucketization.release
    assert release.publishes_all_rows and release.columns["size"].table == ({"kind": "root"},)
    young = context.split.X_train_raw["age"].to_numpy() < 15
    assert np.array_equal(release.columns["age"].codes == 0, young)
    evaluation = bucketization.evaluation_columns(context.split.X_val_raw)
    unseen = context.split.X_val_raw["kind"].to_numpy() == "e"
    assert unseen.any()
    kind = evaluation["kind"]
    assert all(kind.table[code] == ROOT for code in kind.codes[unseen])
    assert not any(kind.table[code] == ROOT for code in kind.codes[~unseen])
    assert bucketization.point_label == "alpha0.5_L50"
    for broken in (
        {"split_sha256": "other"},
        {"buckets": {**pat_payload(context)["buckets"], "kind": {"type": "categorical", "buckets": [["a"], ["a", "b"]]}}},
        {"buckets": {**pat_payload(context)["buckets"], "kind": {"type": "categorical", "buckets": [["a", "b"]]}}},
        {"buckets": {"age": pat_payload(context)["buckets"]["age"]}},
        {"parameters": {"alpha": 0.5}},
    ):
        with pytest.raises(ValueError):
            pat.PatBucketization(pat_payload(context, **broken), context, schema)


def test_pat_identity_payloads():
    context = make_context(train_kinds=("a", "b", "c", "d"))
    schema = HierarchySchema(context.generalization)
    single = pat.PatBucketization(pat.single_bucket_payload(context, schema), context, schema)
    assert all(single.release.columns[qi].table == (ROOT,) for qi in QIS)
    privacy = release_privacy(single.release, context.train_ids, context.raw_codes, context.original)
    assert privacy["min_k"] == context.training_row_count
    identity = pat.PatBucketization(pat.identity_payload(context, schema), context, schema)
    privacy = release_privacy(identity.release, context.train_ids, context.raw_codes, context.original)
    assert privacy["min_k"] == context.original["original_leak_k"]
    assert privacy["released_class_count"] == len(context.split.X_train_raw[list(QIS)].drop_duplicates())
    X_val = context.split.X_val_raw
    for family in ("mlp", "xgboost"):
        encoder = ReleaseEncoder(context.generalization, family=family)
        reference = encoder.level0(context.split.X_train_raw)
        assert np.array_equal(encoder.apply(reference, identity.release.columns), reference)
        reference = encoder.level0(X_val)
        differs = np.any(encoder.apply(reference, identity.evaluation_columns(X_val)) != reference, axis=1)
        # Only records with the category unseen in training ('e', released as ROOT) differ.
        assert differs.any() and np.array_equal(differs, X_val["kind"].to_numpy() == "e")


def load_pat_script(name):
    spec = importlib.util.spec_from_file_location(
        f"pat_script_{name}", ROOT_DIR / "scripts" / "pat" / f"{name}.py",
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def prepared_like_pat(fit, arrays, metadata):
    """What pat_fit.prepare returns, built without PAT's environment (MinMax scaling, codes 1..k)."""
    prepared = {}
    for entry in metadata["qis"]:
        column = arrays[entry["array"]]
        if entry["type"] == "numeric":
            scaled = (column - column.min()) / (column.max() - column.min())
            prepared[entry["name"]] = {"type": "numeric", "raw": column, "scaled32": scaled.astype(np.float32)}
        else:
            order = sorted(range(len(entry["categories"])), key=lambda i: fit.sort_key(entry["categories"][i]))
            observed = [category for category in order if category in set(column.tolist())]
            code = {category: position + 1 for position, category in enumerate(observed)}
            prepared[entry["name"]] = {
                "type": "categorical", "codes": np.asarray([code[c] for c in column.tolist()]),
                "code_categories": observed, "category_leaves": entry["category_leaves"],
                "all_leaves": entry["all_leaves"], "category": column,
            }
    return prepared


def test_pat_bridge_pregroups_and_converts_pat_buckets(monkeypatch):
    bridge, fit = load_pat_script("pat_bridge"), load_pat_script("pat_fit")
    context = make_context(train_kinds=("a", "b", "c", "e"))
    schema = HierarchySchema(context.generalization)
    monkeypatch.setattr(bridge, "PAT_CATEGORY_LIMIT", 3)
    monkeypatch.setattr(bridge, "PREGROUPED", {"synthetic": ("kind",)})
    arrays, metadata = bridge.export_inputs(context)
    kind = next(entry for entry in metadata["qis"] if entry["name"] == "kind")
    # Four leaves in training exceed the limit; level 1 has three groups ('e' sits under the root).
    assert kind["pregroup"]["level"] == 1 and kind["pregroup"]["distinct_in_training_by_level"] == {"0": 4, "1": 3}
    assert kind["categories"] == ["kind.ab", "kind.cd", "kind.e"]
    assert kind["category_leaves"] == [["a", "b"], ["c", "d"], ["e"]]
    prepared = prepared_like_pat(fit, arrays, metadata)
    age = prepared["age"]
    scale = lambda value: (value - age["raw"].min()) / (age["raw"].max() - age["raw"].min())  # noqa: E731
    # An empty bucket between 14.5 and 14.6, and a border exactly at the scaled value of 30.
    pat_buckets = {
        "age": {"size": 4, "borders": [scale(14.5), scale(14.6), float(np.float32(scale(30.0)))]},
        "kind": {"size": 2, "mapping": [0, 1, 0]},
        "size": {"size": 1, "borders": []},
    }
    converted, pat_index = fit.convert(pat_buckets, prepared)
    assert len(converted["age"]["buckets"]) == 3 and converted["age"]["buckets"][-1][0] <= 30
    assert converted["kind"]["buckets"] == [["a", "b", "e"], ["c", "d"]]
    assert converted["size"]["buckets"] == [[None, None]]
    payload = {"schema_version": pat.PAT_SCHEMA, "dataset": context.dataset, "seed": context.seed,
               "split_sha256": context.split_sha256, "parameters": {"alpha": 0.5, "max_leaf_nodes": 4},
               "buckets": converted}
    bucketization = pat.PatBucketization(payload, context, schema)
    release = bucketization.release
    for qi in QIS:
        codes = release.columns[qi].codes
        pairs = np.unique(np.stack([pat_index[qi], codes]), axis=1).shape[1]
        assert pairs == len(np.unique(pat_index[qi])) == len(np.unique(codes))
    privacy = release_privacy(release, context.train_ids, context.raw_codes, context.original)
    sizes = fit.class_sizes(pat_index)
    assert (privacy["min_k"], privacy["released_class_count"]) == (sizes.min(), len(sizes))
    # The harness's convention: a leaf unseen in training is ROOT, even inside a pre-grouped category.
    validation = bucketization.evaluation_columns(context.split.X_val_raw)["kind"]
    unseen = context.split.X_val_raw["kind"].to_numpy() == "d"
    assert unseen.any() and all(validation.table[code] == ROOT for code in validation.codes[unseen])
    # A categorical QI that PAT does not split lists every leaf, which the harness releases as ROOT.
    converted, _ = fit.convert({**pat_buckets, "kind": {"size": 1, "mapping": [0, 0, 0]}}, prepared)
    assert converted["kind"]["buckets"] == [["a", "b", "c", "d", "e"]]
    whole = pat.PatBucketization({**payload, "buckets": converted}, context, schema)
    assert whole.release.columns["kind"].table == (ROOT,)


def test_runner_evaluates_pat_files_with_identity_checks(tmp_path, monkeypatch):
    context = make_context(n=240, dataset="bm_halfmonth")
    monkeypatch.setattr(runner, "build_context", lambda task, data_root=None: context)
    schema = HierarchySchema(context.generalization)
    pat_dir = tmp_path / "pat"
    pat_dir.mkdir()
    split_buckets = pat_payload(context)["buckets"]
    single = pat.single_bucket_payload(context, schema)["buckets"]
    for name, (alpha, leaves, buckets) in {
        "bm_halfmonth_seed7_L050_alpha0.50.json": (0.5, 50, split_buckets),
        "bm_halfmonth_seed7_L100_alpha0.50.json": (0.5, 100, split_buckets),
        "bm_halfmonth_seed7_L050_alpha0.95.json": (0.95, 50, single),
    }.items():
        payload = pat_payload(context, parameters={"alpha": alpha, "max_leaf_nodes": leaves}, buckets=buckets)
        (pat_dir / name).write_text(json.dumps(payload))
    (pat_dir / "other_seed.json").write_text(json.dumps({**pat_payload(context), "seed": 8}))
    matrix = {
        "experiment_id": "t", "experiment_kind": "exp1_privacy_utility", "run_prefix": "t",
        "base_task": {"device": "cpu", "dtype": "float32", "allow_cpu_fallback": True,
                      "pipeline": {"val_size": 0.15, "test_size": 0.15, "nrows": None}},
        "axes": [
            {"name": "dataset", "values": [{"label": "bm_halfmonth", "patch": {"dataset": "bm_halfmonth", "data_path": "data/bank_marketing"}}]},
            {"name": "model", "values": [
                {"label": "mlp", "patch": {"model_name": "mlp", "model": {"downstream": MLP_SPEC}}},
                {"label": "xgboost", "patch": {"model_name": "xgboost", "model": {"downstream": XGB_SPEC}}}]},
            {"name": "seed", "values": [{"label": context.seed, "patch": {"pipeline": {"random_state": context.seed}}}]},
        ],
    }
    (tmp_path / "matrix.yaml").write_text(yaml.safe_dump(matrix))
    (tmp_path / "config.yaml").write_text(yaml.safe_dump({
        "experiment_kind": "exp1_baselines", "matrix_config": str(tmp_path / "matrix.yaml"), "methods": ["pat"],
    }))
    results = tmp_path / "results"
    argv = ["--config", str(tmp_path / "config.yaml"), "--dataset", "bm_halfmonth", "--seed", str(context.seed),
            "--device", "cpu", "--results-dir", str(results), "--method", "pat", "--pat-dir", str(pat_dir)]
    assert runner.main(argv) == 0
    manifest = json.loads(next((results / "manifests").glob("*.json")).read_text())
    checks = manifest["identity_checks"]["PAT"]
    assert checks["single_bucket"]["passed"] and checks["single_bucket"]["grid_points"] == ["alpha0.95_L50"]
    identity = checks["no_generalization"]
    assert identity["passed"] and identity["unseen_category_rows"] == {"validation": 0, "test": 0}
    assert all(record["delta_u_checked"] and record["test_delta_u"] == 0.0 for record in identity["models"].values())
    rows = list(csv.DictReader(open(results / "tables" / f"bm_halfmonth_seed{context.seed}_pat_raw.csv")))
    assert len(rows) == 2 * 3
    by_point = {(row["model"], row["point"]): row for row in rows}
    for model in ("mlp", "xgboost"):
        # Identical buckets of another configuration reuse the first evaluation.
        assert by_point[(model, "alpha0.5_L100")]["evaluation_reused_from"] == "alpha0.5_L50"
        assert by_point[(model, "alpha0.95_L50")]["min_k"] == str(context.training_row_count)
    assert {row["pat_bucket_counts"] for row in rows} == {"age:2;kind:2;size:1", "age:1;kind:1;size:1"}


# Results store and long tables ------------------------------------------------------
def test_evaluation_store_drops_a_partial_last_line(tmp_path):
    path = tmp_path / "store.jsonl"
    store = EvaluationStore(path, resume=False)
    base = {"record_type": "point", "method": "FeatSel", "dataset": "bm", "seed": 42, "model": "mlp"}
    store.append({**base, "point": "keep_1"})
    store.append({**base, "point": "keep_0"})
    with path.open("a", encoding="utf-8") as handle:
        handle.write('{"record_type": "point", "meth')
    with pytest.raises(FileExistsError):
        EvaluationStore(path, resume=False)
    resumed = EvaluationStore(path, resume=True)
    assert len(resumed.records) == 2 and path.read_text().endswith("}\n")
    resumed.append({**base, "point": "keep_2"})
    assert len(EvaluationStore(path, resume=True).records) == 3


def baseline_record(method, seed, point, du, vdu, min_k, tail, reference):
    return {
        "record_type": "point", "experiment": "exp1_privacy_utility", "method": method, "dataset": "bm",
        "model": "xgboost", "seed": seed, "point": point, "test_delta_u": du, "validation_delta_u": vdu,
        "test_loss": reference + du, "baseline_test_loss": reference, "min_k": min_k, "original_leak_k": 1,
        "tail_risk_p99": tail, "original_tail_risk_p99": 0.0,
    }


def test_long_table_keeps_minus_inf_tail(tmp_path):
    reference = {42: 0.21, 43: 0.22}
    store = EvaluationStore(tmp_path / "FIDO.jsonl", resume=False)
    for seed in (42, 43):
        for point, du, vdu, k, tail in [("n31647", 0.0, 0.0, 1, 0.0), ("n200", 0.08, 0.07, 1, -math.inf)]:
            store.append(baseline_record("FIDO", seed, point, du, vdu, k, tail, reference[seed]))
    with open(write_tables(store, tmp_path, "FIDO")["long"], newline="") as handle:
        rows = list(csv.DictReader(handle))
    assert "-inf" in {row["y_value"] for row in rows if row["y_metric"] == "tail_risk_p99"}
    assert {row["x_metric"] for row in rows} == {"test_delta_u"}


def test_upstream_copies_are_unchanged():
    assert set(verify_upstream_copies()) == {
        "fido_curve_models", "entrywise_personalized_random_subsampling", "entrywise_scale_min",
    }


# Runner end to end --------------------------------------------------------------------
def test_runner_end_to_end_with_resume(tmp_path, monkeypatch):
    context = make_context(n=240, dataset="bm_halfmonth")
    monkeypatch.setattr(runner, "build_context", lambda task, data_root=None: context)
    matrix = {
        "experiment_id": "t", "experiment_kind": "exp1_privacy_utility", "run_prefix": "t",
        "base_task": {"device": "cpu", "dtype": "float32", "allow_cpu_fallback": True,
                      "pipeline": {"val_size": 0.15, "test_size": 0.15, "nrows": None}},
        "axes": [
            {"name": "dataset", "values": [{"label": "bm_halfmonth", "patch": {"dataset": "bm_halfmonth", "data_path": "data/bank_marketing"}}]},
            {"name": "model", "values": [
                {"label": "mlp", "patch": {"model_name": "mlp", "model": {"downstream": MLP_SPEC}}},
                {"label": "xgboost", "patch": {"model_name": "xgboost", "model": {"downstream": XGB_SPEC}}}]},
            {"name": "seed", "values": [{"label": context.seed, "patch": {"pipeline": {"random_state": context.seed}}}]},
        ],
    }
    (tmp_path / "matrix.yaml").write_text(yaml.safe_dump(matrix))
    config = {
        "experiment_kind": "exp1_baselines", "matrix_config": str(tmp_path / "matrix.yaml"),
        "methods": ["fido", "entrywise", "featsel"],
        "fido": {"size_grid": {"start_fraction": 0.05, "end_fraction": 1.0, "points": 8},
                 "epsilons": [0.005, 0.01, 0.02, 0.05, 0.1]},
        "featsel": {"search": {"bm_halfmonth": {"mode": "all"}}},
        "entrywise": {"adjustments": ["reid", "recon"], "mults": [2, 5, 10], "fraction_count": None},
    }
    (tmp_path / "config.yaml").write_text(yaml.safe_dump(config))
    results = tmp_path / "results"
    argv = ["--config", str(tmp_path / "config.yaml"), "--dataset", "bm_halfmonth", "--seed", str(context.seed),
            "--device", "cpu", "--results-dir", str(results)]
    assert runner.main(argv) == 0
    manifest = json.loads(next((results / "manifests").glob("*.json")).read_text())
    assert manifest["status"] == "complete"
    assert all(check["passed"] for method in ("FeatSel", "FIDO") for check in manifest["identity_checks"][method].values())
    raw = {method: list(csv.DictReader(open(results / "tables" / f"bm_halfmonth_seed{context.seed}_{method}_raw.csv")))
           for method in ("featsel", "entrywise", "fido")}
    assert len(raw["featsel"]) == 2 * 8 and len(raw["entrywise"]) == 2 * 14 and raw["fido"]
    # MLP and XGBoost evaluate the same stored release.
    by_point = {}
    for row in raw["featsel"] + raw["entrywise"]:
        by_point.setdefault((row["method"], row["point"]), set()).add(row["release_key"])
    assert all(len(keys) == 1 for keys in by_point.values())
    # Repeated EntryWise masks reuse the losses of their first evaluation.
    rows = {(row["model"], row["point"]): row for row in raw["entrywise"]}
    for row in raw["entrywise"]:
        if row["evaluation_reused_from"]:
            source = rows[(row["model"], row["evaluation_reused_from"])]
            assert row["release_content_sha256"] == source["release_content_sha256"]
            assert (row["validation_loss"], row["test_loss"]) == (source["validation_loss"], source["test_loss"])
            assert float(row["fit_seconds"]) == 0.0
    split = read_json_gz(results / "splits" / f"bm_halfmonth_seed{context.seed}.json.gz")
    for row in raw["entrywise"][:3]:
        loaded, payload, _ = load_release(results / row["release_path"], results / "splits" / f"bm_halfmonth_seed{context.seed}.json.gz")
        assert payload["release_key"] == row["release_key"] and loaded.row_count == len(split["train_row_ids"])
    first = {path.name: path.read_text() for path in (results / "evaluations").glob("*.jsonl")}
    with pytest.raises(FileExistsError):
        runner.main(argv)
    assert runner.main(argv + ["--resume"]) == 0
    assert first == {path.name: path.read_text() for path in (results / "evaluations").glob("*.jsonl")}
