"""The reused-graph IF must give exactly the influence states of fresh products.

The reference recomputes, at every CG step, the gradient graph over the full
original data, and for every Fig. 5j admission the validation loss and gradient
of the round. The tests require bit-for-bit equal results.
"""

from __future__ import annotations

import pytest
import torch

from experiments import ranking_models
from experiments.ranking_models import CandidateExperiment, FixedOriginalInfluence, _flat
from prototype.gpu_mlp import TorchMLP

DTYPES = [torch.float32, torch.float64]


def _data(dtype, *, rows=300, features=6, seed=0):
    generator = torch.Generator().manual_seed(seed)
    X = torch.randn(rows, features, generator=generator, dtype=dtype)
    logits = X @ torch.linspace(-1.0, 1.0, features, dtype=dtype)
    uniform = torch.rand(rows, generator=generator, dtype=dtype)
    return X, (uniform < torch.sigmoid(logits)).to(dtype)


def _model(X, y, dtype):
    return TorchMLP(
        hidden_sizes=(8, 8), epochs=40, device="cpu", dtype=dtype, random_state=0,
    ).fit(X, y)


def _with_fresh_products(influence):
    """Give an influence object the reference product: a new gradient graph per call."""

    def hessian_vector(vector):
        gradient = influence.data_gradient(
            influence.original_X, influence.original_y, create_graph=True,
        )
        values = torch.autograd.grad(gradient @ vector, influence.parameters, allow_unused=True)
        regularization = float(getattr(influence.model, "weight_decay", 0.0))
        return _flat(values, influence.parameters).detach() + (
            regularization + influence.damping
        ) * vector

    influence.hessian_vector = hessian_vector
    return influence


@pytest.mark.parametrize("dtype", DTYPES)
@pytest.mark.parametrize("scope", ["last_layer", "all"])
def test_reused_graph_gives_identical_products_and_states(dtype, scope):
    X, y = _data(dtype)
    model = _model(X, y, dtype)
    settings = dict(parameter_scope=scope, damping=1e-3, cg_max_iter=10, cg_tolerance=0.0)
    reused = FixedOriginalInfluence(model, X, y, **settings)
    fresh = _with_fresh_products(FixedOriginalInfluence(model, X, y, **settings))
    generator = torch.Generator().manual_seed(1)
    for _ in range(3):
        vector = torch.randn(reused.original_gradient.numel(), generator=generator, dtype=dtype)
        assert torch.equal(reused.hessian_vector(vector), fresh.hessian_vector(vector))
    new_state = reused.state(X[:150], y[:150])
    old_state = fresh.state(X[:150], y[:150])
    assert torch.equal(new_state.vector, old_state.vector)
    assert new_state.distance == old_state.distance
    assert new_state.cg_iterations == old_state.cg_iterations


class _NoLGA:
    def score_admission(self, *args):
        return {"score": 0.0, "time_seconds": 0.0, "shared_setup_seconds": 0.0}


@pytest.mark.parametrize("dtype", DTYPES)
@pytest.mark.parametrize("mode", ["ranking", "estimation"])
def test_admission_scores_are_unchanged(monkeypatch, tmp_path, dtype, mode):
    X, y = _data(dtype)
    model = _model(X, y, dtype)
    monkeypatch.setattr(
        ranking_models.LGAScorer, "build", classmethod(lambda cls, *args: _NoLGA()),
    )
    solver = {"damping": 1e-3, "cg_max_iter": 10, "cg_tolerance": 0.0}
    experiment = CandidateExperiment(
        mode=mode, seed=0, output_csv=tmp_path / "candidates.csv",
        oracle_candidate_limit_per_type=5, horizontal_last=solver, vertical_all=solver,
    )
    experiment.prepare_original(model, X, y)
    current, admitted, validation = slice(0, 120), slice(120, 135), slice(200, 300)
    experiment.begin_iteration(
        iteration=0, estimator_model=None,
        current_encode=X[current], current_y=y[current],
        validation_encode=X[validation], validation_y=y[validation],
        current_proxy_validation_loss=0.5, current_downstream_validation_loss=0.5,
    )
    result = experiment.score_admission(
        candidate_type="retention_class", candidate_id="c0",
        admitted_encode=X[admitted], admitted_y=y[admitted],
    )

    fresh = _with_fresh_products(FixedOriginalInfluence(
        model, X, y, parameter_scope="last_layer", **solver,
    ))
    fresh_current = fresh.state(X[current], y[current])
    fresh_next = fresh.state(
        torch.cat((X[current], X[admitted])), torch.cat((y[current], y[admitted])),
    )
    assert result["yang_if_distance_score"] == fresh_current.distance - fresh_next.distance
    if mode == "estimation":
        assert result["yang_if_utility_delta"] == (
            fresh.estimated_validation_loss(fresh_current, X[validation], y[validation])
            - fresh.estimated_validation_loss(fresh_next, X[validation], y[validation])
        )
