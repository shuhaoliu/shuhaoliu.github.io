"""The tree check (scripts/check_generalization_trees.py) on small hand-written trees."""

import importlib.util
from pathlib import Path

import pandas as pd

SPEC = importlib.util.spec_from_file_location(
    "check_generalization_trees", Path(__file__).resolve().parents[1] / "scripts" / "check_generalization_trees.py")
check = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(check)


class Loader:
    numeric_attributes = ("age",)
    string_categorical_attributes = ("job",)


def node(node_id, kind, parent, children=(), value=None):
    return {"id": node_id, "kind": kind, "parent": parent, "children": list(children), "value": value}


def age_tree(*intervals):
    leaves = [node(f"age.{i}", "leaf", "age.ANY", value=v) for i, v in enumerate(intervals)]
    return {"root": "age.ANY", "nodes": [node("age.ANY", "root", None, [n["id"] for n in leaves]), *leaves]}


def job_tree(*values):
    leaves = [node(f"job.{v}", "leaf", "job.ANY", value=v) for v in values]
    return {"root": "job.ANY", "nodes": [node("job.ANY", "root", None, [n["id"] for n in leaves]), *leaves]}


def test_a_valid_tree_passes():
    row = check.check_attribute(Loader(), "age", age_tree("18 ~ 39", "40 ~ 95"), pd.Series([18, 40, 95]))
    assert row["problems"] == []
    row = check.check_attribute(Loader(), "job", job_tree("admin", "retired", "student"),
                                pd.Series(["admin", "retired"]))
    assert row["problems"] == [] and row["unused_leaves"] == 1


def test_uncovered_and_doubly_covered_values_fail():
    row = check.check_attribute(Loader(), "age", age_tree("18 ~ 40", "40 ~ 90"), pd.Series([18, 40, 95]))
    assert any("in no leaf" in p for p in row["problems"])
    assert any("more than one leaf" in p for p in row["problems"])
    assert any("overlap" in p for p in row["problems"])
    row = check.check_attribute(Loader(), "job", job_tree("admin", "admin"), pd.Series(["admin", "student"]))
    assert any("in no leaf" in p for p in row["problems"])
    assert any("more than one leaf" in p for p in row["problems"])


def test_broken_parent_links_fail():
    tree = job_tree("admin", "retired")
    tree["nodes"][1]["parent"] = "job.missing"
    row = check.check_attribute(Loader(), "job", tree, pd.Series(["admin"]))
    assert any("not a child of its parent" in p for p in row["problems"])
