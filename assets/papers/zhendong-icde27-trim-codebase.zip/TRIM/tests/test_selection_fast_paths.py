"""Selection shortcuts for datasets with non-QI features must not change outputs.

Bank Marketing and Diabetes have predictors outside the QI set. The reference
run below takes the direct paths: the selection cache is off (no rank columns,
so refinements encode, copy and convert every row) and the class-id privacy
count is forced off, so admission candidates recount min-K with value_counts
over all retained rows.
"""

from __future__ import annotations

import math

from experiments.perf.compare_runs import compare_runs
from experiments.perf.synthetic_income import INCOME_TREE, write_income_like_csvs
from prototype import TRIM_prototype_pipeline as pipeline_module
from prototype import dataloader

QI_SUBSET = ("AGEP", "SCHL", "MAR", "OCCP", "POBP", "SEX")


def test_outputs_identical_with_non_qi_features(tmp_path, monkeypatch):
    from prototype.model_factory import build_model_factory

    directory = write_income_like_csvs(tmp_path / "data", rows=600, seed=5)
    original_greedy_select = pipeline_module._greedy_select
    fast_flags = []

    def fast_greedy_select(*args, **kwargs):
        fast_flags.append(kwargs["count_privacy_by_class"])
        return original_greedy_select(*args, **kwargs)

    runs = {}
    for fast in (False, True):
        if not fast:
            monkeypatch.setattr(
                pipeline_module, "_greedy_select",
                lambda *args, **kwargs: original_greedy_select(
                    *args, **{**kwargs, "count_privacy_by_class": False}),
            )
        else:
            monkeypatch.setattr(pipeline_module, "_greedy_select", fast_greedy_select)
        loader = dataloader.ACSIncomeDataLoader(
            data_dir=directory, state="CA", year=2014, qi_attributes=QI_SUBSET)
        spec = {"family": "torch_logistic", "max_iter": 100}
        factory = build_model_factory(spec, device="cpu", dtype="float64", random_state=42)
        result = pipeline_module.run_trim_pipeline(
            loader, generalization_tree_path=INCOME_TREE, model_factory=factory,
            proxy_model_factory=factory,
            estimator_model_factory=build_model_factory(
                spec, device="cpu", dtype="float64", random_state=42, role="estimator"),
            results_dir=tmp_path / f"runs_{fast}", device="cpu", dtype="float64",
            privacy_cost_floor=math.log1p(0.1), validation_only=True,
            record_iteration_validation_metrics=True, stop_on_utility=False,
            max_iterations=4, initial_sample_fraction=0.1, random_state=42,
            selection_cache=fast,
        )
        runs[fast] = result.run_dir
    assert fast_flags and all(fast_flags)
    assert compare_runs(runs[False], runs[True]) == []
