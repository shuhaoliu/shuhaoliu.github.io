"""Focused checks for the global-recoding TDS baseline. Run explicitly with pytest when authorized."""

import json
from pathlib import Path
import sys
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from experiments.exp1_kanon.hierarchy import MISSING_NODE, HierarchySchema
from experiments.exp1_kanon_global.tds import FittedTDS
from prototype.dataloader import load_generalization_rules


@pytest.fixture
def schema():
    loader = SimpleNamespace(
        feature_columns=("age", "kind", "aux"), qi_attributes=("age", "kind"),
        numeric_attributes=("age", "aux"), categorical_attributes=("kind",),
        category_maps={"kind": {"a": 0, "b": 1, "c": 2}},
    )
    trees = {
        "age": {"nodes": [
            {"id": "age_root", "parent": None, "kind": "root", "height_from_leaf": 1},
            *[{"id": f"age_{i}", "value": i, "parent": "age_root", "kind": "leaf", "height_from_leaf": 0}
              for i in range(8)],
        ]},
        "kind": {"nodes": [
            {"id": "kind_root", "parent": None, "kind": "root", "height_from_leaf": 2},
            {"id": "ab", "parent": "kind_root", "kind": "internal", "height_from_leaf": 1},
            {"id": "a", "value": "a", "parent": "ab", "kind": "leaf", "height_from_leaf": 0},
            {"id": "b", "value": "b", "parent": "ab", "kind": "leaf", "height_from_leaf": 0},
            {"id": "c", "value": "c", "parent": "kind_root", "kind": "leaf", "height_from_leaf": 0},
        ]},
    }
    return HierarchySchema(load_generalization_rules(trees, loader, generalization_level=0))


@pytest.fixture
def random_data():
    rng = np.random.default_rng(0)
    index = pd.RangeIndex(100, 160)
    X = pd.DataFrame({
        "age": rng.integers(0, 8, 60), "kind": rng.choice(["a", "b", "c"], 60), "aux": range(60),
    }, index=index)
    return X, pd.Series(rng.integers(0, 2, 60), index=index)


def releases_by_row(groups, key="row_ids"):
    return {row: group["release"] for group in groups for row in group[key]}


def test_score_is_information_gain_over_anonymity_loss_plus_one(schema):
    X = pd.DataFrame({"age": [0] * 8, "kind": ["a", "a", "b", "b", "c", "c", "c", "c"], "aux": range(8)})
    fitted = FittedTDS(schema, k=2).fit(X, pd.Series([0, 0, 0, 0, 1, 1, 1, 1]))
    first = fitted.history[0]
    assert (first["attribute"], first["node"]) == ("kind", "kind_root")
    assert first["information_gain"] == pytest.approx(1.0)
    assert first["anonymity_loss"] == 4
    assert first["score"] == pytest.approx(1.0 / 5)
    # A valid, beneficial step with zero gain is still taken.
    assert [step["attribute"] for step in fitted.history] == ["kind", "age"]
    assert fitted.history[1]["score"] == 0.0
    released = releases_by_row(fitted.partitions)
    # Records under "ab" all carry label 0, so "ab" is not beneficial.
    assert released[0]["kind"]["node"] == "ab"
    assert released[0]["age"]["node"] == "age_0"
    assert sorted(fitted.cut["kind"]) == sorted(["ab", "c", MISSING_NODE])


def test_every_record_is_published_once_in_classes_of_at_least_k(schema, random_data):
    X, y = random_data
    for k in (1, 2, 5, 13, 60):
        fitted = FittedTDS(schema, k=k).fit(X, y)
        assert sorted(position for group in fitted.partitions for position in group["positions"]) == list(range(60))
        assert fitted.per_record_k(X.index).min() >= k
        assert all(step["min_k_after"] >= k for step in fitted.history)
    assert len(FittedTDS(schema, k=60).fit(X, y).partitions) == 1


def test_equal_raw_values_share_one_released_node(schema, random_data):
    X, y = random_data
    fitted = FittedTDS(schema, k=5).fit(X, y)
    for attribute in ("age", "kind"):
        released = {}
        for group in fitted.partitions:
            for position in group["positions"]:
                value = X[attribute].iloc[position]
                released.setdefault(value, set()).add(json.dumps(group["release"][attribute], sort_keys=True))
        assert all(len(nodes) == 1 for nodes in released.values())


def test_split_creating_a_class_below_k_is_not_taken(schema):
    X = pd.DataFrame({"age": [1] * 5, "kind": ["a"] * 3 + ["c"] * 2, "aux": range(5)})
    fitted = FittedTDS(schema, k=3).fit(X, pd.Series([0, 1, 0, 1, 0]))
    assert {group["release"]["kind"]["node"] for group in fitted.partitions} == {"kind_root"}
    assert "kind" not in {step["attribute"] for step in fitted.history}


def test_missing_values_form_a_branch_that_must_meet_k(schema):
    X = pd.DataFrame({"age": [1] * 6, "kind": ["a", "a", "c", "c", pd.NA, pd.NA], "aux": range(6)})
    y = pd.Series([0, 1] * 3)
    fitted = FittedTDS(schema, k=2).fit(X, y)
    released = releases_by_row(fitted.partitions)
    assert released[4]["kind"]["node"] == released[5]["kind"]["node"] == MISSING_NODE
    encoded = schema.encode(X, fitted.partitions, family="mlp")
    np.testing.assert_array_equal(encoded.loc[[4, 5], ["kind=a", "kind=b", "kind=c"]], np.zeros((2, 3)))
    blocked = FittedTDS(schema, k=3).fit(X, y)
    assert {group["release"]["kind"]["node"] for group in blocked.partitions} == {"kind_root"}


def test_evaluation_records_use_the_training_cut(schema):
    X = pd.DataFrame({"age": [0, 0, 0, 0, 7, 7, 7, 7], "kind": ["a", "a", "b", "b"] * 2, "aux": range(8)})
    fitted = FittedTDS(schema, k=2).fit(X, pd.Series([0, 1, 0, 1, 1, 1, 0, 1]))
    assert sorted(fitted.cut["kind"]) == sorted(["a", "b", "c", MISSING_NODE])
    evaluation = pd.DataFrame({"age": [0, 3, 7], "kind": ["a", "c", "b"], "aux": [0, 0, 0]})
    groups = fitted.transform_groups(evaluation)
    released = releases_by_row(groups, key="positions")
    training = releases_by_row(fitted.partitions)
    assert released[0] == training[0]
    assert released[2] == training[6]
    assert (released[1]["age"]["node"], released[1]["kind"]["node"]) == ("age_3", "c")
    stats = fitted.evaluation_stats(groups, len(evaluation))
    assert stats["unseen_class_record_count"] == 1


def test_saved_release_round_trips(schema):
    X = pd.DataFrame({"age": [0, 0, 0, 0, 7, 7, 7, 7], "kind": ["a", "a", "b", "b"] * 2, "aux": range(8)})
    fitted = FittedTDS(schema, k=2).fit(X, pd.Series([0, 1, 0, 1, 1, 1, 0, 1]))
    restored = FittedTDS.from_dict(schema, json.loads(json.dumps(fitted.to_dict())))
    evaluation = pd.DataFrame({"age": [0, 3, 7], "kind": ["a", "c", "b"], "aux": [0, 0, 0]})
    assert restored.transform_groups(evaluation) == fitted.transform_groups(evaluation)
    pd.testing.assert_series_equal(restored.per_record_k(X.index), fitted.per_record_k(X.index))
    assert restored.history == fitted.history


def test_root_release_matches_trim_root_encoding(schema):
    X = pd.DataFrame({"age": [0, 7], "kind": ["a", "c"], "aux": [11, 19]})
    fitted = FittedTDS(schema, k=2).fit(X, pd.Series([0, 1]))
    assert len(fitted.partitions) == 1
    trim = schema.generalization.change_level({"age": 2, "kind": 2})
    np.testing.assert_allclose(schema.encode(X, fitted.partitions, family="mlp"), trim.encode(X))
    np.testing.assert_allclose(
        schema.encode(X, fitted.partitions, family="xgboost"), trim.encode_xgboost_leaf_space(X).toarray(),
    )
