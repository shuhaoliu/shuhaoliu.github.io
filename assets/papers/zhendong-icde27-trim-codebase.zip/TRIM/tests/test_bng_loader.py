"""BNG credit-g numerics: rounded and clipped to the integer leaves of the BNG tree (Fig. 5d crashed without it)."""

from __future__ import annotations

import itertools
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
import yaml

from prototype import dataloader

ROOT = Path(__file__).resolve().parents[1]
TREE = ROOT / "configs/generalization_trees/bng_credit_g_generalization_tree.yaml"


def _tree():
    return yaml.safe_load(TREE.read_text())


def test_bounds_equal_the_tree_ranges():
    trees = _tree()["trees"]
    for attribute in dataloader.BNG_CREDIT_G_NUMERIC_ATTRIBUTES:
        root = next(node for node in trees[attribute]["nodes"] if node["kind"] == "root")
        ranges = [tuple(int(v) for v in part.split(" ~ ")) for part in root["leaf_values_compressed"].split(", ")]
        assert dataloader.BNG_CREDIT_G_INTEGER_BOUNDS[attribute] == (ranges[0][0], ranges[-1][1])
        # The leaves cover every integer of the range without gaps.
        assert all(high + 1 == low for (_, high), (low, _) in zip(ranges, ranges[1:]))


@pytest.fixture
def bng(tmp_path):
    """A small BNG-like ARFF file: real-valued numerics (with the observed extremes) and the tree's categories."""
    trees = _tree()["trees"]
    rng = np.random.default_rng(0)
    rows = 64
    columns, header = {}, ["@relation bng_sample", ""]
    for attribute in dataloader.BNG_CREDIT_G_FEATURE_COLUMNS:
        if attribute in dataloader.BNG_CREDIT_G_NUMERIC_ATTRIBUTES:
            low, high = dataloader.BNG_CREDIT_G_INTEGER_BOUNDS[attribute]
            values = rng.uniform(low - 0.6, high + 0.45, size=rows)
            values[:2] = (low - 0.54, high + 0.34)
            columns[attribute] = [f"{v:.6f}" for v in values]
            header.append(f"@attribute {attribute} numeric")
        else:
            leaves = [node["value"] for node in trees[attribute]["nodes"] if node["kind"] == "leaf"]
            columns[attribute] = [f"'{v}'" for v in itertools.islice(itertools.cycle(leaves), rows)]
            header.append(f"@attribute {attribute} {{{','.join(repr(v) for v in leaves)}}}")
    columns["class"] = ["good", "bad"] * (rows // 2)
    header += ["@attribute class {good,bad}", "", "@data"]
    lines = [",".join(columns[name][i] for name in (*dataloader.BNG_CREDIT_G_FEATURE_COLUMNS, "class"))
             for i in range(rows)]
    data = tmp_path / "bng.arff"
    data.write_text("\n".join(header + lines) + "\n")
    return dataloader.BNGCreditGDataLoader(csv_path=data)


def test_loaded_numerics_are_integers_inside_the_tree(bng):
    X, y = bng.load()
    for attribute in dataloader.BNG_CREDIT_G_NUMERIC_ATTRIBUTES:
        low, high = dataloader.BNG_CREDIT_G_INTEGER_BOUNDS[attribute]
        values = X[attribute].to_numpy()
        assert np.all(values == np.round(values))
        assert values.min() >= low and values.max() <= high
    assert len(y) == len(X)


def test_leaf_space_encoding_accepts_every_loaded_value(bng):
    X, _ = bng.load()
    levels = {attribute: 0 for attribute in bng.qi_attributes}
    generalization = dataloader.load_generalization_rules_from_file(
        file_path=TREE, data_loader=bng, generalization_level=levels)
    encoded = generalization.encode_xgboost_leaf_space(X)
    assert encoded.shape[0] == len(X)
