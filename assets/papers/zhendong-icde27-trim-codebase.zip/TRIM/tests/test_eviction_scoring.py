"""Published scoring of refine-and-evict variants on a controlled fixture; no real datasets or GPU are needed."""

from __future__ import annotations

import importlib
import json
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import torch

from experiments.check_trim_run import check_run
from prototype.experiment_hooks import ALL_ROWS_AT_MAX_GENERALIZATION, AblationActions

core = importlib.import_module("prototype.TRIM_prototype_pipeline")


class ChainGeneralization:
    """Level L scales q by (3 - L) / 3: level 3 puts every row in one class, lower levels keep the classes of q."""
    def __init__(self, levels):
        self.generalization_level = dict(levels)

    def encode(self, frame):
        return frame[["q"]].astype(float) * ((3 - self.generalization_level["q"]) / 3)

    def change_level(self, levels):
        return ChainGeneralization(levels)


class DeterministicModel:
    """A fixed logistic predictor; fitting never introduces random variation."""
    def set_classes(self, classes):
        self.classes_ = np.asarray(classes)

    def fit(self, encode, labels):
        self.coef_tensor_ = torch.ones(1, device=encode.device, dtype=encode.dtype)
        self.intercept_tensor_ = torch.zeros(1, device=encode.device, dtype=encode.dtype)
        return self

    def predict_proba_tensor(self, encode):
        probability = torch.sigmoid(encode[:, 0])
        return torch.stack((1 - probability, probability), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)


# Classes of 5 and 5 plus six singletons: ratio 4 gives ceiling 16 / 4 = 4, so the
# variant keeps the two classes (min-K 5) and evicts the six singletons, which
# form one class of 6 >= 5 at the start level and can be pooled there.
POOLED_Q = [-1] * 5 + [1] * 5 + [2, -2, 3, -3, 4, -4]
# Only two singletons: their class at the start level has 2 < 5 rows, so
# nothing can be pooled and published scoring equals retained scoring.
UNPOOLED_Q = [-1] * 5 + [1] * 5 + [2, -2]
VALIDATION_Q = [-1, 1, 2, 5]


def _fixture(tmp_path, monkeypatch, train_q):
    train_ids = [f"t{i}" for i in range(len(train_q))]
    val_ids = [f"v{i}" for i in range(len(VALIDATION_Q))]
    row_ids = train_ids + val_ids + ["h0", "h1"]
    frame = pd.DataFrame({"q": train_q + VALIDATION_Q + [-1, 1]}, index=row_ids)
    labels = pd.Series([int(q > 0) for q in frame["q"]], index=row_ids)
    tree = tmp_path / "tree.yaml"
    tree.write_text("trees:\n  q:\n    nodes:\n      - height_from_leaf: 3\n")
    loader = SimpleNamespace(
        task_type="classification", qi_attributes=("q",), feature_columns=("q",),
        load=lambda nrows=None: (frame.copy(), labels.copy()))
    import sklearn.model_selection
    from prototype import dataloader

    def split(X, y, **kwargs):
        held_out = ["h0", "h1"] if any(str(rid).startswith("h") for rid in X.index) else val_ids
        remainder = [rid for rid in row_ids if rid in X.index and rid not in held_out]
        return X.loc[remainder], X.loc[held_out], y.loc[remainder], y.loc[held_out]

    monkeypatch.setattr(sklearn.model_selection, "train_test_split", split)
    monkeypatch.setattr(dataloader, "load_generalization_rules_from_file",
                        lambda file_path, data_loader, generalization_level:
                        ChainGeneralization(generalization_level))
    monkeypatch.setattr(core, "stratified_sample_row_ids", lambda *args: ["t0", "t5"])
    options = {
        "generalization_tree_path": tree, "privacy_cost_floor": 0.05, "initial_sample_size": 2,
        "model_factory": DeterministicModel, "proxy_model_factory": DeterministicModel,
        "estimator_model_factory": DeterministicModel,
        "device": "cpu", "dtype": "float64", "rank_top_k": 3,
        "results_dir": tmp_path / "runs", "tolerance": 1e9, "max_iterations": 1,
        "stop_on_utility": False, "refinement_eviction_ratios": [4],
        "ablation_actions": AblationActions(initialization=ALL_ROWS_AT_MAX_GENERALIZATION),
    }
    return loader, tree, options, frame


def _certified_variants(result):
    actions = [json.loads(line) for line in next(Path(result.run_dir).glob(
        "pipeline_selection_actions_*.jsonl")).read_text().splitlines()]
    return [a for a in actions if a.get("event") == "candidate_evaluation"
            and a.get("eviction_ceiling") is not None]


def test_layout_pools_evicted_rows_and_moves_their_validation_rows(tmp_path, monkeypatch):
    _loader, _tree, _options, frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    train, val = frame.loc[[f"t{i}" for i in range(len(POOLED_Q))]], frame.loc[["v0", "v1", "v2", "v3"]]
    kept, evicted = [f"t{i}" for i in range(10)], [f"t{i}" for i in range(10, 16)]
    candidate, start = ChainGeneralization({"q": 0}), ChainGeneralization({"q": 3})
    train_parts, suppressed, val_parts = core._published_eviction_layout(
        candidate, kept, evicted, 5, [start], train, val, ("q",))
    assert [(ids, g.generalization_level["q"]) for ids, g in train_parts] == [(kept, 0), (evicted, 3)]
    assert suppressed == []
    # v0 and v1 fall in kept classes; v2 (q=2) and v3 (q=5) match the pooled class at level 3.
    assert [(ids, g.generalization_level["q"]) for ids, g in val_parts] == [(["v0", "v1"], 0), (["v2", "v3"], 3)]

    train_parts, suppressed, val_parts = core._published_eviction_layout(
        candidate, kept, evicted, 7, [start], train, val, ("q",))
    assert [ids for ids, _g in train_parts] == [kept]
    assert suppressed == evicted
    assert [ids for ids, _g in val_parts] == [["v0", "v1", "v2", "v3"]]


def test_published_scoring_counts_pooled_rows(tmp_path, monkeypatch):
    loader, tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    retained = core.run_trim_pipeline(loader, **options)
    published = core.run_trim_pipeline(loader, **{**options, "results_dir": tmp_path / "published"},
                                       eviction_scoring="published_check")
    # One variant per target level (q@2, q@1, q@0), each evicting the six singletons.
    retained_rows = {c["candidate_id"]: c["release_row_count"] for c in _certified_variants(retained)}
    published_rows = {c["candidate_id"]: c["release_row_count"] for c in _certified_variants(published)}
    assert sorted(retained_rows) == sorted(published_rows) == ["q@0~k4", "q@1~k4", "q@2~k4"]
    assert set(retained_rows.values()) == {10}
    assert set(published_rows.values()) == {16}
    assert {c["proxy_evaluation_scope"] for c in _certified_variants(published)} == {"published_eviction"}
    assert json.loads((Path(published.run_dir) / "config.json").read_text())["eviction_scoring"] == "published_check"
    assert "eviction_scoring" not in json.loads((Path(retained.run_dir) / "config.json").read_text())
    for result in (retained, published):
        assert check_run(result.run_dir, loader, tree)["commits_checked"] == 1


def test_published_equals_retained_when_nothing_can_be_pooled(tmp_path, monkeypatch):
    loader, tree, options, _frame = _fixture(tmp_path, monkeypatch, UNPOOLED_Q)
    retained = core.run_trim_pipeline(loader, **options)
    published = core.run_trim_pipeline(loader, **{**options, "results_dir": tmp_path / "published"},
                                       eviction_scoring="published_check")
    keys = ("candidate_id", "utility_gain", "score", "next_k", "release_row_count", "lga_score")
    assert ([[c.get(k) for k in keys] for c in _certified_variants(retained)]
            == [[c.get(k) for k in keys] for c in _certified_variants(published)])
    records = [[json.loads(line) for line in (Path(r.run_dir) / "state_history.jsonl").read_text().splitlines()]
               for r in (retained, published)]
    fields = ("operation", "next_k", "retained_count", "mixed_min_k", "eviction_ceiling")
    assert [[rec.get(f) for f in fields] for rec in records[0]] == [[rec.get(f) for f in fields] for rec in records[1]]
    assert check_run(published.run_dir, loader, tree)["commits_checked"] == 1


@pytest.mark.parametrize("overrides", [
    {"eviction_scoring": "pooled"},
    {"eviction_scoring": "published"},
    {"eviction_scoring": "published_check", "refinement_eviction_ratios": None},
])
def test_eviction_scoring_is_validated(tmp_path, monkeypatch, overrides):
    loader, _tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    with pytest.raises(ValueError, match="eviction_scoring"):
        core.run_trim_pipeline(loader, **{**options, **overrides})


@pytest.mark.parametrize("overrides", [
    {"eviction_shortlist": "all"},
    {"eviction_shortlist": "parents"},
    {"eviction_shortlist": "union", "refinement_eviction_ratios": None},
])
def test_eviction_shortlist_is_validated(tmp_path, monkeypatch, overrides):
    loader, _tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    with pytest.raises(ValueError, match="eviction_shortlist"):
        core.run_trim_pipeline(loader, **{**options, **overrides})


def _state_records(result):
    return [json.loads(line) for line in (Path(result.run_dir) / "state_history.jsonl").read_text().splitlines()]


def test_privacy_step_bound_commits_a_bounded_candidate(tmp_path, monkeypatch):
    # A score that rewards large privacy drops picks the un-evicted refinement
    # (min-K 16 -> 1); with max_privacy_step 4 only min-K >= 4 is in bounds, so
    # the eviction variant (min-K 5) is committed instead.
    loader, tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    options["selection_score"] = lambda context: float(context.privacy_cost)
    free = core.run_trim_pipeline(loader, **options)
    bounded = core.run_trim_pipeline(loader, **{**options, "results_dir": tmp_path / "bounded"}, max_privacy_step=4)
    assert (_state_records(free)[1]["current_k"], _state_records(free)[1]["next_k"]) == (16, 1)
    assert (_state_records(bounded)[1]["current_k"], _state_records(bounded)[1]["next_k"]) == (16, 5)
    assert json.loads((Path(bounded.run_dir) / "config.json").read_text())["max_privacy_step"] == 4.0
    assert check_run(bounded.run_dir, loader, tree)["commits_checked"] == 1


def test_privacy_step_bound_falls_back_when_nothing_is_in_bounds(tmp_path, monkeypatch):
    # With bound 2 (min-K >= 8) no candidate is in bounds, so the best score wins as without a bound.
    loader, tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    free = core.run_trim_pipeline(loader, **options)
    bounded = core.run_trim_pipeline(loader, **{**options, "results_dir": tmp_path / "bounded"}, max_privacy_step=2)
    assert _state_records(free)[1]["next_k"] == _state_records(bounded)[1]["next_k"]
    assert check_run(bounded.run_dir, loader, tree)["commits_checked"] == 1


@pytest.mark.parametrize("step", [1, 0.5, "4", True, float("inf")])
def test_max_privacy_step_is_validated(tmp_path, monkeypatch, step):
    loader, _tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    with pytest.raises(ValueError, match="max_privacy_step"):
        core.run_trim_pipeline(loader, **options, max_privacy_step=step)


def test_union_shortlist_keeps_the_default_candidates(tmp_path, monkeypatch):
    # "union" certifies every candidate that the default shortlist certifies, plus the variants of shortlisted
    # refinements; with top-k 1 the default checks one un-evicted refinement and the variants' own top-1.
    loader, tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    options["rank_top_k"] = 1

    def certified(result):
        actions = [json.loads(line) for line in next(Path(result.run_dir).glob(
            "pipeline_selection_actions_*.jsonl")).read_text().splitlines()]
        return {a["candidate_id"] for a in actions if a.get("event") == "candidate_evaluation"
                and a["action"] == "vertical_refinement"}

    default = core.run_trim_pipeline(loader, **options)
    union = core.run_trim_pipeline(loader, **{**options, "results_dir": tmp_path / "union"},
                                   eviction_shortlist="union")
    assert certified(default) <= certified(union)
    assert json.loads((Path(union.run_dir) / "config.json").read_text())["eviction_shortlist"] == "union"
    assert check_run(union.run_dir, loader, tree)["commits_checked"] == 1


def test_published_check_keeps_the_default_lga_ranking(tmp_path, monkeypatch):
    # "published_check" scores the certified variants on their published rows but ranks them with the
    # kept-row LGA, so the variants' LGA scores equal those of the run with retained scoring.
    loader, tree, options, _frame = _fixture(tmp_path, monkeypatch, POOLED_Q)
    default = core.run_trim_pipeline(loader, **options)
    checked = core.run_trim_pipeline(loader, **{**options, "results_dir": tmp_path / "checked"},
                                     eviction_scoring="published_check")
    lga = lambda result: {c["candidate_id"]: c["lga_score"] for c in _certified_variants(result)}
    assert lga(default) == lga(checked)
    assert {c["proxy_evaluation_scope"] for c in _certified_variants(checked)} == {"published_eviction"}
    assert {c["release_row_count"] for c in _certified_variants(checked)} == {16}
    assert check_run(checked.run_dir, loader, tree)["commits_checked"] == 1
