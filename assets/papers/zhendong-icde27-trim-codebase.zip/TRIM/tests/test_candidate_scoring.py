"""Candidate scoring scope: the proxy is fitted on the retained rows D_{t-1}+o."""

from __future__ import annotations

import importlib
import json
import math
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
import torch

from experiments.check_trim_run import check_run

core = importlib.import_module("prototype.TRIM_prototype_pipeline")


class ChainGeneralization:
    def __init__(self, levels):
        self.generalization_level = dict(levels)

    def encode(self, frame):
        return frame[["q"]].astype(float) * ((3 - self.generalization_level["q"]) / 3)

    def change_level(self, levels):
        return ChainGeneralization(levels)


class FixedLogisticModel:
    """Estimator and target: a fixed predictor with LGA parameters."""
    def set_classes(self, classes):
        self.classes_ = np.asarray(classes)

    def fit(self, encode, labels):
        self.coef_tensor_ = torch.ones(1, device=encode.device, dtype=encode.dtype)
        self.intercept_tensor_ = torch.zeros(1, device=encode.device, dtype=encode.dtype)
        return self

    def predict_proba_tensor(self, encode):
        probability = torch.sigmoid(encode[:, 0])
        return torch.stack((1 - probability, probability), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)


class LabelRateModel:
    """Proxy that predicts its training label rate, so its loss depends on the rows."""
    def set_classes(self, classes):
        self.classes_ = np.asarray(classes)

    def fit(self, encode, labels):
        rate = float(torch.as_tensor(labels, dtype=torch.float64).mean())
        self.rate_ = min(max(rate, 0.05), 0.95)
        return self

    def predict_proba_tensor(self, encode):
        rate = torch.full((encode.shape[0],), self.rate_, device=encode.device, dtype=encode.dtype)
        return torch.stack((1 - rate, rate), dim=1)

    def predict_tensor(self, encode):
        return (self.predict_proba_tensor(encode)[:, 1] >= 0.5).to(encode.dtype)


def rate_loss(row_ids):
    """Validation log loss of LabelRateModel fitted on row_ids (labels v0=0, v1=1)."""
    # Training row t{i} has label i % 2.
    rate = min(max(float(np.mean([int(str(rid)[1:]) % 2 for rid in row_ids])), 0.05), 0.95)
    return -(math.log(1 - rate) + math.log(rate)) / 2


@pytest.fixture
def scoring(tmp_path, monkeypatch):
    row_ids = [f"t{i}" for i in range(8)] + ["v0", "v1", "h0", "h1"]
    frame = pd.DataFrame({"q": [-1, 1] * 6}, index=row_ids)
    labels = pd.Series([0, 1] * 6, index=row_ids)
    tree = tmp_path / "tree.yaml"
    tree.write_text("trees:\n  q:\n    nodes:\n      - height_from_leaf: 3\n")
    loader = SimpleNamespace(
        task_type="classification", qi_attributes=("q",), feature_columns=("q",),
        load=lambda nrows=None: (frame.copy(), labels.copy()))
    import sklearn.model_selection
    from prototype import dataloader

    def split(X, y, **kwargs):
        held_out = ["h0", "h1"] if any(str(rid).startswith("h") for rid in X.index) else ["v0", "v1"]
        remainder = [rid for rid in row_ids if rid in X.index and rid not in held_out]
        return X.loc[remainder], X.loc[held_out], y.loc[remainder], y.loc[held_out]

    monkeypatch.setattr(sklearn.model_selection, "train_test_split", split)
    monkeypatch.setattr(dataloader, "load_generalization_rules_from_file",
                        lambda file_path, data_loader, generalization_level:
                        ChainGeneralization(generalization_level))
    # Labels 0, 1, 0: the retained proxy sees rate 1/3, the mixed release 1/2.
    monkeypatch.setattr(core, "stratified_sample_row_ids", lambda *args: ["t0", "t1", "t2"])
    options = {
        "generalization_tree_path": tree, "privacy_cost_floor": 0.05,
        "initial_sample_size": 3,
        "model_factory": FixedLogisticModel, "proxy_model_factory": LabelRateModel,
        "estimator_model_factory": FixedLogisticModel,
        "device": "cpu", "dtype": "float64", "rank_top_k": 2,
        "results_dir": tmp_path / "runs",
    }
    return loader, tree, options


def test_gain_reference_and_candidates_use_the_retained_rows(scoring, monkeypatch):
    loader, tree, options = scoring
    calls = []
    original = core._greedy_select

    def spy(state, **kwargs):
        unchanged = kwargs["candidate_release_evaluator"](
            state.current_generalization, 1, list(state.selected_row_ids))
        calls.append((sorted(state.selected_row_ids), float(state.actual_model_loss), unchanged))
        return original(state, **kwargs)

    monkeypatch.setattr(core, "_greedy_select", spy)
    result = core.run_trim_pipeline(loader, **options, tolerance=-1e6, max_iterations=1)
    row_ids, reference, unchanged = calls[0]
    assert row_ids == ["t0", "t1", "t2"]
    assert unchanged["evaluation_scope"] == "retained"
    assert unchanged["row_count"] == 3
    assert reference == pytest.approx(rate_loss(row_ids))
    # Admitting the remaining class moves the retained label rate to 1/2.
    assert result.iteration_count == 1
    # Scoring the unchanged state reproduces the gain reference exactly.
    assert unchanged["validation_loss"] == pytest.approx(reference, abs=1e-12)

    run_dir = Path(result.run_dir)
    (action_log,) = run_dir.glob("pipeline_selection_actions_*.jsonl")
    candidates = [record for record in map(json.loads, action_log.read_text().splitlines())
                  if record.get("event") == "candidate_evaluation"]
    assert candidates
    for candidate in candidates:
        assert candidate["proxy_evaluation_scope"] == "retained"
        assert candidate["utility_gain"] == pytest.approx(
            candidate["current_predicted_model_loss"] - candidate["next_predicted_model_loss"])
        assert candidate["release_row_count"] == candidate["next_selected_row_count"]
    assert check_run(run_dir, loader, tree)["status"] == "ok"


def test_retained_scoring_still_reports_the_mixed_release(scoring):
    loader, tree, options = scoring
    result = core.run_trim_pipeline(loader, **options, tolerance=1e9, max_iterations=1,
                                    stop_on_utility=False)
    run_dir = Path(result.run_dir)
    (row,) = json.loads((run_dir / "trim_iterations.json").read_text())["iterations"]
    retained = json.loads((run_dir / "ordinary_selected_row_ids.json").read_text())[
        "ordinary_selected_row_ids"]
    # The search reference is the proxy on D_t; the curve point is the mixed release.
    assert row["search_proxy_validation_loss"] == pytest.approx(rate_loss(retained))
    assert "evaluation_scope" not in row and "assignment_counts" in row
    assert row["validation_loss"] == pytest.approx(rate_loss(row["assigned_row_ids"]))
    assert row["row_count"] == len(row["assigned_row_ids"])
