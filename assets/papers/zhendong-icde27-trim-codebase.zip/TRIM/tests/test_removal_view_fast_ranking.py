"""The removal view's shortlist ranks candidates by estimated progress per utility cost."""

from __future__ import annotations

from experiments.appendix_removal_view import pipeline


def _candidate(action, key, progress, cost, active_rows=10):
    return {
        "action": action,
        "retention_class_key": key,
        "privacy_progress": progress,
        "normalized_fast_utility_cost": cost,
        "next_active_row_count": active_rows,
    }


def test_shortlist_ranks_by_estimated_ratio_not_by_cost_alone():
    removal = _candidate("remove_retention_class", "a", 1e-5, 1e-6)  # ratio 10
    coarsen = _candidate("attribute_coarsen", "b", 0.3, 0.02)  # ratio 15
    ranked = sorted([removal, coarsen], key=pipeline._fast_rank_key)
    assert ranked == [coarsen, removal]


def test_shortlist_breaks_ratio_ties_by_progress_and_puts_unknown_costs_last():
    larger = _candidate("remove_retention_class", "a", 0.2, 0.1)  # ratio 2
    smaller = _candidate("remove_retention_class", "b", 0.1, 0.05)  # ratio 2
    unknown = _candidate("remove_retention_class", "c", 0.5, None)
    ranked = sorted([unknown, smaller, larger], key=pipeline._fast_rank_key)
    assert ranked == [larger, smaller, unknown]
