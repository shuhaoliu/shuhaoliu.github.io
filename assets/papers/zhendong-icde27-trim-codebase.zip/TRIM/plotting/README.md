# Plotting

Each paper figure, table and set of reported numbers has one script in `plotting/paper/`. Run them from the project
root after the runs of `configs/paper/<panel>/`. Every script reads `results/<panel>/` and writes
`figures/<panel>/` by default; `--results` and `--output` change both. Each script's docstring states its inputs and
rules; `--help` prints it. Figures are written as PDF and PNG and named after their panel (`fig4a.pdf`, ...,
`fig5c.pdf`, `fig8a.pdf`); `plotting/paper/style/` holds the drawing code they share.

| Paper item | Command | Reads (under `results/<panel>/`) |
|---|---|---|
| Fig. 4a-4h and the Exp-1 numbers | `python -m plotting.paper.fig4` | `<dataset>_<model>_seed<s>/` trajectory.csv; `baselines*/combined/baseline_long.csv`; `tds/*/baseline_long.csv` |
| Table IV (DP-SGD) | `python -m plotting.paper.table4` | `dpsgd_income_k235/` training_mode_summary.csv, manifest.json, kanon_sup_release.json |
| Fig. 5a, 5b (attacks) | `python -m plotting.paper.fig5ab` | `attacks_income_seed<s>/` results.csv; `baselines_attacks/baseline_attacks.csv`; `inference_average/inference_average_seed<s>.csv` |
| Fig. 5c (runtime) and the shared Fig. 5a-5d legend (`fig5_legend.pdf`) | `python -m plotting.paper.fig5c` | `runtime_<dataset>_seed<s>/` TRIM runs; `baselines/jobs/*.json`; `tds/*/<task>/` |
| Fig. 5d (BNG scalability) | `python -m plotting.paper.fig5d` | `bng_seed<s>/` run_summaries.jsonl; `baselines_n<rows>/jobs/*.json`; `tds_n<rows>/*/<task>/` |
| Listing 1 (audit log) | `python -m plotting.paper.listing1` | `audit_log_income/` action log and state history (and the dataset, to name classes) |
| Fig. 5e (evaluation budget b) | `python -m plotting.paper.fig5e` | `budget_pubcov_seed<s>_b<b>/` metrics.json |
| Fig. 5f (seed ratio) and Fig. 8a-8c (full version: seed ratio on PubCov, Diabetes, BM) | `python -m plotting.paper.fig5f` | `seed_ratio_<dataset>_seed<s>_ratio_<r>/` TRIM runs |
| Fig. 5g (adversary knowledge) | `python -m plotting.paper.fig5g` | `background_pubcov/` background_knowledge.csv; `baselines/fig5g_baselines.csv` |
| Cost floor kappa (Exp-5 text) | `python -m plotting.paper.kappa` | `kappa_income_x<x>_seed<s>/` metrics.json, config.json |
| Fig. 5h (retention classes) | `python -m plotting.paper.fig5h` | `enumeration_pubcov_seed<s>/` run_summaries.jsonl |
| Fig. 5i (ranking) | `python -m plotting.paper.fig5i` | `ranking_income_seed<s>/` and `ranking_proxy_refit_income_seed42/` candidate and runtime CSVs |
| Fig. 5j (utility estimation) | `python -m plotting.paper.fig5j` | `estimation_income_{evaluation,calibration}/` estimate CSVs |
| Fig. 5k (structural ablation) | `python -m plotting.paper.fig5k` | `structural_pubcov_seed<s>/` iterations.csv |
| Fig. 5l (selection rules) | `python -m plotting.paper.fig5l` | `selection_<rule>_pubcov_seed<s>/` iterations.csv, state_history.jsonl |
| Fig. 7 (full version: retention vs. removal view) | `python -m plotting.paper.fig7` | `removal_view_<dataset>_seed42/`, `retention_view_<dataset>_seed42/` |

A TRIM or TDS run creates a time-stamped experiment folder under its config's `results_root`; the scripts read the
newest one per config (TDS: per task). TDS's time is read from file times (the last K's `metrics.json` minus
`reference.json`), so copy TDS result folders with their times (`cp -p`, `rsync -t`).

In Fig. 4, Delta U is the increase in test log loss over each method's best output, the full training split included
for the baselines: every curve is shifted so that its lowest-loss point lies at Delta U 0
(`plotting/paper/style/privacy_utility.py`).

## Long-table schema

Baseline points (the baseline harness and TDS) are read as long tables, one row per point and y metric:

| Field | Description |
|---|---|
| `experiment` | Experiment identifier |
| `method` | Method name |
| `dataset` | Dataset key |
| `model` | Model key |
| `seed` | Replicate seed |
| `point` | Operating point identifier |
| `x_metric`, `x_value` | x-axis metric and value (`test_delta_u`) |
| `y_metric`, `y_value` | y-axis metric and value (`min_k` or `tail_risk_p99`) |
| `y_reference` | Per-seed reference of the y metric (K0 for `min_k`, the original P99 tail for `tail_risk_p99`) |
