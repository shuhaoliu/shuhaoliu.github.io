"""Scripts that draw the paper's figures and print its reported numbers (plotting/paper/)."""
