"""Shared helpers of the paper figure scripts: locating run outputs and TRIM's algorithm time to its stop.

Every paper config writes to ``results/<panel>/<config stem>/``. A TRIM or TDS run creates one experiment
directory ``<UTC time>_<id>_<experiment id>[_<label>]`` there; the scripts read the newest experiment directory of
each config stem (TDS: the newest copy of each task), so a repeated run replaces an earlier one without mixing the
two. The baseline harness and the baseline scripts write directly into their config stem's folder.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
SEEDS = (42, 43, 44, 45, 46)
# TRIM's algorithm time: run totals of metrics.json (experiments/exp3_runtime/_metrics.py).
ALGORITHM_TIME_FIELDS = ("candidate_enumeration_total_time_seconds", "selection_time_seconds",
                         "privacy_accounting_time_seconds", "backend_retraining_certification_time_seconds")


def parse_args(panel: str, description: str, extra=None) -> argparse.Namespace:
    """``--results`` (default results/<panel>) and ``--output`` (default figures/<panel>), plus extra arguments."""
    parser = argparse.ArgumentParser(description=description,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--results", type=Path, default=PROJECT_ROOT / "results" / panel,
                        help="Folder holding one subfolder per config stem of configs/paper/%s/." % panel)
    parser.add_argument("--output", type=Path, default=PROJECT_ROOT / "figures" / panel)
    if extra is not None:
        extra(parser)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    return args


def experiment_dirs(results: Path, stem_pattern: str = "*") -> dict[str, Path]:
    """{config stem: newest experiment directory} for the config stems matching ``stem_pattern``."""
    found = {}
    for stem_dir in sorted(results.glob(stem_pattern)):
        if not stem_dir.is_dir():
            continue
        runs = sorted(path for path in stem_dir.iterdir() if path.is_dir() and re.match(r"\d{8}T\d{6}Z_", path.name))
        if runs:
            found[stem_dir.name] = runs[-1]
    return found


def files(results: Path, stem_pattern: str, name_pattern: str) -> list[Path]:
    """Every file matching ``name_pattern`` below the newest experiment directory of each matching config stem."""
    return [path for run in experiment_dirs(results, stem_pattern).values() for path in sorted(run.rglob(name_pattern))]


def one(paths, what: str):
    paths = list(paths)
    if len(paths) != 1:
        raise FileNotFoundError(f"Expected one {what}, found {len(paths)}: {[str(p) for p in paths][:5]}")
    return paths[0]


def read_csv(path: Path) -> list[dict]:
    with Path(path).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def read_jsonl(path: Path) -> list[dict]:
    with Path(path).open(encoding="utf-8") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def trim_run_dirs(results: Path, stem_pattern: str) -> dict[str, Path]:
    """{config stem: TRIM run directory} for configs that run one TRIM task (the folder holding metrics.json)."""
    out = {}
    for stem, run in experiment_dirs(results, stem_pattern).items():
        out[stem] = one((path.parent for path in run.rglob("metrics.json")
                         if (path.parent / "trim_iterations.json").exists()), f"TRIM run below {run}")
    return out


def algorithm_seconds(run_dir: Path) -> float:
    """TRIM's algorithm time of a run: the run totals of retention-class enumeration, candidate selection, privacy
    accounting and model retraining (metrics.json timings).

    This is everything TRIM computes except data loading, the full-data reference fits, the final test evaluation and
    recorded observations; the retraining total holds the fits on D_0, the proxy reference fit and every final check
    (the rule of experiments/exp3_runtime/_metrics.py).
    """
    timings = json.loads((Path(run_dir) / "metrics.json").read_text(encoding="utf-8"))["timings"]
    return math.fsum(float(timings[field]) for field in ALGORITHM_TIME_FIELDS)


def seconds_to_stop(run_dir: Path):
    """TRIM's algorithm time of a run that stops on utility, through its stop (``algorithm_seconds``).

    Returns (seconds, tolerance), or (None, tolerance) when the run ended before a final check passed.
    """
    run_dir = Path(run_dir)
    config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
    metrics = json.loads((run_dir / "metrics.json").read_text(encoding="utf-8"))
    if not config["stop_on_utility"]:
        raise ValueError(f"{run_dir} is a trajectory (stop_on_utility false), not a utility-stopped run.")
    tolerance = float(config["tolerance"])
    if metrics["termination_condition"] != "loss_threshold_met":
        return None, tolerance
    return algorithm_seconds(run_dir), tolerance


def tds_loop_seconds(task_dir: Path) -> float:
    """TDS time under the baselines' rule: the K loop only, after data loading and the full-data reference fit.

    The TDS runner writes reference.json right before its K loop and tds/k_<K>/metrics.json at the end of each K,
    so the loop takes mtime(last metrics.json) - mtime(reference.json). Copy result folders with their file times
    (cp -p, rsync -t) before using this.
    """
    start = (task_dir / "reference.json").stat().st_mtime
    return max(path.stat().st_mtime for path in task_dir.glob("tds/k_*/metrics.json")) - start


def tds_task_dirs(results: Path, stem_pattern: str) -> dict[tuple[str, str], Path]:
    """{(config stem, task): folder} of the TDS tasks (reference.json and tds/k_*/metrics.json), newest copy each.

    One TDS config may be run once per dataset and seed, so every experiment directory is read, not only the newest.
    """
    found = {}
    for stem_dir in sorted(results.glob(stem_pattern)):
        runs = sorted(p for p in stem_dir.iterdir() if p.is_dir() and re.match(r"\d{8}T\d{6}Z_", p.name)) \
            if stem_dir.is_dir() else []
        for run in runs:
            for path in sorted(run.rglob("reference.json")):
                if any(path.parent.glob("tds/k_*/metrics.json")):
                    found[(stem_dir.name, path.parent.name)] = path.parent
    return found


def baseline_files(results: Path, stem_pattern: str, relative_pattern: str) -> list[Path]:
    """Files of the baseline harness and scripts, which write directly into their config stem's folder."""
    return [path for stem_dir in sorted(results.glob(stem_pattern)) if stem_dir.is_dir()
            for path in sorted(stem_dir.glob(relative_pattern))]


def save(fig, output: Path, name: str, dpi: int = 300, png: bool = True) -> Path:
    fig.savefig(output / f"{name}.pdf")
    if png:
        fig.savefig(output / f"{name}.png", dpi=dpi)
    return output / f"{name}.pdf"
