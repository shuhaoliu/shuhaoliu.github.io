"""Scripts that draw the paper's figures and print its reported numbers from the runs of configs/paper/."""
