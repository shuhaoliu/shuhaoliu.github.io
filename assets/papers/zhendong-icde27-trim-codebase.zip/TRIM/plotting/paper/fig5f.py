"""Fig. 5f (seed ratio, Income) and Fig. 8a-8c (the appendix figure of PubCov, Diabetes and BM).

Inputs under --results (default results/fig5f): seed_ratio_<dataset>_seed<s>_ratio_<r>/, one TRIM run per dataset,
seed and seed ratio (experiments.exp5_sensitivity.run_seed_ratio).
Each run stops on utility at epsilon (Income 0.09, PubCov 0.1, Diabetes 0.005, BM 0.01): point of a run = the
release at the stop of its final check; time = algorithm time up to that stop, checks included; leak = -ln(min-K) of
that release. Each panel point is the mean over the seeds whose final check passes; a white marker shows that some
seed's does not.

    python -m plotting.paper.fig5f [--results results/fig5f] [--output figures/fig5f]
"""

from __future__ import annotations

import json
import math
import re
import statistics

import matplotlib.pyplot as plt

from ._common import SEEDS, parse_args, read_jsonl, save, seconds_to_stop, trim_run_dirs

FIGURE_SIZE = (5.5, 5.0)
LABEL_SIZE = 18
LINEWIDTH = 4
MARKER_SIZE = 5
DPI = 300
EPS = {"income": 0.09, "pubcov": 0.1, "diabetes": 0.005, "bm": 0.01}
XTICKS = [0.1, 1.2, 2, 2.8, 4]
PANELS = {  # dataset -> (output name, time limits, leak limits: a 2.5-wide window for every dataset)
    "income": ("fig5f", (0, 180), (-6.0, -3.5)),
    "pubcov": ("fig8a", (0, 40), (-10.5, -8.0)),
    "diabetes": ("fig8b", (0, 175), (-9.5, -6.5)),
    "bm": ("fig8c", (0, 50), (-6.25, -3.75)),
}


def configure_matplotlib():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "DejaVu Sans"],
        "font.size": LABEL_SIZE,
        "axes.labelsize": LABEL_SIZE,
        "xtick.labelsize": LABEL_SIZE,
        "ytick.labelsize": LABEL_SIZE,
        "axes.linewidth": LINEWIDTH,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def draw_linear(ax, ratios, values, hollow, ylabel, ylim):
    ax.plot(ratios, values, color="black", marker="o", markersize=MARKER_SIZE, markerfacecolor="black",
            markeredgecolor="black", markeredgewidth=LINEWIDTH, linewidth=LINEWIDTH)
    pts = [(x, y) for x, y, h in zip(ratios, values, hollow) if h]
    if pts:
        ax.plot(*zip(*pts), linestyle="none", marker="o", markersize=11, markerfacecolor="white",
                markeredgecolor="black", markeredgewidth=3, zorder=3)
    ax.set_ylabel(ylabel)
    ax.set_ylim(*ylim)
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    ax.grid(True, alpha=0.28)


def seed_evicted_in_round0(run_dir):
    """Whether TRIM's first committed round evicts every seed row."""
    history = read_jsonl(run_dir / "state_history.jsonl")
    seed_ids = set(history[0].get("bootstrap_row_ids") or history[0].get("retained_row_ids") or [])
    return len(history) > 1 and seed_ids <= set(history[1].get("evicted_row_ids") or [])


def main():
    args = parse_args("fig5f", __doc__)
    cells = {}
    for stem, run_dir in trim_run_dirs(args.results, "seed_ratio_*").items():
        dataset, seed, ratio = re.match(r"seed_ratio_(\w+?)_seed(\d+)_ratio_(0p\d+)$", stem).groups()
        ratio = float(ratio.replace("p", "."))
        seconds, tolerance = seconds_to_stop(run_dir)
        if tolerance != EPS[dataset]:
            raise ValueError(f"{stem}: tolerance {tolerance} is not the panel's epsilon {EPS[dataset]}.")
        cell = cells.setdefault((dataset, ratio), {"met": [], "evicted": 0, "runs": 0})
        cell["runs"] += 1
        cell["evicted"] += seed_evicted_in_round0(run_dir)
        if seconds is not None:
            metrics = json.loads((run_dir / "metrics.json").read_text(encoding="utf-8"))
            cell["met"].append((int(seed), seconds, -math.log(float(metrics["final_leak_k"]))))
    configure_matplotlib()
    for dataset, (name, tlim, llim) in PANELS.items():
        keys = sorted(r for d, r in cells if d == dataset)
        ratios = [r * 100 for r in keys]
        met = [cells[(dataset, r)]["met"] for r in keys]
        times = [statistics.mean(t for _, t, _ in m) for m in met]
        leaks = [statistics.mean(v for _, _, v in m) for m in met]
        hollow = [len(m) < len(SEEDS) for m in met]
        fig, (ax_top, ax_bottom) = plt.subplots(2, 1, sharex=True, figsize=FIGURE_SIZE,
                                                gridspec_kw={"height_ratios": [1, 1], "hspace": 0.2})
        draw_linear(ax_top, ratios, times, hollow, "Exec. time (s)", tlim)
        ax_top.tick_params(axis="x", which="both", bottom=False, labelbottom=False)
        draw_linear(ax_bottom, ratios, leaks, hollow, "leak", llim)
        ax_bottom.set_xticks(XTICKS)
        ax_bottom.set_xticklabels([f"{x:g}%" for x in XTICKS])
        ax_bottom.set_xlim(ratios[0], ratios[-1])
        ax_bottom.set_xlabel("initial sample ratio")
        fig.subplots_adjust(left=0.17, bottom=0.12, right=0.95, top=0.98)
        save(fig, args.output, name, dpi=DPI)
        plt.close(fig)
        runs = sum(cells[(dataset, r)]["runs"] for r in keys)
        evicted = sum(cells[(dataset, r)]["evicted"] for r in keys)
        print(f"{dataset} (epsilon {EPS[dataset]}): leak {min(leaks):.2f} to {max(leaks):.2f}, "
              f"time {min(times):.0f}-{max(times):.0f} s; round 0 evicts the whole seed in {evicted} of {runs} runs")
        print("  " + " ".join(f"{r:g}%:{t:.0f}s/{v:.2f}{'*' if h else ''}"
                              for r, t, v, h in zip(ratios, times, leaks, hollow)))
        # Appendix text: runs meeting epsilon; seeds below 1% vs above 1.2% (means over the met runs of each group).
        met_runs = sum(len(m) for m in met)
        below = [x for r, m in zip(keys, met) if r < 0.01 for x in m]
        above = [x for r, m in zip(keys, met) if r > 0.012 for x in m]
        lb, la = statistics.mean(v for _, _, v in below), statistics.mean(v for _, _, v in above)
        tb, ta = statistics.mean(t for _, t, _ in below), statistics.mean(t for _, t, _ in above)
        print(f"  meets epsilon in {met_runs} of {runs} runs; below 1% vs above 1.2%: leak {lb:.3f} / {la:.3f} "
              f"(diff {abs(lb - la):.3f}), time {tb:.1f} / {ta:.1f} s ({max(tb, ta) / min(tb, ta):.3f}x)")


if __name__ == "__main__":
    main()
