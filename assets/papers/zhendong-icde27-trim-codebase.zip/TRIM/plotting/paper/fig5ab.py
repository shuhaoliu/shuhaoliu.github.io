"""Fig. 5a (empirical attacks) and Fig. 5b (operational relevance of the leak), Income.

Inputs under --results (default results/fig5ab):
  attacks_income_seed<s>/   TRIM's attack runs (experiments.exp2_attacks.run_exp2_attacks), results.csv;
  baselines_attacks/        baseline_attacks.csv (scripts/attack_baselines.py), the same attacks on each baseline's
                            release at epsilon 0.05;
  inference_average/        inference_average_seed<s>.csv (scripts/attack_inference_average.py): QI inference with
                            every QI in turn as the target, on TRIM's releases from round 3 on.
Every attack error is the smaller of the attack's own error and the error of guessing the most frequent value
(an adversary can always guess), for TRIM and for the baselines.
- Fig. 5a: per method, the mean over seeds 42-46 of the error on its release (TRIM: its final release); labels show
  TRIM's value and each other method's difference from it.
- Fig. 5b: one point per attacked TRIM release from round 3 on (the final release is the last round), pooled over the
  seeds; Delta = error of guessing - attack error; x = leak = -log(min-K / K0). Inference: Delta averaged over the
  targets of inference_average/ (the race attack of Fig. 5a never beats guessing on these releases).

    python -m plotting.paper.fig5ab [--results results/fig5ab] [--output figures/fig5ab]
"""

from __future__ import annotations

import math
import statistics
from collections import namedtuple

from ._common import SEEDS, baseline_files, files, parse_args, read_csv
from .style import attacks, two_error

Bar = namedtuple("Bar", "method reconstruction_error linkage_error")
BASELINES = ("PAT", "FeatSel", "FIDO", "EntryWise")


def attack_error(row, attack, guess):
    """Error of the attack in column ``attack``, counted as guessing when the attack does worse than guessing."""
    return min(float(row[attack]), float(row[guess]))


def main():
    args = parse_args("fig5ab", __doc__)
    trim = [row for path in files(args.results, "attacks_income_seed*", "results.csv") for row in read_csv(path)]
    base = [row for path in baseline_files(args.results, "baselines*", "baseline_attacks.csv") for row in read_csv(path)]
    seeds = sorted(int(s) for s in SEEDS)
    final = [r for r in trim if r["release_point"] == "final"]
    if sorted(int(r["seed"]) for r in final) != seeds:
        raise ValueError(f"TRIM final releases for seeds {sorted(r['seed'] for r in final)}, expected {seeds}")
    bars = [Bar("TRIM",
                statistics.mean(attack_error(r, "reconstruction_error", "reconstruction_baseline_error") for r in final),
                statistics.mean(attack_error(r, "linkage_error", "linkage_baseline_error") for r in final))]
    for method in BASELINES:
        rows = [r for r in base if r["method"] == method]
        if sorted(int(r["seed"]) for r in rows) != seeds:
            raise ValueError(f"{method}: seeds {sorted(r['seed'] for r in rows)}, expected {seeds}")
        bars.append(Bar(method,
                        statistics.mean(attack_error(r, "reconstruction_test_reconstruction_error_mean",
                                                     "reconstruction_baseline_test_reconstruction_error_mean")
                                        for r in rows),
                        statistics.mean(attack_error(r, "linkage_test_linkage_error",
                                                     "linkage_baseline_test_linkage_error") for r in rows)))
    for bar in bars:
        print(f"{bar.method:12s} reconstruction {bar.reconstruction_error:.4f}  inference {bar.linkage_error:.4f}")
    attacks.plot(bars, args.output, "fig5a")
    inference = {}
    for path in baseline_files(args.results, "inference_average", "inference_average_seed*.csv"):
        for row in read_csv(path):
            inference.setdefault((int(row["seed"]), row["release_point"]), []).append(row)
    points = []
    for r in trim:
        if r["release_point"] == "final" or int(r["iteration"]) < two_error.DEFAULT_MIN_ITERATION:
            continue
        targets = inference.get((int(r["seed"]), r["release_point"]))
        if not targets:
            raise ValueError(f"No averaged inference for seed {r['seed']} {r['release_point']} (inference_average/).")
        average_error = statistics.mean(attack_error(t, "test_linkage_error", "baseline_test_linkage_error")
                                        for t in targets)
        average_guess = statistics.mean(float(t["baseline_test_linkage_error"]) for t in targets)
        points.append(two_error.Point(
            iteration=int(r["iteration"]),
            x=-math.log(float(r["min_k"]) / float(r["original_leak_k"])),
            linkage_error=average_error,
            reconstruction_error=attack_error(r, "reconstruction_error", "reconstruction_baseline_error"),
            baseline_linkage_error=average_guess,
            baseline_reconstruction_error=float(r["reconstruction_baseline_error"])))
    points.sort(key=lambda p: (p.x, p.iteration))
    for p in points:
        print(f"leak {p.x:7.3f}  dInfer {p.baseline_linkage_error - p.linkage_error:+.4f}  "
              f"dRecon {p.baseline_reconstruction_error - p.reconstruction_error:+.4f}")
    two_error.plot_points(points, args.output, "fig5b")


if __name__ == "__main__":
    main()
