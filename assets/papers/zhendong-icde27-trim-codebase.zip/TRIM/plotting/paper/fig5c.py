"""Fig. 5c (relative execution time, MLP target) and the shared Fig. 5a-5d legend.

Inputs under --results (default results/fig5c):
  runtime_<dataset>_seed<s>/   TRIM runs (experiments.exp3_runtime.run_execution_time);
  baselines/                   timing records jobs/<dataset>_seed<s>_mlp.json (scripts/time_baselines.py);
  tds/                         TDS runs (reference.json and tds/k_*/metrics.json per task).
Times:
  TRIM       algorithm time until its final check passes: in the initial state and after each round, when the
             proxy's validation Delta U on D_t is within epsilon, TRIM retrains the target model on the release and
             checks validation Delta U <= epsilon; it stops when that check passes. The time includes the checks.
             Epsilon: Income 0.09, PubCov 0.1, Diabetes 0.005, BM 0.01 (the smallest epsilon every method meets on
             all five seeds);
  FeatSel, EntryWise, FIDO
             the harness's method loop (every release of the method's grid generated, privacy-scored and fitted,
             after data loading and the full-data reference fit);
  PAT        the grid fits in PAT's environment plus its harness loop;
  TDS        its K loop under the same rule (last K's metrics.json minus reference.json, file times).
Bar = mean seconds of the method / mean seconds of TRIM over seeds 42-46.

    python -m plotting.paper.fig5c [--results results/fig5c] [--output figures/fig5c]
"""

from __future__ import annotations

import csv
import json
import re
import statistics

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402

from ._common import SEEDS, baseline_files, parse_args, seconds_to_stop, tds_loop_seconds, tds_task_dirs, \
    trim_run_dirs  # noqa: E402
from .style import legend  # noqa: E402

# dataset key of the configs -> (dataset key of the baseline runs, epsilon, tick label)
DATASETS = {
    "income": ("income", 0.09, r"$\mathtt{Income}$"),
    "pubcov": ("pubcov", 0.1, r"$\mathtt{PubCov}$"),
    "diabetes": ("diabetes", 0.005, r"$\mathtt{Diabetes}$"),
    "bm": ("bm_halfmonth", 0.01, r"$\mathtt{BM}$"),
}
PLOT_METHODS = ("TRIM", "PAT", "FeatSel", "EntryWise", "FIDO", "TDS")
METHOD_STYLES = {
    "TRIM": {"color": "black", "hatch": ""},
    "PAT": {"color": "#0072B2", "hatch": "//"},
    "FeatSel": {"color": "#E69F00", "hatch": "oo"},
    "EntryWise": {"color": "#d62728", "hatch": "++"},
    "FIDO": {"color": "#009E73", "hatch": "xx"},
    "TDS": {"color": "#882255", "hatch": "\\\\"},
}
FIGURE_SIZE = (5.5, 5.0)
LINEWIDTH = 4
DPI = 300
BAR_WIDTH = 0.13


def load_seconds(results):
    """{dataset: {method: {seed: seconds}}}."""
    seconds = {key: {} for key in DATASETS}
    harness_keys = {harness: key for key, (harness, _eps, _label) in DATASETS.items()}
    for stem, run_dir in trim_run_dirs(results, "runtime_*_seed*").items():
        key, seed = re.match(r"runtime_(\w+)_seed(\d+)$", stem).groups()
        value, tolerance = seconds_to_stop(run_dir)
        if tolerance != DATASETS[key][1]:
            raise ValueError(f"TRIM {stem}: tolerance {tolerance} is not the panel's epsilon {DATASETS[key][1]}.")
        if value is None:
            raise ValueError(f"TRIM {stem}: the run ended before its final check passed.")
        seconds[key].setdefault("TRIM", {})[int(seed)] = value
    for path in baseline_files(results, "baselines*", "jobs/*.json"):
        record = json.loads(path.read_text(encoding="utf-8"))
        if record.get("model") != "mlp" or record.get("dataset") not in harness_keys:
            continue
        key = harness_keys[record["dataset"]]
        for method, name in (("fido", "FIDO"), ("entrywise", "EntryWise"), ("featsel", "FeatSel"), ("pat", "PAT")):
            entry = record["methods"].get(method, {})
            if entry.get("status") == "complete":
                seconds[key].setdefault(name, {})[int(record["seed"])] = entry["seconds"]
    for task_dir in tds_task_dirs(results, "tds*").values():
        k_metrics = [json.loads(p.read_text(encoding="utf-8")) for p in task_dir.glob("tds/k_*/metrics.json")]
        if k_metrics[0]["model"] != "mlp":
            continue
        if any(m.get("tree_cache_hit") for m in k_metrics):
            raise ValueError(f"TDS {task_dir}: a K reused a cached tree; time it from an empty cache.")
        key = harness_keys.get(k_metrics[0]["dataset"], k_metrics[0]["dataset"])
        seconds[key].setdefault("TDS", {})[int(k_metrics[0]["seed"])] = tds_loop_seconds(task_dir)
    for key, methods in seconds.items():
        for method in PLOT_METHODS:
            if sorted(methods.get(method, {})) != list(SEEDS):
                raise ValueError(f"{method} {key}: seeds {sorted(methods.get(method, {}))}, expected {list(SEEDS)}")
    return seconds


def plot(method_ratios, output):
    legend.configure_matplotlib()
    fig, ax = plt.subplots(figsize=FIGURE_SIZE)
    centers = list(range(len(DATASETS)))
    offsets = [(i - (len(PLOT_METHODS) - 1) / 2.0) * BAR_WIDTH for i in range(len(PLOT_METHODS))]
    for index, method in enumerate(PLOT_METHODS):
        style = METHOD_STYLES[method]
        ax.bar([x + offsets[index] for x in centers], [method_ratios[key][method] for key in DATASETS],
               width=BAR_WIDTH, color=style["color"], hatch=style["hatch"], edgecolor="black", linewidth=0.8,
               label=method)
    ax.set_xticks(centers)
    ax.set_xticklabels([label for _harness, _eps, label in DATASETS.values()])
    ax.set_ylabel("Execution time (x)")
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    ax.set_yscale("log")
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _position: f"{value:g}"))
    ax.axhline(1.0, color="0.35", linewidth=1.5, linestyle="--", zorder=0.5)
    ax.grid(True, axis="y", which="major", alpha=0.28)
    fig.subplots_adjust(left=0.18, bottom=0.07, right=0.97, top=0.97)
    fig.savefig(output / "fig5c.png", dpi=DPI)
    fig.savefig(output / "fig5c.pdf")
    plt.close(fig)


def main():
    args = parse_args("fig5c", __doc__)
    seconds = load_seconds(args.results)
    ratios = {key: {m: statistics.mean(methods[m].values()) / statistics.mean(methods["TRIM"].values())
                    for m in PLOT_METHODS} for key, methods in seconds.items()}
    plot(ratios, args.output)
    legend.plot_legend(args.output, "fig5_legend")
    with (args.output / "fig5c_times.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["dataset", "epsilon", "method", "mean_seconds", "ratio_to_trim_mean", "per_seed_ratio_min",
                         "per_seed_ratio_max"])
        for key, (_harness, eps, _label) in DATASETS.items():
            trim = seconds[key]["TRIM"]
            for method in PLOT_METHODS:
                per_seed = [seconds[key][method][s] / trim[s] for s in SEEDS]
                writer.writerow([key, eps, method, f"{statistics.mean(seconds[key][method].values()):.1f}",
                                 f"{ratios[key][method]:.3f}", f"{min(per_seed):.3f}", f"{max(per_seed):.3f}"])
    for key in DATASETS:
        print(key, {method: round(value, 3) for method, value in ratios[key].items()})
    print("PAT / TRIM:", ", ".join(f"{key} {ratios[key]['PAT']:.2f}x" for key in DATASETS))


if __name__ == "__main__":
    main()
