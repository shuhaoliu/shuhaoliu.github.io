"""Fig. 5k (structural ablation, PubCov) and its text number.

Inputs under --results (default results/fig5k): structural_pubcov_seed<s>/ (experiments.exp6_ablation.run_structural),
iterations.csv with every arm's states. Curve at Delta U = x: per arm and seed the lowest leak (top) or leak T
(bottom) among the states with test Delta U <= x, the original data (0, 0) always counting; then the mean over seeds
42-46, up to Delta U 0.06. Leak = -log(min-K / K0); leak T = the P99 tail as recorded.
Text number: at each leak that RefineEvict's mean curve reaches, its Delta U over TRIM's.

    python -m plotting.paper.fig5k [--results results/fig5k] [--output figures/fig5k]
"""

from __future__ import annotations

import math
import re

from ._common import SEEDS, files, parse_args, read_csv
from .style import ablation_line

# TRIM-H last: its whole curve is the origin (leak 0 by construction), so it is drawn on top to stay visible.
METHODS = ["TRIM", "TRIM-V", "RefineOnly", "RefineEvict", "TRIM-H"]
XMAX = 0.06
STEP = 0.0025


def states_by_seed(results):
    states = {m: {} for m in METHODS}
    for path in files(results, "structural_pubcov_seed*", "iterations.csv"):
        seed = int(re.search(r"seed(\d+)", path.relative_to(results).parts[0]).group(1))
        for r in read_csv(path):
            if r["method"] in states:
                states[r["method"]].setdefault(seed, []).append(
                    (float(r["test_loss"]) - float(r["baseline_test_loss"]),
                     -math.log(float(r["min_k"]) / float(r["original_leak_k"])), float(r["tail_risk_p99"])))
    for method in METHODS:
        if sorted(states[method]) != list(SEEDS):
            raise ValueError(f"{method}: seeds {sorted(states[method])}, expected {list(SEEDS)}")
    return {m: [states[m][s] for s in SEEDS] for m in METHODS}


def main():
    args = parse_args("fig5k", __doc__)
    states = states_by_seed(args.results)
    top = min(max(d for runs in states.values() for run in runs for d, _, _ in run), XMAX)
    grid = [round(STEP * i, 4) for i in range(0, int(math.ceil(top / STEP)) + 1)]
    # With the step bound, RefineOnly's first move admits every record at full suppression; from then on it is
    # TRIM-V, so the two mean curves coincide. TRIM-V is drawn on top with offset markers so both stay visible.
    extra = {"TRIM-V": {"zorder": 3, "markevery": (2, 4)}}
    ablation_line.draw_mean(states, METHODS, grid, args.output, "fig5k", styles_extra=extra)
    ratio_grid = [round(STEP * i, 4) for i in range(0, int(round(XMAX / STEP)) + 1)]
    trim = ablation_line.mean_curve(states["TRIM"], 1, ratio_grid)
    evict = ablation_line.mean_curve(states["RefineEvict"], 1, ratio_grid)

    def first_x(ys, level):
        return next((x for x, y in zip(ratio_grid, ys) if y <= level + 1e-12), None)

    ratios = []
    for level in sorted({round(y, 6) for y in evict if y < 0}, reverse=True):
        xr, xt = first_x(evict, level), first_x(trim, level)
        if xr and xt:
            ratios.append(xr / xt)
            print(f"leak {level:7.3f}: RefineEvict Delta U {xr:.4f}, TRIM {xt:.4f}, ratio {xr / xt:.2f}")
    print(f"RefineEvict / TRIM Delta U over {len(ratios)} leak levels: {min(ratios):.2f}-{max(ratios):.2f}x")


if __name__ == "__main__":
    main()
