"""Fig. 5a style: attack errors per method (bars; labels show TRIM's value and the others' difference)."""

import math
from pathlib import Path

import matplotlib.pyplot as plt

LABEL_SIZE = 18
BAR_WIDTH = 0.68
DPI = 300
FIGURE_SIZE = (5.5, 5.0)
LINEWIDTH = 4
BAR_LABEL_OFFSET = 0.02
BAR_LABEL_HEADROOM = 0.10
BAR_LABEL_SIZE = 14
X_TICK_SIZE = 14
Y_TICK_SIZE = LABEL_SIZE
# Colors and hatches of the Fig. 5a-5d legend (style/legend.py).
METHOD_STYLES = {
    "TRIM": {"color": "black", "hatch": ""},
    "PAT": {"color": "#0072B2", "hatch": "//"},
    "FeatSel": {"color": "#E69F00", "hatch": "oo"},
    "FIDO": {"color": "#009E73", "hatch": "xx"},
    "EntryWise": {"color": "#d62728", "hatch": "++"},
}


def configure_matplotlib():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "DejaVu Sans"],
            "font.size": LABEL_SIZE,
            "axes.labelsize": LABEL_SIZE,
            "xtick.labelsize": X_TICK_SIZE,
            "ytick.labelsize": Y_TICK_SIZE,
            "axes.linewidth": LINEWIDTH,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

def format_bar_label(value, *, show_sign=False):
    if not math.isfinite(value):
        return "n/a"
    if abs(value) < 0.005:
        return "0"
    return f"{value:+.2f}" if show_sign else f"{value:.2f}"

def draw_metric_bars(ax, bars, metric_name, ylabel):
    values = [getattr(bar, metric_name) for bar in bars]
    trim_value = next(
        (value for bar, value in zip(bars, values) if bar.method == "TRIM" and math.isfinite(value)),
        math.nan,
    )
    for index, bar in enumerate(bars):
        style = METHOD_STYLES[bar.method]
        value = values[index]
        missing = not math.isfinite(value)
        height = 0.0 if missing else value
        ax.bar(
            index,
            height,
            width=BAR_WIDTH,
            color=style["color"],
            hatch=style["hatch"],
            edgecolor="black",
            linewidth=LINEWIDTH,
        )
        if bar.method == "TRIM":
            label = format_bar_label(value)
        else:
            label = format_bar_label(value - trim_value, show_sign=True)
        if missing:
            label_y = BAR_LABEL_OFFSET
            va = "bottom"
        elif value < 0:
            label_y = value - BAR_LABEL_OFFSET
            va = "top"
        else:
            label_y = value + BAR_LABEL_OFFSET
            va = "bottom"
        ax.text(index, label_y, label, ha="center", va=va, fontsize=BAR_LABEL_SIZE)

    ax.set_xticks(list(range(len(bars))))
    ax.set_xticklabels([bar.method for bar in bars], rotation=0, ha="center")
    ax.set_ylabel(ylabel)
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    ax.grid(True, axis="y", alpha=0.28)
    finite = [value for value in values if math.isfinite(value)]
    if finite:
        y_max = max(finite)
        y_limit = y_max + BAR_LABEL_OFFSET + BAR_LABEL_HEADROOM
        ax.set_ylim(0.0, y_limit if y_max > 0 else 1.0)

def plot(bars, output_dir, name):
    """Reconstruction error (top) and inference error (bottom) of each method's release, as <name>.png/.pdf."""
    configure_matplotlib()
    fig, (ax_top, ax_bottom) = plt.subplots(
        2,
        1,
        figsize=FIGURE_SIZE,
        sharex=True,
        gridspec_kw={"height_ratios": [1, 1], "hspace": 0.20},
    )
    draw_metric_bars(ax_top, bars, "reconstruction_error", "Recon. error")
    ax_top.tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    draw_metric_bars(ax_bottom, bars, "linkage_error", "Infer. error")

    output_dir = Path(output_dir).expanduser().resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    fig.subplots_adjust(left=0.18, bottom=0.07, right=0.97, top=0.98)
    png_path = output_dir / f"{name}.png"
    pdf_path = output_dir / f"{name}.pdf"
    fig.savefig(png_path, dpi=DPI)
    fig.savefig(pdf_path)
    plt.close(fig)
    return png_path, pdf_path
