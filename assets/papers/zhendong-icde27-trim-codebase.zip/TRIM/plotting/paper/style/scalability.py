"""Fig. 5d style: execution time against the number of rows (log x axis, linear time axis)."""

import math

import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, NullFormatter

FIGURE_SIZE = (5.5, 5.0)
LABEL_SIZE = 18
TICK_SIZE = 18
X_TICK_LABEL_SIZE = 14
LINEWIDTH = 4
PLOT_LINEWIDTH = 4
MARKER_SIZE = 8
# FIDO's curve lies near 0 s; it is drawn 200 s higher so that it stays visible above the axis.
FIDO_PLOT_Y_OFFSET_SECONDS = 200
DPI = 300
Y_TICKS = (0, 2000, 4000, 6000)
METHOD_ORDER = ("TRIM", "FIDO", "PAT", "FeatSel", "EntryWise", "TDS")
METHOD_STYLES = {
    "TRIM": {"color": "black", "marker": "o", "linestyle": "-", "linewidth": LINEWIDTH},
    "FIDO": {"color": "#009E73", "marker": "D", "linestyle": "-", "linewidth": LINEWIDTH, "markersize": 8,
             "markerfacecolor": "#009E73", "markeredgecolor": "#009E73", "markeredgewidth": 1.4},
    "PAT": {"color": "#0072B2", "marker": "s", "linestyle": "-.", "linewidth": LINEWIDTH * 0.8,
            "markersize": MARKER_SIZE * 0.8, "markerfacecolor": "#0072B2", "markeredgecolor": "#0072B2"},
    "FeatSel": {"color": "#E69F00", "marker": "^", "linestyle": "--", "linewidth": LINEWIDTH * 0.8 + 1,
                "markersize": MARKER_SIZE * 0.8 + 1, "markerfacecolor": "#E69F00", "markeredgecolor": "#E69F00"},
    "EntryWise": {"color": "#d62728", "marker": "p", "linestyle": (0, (0.1, 1.1)), "linewidth": LINEWIDTH,
                  "markersize": MARKER_SIZE + 1, "markerfacecolor": "#d62728", "markeredgecolor": "#d62728"},
    "TDS": {"color": "#882255", "marker": "X", "linestyle": (0, (4, 1)), "linewidth": LINEWIDTH * 0.8,
            "markersize": MARKER_SIZE + 2, "markerfacecolor": "#882255", "markeredgecolor": "#882255"},
}


def configure_matplotlib():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "DejaVu Sans"],
        "font.size": LABEL_SIZE,
        "axes.labelsize": LABEL_SIZE,
        "xtick.labelsize": TICK_SIZE,
        "ytick.labelsize": TICK_SIZE,
        "axes.linewidth": LINEWIDTH,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def nrows_label(nrows):
    if nrows >= 1000 and nrows % 1000 == 0:
        return f"{nrows // 1000}k"
    if nrows >= 1000:
        return f"{nrows / 1000:g}k"
    return str(nrows)


def seconds_label(seconds):
    if seconds >= 1000 and seconds % 1000 == 0:
        return f"{int(seconds) // 1000}k"
    if seconds >= 1000:
        return f"{seconds / 1000:g}k"
    return f"{seconds:g}"


def plot(points, output_dir, hollow=frozenset()):
    """Draw {method: [(rows, seconds)]}; TDS markers at the row counts in ``hollow`` are drawn white-filled.

    The time axis ends 1% above the largest curve.
    """
    configure_matplotlib()
    fig, ax = plt.subplots(figsize=FIGURE_SIZE)
    all_xs = []
    for method in [m for m in METHOD_ORDER if points.get(m)]:
        xs = [x for x, _ in points[method]]
        ys = [y + FIDO_PLOT_Y_OFFSET_SECONDS if method == "FIDO" else y for _, y in points[method]]
        all_xs.extend(xs)
        style = METHOD_STYLES[method]
        line = ax.plot(xs, ys, color=style["color"], marker=style["marker"], linestyle=style["linestyle"],
                       linewidth=style.get("linewidth", PLOT_LINEWIDTH), markersize=style.get("markersize", MARKER_SIZE),
                       markerfacecolor=style.get("markerfacecolor", style["color"]),
                       markeredgecolor=style.get("markeredgecolor", style["color"]),
                       markeredgewidth=style.get("markeredgewidth", 1.0), label="_nolegend_")
        if method == "TDS":
            # Filled where every seed meets the utility tolerance, white-filled where some seeds do not.
            line[0].set_marker("None")
            for x, y in zip(xs, ys):
                ax.plot([x], [y], linestyle="None", marker=style["marker"], markersize=style["markersize"],
                        markeredgewidth=1.6, markerfacecolor="white" if x in hollow else style["color"],
                        markeredgecolor=style["color"], zorder=6)
    ax.set_xscale("log")
    ax.set_yscale("linear")
    ax.set_xlabel("Rows")
    ax.set_ylabel("Execution time (s)")
    ax.grid(True, which="major", axis="both", alpha=0.28)
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    xs = sorted(set(all_xs))
    ax.set_xticks(xs)
    ax.set_xticklabels([nrows_label(row) for row in xs], rotation=35, ha="right", fontsize=X_TICK_LABEL_SIZE)
    ax.xaxis.set_minor_formatter(NullFormatter())
    ax.set_xlim(min(xs), max(xs))
    ax.set_yticks(Y_TICKS)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _position: seconds_label(value)))
    ax.yaxis.set_minor_formatter(NullFormatter())
    top = max(y for method_points in points.values() for _, y in method_points if math.isfinite(y))
    ax.set_ylim(0, top * 1.01)
    fig.subplots_adjust(left=0.14, bottom=0.16, right=0.98, top=0.98)
    output_dir.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_dir / "fig5d.png", dpi=DPI)
    fig.savefig(output_dir / "fig5d.pdf")
    plt.close(fig)
    return output_dir / "fig5d.pdf"
