"""Fig. 5h style: one black bar per retention-class enumeration method."""

import math

import matplotlib.pyplot as plt

# x-axis order of the enumeration methods; every bar is solid black.
METHODS = ["TRIM", "Sample", "KMeans", "IL", "RandomSplit"]

FIGURE_SIZE = (5.5, 5.0)

LABEL_SIZE = 18

LINEWIDTH = 4

BAR_WIDTH = 0.55

XTICK_SIZE = 14

BAR_VALUE_LABEL_SIZE = 14

def configure_matplotlib():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "DejaVu Sans"],
            "font.size": LABEL_SIZE,
            "axes.labelsize": LABEL_SIZE,
            "xtick.labelsize": XTICK_SIZE,
            "ytick.labelsize": LABEL_SIZE,
            "axes.linewidth": LINEWIDTH,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

def format_bar_value(value):
    if abs(value) < 0.005:
        value = 0.0
    abs_value = abs(value)
    if abs_value >= 1000:
        return f"{value:.1e}"
    if abs_value >= 100:
        return f"{value:.0f}"
    if abs_value >= 10:
        return f"{value:.1f}"
    return f"{value:.2f}"

def draw_bars(ax, values, ylabel, log_y=False):
    x_centers = list(range(len(METHODS)))
    finite_values = [value for value in values if math.isfinite(value)]
    positive_values = [value for value in finite_values if value > 0]
    max_positive = max(positive_values) if positive_values else math.nan
    linear_padding = 0.03
    if finite_values:
        value_range = max(finite_values) - min(finite_values)
        max_abs_value = max(abs(value) for value in finite_values)
        linear_padding = max(value_range * 0.03, max_abs_value * 0.02, 0.03)
    for i in range(len(METHODS)):
        value = values[i]
        height = value if value == value else 0.0  # NaN -> 0
        ax.bar(
            i,
            height,
            width=BAR_WIDTH,
            color="black",
            hatch="",
            edgecolor="black",
            linewidth=LINEWIDTH,
        )
        if math.isfinite(value):
            label_color = "black"
            if log_y:
                if value <= 0:
                    continue
                if math.isfinite(max_positive) and value >= max_positive * 0.5 and value > 10:
                    label_y = value / 1.3
                    label_va = "top"
                    label_color = "white"
                else:
                    label_y = value * 1.08
                    label_va = "bottom"
            elif value > 0 or min(finite_values) >= 0:
                label_y = value + linear_padding
                label_va = "bottom"
            else:
                label_y = value - linear_padding
                label_va = "top"
            ax.text(
                i,
                label_y,
                format_bar_value(value),
                ha="center",
                va=label_va,
                fontsize=BAR_VALUE_LABEL_SIZE,
                color=label_color,
                clip_on=False,
            )
    ax.set_xticks(x_centers)
    ax.set_xticklabels(METHODS, fontsize=XTICK_SIZE)
    ax.set_ylabel(ylabel)
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    if log_y:
        ax.set_yscale("log")
        positive = [v for v in values if v == v and v > 0]
        if positive:
            min_exponent = math.floor(math.log2(min(positive)))
            max_exponent = math.ceil(math.log2(max(positive)))
            tick_exponents = range(max(0, min_exponent), max_exponent + 1)
            ticks = [2**exponent for exponent in tick_exponents]
            if not ticks:
                ticks = [1]
            tick_labels = [f"{int(tick):g}" for tick in ticks]
            ax.set_yticks(ticks)
            ax.set_yticklabels(tick_labels)
            ax.set_ylim(min(positive) / 1.2, ticks[-1] * 1.5)
        ax.axhline(
            1.0,
            color="0.35",
            linewidth=1.5,
            linestyle="--",
            zorder=0.5,
        )
    elif finite_values:
        min_tick = int(2 * math.floor(min(finite_values) / 2))
        max_tick = int(2 * math.ceil(max(finite_values) / 2))
        if min_tick == max_tick:
            min_tick -= 2
            max_tick += 2
        ticks = list(range(min_tick, max_tick + 1, 2))
        ax.set_yticks(ticks)
        ax.set_ylim(min_tick - 0.6, max_tick + 0.6)
    ax.grid(True, alpha=0.28)
