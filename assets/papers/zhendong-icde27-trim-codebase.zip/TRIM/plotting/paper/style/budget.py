"""Fig. 5e style: execution time (top) and leak (bottom) against the evaluation budget b."""

import math

import matplotlib.pyplot as plt

FIGURE_SIZE = (5.5, 5.0)

LABEL_SIZE = 18

Y_LABEL_SIZE = 16

LINEWIDTH = 4

MARKER_SIZE = 5


def configure_matplotlib():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "DejaVu Sans"],
            "font.size": LABEL_SIZE,
            "axes.labelsize": LABEL_SIZE,
            "xtick.labelsize": LABEL_SIZE,
            "ytick.labelsize": 14,
            "axes.linewidth": LINEWIDTH,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

def finite_float(value, default=math.nan):
    if value is None:
        return default
    try:
        return float(value)
    except (TypeError, ValueError):
        return default

def display_leak_value(leak_k):
    value = finite_float(leak_k)
    if not math.isfinite(value) or value <= 0:
        return math.nan
    result = -math.log(value)
    if abs(result) < 1e-12:
        return 0.0
    return result


def draw_line(ax, budgets, values, ylabel):
    x_values = list(budgets)
    y_values = [value if math.isfinite(value) else math.nan for value in values]
    ax.plot(
        x_values,
        y_values,
        color="black",
        marker="o",
        markersize=MARKER_SIZE,
        linewidth=LINEWIDTH,
    )
    ax.set_xticks(x_values)
    ax.set_xticklabels([str(b) for b in budgets])
    ax.set_ylabel(ylabel, fontsize=Y_LABEL_SIZE)
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    ax.grid(True, axis="y", alpha=0.28)
