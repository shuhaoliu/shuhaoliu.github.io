"""Fig. 5g style: leak (top) and worst-case re-identification success (bottom) against the number of known QIs."""

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from matplotlib.ticker import FixedLocator, MultipleLocator  # noqa: E402
from matplotlib.transforms import ScaledTranslation  # noqa: E402

DEFAULT_DPI = 300
FIGURE_SIZE = (5.5, 5.0)
LABEL_SIZE = 18
LINEWIDTH = 4
MARKER_SIZE = 9
LEAK_LIMITS = (-12.0, 1.0)
METHOD_STYLES = {
    "TRIM": {"color": "black", "marker": "o", "linestyle": "-", "linewidth": LINEWIDTH, "zorder": 5},
    "PAT": {"color": "#0072B2", "marker": "s", "linestyle": (0, (2, 0.5, 0.5, 0.5)), "linewidth": LINEWIDTH * 0.8,
            "markersize": MARKER_SIZE * 0.8, "markerfacecolor": "#0072B2", "markeredgecolor": "#0072B2", "zorder": 4},
    "FeatSel": {"color": "#E69F00", "marker": "^", "linestyle": (0, (2, 0.5)), "linewidth": LINEWIDTH * 0.8 + 1,
                    "markersize": MARKER_SIZE * 0.8 + 1, "markerfacecolor": "#E69F00", "markeredgecolor": "#E69F00",
                    "zorder": 2},
    "EntryWise": {"color": "#d62728", "marker": "p", "linestyle": (0, (0.1, 1.1)), "linewidth": LINEWIDTH,
                      "markerfacecolor": "#d62728", "markeredgecolor": "#d62728", "markeredgewidth": 1.6,
                      "dash_capstyle": "round", "zorder": 3},
    "FIDO": {"color": "#009E73", "marker": "D", "linestyle": "-", "linewidth": LINEWIDTH,
             "markerfacecolor": "#009E73", "markeredgecolor": "#009E73", "markeredgewidth": 1.4, "zorder": 1},
    # Drawn above TRIM's thicker line, which it follows closely.
    "TDS": {"color": "#882255", "marker": "X", "linestyle": (0, (4, 1)), "linewidth": LINEWIDTH * 0.8,
            "markersize": 10, "markerfacecolor": "#882255", "markeredgecolor": "#882255", "zorder": 5.5},
}
# Vertical offsets of curves that coincide (leak 0), so that they do not hide each other.
TOP_PANEL_Y_OFFSETS = {"TRIM": 0.0, "PAT": -0.12, "FeatSel": -0.24, "EntryWise": -0.36, "FIDO": -0.48}


def configure_matplotlib():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "DejaVu Sans"],
        "font.size": LABEL_SIZE,
        "axes.labelsize": LABEL_SIZE,
        "xtick.labelsize": LABEL_SIZE,
        "ytick.labelsize": LABEL_SIZE,
        "axes.linewidth": LINEWIDTH,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def plot_results(summary_frame, offsets, output_png, output_pdf, first=1, last=10):
    """Rows: method, known_attribute_count, worst_success_probability, success_drawn (bottom panel values)."""
    configure_matplotlib()
    methods = list(dict.fromkeys(summary_frame["method"].tolist()))
    fig, (ax_top, ax_bottom) = plt.subplots(2, 1, sharex=False, figsize=FIGURE_SIZE,
                                            gridspec_kw={"height_ratios": [1, 1], "hspace": 0.2})
    for method in methods:
        frame = summary_frame[summary_frame["method"] == method]
        style = dict(METHOD_STYLES[method])
        marker_size = style.pop("markersize", MARKER_SIZE)
        worst = frame["worst_success_probability"].astype(float).to_numpy()
        if np.any(worst <= 0.0):
            raise ValueError("worst_success_probability must be positive for log plotting.")
        ax_top.plot(frame["known_attribute_count"], np.log(worst) + offsets.get(method, 0.0),
                    markersize=marker_size, alpha=0.95, label=method, **style)
        ax_bottom.plot(frame["known_attribute_count"], frame["success_drawn"], markersize=marker_size, alpha=0.95,
                       label=method, **style)
    ax_bottom.set_yscale("log")
    ax_bottom.set_ylim(1e-6, 3.0)
    for axis in (ax_top, ax_bottom):
        axis.grid(True, alpha=0.28)
        axis.tick_params(width=LINEWIDTH)
        for spine in axis.spines.values():
            spine.set_linewidth(LINEWIDTH)
    ax_top.set_ylabel("leak")
    ax_bottom.set_ylabel("Worst-case re-ID success", fontsize=16)
    ax_bottom.set_xlabel("# Known QI attributes")
    for axis in (ax_top, ax_bottom):
        axis.set_xlim(first, last)
    ax_bottom.set_xticks(range(first, last + 1))
    ax_top.set_xticks(range(first, last + 1))
    shift = ScaledTranslation(-8 / 72, 0, fig.dpi_scale_trans)
    tick_labels = ax_bottom.get_xticklabels()
    if tick_labels:
        tick_labels[-1].set_transform(tick_labels[-1].get_transform() + shift)
    ax_top.spines["bottom"].set_visible(True)
    ax_top.tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    ax_bottom.spines["top"].set_visible(True)
    ax_top.set_ylim(*LEAK_LIMITS)
    ax_top.yaxis.set_major_locator(MultipleLocator(5))
    ax_bottom.yaxis.set_major_locator(FixedLocator([1e-6, 1e-4, 1e-2, 1e0]))
    fig.subplots_adjust(left=0.20, bottom=0.14, right=0.97, top=0.98)
    fig.savefig(output_png, dpi=DEFAULT_DPI)
    fig.savefig(output_pdf)
    plt.close(fig)
