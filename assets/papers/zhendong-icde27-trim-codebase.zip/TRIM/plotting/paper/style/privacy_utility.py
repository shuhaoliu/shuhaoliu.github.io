"""Fig. 4 style: the privacy--utility curves of TRIM and the baselines, one dataset and target model per panel.

Each panel stacks the worst-case leak -log(K/K0) (top) over the P99 tail leak, leak T (bottom), both against test
Delta U.

Points:
  TRIM       every round of the search, from the trajectory.csv files: the round's release, its test Delta U, min-K
             and tail leak;
  baselines  every operating point of the method's sweep, from long tables (plotting/README.md) with one min_k row and
             one tail_risk_p99 row per point.
A drawn point is the mean test Delta U and the mean leak over the seeds of one TRIM round (or one baseline operating
point); rounds or points that not every seed reaches are not drawn (and are printed).

Delta U is the increase in test log loss over each method's best output, the full training split included for the
baselines: a baseline's curve also holds its full-split output (the full-data model: Delta U 0, leak 0), and every
curve is shifted so that its lowest-loss point lies at Delta U 0. Each curve keeps, at every Delta U, the lowest leak
reached at or below that Delta U.
"""

from __future__ import annotations

import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
from matplotlib import pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.ticker import MultipleLocator  # noqa: E402

# Experiment of the long-table rows that the panels read.
EXPERIMENT = "exp1_privacy_utility"
# Line styles and legend labels; KAnonGlobal is KAnon run with TDS.
STYLES = {
    "TRIM": {"label": "TRIM", "color": "black", "marker": "o", "linestyle": "-",
             "linewidth": 4, "markersize": 9, "zorder": 5},
    "PAT": {"label": "PAT", "color": "#0072B2", "marker": "s",
            "linestyle": (0, (2, 0.5, 0.5, 0.5)), "linewidth": 3.2, "markersize": 7.2,
            "zorder": 4},
    "FeatSel": {"label": "FeatSel", "color": "#E69F00", "marker": "^",
                "linestyle": (0, (2, 0.5)), "linewidth": 4.2, "markersize": 8.2, "zorder": 2},
    "FIDO": {"label": "FIDO", "color": "#009E73", "marker": "D", "linestyle": "-",
             "linewidth": 4, "markersize": 9, "markeredgewidth": 1.4, "zorder": 1},
    "EntryWise": {"label": "EntryWise", "color": "#d62728", "marker": "p",
                  "linestyle": (0, (0.1, 1.1)), "linewidth": 4, "markersize": 9,
                  "markeredgewidth": 1.6, "dash_capstyle": "round", "zorder": 3},
    "KAnonGlobal": {"label": "TDS", "color": "#882255", "marker": "X",
                    "linestyle": (0, (4, 1)), "linewidth": 3.2, "markersize": 10, "zorder": 4},
}
TRIM_FIELDS = {"dataset", "model_name", "seed", "iteration", "test_loss", "test_delta_u", "min_k", "original_leak_k",
               "tail_risk_p99"}
BASELINE_FIELDS = {"experiment", "method", "dataset", "model", "seed", "point", "x_metric", "x_value", "y_metric",
                   "y_value", "y_reference"}
POINT_COLUMNS = ["dataset", "model", "method", "panel", "point", "test_delta_u", "y", "seeds"]
# Full-data test losses behind one dataset/model/seed must agree this closely.
REFERENCE_TOLERANCE = 1e-6
DPI = 300


def read_rows(path: Path) -> list[dict]:
    path = Path(path)
    with path.open("r", encoding="utf-8", newline="") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None or len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ValueError(f"CSV input has no header or duplicate headers: {path}")
        rows = list(reader)
    if not rows:
        raise ValueError(f"Input file contains no rows: {path}")
    for row_number, row in enumerate(rows, start=2):
        if None in row:
            raise ValueError(f"CSV row has more values than headers at {path} row {row_number}.")
    return rows


def number(value, field: str, path: Path, row_number: int) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError) as error:
        raise ValueError(f"Invalid numeric {field!r} at {path} row {row_number}: {value!r}") from error
    if not math.isfinite(parsed):
        raise ValueError(f"Non-finite numeric {field!r} at {path} row {row_number}: {value!r}")
    return parsed


def tail_number(value, path: Path, row_number: int) -> float:
    """A P99 tail leak: finite, or -inf for a release covering at most 1% of the training rows."""
    if str(value).strip().lower() in {"-inf", "-infinity"}:
        return -math.inf
    return number(value, "tail_risk_p99", path, row_number)


def require(row: dict, fields: set[str], path: Path, row_number: int) -> None:
    missing = sorted(field for field in fields if field not in row)
    if missing:
        raise ValueError(f"Missing fields {missing} at {path} row {row_number}.")


def read_trim(paths, dataset, model, seeds, outputs, references):
    """TRIM's rounds: outputs[("TRIM", seed)][round] = {"du", "leak", "tail"}; references[seed]["TRIM"]."""
    for path in map(Path, paths):
        for row_number, row in enumerate(read_rows(path), start=2):
            require(row, TRIM_FIELDS, path, row_number)
            seed = int(row["seed"])
            if row["dataset"].strip() != dataset or row["model_name"].strip() != model or seed not in seeds:
                continue
            run = outputs[("TRIM", seed)]
            point = row["iteration"].strip()
            if point in run:
                raise ValueError(f"Duplicate TRIM round {point} for seed {seed} at {path} row {row_number}.")
            du = number(row["test_delta_u"], "test_delta_u", path, row_number)
            min_k = number(row["min_k"], "min_k", path, row_number)
            k0 = number(row["original_leak_k"], "original_leak_k", path, row_number)
            if min_k <= 0 or k0 <= 0:
                raise ValueError(f"min_k and original_leak_k must be positive at {path} row {row_number}.")
            run[point] = {"du": du, "leak": math.log(k0) - math.log(min_k),
                          "tail": tail_number(row["tail_risk_p99"], path, row_number)}
            reference = number(row["test_loss"], "test_loss", path, row_number) - du
            known = references[seed].setdefault("TRIM", reference)
            if abs(known - reference) > REFERENCE_TOLERANCE:
                raise ValueError(f"TRIM rows for seed {seed} imply full-data test losses {known} and {reference} "
                                 f"({path} row {row_number}).")


def read_baselines(paths, methods, dataset, model, seeds, outputs, references):
    """The baselines' operating points: outputs[(method, seed)][point] = {"du", "leak", "tail"}."""
    for path in map(Path, paths):
        for row_number, row in enumerate(read_rows(path), start=2):
            require(row, BASELINE_FIELDS, path, row_number)
            method = row["method"].strip()
            seed = int(row["seed"])
            y_metric = row["y_metric"].strip()
            if (row["experiment"].strip() != EXPERIMENT or method not in methods or row["dataset"].strip() != dataset
                    or row["model"].strip() != model or seed not in seeds
                    or row["x_metric"].strip() != "test_delta_u" or y_metric not in ("min_k", "tail_risk_p99")):
                continue
            point = row["point"].strip()
            du = number(row["x_value"], "x_value", path, row_number)
            entry = outputs[(method, seed)].setdefault(point, {"du": du})
            if entry["du"] != du:
                raise ValueError(f"{method} point {point} of seed {seed} has two test Delta U values "
                                 f"({path} row {row_number}).")
            panel = "leak" if y_metric == "min_k" else "tail"
            if panel in entry:
                raise ValueError(f"Duplicate {y_metric} row for {method} point {point} of seed {seed} "
                                 f"({path} row {row_number}).")
            if panel == "leak":
                min_k = number(row["y_value"], "y_value", path, row_number)
                k0 = number(row["y_reference"], "y_reference", path, row_number)
                if min_k <= 0 or k0 <= 0:
                    raise ValueError(f"min_k and its reference must be positive at {path} row {row_number}.")
                entry["leak"] = math.log(k0) - math.log(min_k)
            else:
                entry["tail"] = tail_number(row["y_value"], path, row_number)
            # The full-split output lies at tail leak 0, which holds only when the original data's tail leak is 0.
            if str(row.get("original_tail_risk_p99") or "").strip():
                original_tail = number(row["original_tail_risk_p99"], "original_tail_risk_p99", path, row_number)
                if original_tail != 0.0:
                    raise ValueError(f"The full-split output of {method} assumes original tail leak 0; found "
                                     f"{original_tail} ({path} row {row_number}).")
            if str(row.get("baseline_test_loss") or "").strip():
                reference = number(row["baseline_test_loss"], "baseline_test_loss", path, row_number)
                known = references[seed].setdefault(method, reference)
                if abs(known - reference) > REFERENCE_TOLERANCE:
                    raise ValueError(f"{method} rows for seed {seed} record full-data test losses {known} and "
                                     f"{reference} ({path} row {row_number}).")


def method_curve(method, runs, seeds, where=""):
    """{"leak": [(Delta U, leak, point)], "tail": [...]}: seed means per point, shifted to the method's best output."""
    curve = {"leak": [], "tail": []}
    common = set.intersection(*(set(run) for run in runs))
    for seed, run in zip(seeds, runs):
        dropped = sorted(set(run) - common, key=lambda point: (len(point), point))
        if dropped:
            print(f"{method} {where} seed {seed}: dropped rounds/points {dropped}, which not every seed reached.")
    for point in common:
        x = statistics.fmean(run[point]["du"] for run in runs)
        for panel in curve:
            curve[panel].append((x, statistics.fmean(run[point][panel] for run in runs), point))
    for panel in curve:
        points = sorted(curve[panel])
        if method != "TRIM":
            points = points + [(0.0, 0.0, "full-data")]
        points = sorted(points, key=lambda item: item[0])
        envelope = []
        for x, y, point in points:
            envelope.append((x, min(y, envelope[-1][1]) if envelope else y, point))
        if method == "TRIM":
            envelope.insert(0, (envelope[0][0], 0.0, "origin"))
        curve[panel] = [(x - envelope[0][0], y, point) for x, y, point in envelope]
    return curve


def curves(trim_files, long_tables, dataset, model, seeds, methods):
    """{method: curve} of one panel, in the order of ``methods``."""
    seeds = list(seeds)
    table_methods = [m for m in methods if m != "TRIM"]
    outputs, references = defaultdict(dict), defaultdict(dict)
    read_trim(trim_files, dataset, model, seeds, outputs, references)
    read_baselines(long_tables, table_methods, dataset, model, seeds, outputs, references)
    unchecked = set()
    for method in ["TRIM", *table_methods]:
        for seed in seeds:
            run = outputs.get((method, seed))
            if not run:
                raise ValueError(f"No {method} rows for {dataset} {model} seed {seed}.")
            incomplete = sorted(point for point, entry in run.items() if not {"leak", "tail"} <= set(entry))
            if incomplete:
                raise ValueError(f"{method} points {incomplete} of seed {seed} lack a min_k or tail_risk_p99 row.")
            if method == "TRIM":
                continue
            if method not in references[seed]:
                unchecked.add(method)
            elif abs(references[seed][method] - references[seed]["TRIM"]) > REFERENCE_TOLERANCE:
                raise ValueError(f"{method} and TRIM measure Delta U from different full-data test losses for "
                                 f"{dataset} {model} seed {seed}: {references[seed][method]} and "
                                 f"{references[seed]['TRIM']}.")
    if unchecked:
        print(f"Not checked against TRIM's full-data test loss (no baseline_test_loss): {sorted(unchecked)}")
    out = {method: method_curve(method, [outputs[(method, seed)] for seed in seeds], seeds, f"{dataset} {model}")
           for method in ["TRIM", *table_methods]}
    return {method: out[method] for method in methods}


def configure_matplotlib():
    # The panels embed DejaVu Sans.
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["DejaVu Sans"],
        "font.size": 18,
        "axes.labelsize": 18,
        "xtick.labelsize": 18,
        "ytick.labelsize": 18,
        "axes.linewidth": 4,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def draw(panel_curves, output: Path, name: str, xmax=None):
    """One panel as <name>.pdf and <name>.png; with ``xmax``, the Delta U axis ends there and no point beyond it is
    drawn."""
    configure_matplotlib()
    figure, axes = plt.subplots(2, 1, sharex=True, figsize=(5.5, 5.0),
                                gridspec_kw={"height_ratios": [1, 1], "hspace": 0.20})
    plotted_x = []
    for method, curve in panel_curves.items():
        style = {key: value for key, value in STYLES[method].items() if key != "label"}
        for axis, panel in zip(axes, ("leak", "tail")):
            points = curve[panel]
            if xmax is not None:
                points = [point for point in points if point[0] <= xmax]
            # Markers inside a flat stretch are dropped; the line is unchanged.
            points = [point for index, point in enumerate(points)
                      if index in (0, len(points) - 1) or not points[index - 1][1] == point[1] == points[index + 1][1]]
            axis.plot([point[0] for point in points], [point[1] for point in points], **style)
            plotted_x += [point[0] for point in points]
    axes[0].set_ylabel("leak")
    axes[1].set_ylabel("leak T")
    axes[1].set_xlabel(r"$\Delta U$")
    for axis in axes:
        axis.yaxis.set_major_locator(MultipleLocator(5))
        axis.grid(True, alpha=0.28)
        axis.tick_params(width=4)
        for spine in axis.spines.values():
            spine.set_linewidth(4)
    axes[0].tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    # Every curve starts at Delta U 0, so the axis does too.
    x_max = max(plotted_x)
    axes[1].set_xlim(0, x_max * 1.02 if x_max > 0 else 0.01)
    if xmax is not None:
        axes[1].set_xlim(right=xmax)
    # With a fixed xmax the last tick label sits on the right edge; leave room for it.
    figure.subplots_adjust(left=0.19, bottom=0.14, right=0.97 if xmax is None else 0.93, top=0.98)
    for extension in ("pdf", "png"):
        figure.savefig(output / f"{name}.{extension}", dpi=DPI)
    plt.close(figure)


def draw_legend(methods, output: Path, name: str):
    """The legend of the panels as <name>.pdf and <name>.png; 1.8 inches per entry, so that more methods widen it
    instead of shrinking its text."""
    configure_matplotlib()
    figure = plt.figure(figsize=(1.8 * len(methods), 0.34317))
    handles = [Line2D([], [], label=STYLES[method]["label"],
                      **{key: value for key, value in STYLES[method].items() if key != "label"})
               for method in methods]
    figure.legend(handles=handles, loc="center", ncol=len(handles), frameon=False, fontsize=12, columnspacing=1.2,
                  handlelength=4.0)
    figure.subplots_adjust(left=0, bottom=0, right=1, top=1)
    for extension in ("pdf", "png"):
        figure.savefig(output / f"{name}.{extension}", dpi=DPI)
    plt.close(figure)


def write_points(panel_curves, dataset, model, seeds, path: Path):
    """Every drawn point (before the xmax cut) of one panel, one row per method, panel and point."""
    with Path(path).open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle)
        writer.writerow(POINT_COLUMNS)
        for method, curve in panel_curves.items():
            for panel, points in curve.items():
                for x, y, point in points:
                    writer.writerow([dataset, model, method, panel, point, repr(x), repr(y),
                                     " ".join(str(seed) for seed in seeds)])
