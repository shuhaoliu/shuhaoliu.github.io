"""Fig. 5i/5j style: one solid black bar per method, labelled with its value."""

import math

import matplotlib.pyplot as plt

LABEL_SIZE = 18

XTICK_SIZE = 14

LINEWIDTH = 4

BAR_WIDTH = 0.55

BAR_VALUE_LABEL_SIZE = 14

DPI = 300

def configure_matplotlib():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "DejaVu Sans"],
            "font.size": LABEL_SIZE,
            "axes.labelsize": LABEL_SIZE,
            "xtick.labelsize": XTICK_SIZE,
            "ytick.labelsize": LABEL_SIZE,
            "axes.linewidth": LINEWIDTH,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

def format_bar_value(value):
    if abs(value) < 0.005:
        value = 0.0
    abs_value = abs(value)
    if abs_value >= 1000:
        exponent = math.floor(math.log10(abs_value))
        mantissa = value / (10**exponent)
        return rf"${mantissa:.1f} \times 10^{{{exponent}}}$"
    if abs_value >= 100:
        return f"{value:.0f}"
    if abs_value >= 10:
        return f"{value:.1f}"
    return f"{value:.2f}"

def draw_bars(ax, values, labels, ylabel, log_y=False, value_format=None):
    """Solid black bars, one per method in ``labels`` order, each labelled with its value."""
    value_format = value_format or format_bar_value
    x_centers = list(range(len(labels)))
    finite_values = [value for value in values if math.isfinite(value)]
    positive_values = [value for value in finite_values if value > 0]
    max_positive = max(positive_values) if positive_values else math.nan
    linear_padding = 0.03
    if finite_values:
        value_range = max(finite_values) - min(finite_values)
        max_abs_value = max(abs(value) for value in finite_values)
        linear_padding = max(value_range * 0.03, max_abs_value * 0.02, 0.03)
    for i in range(len(labels)):
        value = values[i]
        height = value if value == value else 0.0
        ax.bar(
            i,
            height,
            width=BAR_WIDTH,
            color="black",
            hatch="",
            edgecolor="black",
            linewidth=LINEWIDTH,
        )
        if math.isfinite(value):
            if log_y:
                if value <= 0:
                    continue
                ax.annotate(
                    value_format(value),
                    xy=(i, value),
                    xytext=(0, 6),
                    textcoords="offset points",
                    ha="center",
                    va="bottom",
                    fontsize=BAR_VALUE_LABEL_SIZE,
                    color="black",
                    clip_on=False,
                )
                continue
            elif value > 0 or min(finite_values) >= 0:
                label_y = value + linear_padding
                label_va = "bottom"
            else:
                label_y = value - linear_padding
                label_va = "top"
            ax.text(
                i,
                label_y,
                value_format(value),
                ha="center",
                va=label_va,
                fontsize=BAR_VALUE_LABEL_SIZE,
                clip_on=False,
            )
    ax.set_xticks(x_centers)
    ax.set_xticklabels(labels)
    ax.set_ylabel(ylabel)
    ax.tick_params(width=LINEWIDTH)
    for spine in ax.spines.values():
        spine.set_linewidth(LINEWIDTH)
    if log_y:
        ax.set_yscale("log")
        positive = [v for v in values if v == v and v > 0]
        if positive:
            min_exponent = min(0, math.floor(math.log10(min(positive))))
            max_exponent = max(0, math.ceil(math.log10(max(positive))))
            exponent_step = max(1, math.ceil((max_exponent - min_exponent) / 3))
            tick_exponents = list(
                range(min_exponent, max_exponent + 1, exponent_step)
            )
            if tick_exponents[-1] != max_exponent:
                tick_exponents.append(max_exponent)
            ticks = [10**exponent for exponent in tick_exponents]
            tick_labels = [
                "1" if exponent == 0 else f"$10^{{{exponent}}}$"
                for exponent in tick_exponents
            ]
            ax.set_yticks(ticks)
            ax.set_yticklabels(tick_labels)
            ax.set_ylim(ticks[0] / 1.4, max(ticks[-1] * 10.0, max_positive * 30.0))
    else:
        if finite_values and min(finite_values) >= 0 and max(finite_values) <= 1:
            ax.set_ylim(0.0, 1.12)
        elif finite_values:
            ax.margins(y=0.18)
    ax.grid(True, alpha=0.28)

