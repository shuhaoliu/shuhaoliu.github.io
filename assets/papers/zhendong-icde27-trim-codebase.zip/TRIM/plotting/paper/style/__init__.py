"""Drawing styles shared by the paper figure scripts."""
