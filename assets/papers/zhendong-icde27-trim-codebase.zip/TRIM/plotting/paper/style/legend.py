"""The legend shared by Fig. 5a-5d: bar patches of the Fig. 5c methods, then the line markers of Fig. 5d."""

from pathlib import Path

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

# Line styles of the Fig. 4 methods, used for the line entries.
LINE_WIDTH = 4
LINE_MARKER_SIZE = 9
LINE_STYLES = {
    "TRIM": {"color": "black", "marker": "o", "linestyle": "-", "linewidth": LINE_WIDTH, "zorder": 5},
    "PAT": {"color": "#0072B2", "marker": "s", "linestyle": (0, (2, 0.5, 0.5, 0.5)), "linewidth": LINE_WIDTH * 0.8,
            "markersize": LINE_MARKER_SIZE * 0.8, "markerfacecolor": "#0072B2", "markeredgecolor": "#0072B2",
            "zorder": 4},
    "FeatSel": {"color": "#E69F00", "marker": "^", "linestyle": (0, (2, 0.5)), "linewidth": LINE_WIDTH * 0.8 + 1,
                    "markersize": LINE_MARKER_SIZE * 0.8 + 1, "markerfacecolor": "#E69F00",
                    "markeredgecolor": "#E69F00", "zorder": 2},
    "FIDO": {"color": "#009E73", "marker": "D", "linestyle": "-", "linewidth": LINE_WIDTH,
             "markerfacecolor": "#009E73", "markeredgecolor": "#009E73", "markeredgewidth": 1.4, "zorder": 1},
    "EntryWise": {"color": "#d62728", "marker": "p", "linestyle": (0, (0.1, 1.1)), "linewidth": LINE_WIDTH,
                      "markerfacecolor": "#d62728", "markeredgecolor": "#d62728", "markeredgewidth": 1.6,
                      "dash_capstyle": "round", "zorder": 3},
    "TDS": {"color": "#882255", "marker": "X", "linestyle": (0, (4, 1)), "linewidth": 3.2, "markersize": 10,
            "markerfacecolor": "#882255", "markeredgecolor": "#882255"},
}

# Bar styles of the Fig. 5c methods; hatches keep grayscale prints readable.
BAR_STYLES = {
    "TRIM": {"color": "black", "hatch": ""},
    "PAT": {"color": "#0072B2", "hatch": "//"},
    "FeatSel": {"color": "#E69F00", "hatch": "oo"},
    "EntryWise": {"color": "#d62728", "hatch": "++"},
    "FIDO": {"color": "#009E73", "hatch": "xx"},
    "TDS": {"color": "#882255", "hatch": "\\\\"},
}
METHODS = ("TRIM", "PAT", "FeatSel", "EntryWise", "FIDO", "TDS")

# Text width of the IEEE two-column page.
LEGEND_FIGURE_SIZE = (7.0056, 0.28)
LEGEND_FONT_SIZE = 7
LEGEND_ARTIST_SCALE = LEGEND_FONT_SIZE / 12.0
LABEL_SIZE = 18
TICK_SIZE = 16
LINEWIDTH = 4
DPI = 300


def configure_matplotlib():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "DejaVu Sans"],
        "font.size": LABEL_SIZE,
        "axes.labelsize": LABEL_SIZE,
        "xtick.labelsize": TICK_SIZE,
        "ytick.labelsize": TICK_SIZE,
        "axes.linewidth": LINEWIDTH,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def plot_legend(output_dir, name):
    """Write the twelve-entry legend (six bars, six lines) as PNG and PDF; returns both paths."""
    fig = plt.figure(figsize=LEGEND_FIGURE_SIZE)
    handles, labels = [], []
    for method in METHODS:
        style = BAR_STYLES[method]
        handles.append(Patch(facecolor=style["color"], hatch=style["hatch"], edgecolor="black",
                             linewidth=0.8 * LEGEND_ARTIST_SCALE))
        labels.append(method)
    for method in METHODS:
        style = dict(LINE_STYLES[method])
        marker_size = style.pop("markersize", LINE_MARKER_SIZE) * LEGEND_ARTIST_SCALE
        for size_key in ("linewidth", "markeredgewidth"):
            if size_key in style:
                style[size_key] *= LEGEND_ARTIST_SCALE
        handles.append(Line2D([], [], markersize=marker_size, **style))
        labels.append(method)
    # Twelve entries fit the text width with short handles and gaps.
    fig.legend(handles, labels, frameon=False, loc="center", bbox_to_anchor=(0.5, 0.5), ncol=len(labels),
               fontsize=LEGEND_FONT_SIZE, columnspacing=0.3, handlelength=2.4, handleheight=1.1, handletextpad=0.25,
               borderpad=0.0)
    fig.subplots_adjust(left=0, bottom=0, right=1, top=1)
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    png_path, pdf_path = output_dir / f"{name}.png", output_dir / f"{name}.pdf"
    fig.savefig(png_path, dpi=DPI)
    fig.savefig(pdf_path)
    plt.close(fig)
    return png_path, pdf_path
