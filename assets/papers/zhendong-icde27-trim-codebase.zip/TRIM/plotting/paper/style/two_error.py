"""Fig. 5b style: the attacks' gain over guessing against the leak of each attacked TRIM release."""

from dataclasses import dataclass

from pathlib import Path

import matplotlib.pyplot as plt

DEFAULT_MIN_ITERATION = 3

FIGURE_SIZE = (5.5, 5.0)

LABEL_SIZE = 18

LINEWIDTH = 4

MARKER_SIZE = 9

DPI = 300

LINE_STYLE = {
    "color": "black",
    "marker": "o",
    "linestyle": "-",
    "linewidth": LINEWIDTH,
    "markersize": MARKER_SIZE,
    "markerfacecolor": "black",
    "markeredgecolor": "black",
}

@dataclass(frozen=True)
class Point:
    """One attacked TRIM release: its round, leak x, the attacks' errors and the errors of guessing."""
    iteration: int
    x: float
    linkage_error: float
    reconstruction_error: float
    baseline_linkage_error: float
    baseline_reconstruction_error: float

def configure_matplotlib():
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Helvetica", "DejaVu Sans"],
            "font.size": LABEL_SIZE,
            "axes.labelsize": LABEL_SIZE,
            "xtick.labelsize": LABEL_SIZE,
            "ytick.labelsize": LABEL_SIZE,
            "axes.linewidth": LINEWIDTH,
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
        }
    )

def plot_points(points, output_dir, name):
    """Gain over guessing of the inference (top) and reconstruction (bottom) attacks, as <name>.png/.pdf."""
    points = list(points)
    if not points:
        raise ValueError("at least one point is required.")

    configure_matplotlib()
    fig, (ax_top, ax_bottom) = plt.subplots(
        2,
        1,
        sharex=True,
        figsize=FIGURE_SIZE,
        gridspec_kw={"height_ratios": [1, 1], "hspace": 0.20},
    )
    xs = [point.x for point in points]
    ax_top.plot(
        xs,
        [
            point.baseline_linkage_error - point.linkage_error
            for point in points
        ],
        **LINE_STYLE,
    )
    ax_bottom.plot(
        xs,
        [
            point.baseline_reconstruction_error - point.reconstruction_error
            for point in points
        ],
        **LINE_STYLE,
    )

    # Each panel on its own scale, always including 0, so a gain's trend is visible without exaggerating its size.
    series = {
        ax_top: [point.baseline_linkage_error - point.linkage_error for point in points],
        ax_bottom: [point.baseline_reconstruction_error - point.reconstruction_error for point in points],
    }
    for axis, gains in series.items():
        low, high = min(0.0, min(gains)), max(0.0, max(gains))
        span = max(high - low, 1e-9)
        axis.grid(True, alpha=0.28)
        axis.tick_params(width=LINEWIDTH)
        axis.set_ylim(low - 0.08 * span, high + 0.08 * span)
        for spine in axis.spines.values():
            spine.set_linewidth(LINEWIDTH)

    ax_top.set_ylabel(r"$\Delta$ Infer. error")
    ax_bottom.set_ylabel(r"$\Delta$ Recon. error")
    ax_bottom.set_xlabel("leak")
    set_x_limits(ax_bottom, xs)
    ax_top.tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    fig.subplots_adjust(left=0.18, bottom=0.14, right=0.97, top=0.98)

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    png_path = output_dir / f"{name}.png"
    pdf_path = output_dir / f"{name}.pdf"
    fig.savefig(png_path, dpi=DPI)
    fig.savefig(pdf_path)
    plt.close(fig)
    return png_path, pdf_path

def set_x_limits(axis, xs):
    x_min = min(xs)
    x_max = max(xs)
    if x_min < x_max:
        axis.set_xlim(x_min, x_max)
    else:
        axis.set_xlim(x_min - 0.1, x_max + 0.1)

