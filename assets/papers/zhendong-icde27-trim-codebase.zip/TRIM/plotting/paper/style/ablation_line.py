"""Fig. 5k/5l style: five-seed mean of the lowest leak (top) and leak T (bottom) reached within each Delta U."""

import statistics

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402
from matplotlib.ticker import MaxNLocator  # noqa: E402

LABEL_SIZE = 18
LINEWIDTH = 4
MARKER_SIZE = 9
DPI = 300
METHOD_STYLES = {
    "TRIM": {"color": "black", "marker": "o", "linestyle": "-", "linewidth": LINEWIDTH, "zorder": 5},
    "Privacy": {"color": "0.35", "marker": "s", "linestyle": "--", "linewidth": LINEWIDTH * 0.8,
                "markersize": MARKER_SIZE * 0.85, "markerfacecolor": "0.35", "markeredgecolor": "0.35"},
    "Utility": {"color": "#E69F00", "marker": "^", "linestyle": ":", "linewidth": LINEWIDTH * 0.8,
                     "markersize": MARKER_SIZE * 0.85, "markerfacecolor": "#E69F00", "markeredgecolor": "#E69F00"},
    "Random": {"color": "#56B4E9", "marker": "D", "linestyle": "-.", "linewidth": LINEWIDTH * 0.8,
               "markersize": MARKER_SIZE * 0.78, "markerfacecolor": "#56B4E9", "markeredgecolor": "#56B4E9"},
    "IF": {"color": "black", "marker": "p", "linestyle": "-", "linewidth": LINEWIDTH * 0.8,
                "markersize": MARKER_SIZE * 0.9, "markerfacecolor": "white", "markeredgecolor": "black",
                "markeredgewidth": 1.4},
    "TRIM-H": {"color": "0.35", "marker": "s", "linestyle": "--", "linewidth": LINEWIDTH * 0.8,
               "markerfacecolor": "0.35", "markeredgecolor": "0.35"},
    "TRIM-V": {"color": "black", "marker": "^", "linestyle": ":", "linewidth": LINEWIDTH * 0.8,
               "markerfacecolor": "white", "markeredgecolor": "black", "markeredgewidth": 1.4},
    "RefineOnly": {"color": "#0072B2", "marker": "D", "linestyle": "-", "linewidth": LINEWIDTH,
                   "markerfacecolor": "white", "markeredgecolor": "#0072B2", "markeredgewidth": 1.8},
    "RefineEvict": {"color": "#D55E00", "marker": "x", "linestyle": (0, (1.2, 1.2)), "linewidth": LINEWIDTH * 0.6,
                    "markeredgecolor": "#D55E00", "markeredgewidth": 2.0},
}
# Legend labels that differ from the method names.
METHOD_LABELS = {"TRIM-H": r"$\mathrm{TRIM}_{\mathrm{H}}$", "TRIM-V": r"$\mathrm{TRIM}_{\mathrm{V}}$"}


def configure_matplotlib():
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "DejaVu Sans"],
        "font.size": LABEL_SIZE,
        "axes.labelsize": LABEL_SIZE,
        "xtick.labelsize": LABEL_SIZE,
        "ytick.labelsize": LABEL_SIZE,
        "axes.linewidth": LINEWIDTH,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })


def mean_curve(states_by_seed, column, grid):
    """Per Delta U = x: the lowest value among a run's states with test Delta U <= x (the original data, 0, always
    counts), averaged over the seeds. States are (test Delta U, leak, leak T)."""
    return [statistics.mean(min([s[column] for s in states if s[0] <= x] + [0.0]) for states in states_by_seed)
            for x in grid]


def draw_mean(states, methods, grid, output, name, styles_extra=None, legend_order=None):
    """``states``: {method: [states of seed 42, ..., states of seed 46]}; one line per method, both panels."""
    configure_matplotlib()
    fig, axes = plt.subplots(2, 1, sharex=True, figsize=(5.5, 6.6),
                             gridspec_kw={"height_ratios": [1, 1], "hspace": 0.20})
    handles = []
    for method in methods:
        style = dict(METHOD_STYLES[method])
        size = style.pop("markersize", MARKER_SIZE)
        extra = (styles_extra or {}).get(method, {"markevery": 4})
        for ax, column in zip(axes, (1, 2)):
            ax.plot(grid, mean_curve(states[method], column, grid), markersize=size * 0.8, alpha=0.95, **extra,
                    **style)
        handles.append((Line2D([0], [0], markersize=size * 0.8, **style), METHOD_LABELS.get(method, method)))
    for ax in axes:
        ax.grid(True, alpha=0.28)
        ax.tick_params(width=LINEWIDTH)
        ax.yaxis.set_major_locator(MaxNLocator(nbins=5, integer=True))
        for spine in ax.spines.values():
            spine.set_linewidth(LINEWIDTH)
    axes[0].set_ylabel("leak")
    axes[1].set_ylabel("leak T")
    axes[1].set_xlabel(r"$\Delta U$")
    axes[1].set_xlim(0.0, grid[-1])
    ordered = [handles[i] for i in legend_order] if legend_order else handles
    axes[1].legend([h for h, _ in ordered], [label for _, label in ordered], frameon=False, loc="lower left", ncol=2,
                   fontsize=14, columnspacing=0.6, handlelength=1.5, handletextpad=0.5, labelspacing=0.15)
    lo, hi = axes[1].get_ylim()
    axes[1].set_ylim(lo - 0.35 * (hi - lo), hi)
    fig.subplots_adjust(left=0.19, bottom=0.14, right=0.94, top=0.98)
    for ext in ("pdf", "png"):
        fig.savefig(output / f"{name}.{ext}", dpi=DPI)
    plt.close(fig)
    return output / f"{name}.pdf"
