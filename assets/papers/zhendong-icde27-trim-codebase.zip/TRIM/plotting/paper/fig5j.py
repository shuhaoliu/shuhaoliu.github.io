"""Fig. 5j (utility estimation, Income): execution time and the error of each utility estimator.

Inputs under --results (default results/fig5j), from experiments.exp6_estimation.run:
  estimation_income_evaluation/   evaluation seeds 42-46: seed_<s>_estimates.csv (per round and method) and
                                  seed_<s>_estimates_candidate_estimates.csv (per proxy-evaluated candidate);
  estimation_income_calibration/  calibration seeds 47-49, the same files.
Every estimator is compared with retraining the target M on the same candidates (TRIM = the proxy refit; IF; LGA
scaled by eta; Retrain = M itself, error 0). eta is fitted on the calibration seeds as
experiments/exp6_estimation/calibrate.py does: the lower weighted median of actual / raw LGA, weights |raw LGA|.
Utility MAE and rho MAE pool the candidates of a seed, then the seeds get equal weight; execution time = each method's
time summed over a seed's rounds, relative to TRIM, averaged over seeds. All rounds count. Also printed (text only):
the rho error of the operation each method selects per round (the summary rows' selected candidate), averaged alike.

    python -m plotting.paper.fig5j [--results results/fig5j] [--output figures/fig5j]
"""

from __future__ import annotations

import math
import re
import statistics as st
from collections import defaultdict

import matplotlib.pyplot as plt

from ._common import files, parse_args, read_csv, save
from .style import ranking as bars

METHODS = ("trim", "if", "lga", "retrain")
LABELS = ["TRIM", "IF", "LGA", "Retrain"]


def load(results, stem):
    out = {}
    for path in files(results, stem, "seed_*_estimates_candidate_estimates.csv"):
        seed = int(re.match(r"seed_(\d+)_", path.name).group(1))
        out[seed] = {"candidates": read_csv(path), "summary": read_csv(path.with_name(f"seed_{seed}_estimates.csv"))}
    if not out:
        raise FileNotFoundError(f"No estimates under {results / stem}")
    return out


def fit_eta(calibration):
    pairs = [(float(r["raw_lga_score"]), float(r["actual_utility_delta"]))
             for data in calibration.values() for r in data["candidates"] if r["method"] == "lga"]
    ratios = sorted((b / a, abs(a)) for a, b in pairs if a != 0.0)
    half, cumulative = math.fsum(w for _, w in ratios) / 2.0, 0.0
    for ratio, weight in ratios:
        cumulative += weight
        if cumulative >= half:
            return ratio, len(pairs)
    raise ValueError("eta cannot be fitted: no calibration candidate with a nonzero LGA score.")


def summarize(evaluation, eta):
    time, utility, rho, selected = ({m: [] for m in METHODS} for _ in range(4))
    for seed, data in sorted(evaluation.items()):
        totals = defaultdict(float)
        for r in data["summary"]:
            totals[r["method"]] += float(r["time_seconds"])
        errors = {m: ([], []) for m in METHODS}
        lga_rho_error = {}
        for r in data["candidates"]:
            if r["method"] == "lga":
                estimate = eta * float(r["raw_lga_score"])
                u_err = abs(estimate - float(r["actual_utility_delta"]))
                s_err = abs(estimate / float(r["privacy_cost"]) - float(r["actual_rho"]))
                lga_rho_error[(r["iteration"], r["candidate_type"], r["candidate_id"])] = s_err
            else:
                u_err, s_err = float(r["utility_abs_error"]), float(r["score_abs_error"])
            errors[r["method"]][0].append(u_err)
            errors[r["method"]][1].append(s_err)
        chosen = defaultdict(list)
        for r in data["summary"]:
            if r["method"] == "lga":
                chosen["lga"].append(lga_rho_error[(r["iteration"], r["selected_candidate_type"],
                                                    r["selected_candidate_id"])])
            elif r["method"] != "retrain":
                chosen[r["method"]].append(float(r["score_abs_error"]))
        for m in METHODS:
            time[m].append(totals[m] / totals["trim"])
            utility[m].append(st.mean(errors[m][0]))
            rho[m].append(st.mean(errors[m][1]))
            selected[m].append(st.mean(chosen[m]) if m != "retrain" else 0.0)
    return ([st.mean(d[m]) for m in METHODS] for d in (time, utility, rho, selected))


def main():
    args = parse_args("fig5j", __doc__)
    evaluation = load(args.results, "estimation_income_evaluation")
    calibration = load(args.results, "estimation_income_calibration")
    eta, n_pairs = fit_eta(calibration)
    time_row, utility_row, rho_row, selected_row = summarize(evaluation, eta)
    print(f"evaluation seeds {sorted(evaluation)}, calibration seeds {sorted(calibration)}; "
          f"eta {eta:.4g} from {n_pairs} candidates")
    for name, row in (("time / TRIM", time_row), ("utility MAE", utility_row), ("rho MAE", rho_row),
                      ("selected rho", selected_row)):
        print(f"  {name:13s}" + "  ".join(f"{label} {v:.4g}" for label, v in zip(LABELS, row)))
    print("  TRIM's selected-operation rho error is "
          + ", ".join(f"{100 * (1 - selected_row[0] / selected_row[i]):.2f}% below {LABELS[i]}" for i in (2, 1)))
    bars.configure_matplotlib()
    plt.rcParams["xtick.labelsize"] = 18
    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(5.5, 6.6), gridspec_kw={"hspace": 0.20})
    bars.draw_bars(axes[0], time_row, LABELS, "Exec. time (x)", log_y=True)
    axes[0].axhline(1.0, color="0.35", linestyle="--", linewidth=2, zorder=0)
    # IF's refinement errors are orders of magnitude above the others, so the MAE rows use a log axis with
    # two-significant-digit labels; Retrain's error is 0 by construction and is labelled at the bottom.
    for ax, row, label in ((axes[1], utility_row, "Utility MAE"), (axes[2], rho_row, r"$\rho$ MAE")):
        bars.draw_bars(ax, row, LABELS, label, log_y=True, value_format=lambda value: f"{value:.2g}")
        ax.text(3, ax.get_ylim()[0] * 1.5, "0", ha="center", va="bottom", fontsize=bars.BAR_VALUE_LABEL_SIZE)
    for ax in axes[:2]:
        ax.tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    fig.subplots_adjust(left=0.19, bottom=0.07, right=0.97, top=0.98)
    save(fig, args.output, "fig5j", dpi=bars.DPI)
    plt.close(fig)


if __name__ == "__main__":
    main()
