"""Table IV (utility degradation under DP-SGD training, Income, MLP) as Markdown and LaTeX rows.

Inputs under --results (default results/table4): dpsgd_income_k235/ (experiments.exp1_dp.run_exp1_dp run on the TRIM
release of trim_release_income_k235/): training_mode_summary.csv, manifest.json and kanon_sup_release.json.
Entries: the original data = increase of its test log loss over the no-noise original model; TRIM and KAnon rows =
increase over the original data in the same column. Columns: no noise, then DP-SGD with e^epsilon = 5, 2, 1.5.

    python -m plotting.paper.table4 [--results results/table4] [--output figures/table4]
"""

from __future__ import annotations

import json
import math

from ._common import experiment_dirs, parse_args, read_csv

COLUMNS = (("sgd", ""), ("dp_sgd", "5.0"), ("dp_sgd", "2.0"), ("dp_sgd", "1.5"))
NAMES = {"trim": r"\TRIM", "mondrian": r"\kw{KAnon} ($k=%d$, Mondrian~\cite{lefevre-icde06-mondrian})",
         "kanon_sup": r"{\kw{KAnon} ($k=%d$, TDS, $\leq5\%%$)}"}


def main():
    args = parse_args("table4", __doc__)
    run = experiment_dirs(args.results, "dpsgd_income_k235")["dpsgd_income_k235"]
    value = {(r["training_mode"], r["method"], r["x"]): float(r["mean_test_logloss"])
             for r in read_csv(run / "training_mode_summary.csv")}
    manifest = json.loads((run / "manifest.json").read_text(encoding="utf-8"))
    suppressed = json.loads((run / "kanon_sup_release.json").read_text(encoding="utf-8"))
    k = int(manifest.get("target_k") or manifest["trim_release"]["target_k"])
    trim_min_k = int(manifest["trim_release"]["min_k"])
    base = value[("sgd", "original", "")]
    original = [value[(mode, "original", x)] - base for mode, x in COLUMNS]
    published = {"trim": manifest["trim_release"]["row_count"], "mondrian": None,
                 "kanon_sup": suppressed["published_row_count"]}
    md = ["| Method | No noise | e^eps = 5 | 2 | 1.5 | rows published |", "|---|---|---|---|---|---|",
          "| Original | " + " | ".join(f"{x:.3f}" for x in original) + " | all |"]
    tex = ["    Original Dataset", *[f"    & {{${x:.3f}$}}" if i else "    & $0$" for i, x in enumerate(original)]]
    tex[-1] += r" \\"
    for method in ("trim", "mondrian", "kanon_sup"):
        values = [value[(mode, method, x)] - value[(mode, "original", x)] for mode, x in COLUMNS]
        rows = "all" if published[method] is None else f"{published[method]:,}"
        md.append(f"| {method} (k = {k}) | " + " | ".join(f"+{x:.3f}" for x in values) + f" | {rows} |")
        label = (NAMES[method] + f" (\\Leakage$=-{math.log(trim_min_k):.2f}$)" if method == "trim"
                 else NAMES[method] % k)
        tex.append(f"    {label}")
        tex.extend(f"    & {{$+{x:.3f}$}}" for x in values)
        tex[-1] += r" \\"
    (args.output / "table4.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    (args.output / "table4_rows.tex").write_text("\n".join(tex) + "\n", encoding="utf-8")
    print("\n".join(md))


if __name__ == "__main__":
    main()
