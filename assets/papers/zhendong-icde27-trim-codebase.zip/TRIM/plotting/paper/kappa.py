"""Varying the cost floor kappa = log(1 + x) (Income, epsilon 0.09, text numbers of Exp-5).

Inputs under --results (default results/kappa): kappa_income_x<x>_seed<s>/ (experiments.exp1_privacy_utility.run).
Each run stops on utility at epsilon 0.09; its release is the one at the stop of its final check, and a run that ends
before a final check passes returns the original data (leak 0). Printed per x: min-K of the release per seed, how many
seeds meet epsilon, and the mean leak over the five seeds.

    python -m plotting.paper.kappa [--results results/kappa] [--output figures/kappa]
"""

from __future__ import annotations

import json
import math
import re
import statistics

from ._common import SEEDS, files, parse_args

XS = ("0p01", "0p05", "0p1", "0p25", "0p5")
EPS = 0.09


def main():
    args = parse_args("kappa", __doc__)
    runs = {}
    for path in files(args.results, "kappa_income_x*_seed*", "metrics.json"):
        x, seed = re.match(r"kappa_income_x(\w+?)_seed(\d+)$", path.relative_to(args.results).parts[0]).groups()
        config = json.loads((path.parent / "config.json").read_text(encoding="utf-8"))
        if float(config["tolerance"]) != EPS or not config["stop_on_utility"]:
            raise ValueError(f"{path.parent}: expected a run that stops on utility at epsilon {EPS}.")
        runs[(x, int(seed))] = json.loads(path.read_text(encoding="utf-8"))
    lines = [f"epsilon {EPS} (release at the stop of the final check; a run that ends before it passes releases D)"]
    means = []
    for x in XS:
        leaks, cells = [], []
        for seed in SEEDS:
            metrics = runs[(x, seed)]
            k = int(metrics["final_leak_k"]) if metrics["termination_condition"] == "loss_threshold_met" else None
            leaks.append(0.0 if k is None else -math.log(k))
            cells.append("  inf" if k is None else f"{k:5d}")
        means.append(statistics.mean(leaks))
        lines.append(f"  x={x.replace('p', '.'):5s} min-K per seed {' '.join(cells)} | "
                     f"meet {sum(c != '  inf' for c in cells)}/{len(SEEDS)} | mean leak {means[-1]:6.2f}")
    lines.append(f"  mean leak ranges from {min(means):.2f} to {max(means):.2f}")
    (args.output / "kappa_numbers.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
