"""Fig. 5h (quality of retention classes, PubCov): execution time relative to TRIM and leak per method, five seeds.

Inputs under --results (default results/fig5h): enumeration_pubcov_seed<s>/ (experiments.exp6_ablation.run_enumeration),
their run_summaries.jsonl. Time = the method's mean algorithm time over the seeds / TRIM's mean; leak = the mean over
the seeds of -ln(final min-K / original min-K). Every seed is printed, then the means the panel draws.

    python -m plotting.paper.fig5h [--results results/fig5h] [--output figures/fig5h]
"""

from __future__ import annotations

import math
import statistics

from matplotlib import pyplot as plt

from ._common import SEEDS, files, parse_args, read_jsonl, save
from .style import enumeration


def leak(row):
    return -math.log(int(float(row["final_leak_k"])) / int(float(row["original_leak_k"])))


def main():
    args = parse_args("fig5h", __doc__)
    rows = {}
    for path in files(args.results, "enumeration_pubcov_seed*", "run_summaries.jsonl"):
        for row in read_jsonl(path):
            rows[(int(row["seed"]), row["method"])] = row
    order = enumeration.METHODS
    for seed in sorted({s for s, _ in rows}):
        trim_time = float(rows[(seed, "TRIM")]["algorithm_time_seconds"])
        print(f"seed {seed}: " + "; ".join(
            f"{m} {float(rows[(seed, m)]['algorithm_time_seconds']) / trim_time:.2f}x leak {leak(rows[(seed, m)]):.2f}"
            for m in order))
    if {s for s, _ in rows} != set(SEEDS):
        raise ValueError(f"Fig. 5h needs seeds {SEEDS}; found {sorted({s for s, _ in rows})}.")
    times = [statistics.mean(float(rows[(s, m)]["algorithm_time_seconds"]) for s in SEEDS) for m in order]
    relative = [t / times[order.index("TRIM")] for t in times]
    leaks = [statistics.mean(leak(rows[(s, m)]) for s in SEEDS) for m in order]
    print("mean of the seeds: " + "; ".join(f"{m} {r:.3f}x leak {v:.3f}" for m, r, v in zip(order, relative, leaks)))
    enumeration.configure_matplotlib()
    fig, (top, bottom) = plt.subplots(2, 1, sharex=True, figsize=enumeration.FIGURE_SIZE,
                                      gridspec_kw={"height_ratios": [1, 1], "hspace": 0.20})
    enumeration.draw_bars(top, relative, "Exec. time (x)", log_y=True)
    top.tick_params(axis="x", which="both", bottom=False, labelbottom=False)
    enumeration.draw_bars(bottom, leaks, "leak")
    min_tick = int(2 * math.floor(min(leaks) / 2))
    bottom.set_yticks(list(range(min_tick, 1, 2)))
    bottom.set_ylim(min_tick - 0.6, 0.6)
    fig.subplots_adjust(left=0.175, bottom=0.07, right=0.965, top=0.98)
    save(fig, args.output, "fig5h", dpi=150)
    plt.close(fig)


if __name__ == "__main__":
    main()
