"""Fig. 5e (evaluation budget b, PubCov, XGBoost target, epsilon 0.02, 3% seed): execution time and leak against b,
the mean over seeds 42-46.

Inputs under --results (default results/fig5e): budget_pubcov_seed<s>_b<b>/, one TRIM run per seed and b
(experiments.exp5_sensitivity.run_topk); each run stops when its final check passes (or returns D).
Time = algorithm time of the run, the final checks included (plotting.paper._common.algorithm_seconds);
leak = -ln(min-K of the release), 0 when the run meets epsilon in no round. Each point is the mean over the five seeds;
a white marker shows that some seed does not meet epsilon. Every seed and b is printed.

    python -m plotting.paper.fig5e [--results results/fig5e] [--output figures/fig5e]
"""

from __future__ import annotations

import json
import math
import re
import statistics

from matplotlib import pyplot as plt
from matplotlib.transforms import ScaledTranslation

from ._common import SEEDS, algorithm_seconds, parse_args, save, trim_run_dirs
from .style import budget


def draw(bs, times, leaks, hollow, output):
    """Time (top) and leak (bottom) against b; white markers at the b values in ``hollow``."""
    budget.configure_matplotlib()
    fig, (top, bottom) = plt.subplots(2, 1, sharex=True, figsize=budget.FIGURE_SIZE,
                                      gridspec_kw={"height_ratios": [1, 1], "hspace": 0.2})
    for ax, values, label in ((top, times, "Exec. time (s)"), (bottom, leaks, "leak")):
        budget.draw_line(ax, bs, values, label)
        if label == "leak":  # the leak axis starts at 0 (ticks 0, -2, ...)
            ax.set_ylim(2 * math.floor(min(values) / 2), 0)
        points = [(b, v) for b, v in zip(bs, values) if b in hollow]
        if points:
            ax.plot(*zip(*points), linestyle="none", marker="o", markersize=11, markerfacecolor="white",
                    markeredgecolor="black", markeredgewidth=3, zorder=3)
    top.spines["bottom"].set_visible(True)
    top.tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    bottom.spines["top"].set_visible(True)
    bottom.set_xlabel(r"$b$")
    bottom.set_xlim(min(bs), max(bs))
    labels = bottom.get_xticklabels()
    labels[-1].set_transform(labels[-1].get_transform() + ScaledTranslation(-8 / 72, 0, fig.dpi_scale_trans))
    fig.subplots_adjust(left=0.16, bottom=0.145, right=0.97, top=0.98)
    save(fig, output, "fig5e", dpi=150)
    plt.close(fig)


def main():
    args = parse_args("fig5e", __doc__)
    cells = {}
    for stem, run in trim_run_dirs(args.results, "budget_pubcov_seed*_b*").items():
        seed, b = map(int, re.search(r"_seed(\d+)_b(\d+)$", stem).groups())
        metrics = json.loads((run / "metrics.json").read_text(encoding="utf-8"))
        met = not metrics.get("infeasible")
        leak = budget.display_leak_value(metrics.get("mixed_min_k") or metrics.get("final_leak_k")) if met else 0.0
        cells[(b, seed)] = (algorithm_seconds(run), leak, met)
    bs = sorted({b for b, _ in cells})
    for b in bs:
        if sorted(seed for b2, seed in cells if b2 == b) != list(SEEDS):
            raise ValueError(f"b {b}: seeds {sorted(s for b2, s in cells if b2 == b)}, expected {list(SEEDS)}")
    times = [statistics.mean(cells[(b, seed)][0] for seed in SEEDS) for b in bs]
    leaks = [statistics.mean(cells[(b, seed)][1] for seed in SEEDS) for b in bs]
    hollow = {b for b in bs if not all(cells[(b, seed)][2] for seed in SEEDS)}
    draw(bs, times, leaks, hollow, args.output)
    for b, t, v in zip(bs, times, leaks):
        met = sum(cells[(b, seed)][2] for seed in SEEDS)
        seeds = "  ".join(f"{seed}: {cells[(b, seed)][0]:6.0f} s {cells[(b, seed)][1]:6.2f}" for seed in SEEDS)
        print(f"b {b:2d}: mean {t:6.0f} s, leak {v:6.2f}, meets epsilon on {met}/5 | {seeds}")


if __name__ == "__main__":
    main()
