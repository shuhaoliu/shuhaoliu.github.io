"""Fig. 5g (adversary knowledge, PubCov): leak and worst-case re-identification success for 1-6 known QIs.

Inputs under --results (default results/fig5g):
  background_pubcov/   TRIM's run (experiments.exp5_sensitivity.run_background): background_knowledge.csv per seed;
  baselines/           fig5g_baselines.csv (scripts/fig5g_baselines.py): PAT, FeatSel, EntryWise, FIDO and KAnon (TDS)
                       on their most private release with test Delta U <= 0.07, one row per method, seed and number of
                       known QIs, in the columns of TRIM's background_knowledge.csv.
Curve value = the five-seed mean of the worst-case success probability; leak = its log. Curves that sit at leak 0
from two known QIs on are offset slightly (in the bottom panel by the factor e^offset) so they stay visible.

    python -m plotting.paper.fig5g [--results results/fig5g] [--output figures/fig5g]
"""

from __future__ import annotations

import math
import re
import statistics

import pandas as pd

from ._common import SEEDS, baseline_files, files, parse_args, read_csv
from .style import background as bk

FIRST, LAST = 1, 6
METHODS = ("TRIM", "PAT", "FeatSel", "EntryWise", "FIDO", "TDS")


def trim_rows(results):
    worst = {}
    for path in files(results, "background_pubcov", "background_knowledge.csv"):
        for row in read_csv(path):
            seed = int(re.search(r"seed_(\d+)", row["run_id"]).group(1))
            worst[("TRIM", seed, int(row["known_attribute_count"]))] = float(row["worst_success_probability"])
    return worst


def main():
    args = parse_args("fig5g", __doc__)
    worst = trim_rows(args.results)
    for path in baseline_files(args.results, "baselines*", "fig5g_baselines.csv"):
        for row in read_csv(path):
            if row["method"] in METHODS:
                worst[(row["method"], int(row["seed"]), int(row["known_attribute_count"]))] = float(
                    row["worst_success_probability"])
    rows = [{"method": method, "known_attribute_count": r,
             "worst_success_probability": statistics.mean(worst[(method, s, r)] for s in SEEDS)}
            for method in METHODS for r in range(FIRST, LAST + 1)]
    offsets = {}
    for method in METHODS:
        at_zero = all(row["worst_success_probability"] == 1.0 for row in rows
                      if row["method"] == method and row["known_attribute_count"] >= 2)
        offsets[method] = bk.TOP_PANEL_Y_OFFSETS.get(method, 0.0) if at_zero else 0.0
    for row in rows:
        row["success_drawn"] = row["worst_success_probability"] * math.exp(offsets[row["method"]])
    frame = pd.DataFrame(rows)
    frame.to_csv(args.output / "fig5g_points.csv", index=False)
    bk.plot_results(frame, offsets, args.output / "fig5g.png", args.output / "fig5g.pdf", FIRST, LAST)
    for method in METHODS:
        leaks = " ".join("%.2f" % math.log(row["worst_success_probability"]) for row in rows if row["method"] == method)
        print(f"{method:14s} leak for {FIRST}-{LAST} known QIs: {leaks}")


if __name__ == "__main__":
    main()
