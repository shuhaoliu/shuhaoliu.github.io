"""Fig. 7 (appendix: retention view vs. removal view), seed 42, MLP target.

Each dataset has one TRIM_R run and one TRIM run, both on the seed-42 split
(the configurations in configs/paper/fig7/).

Inputs under --results (default results/fig7):
  removal_view_<dataset>_seed42/     TRIM_R (experiments.appendix_removal_view.run), run_summaries.jsonl: algorithm
                                     seconds = total - full-data baseline - final verification;
  retention_view_<dataset>_seed42/   TRIM with the same settings (experiments.exp3_runtime.run_execution_time), stopping
                                     on utility at epsilon: algorithm seconds up to the stop of its final check,
                                     checks included.
Bar = TRIM_R's seconds / TRIM's (TRIM = 1). Also printed: TRIM_R's rounds, stop reason and final min-K.

    python -m plotting.paper.fig7 [--results results/fig7] [--output figures/fig7]
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
from matplotlib.ticker import FuncFormatter  # noqa: E402

from ._common import files, one, parse_args, read_jsonl, save, seconds_to_stop, trim_run_dirs  # noqa: E402

DATASETS = (("income", "Income"), ("pubcov", "PubCov"), ("diabetes", "Diabetes"), ("bm", "BM"))
EPS = {"income": 0.09, "pubcov": 0.05, "diabetes": 0.02, "bm": 0.005}
BAR_WIDTH = 0.28
LINEWIDTH = 4


def main():
    args = parse_args("fig7", __doc__)
    trim = trim_run_dirs(args.results, "retention_view_*_seed42")
    ratios = {}
    for key, name in DATASETS:
        (row,) = read_jsonl(one(files(args.results, f"removal_view_{key}_seed42", "run_summaries.jsonl"),
                                f"TRIM_R summary of {key}"))
        removal = row["total_seconds"] - row["baseline_seconds"] - row["final_verification_seconds"]
        trim_run = trim[f"retention_view_{key}_seed42"]
        seconds, tolerance = seconds_to_stop(trim_run)
        if tolerance != EPS[key]:
            raise ValueError(f"TRIM {key}: tolerance {tolerance} is not the panel's epsilon {EPS[key]}.")
        if seconds is None:
            raise ValueError(f"TRIM {key}: the run ended before its final check passed.")
        trim_metrics = json.loads((trim_run / "metrics.json").read_text(encoding="utf-8"))
        iteration = int(trim_metrics["iteration_count"]) - 1
        metrics_path = Path(row["run_dir"]) / "metrics.json"
        metrics = json.loads(metrics_path.read_text(encoding="utf-8")) if metrics_path.exists() else {}
        ratios[key] = removal / seconds
        print(f"{name:9s} TRIM {seconds:8.1f} s (round {iteration}, leak {-math.log(float(trim_metrics['final_leak_k'])):.2f}) | "
              f"TRIM_R {removal:9.1f} s ({row['iteration_count']} rounds, {metrics.get('termination_condition')}, "
              f"min-K {row['final_leak_k']}) | {ratios[key]:.1f}x")
    plt.rcParams.update({
        "font.family": "sans-serif",
        "font.sans-serif": ["Helvetica", "DejaVu Sans"],
        "font.size": 18,
        "axes.labelsize": 18,
        "xtick.labelsize": 16,
        "ytick.labelsize": 16,
        "axes.linewidth": LINEWIDTH,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
    })
    fig, ax = plt.subplots(figsize=(5.5, 5.0))
    centers = range(len(DATASETS))
    ax.bar([x - BAR_WIDTH / 2 for x in centers], [1.0] * len(DATASETS), width=BAR_WIDTH, color="black",
           edgecolor="black", linewidth=0.8, label="TRIM")
    ax.bar([x + BAR_WIDTH / 2 for x in centers], [ratios[key] for key, _ in DATASETS], width=BAR_WIDTH,
           color="#0072B2", hatch="..", edgecolor="black", linewidth=0.8, label=r"TRIM$_R$")
    for x, (key, _) in zip(centers, DATASETS):
        ax.text(x + BAR_WIDTH / 2, ratios[key] * 1.15, f"{ratios[key]:.1f}x", ha="center", va="bottom", fontsize=11)
    ax.set_xticks(list(centers))
    ax.set_xticklabels([name for _, name in DATASETS], fontfamily="DejaVu Sans Mono")
    ax.set_ylabel("Execution time (x)")
    ax.tick_params(width=LINEWIDTH)
    ax.set_yscale("log")
    ax.set_ylim(0.1, 10000.0)
    ax.yaxis.set_major_formatter(FuncFormatter(lambda value, _position: f"{value:g}"))
    ax.axhline(1.0, color="0.35", linewidth=1.5, linestyle="--", zorder=0.5)
    ax.grid(True, axis="y", which="major", alpha=0.28)
    ax.legend(loc="upper right", frameon=False, fontsize=11, handlelength=2.4, handletextpad=0.5)
    fig.subplots_adjust(left=0.18, bottom=0.07, right=0.97, top=0.97)
    ax.yaxis.set_label_coords(-0.1654, 0.5)  # room for the "10000" tick label
    save(fig, args.output, "fig7")
    plt.close(fig)


if __name__ == "__main__":
    main()
