"""Fig. 5d (scalability on BNG, 120K-950K rows).

Inputs under --results (default results/fig5d):
  bng_seed<s>/          TRIM runs (experiments.exp3_runtime.run_bng), stopping on utility at epsilon 0.05: algorithm
                        time up to the stop of the final check, checks included (paper_algorithm_time_seconds in
                        run_summaries.jsonl);
  baselines_n<rows>/    timing records jobs/bng_seed<s>_<model>.json (scripts/time_baselines.py): FIDO, EntryWise
                        and FeatSel = the harness's method loop; PAT = its grid fits plus its harness loop;
  tds_n<rows>/          TDS runs: the K loop (last K's metrics.json minus reference.json, file times).
Each curve is the five-seed mean per size. FIDO is drawn 200 s higher so that it stays visible. TDS markers are white
where some seed has no release with test Delta U <= epsilon (0.05).

    python -m plotting.paper.fig5d [--results results/fig5d] [--output figures/fig5d]
"""

from __future__ import annotations

import json
import re
import statistics
from pathlib import Path

from ._common import SEEDS, baseline_files, files, parse_args, read_jsonl, tds_loop_seconds, tds_task_dirs
from .style import scalability

SIZES = (120000, 240000, 360000, 480000, 600000, 720000, 950000)
EPS = 0.05
BASELINES = (("FIDO", "fido"), ("PAT", "pat"), ("FeatSel", "featsel"), ("EntryWise", "entrywise"))


def nrows_of(row):
    if row.get("nrows") not in (None, ""):
        return int(row["nrows"])
    config = json.loads((Path(row["run_dir"]) / "config.json").read_text(encoding="utf-8"))
    return int(config.get("nrows") or config["pipeline"]["nrows"])


def load(results):
    seconds = {}
    for path in files(results, "bng_seed*", "run_summaries.jsonl"):
        for row in read_jsonl(path):
            if row.get("paper_algorithm_time_seconds") is None:
                raise ValueError(f"TRIM {row.get('run_id')}: the run ended before its final check passed.")
            seconds.setdefault("TRIM", {}).setdefault(nrows_of(row), []).append(row["paper_algorithm_time_seconds"])
    for path in baseline_files(results, "baselines_n*", "jobs/*.json"):
        n = int(re.match(r"baselines_n(\d+)$", path.parents[1].name).group(1))
        record = json.loads(path.read_text(encoding="utf-8"))
        for label, key in BASELINES:
            entry = record["methods"].get(key, {})
            if entry.get("status") == "complete":
                seconds.setdefault(label, {}).setdefault(n, []).append(entry["seconds"])
    meets = {}
    for (stem, _task), task_dir in tds_task_dirs(results, "tds_n*").items():
        n = int(re.match(r"tds_n(\d+)$", stem).group(1))
        k_metrics = [json.loads(p.read_text(encoding="utf-8")) for p in task_dir.glob("tds/k_*/metrics.json")]
        if any(m.get("tree_cache_hit") for m in k_metrics):
            raise ValueError(f"TDS {task_dir}: a K reused a cached tree; time it from an empty cache.")
        seconds.setdefault("TDS", {}).setdefault(n, []).append(tds_loop_seconds(task_dir))
        meets.setdefault(n, []).append(any(m["test_delta_u"] <= EPS for m in k_metrics))
    for method, by_size in seconds.items():
        for n in SIZES:
            if len(by_size.get(n, [])) != len(SEEDS):
                raise ValueError(f"{method} at {n} rows: {len(by_size.get(n, []))} runs, expected {len(SEEDS)}")
    return seconds, meets


def main():
    args = parse_args("fig5d", __doc__)
    seconds, meets = load(args.results)
    mean = {method: {n: statistics.mean(by_size[n]) for n in SIZES} for method, by_size in seconds.items()}
    points = {method: [(n, mean[method][n]) for n in SIZES] for method in mean}
    hollow = frozenset(n for n in SIZES if not all(meets[n]))
    scalability.plot(points, args.output, hollow=hollow)
    lines = ["seconds (five-seed mean)  " + " ".join(f"{n // 1000:>6d}K" for n in SIZES) + "   950K / 120K"]
    for method in ("TRIM", "TDS", "FIDO", "EntryWise", "PAT", "FeatSel"):
        lines.append(f"{method:24s} " + " ".join(f"{mean[method][n]:7.0f}" for n in SIZES)
                     + f"   {mean[method][950000] / mean[method][120000]:.2f}x")
    for method in ("TDS", "EntryWise", "PAT", "FeatSel"):
        ratios = [mean[method][n] / mean["TRIM"][n] for n in SIZES]
        lines.append(f"{method} / TRIM: {min(ratios):.2f}-{max(ratios):.2f}x")
    lines.append("TDS seeds meeting epsilon " + " ".join(f"{sum(meets[n])}/{len(meets[n])}" for n in SIZES)
                 + f"; runs missing it: {sum(not ok for n in SIZES for ok in meets[n])} of "
                 f"{sum(len(meets[n]) for n in SIZES)}")
    (args.output / "fig5d_numbers.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
