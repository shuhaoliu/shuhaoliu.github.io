"""Fig. 5i (ranking methods, Income): execution time and how well each method orders the candidates.

Inputs under --results (default results/fig5i), from experiments.exp6_ranking.run:
  ranking_income_seed<s>/           five full runs: seed_<s>_candidates.csv and seed_<s>_runtime.csv; their ground
                                    truth is the target M refit on every measured candidate;
  ranking_proxy_refit_income_seed42/  the first eight rounds of seed 42 with the proxy also refit on every measured
                                    candidate (the check that TRIM's ranking feeds).
Rows:
  Exec. time (x)   each method's scoring time relative to TRIM over the five full runs (Retrain = refitting M);
  Inclusion        pairwise accuracy against the proxy refit, retention-class inclusions of the eight rounds;
  Refinement       pairwise accuracy against the M refit, attribute refinements of the five full runs.
Pairwise accuracy = the share of candidate pairs within a round and family that a method orders like the ground truth
(0.5 = chance), over rounds with at least 3 candidates of the family, averaged over rounds. Retrain is the ground truth
itself. IF is its score as computed, not divided by the privacy cost.

    python -m plotting.paper.fig5i [--results results/fig5i] [--output figures/fig5i]
"""

from __future__ import annotations

import statistics as st
from collections import defaultdict

import matplotlib.pyplot as plt

from ._common import files, parse_args, read_csv, save
from .style import ranking as bars

LABELS = ["TRIM", "IF", "Random", "Retrain"]
# Score column of each method in the candidate CSVs (Retrain: the ground truth's column) and its key in the runtime CSVs.
COLUMNS = {"TRIM": "rank_score", "IF": "yang_if_distance_score", "Random": "random_score"}
TIME_KEYS = {"TRIM": "trim", "IF": "if", "Random": "random", "Retrain": "retrain"}
# What each runtime row times: the scoring of every ranked candidate (Retrain: every refit of the measured candidates).
TIMING_SCOPES = {"trim": "all_ranked_candidates_including_setup", "if": "all_ranked_candidates_including_setup",
                 "random": "all_ranked_candidates_including_setup",
                 "retrain": "all_exact_evaluation_attempts_in_common_pool"}


def relative_times(candidate_paths, runtime_paths):
    """Per seed, each method's time summed over the rounds with measured candidates, over TRIM's; mean over seeds."""
    rounds = {(int(r["seed"]), int(r["iteration"])) for path in candidate_paths for r in read_csv(path)}
    times = {}
    for path in runtime_paths:
        for r in read_csv(path):
            key = (int(r["seed"]), int(r["iteration"]), r["method"])
            if key in times or r["timing_scope"] != TIMING_SCOPES.get(r["method"]):
                raise ValueError(f"{path}: duplicate row or unexpected timing scope for {key}")
            times[key] = float(r["time_seconds"])
    if set(times) != {(seed, iteration, key) for seed, iteration in rounds for key in TIMING_SCOPES}:
        raise ValueError("The runtime CSVs must hold one row per method for every round with measured candidates.")
    per_seed = []
    for seed in sorted({seed for seed, _ in rounds}):
        total = {key: 0.0 for key in TIMING_SCOPES}
        for iteration in sorted(i for s, i in rounds if s == seed):
            for key in TIMING_SCOPES:
                total[key] += times[(seed, iteration, key)]
        per_seed.append({key: total[key] / total["trim"] for key in TIMING_SCOPES})
    return [st.fmean(row[TIME_KEYS[label]] for row in per_seed) for label in LABELS]


def pair_accuracy(rows, family, truth_column):
    by_round = defaultdict(list)
    for r in rows:
        if r["candidate_type"] == family:
            by_round[(r["seed"], int(r["iteration"]))].append(r)
    columns = {**COLUMNS, "Retrain": truth_column}
    out = {m: [] for m in columns}
    for cands in by_round.values():
        if len(cands) < 3:
            continue
        truth = [float(r[truth_column]) for r in cands]
        for m, col in columns.items():
            score = [float(r[col]) for r in cands]
            pairs = [(i, j) for i in range(len(cands)) for j in range(i + 1, len(cands)) if truth[i] != truth[j]]
            if pairs:
                out[m].append(sum((score[i] - score[j]) * (truth[i] - truth[j]) > 0 for i, j in pairs) / len(pairs))
    return [st.mean(out[m]) for m in LABELS]


def main():
    args = parse_args("fig5i", __doc__)
    candidates = files(args.results, "ranking_income_seed*", "seed_*_candidates.csv")
    runtimes = files(args.results, "ranking_income_seed*", "seed_*_runtime.csv")
    time_row = relative_times(candidates, runtimes)
    proxy_refit = [r for path in files(args.results, "ranking_proxy_refit_income_seed42", "seed_42_candidates.csv")
             for r in read_csv(path)]
    inclusion = pair_accuracy(proxy_refit, "retention_class", "proxy_selection_score")
    full = [r for path in candidates for r in read_csv(path)]
    refinement = pair_accuracy(full, "vertical_refinement", "exact_selection_score")
    bars.configure_matplotlib()
    plt.rcParams["xtick.labelsize"] = 18
    fig, axes = plt.subplots(3, 1, sharex=True, figsize=(5.5, 6.6), gridspec_kw={"hspace": 0.20})
    bars.draw_bars(axes[0], time_row, LABELS, "Exec. time (x)", log_y=True)
    axes[0].axhline(1.0, color="0.35", linestyle="--", linewidth=2, zorder=0)
    bars.draw_bars(axes[1], inclusion, LABELS, "Inclusion")
    bars.draw_bars(axes[2], refinement, LABELS, "Refinement")
    for ax in axes[1:]:
        ax.set_ylim(0.0, 1.25)
        ax.axhline(0.5, color="0.35", linestyle=":", linewidth=2, zorder=0)  # chance level
    for ax in axes[:2]:
        ax.tick_params(axis="x", which="both", bottom=True, labelbottom=False)
    fig.subplots_adjust(left=0.19, bottom=0.07, right=0.97, top=0.98)
    save(fig, args.output, "fig5i", dpi=bars.DPI)
    plt.close(fig)
    for name, row in (("time / TRIM", time_row), ("inclusion accuracy", inclusion), ("refinement accuracy", refinement)):
        print(f"{name:20s} " + "  ".join(f"{label} {v:.3g}" for label, v in zip(LABELS, row)))


if __name__ == "__main__":
    main()
