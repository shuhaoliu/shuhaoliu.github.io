"""Fig. 4a-4h (privacy--utility of TRIM and the baselines) and the Exp-1 numbers in the text.

Inputs under --results (default results/fig4):
  <dataset>_<model>_seed<s>/  TRIM runs (configs/paper/fig4/), their trajectory.csv files;
  baselines*/                 the baseline harness runs (scripts/run_baselines.py), combined/baseline_long.csv;
  tds*/                       the KAnon (TDS) sweeps (experiments.exp1_kanon_global.run), baseline_long.csv.
Every panel: seeds 42-46; one point per TRIM round and per baseline operating point (the mean over the seeds); Delta U
over each method's best output, the full split included for the baselines (style/privacy_utility.py). Income panels
end at Delta U 0.1 and BM panels at 0.02.

Outputs under --output (default figures/fig4): fig4a.pdf ... fig4h.pdf (and .png), the legend fig4_legend.pdf, the
drawn points fig4<x>_points.csv, and fig4_numbers.txt with
  (1) PAT's Delta U over TRIM's at the same leak (ratio range per model; headline = 1 - 1/largest ratio),
  (2) baseline points below TRIM's curve, (3) PAT's first leak reduction, (4) EntryWise/FIDO lowest leak,
  (5) TRIM's leak difference between the two target models (largest relative difference on a Delta U grid).

    python -m plotting.paper.fig4 [--results results/fig4] [--output figures/fig4]
"""

from __future__ import annotations

import csv
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from ._common import SEEDS, baseline_files, files, parse_args
from .style import privacy_utility

# Panel -> (dataset key of the configs, dataset key of the rows, model, Delta U cap of the drawing)
PANELS = {
    "4a": ("income", "income", "mlp", 0.1),
    "4b": ("income", "income", "xgboost", 0.1),
    "4c": ("diabetes", "diabetes", "mlp", None),
    "4d": ("diabetes", "diabetes", "xgboost", None),
    "4e": ("pubcov", "pubcov", "mlp", None),
    "4f": ("pubcov", "pubcov", "xgboost", None),
    "4g": ("bm", "bm_halfmonth", "mlp", 0.02),
    "4h": ("bm", "bm_halfmonth", "xgboost", 0.02),
}
NAMES = {"4a": "Income MLP", "4b": "Income XGBoost", "4c": "Diabetes MLP", "4d": "Diabetes XGBoost",
         "4e": "PubCov MLP", "4f": "PubCov XGBoost", "4g": "BM MLP", "4h": "BM XGBoost"}
METHODS = ["TRIM", "PAT", "FeatSel", "EntryWise", "KAnonGlobal", "FIDO"]
BASELINES = ("PAT", "FeatSel", "EntryWise", "FIDO", "KAnonGlobal")
TOL = 1e-9
COARSE = 0.1  # PAT points within 0.1 of PAT's lowest leak are its coarsest operating points
ZERO = 0.001  # TRIM reducing leak at Delta U below this is at no cost (an "unreduced" case)


def merged(sources, target):
    """One long table of ``sources`` (same columns); a point measured twice (a repeated run) is kept once, from the later file."""
    rows, fields = {}, None
    for path in sources:
        with open(path, encoding="utf-8") as handle:
            reader = csv.DictReader(handle)
            fields = fields or reader.fieldnames
            for row in reader:
                rows[tuple(row[k] for k in ("method", "variant", "dataset", "model", "seed", "point",
                                            "y_metric"))] = row
    with open(target, "w", newline="", encoding="utf-8") as out:
        writer = csv.DictWriter(out, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows.values())
    return target


def long_tables(results, scratch):
    """The harness's combined long tables and the TDS sweeps' long tables, one merged file each."""
    harness = baseline_files(results, "baselines*", "combined/baseline_long.csv")
    tds = [path for stem_dir in sorted(results.glob("tds*")) if stem_dir.is_dir()
           for path in sorted(stem_dir.glob("*/baseline_long.csv"))]
    if not harness or not tds:
        raise FileNotFoundError(f"Baseline long tables missing under {results}: harness {len(harness)}, TDS {len(tds)}")
    return merged(harness, scratch / "harness_long.csv"), merged(tds, scratch / "tds_long.csv")


def draw(args, scratch):
    harness, tds = long_tables(args.results, scratch)
    points = {}
    for tag, (config_key, dataset, model, cap) in PANELS.items():
        trim = files(args.results, f"{config_key}_{model}_seed*", "trajectory.csv")
        if not trim:
            raise FileNotFoundError(f"Fig. {tag}: no TRIM trajectory.csv under {args.results}")
        curves = privacy_utility.curves(trim, [tds, harness], dataset, model, SEEDS, METHODS)
        privacy_utility.draw(curves, args.output, f"fig{tag}", xmax=cap)
        path = args.output / f"fig{tag}_points.csv"
        privacy_utility.write_points(curves, dataset, model, SEEDS, path)
        points[tag] = (path, cap)
    privacy_utility.draw_legend(METHODS, args.output, "fig4_legend")
    return points


def load(points, tag, panel):
    path, cap = points[tag]
    df = pd.read_csv(path)
    df = df[(df.panel == panel) & np.isfinite(df.y)]
    if cap is not None:
        df = df[df.test_delta_u <= cap + 1e-12]
    return df


def envelope(trim):
    trim = trim.sort_values("test_delta_u")
    return trim.test_delta_u.values, np.minimum.accumulate(trim.y.values)


def env_at(tx, ty, u):
    i = np.searchsorted(tx, u + 1e-12, side="right") - 1
    return np.where(i >= 0, ty[np.maximum(i, 0)], 0.0)


def pat_ratios(points, lines):
    """PAT's Delta U over TRIM's smallest Delta U with no larger leak, at PAT's drawn operating points."""
    rows = []
    for tag in PANELS:
        df = load(points, tag, "leak")
        trim = df[df.method == "TRIM"][["test_delta_u", "y"]]
        pat, best = [], np.inf
        for row in df[df.method == "PAT"].sort_values(["test_delta_u", "y"]).itertuples():
            if row.y < best - TOL:  # vertices of PAT's drawn (lower-envelope) curve
                pat.append(row)
                best = row.y
        coarsest = min(p.y for p in pat)
        lines.append(f"\nFig. {tag} {NAMES[tag]}: PAT point, leak, Delta U PAT, Delta U TRIM, ratio, note")
        for p in pat:
            note, ratio, du_trim = "", np.nan, np.nan
            if p.y >= -TOL:
                note = "leak 0: unreduced, no ratio"
            else:
                match = trim[trim.y <= p.y + TOL]
                if match.empty:
                    note = "beyond TRIM's lowest leak"
                else:
                    du_trim = match.test_delta_u.min()
                    ratio = p.test_delta_u / du_trim if du_trim > 0 else np.inf
                    if p.y <= coarsest + COARSE:
                        note = "coarsest PAT points (excluded)"
                    elif du_trim < ZERO:
                        note = f"TRIM reduces leak at Delta U < {ZERO} (excluded)"
            rows.append(dict(panel=tag, model=NAMES[tag].split()[-1], ratio=ratio, note=note))
            lines.append(f"  {p.point:18s} {p.y:7.2f} {p.test_delta_u:9.4f} {du_trim:9.4f} {ratio:7.2f}   {note}")
    table = pd.DataFrame(rows)
    ok = table[(table.note == "") & np.isfinite(table.ratio)]
    lines.append("\n(1) PAT / TRIM Delta U ratio at the same leak")
    for model in ("MLP", "XGBoost"):
        part = ok[ok.model == model]
        lines.append(f"  {model:8s} {part.ratio.min():.2f}-{part.ratio.max():.2f}x ({len(part)} points)")
    lines.append(f"  headline: up to {100 * (1 - 1 / ok.ratio.max()):.1f}% less utility degradation than PAT")


def checks(points, lines):
    lines.append("\n(2) Baseline points below TRIM's curve (within TRIM's drawn Delta U range)")
    for panel in ("leak", "tail"):
        for tag in PANELS:
            df = load(points, tag, panel)
            tx, ty = envelope(df[df.method == "TRIM"])
            out = []
            for method in BASELINES:
                pts = df[(df.method == method) & (df.test_delta_u <= tx[-1] + 1e-12)]
                if pts.empty:
                    continue
                gap = pts.y.values - env_at(tx, ty, pts.test_delta_u.values)
                below = pts[gap < -TOL]
                text = f"{method} {len(below)}/{len(pts)}"
                if len(below):
                    text += f" (from Delta U {below.test_delta_u.min():.3f}, up to {-gap.min():.2f} lower)"
                out.append(text)
            lines.append(f"  [{panel}] Fig. {tag}: " + "; ".join(out))
    lines.append("\n(3) PAT's smallest drawn Delta U with leak < 0; TRIM's leak at Delta U <= 0.02")
    for tag in PANELS:
        df = load(points, tag, "leak")
        pat = df[(df.method == "PAT") & (df.y < -TOL)]
        tx, ty = envelope(df[df.method == "TRIM"])
        first = (f"{pat.test_delta_u.min():.4f} (leak {pat.loc[pat.test_delta_u.idxmin(), 'y']:.2f})"
                 if len(pat) else "never")
        lines.append(f"  Fig. {tag}: PAT {first}; TRIM {float(env_at(tx, ty, 0.02)):.2f}")
    lines.append("\n(4) Lowest drawn leak of EntryWise and FIDO")
    for tag in PANELS:
        df = load(points, tag, "leak")
        lines.append(f"  Fig. {tag}: " + "; ".join(f"{m} {df[df.method == m].y.min():.2f}"
                                                   for m in ("EntryWise", "FIDO")))
    lines.append("\n(5) TRIM's leak, MLP vs XGBoost target (relative difference on a Delta U grid)")
    grid = np.round(np.arange(0.005, 0.1001, 0.005), 3)
    worst = 0.0
    for data, (a, b) in {"Income": ("4a", "4b"), "Diabetes": ("4c", "4d"), "PubCov": ("4e", "4f"),
                         "BM": ("4g", "4h")}.items():
        ta, tb = (load(points, t, "leak") for t in (a, b))
        xa, ya = envelope(ta[ta.method == "TRIM"])
        xb, yb = envelope(tb[tb.method == "TRIM"])
        xs = grid[grid <= min(xa[-1], xb[-1]) + 1e-12]
        la, lb = env_at(xa, ya, xs), env_at(xb, yb, xs)
        keep = (la < -TOL) & (lb < -TOL)
        rel = np.abs(la - lb)[keep] / np.maximum(np.abs(la), np.abs(lb))[keep]
        worst = max(worst, rel.max())
        lines.append(f"  {data:9s} max {100 * rel.max():.1f}% at Delta U {xs[keep][np.argmax(rel)]:.3f}, "
                     f"mean {100 * rel.mean():.1f}% ({keep.sum()} grid points)")
    lines.append(f"  largest over the datasets: {100 * worst:.1f}%")


def main():
    args = parse_args("fig4", __doc__)
    with tempfile.TemporaryDirectory() as scratch:
        points = draw(args, Path(scratch))
    lines = []
    pat_ratios(points, lines)
    checks(points, lines)
    (args.output / "fig4_numbers.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))


if __name__ == "__main__":
    main()
