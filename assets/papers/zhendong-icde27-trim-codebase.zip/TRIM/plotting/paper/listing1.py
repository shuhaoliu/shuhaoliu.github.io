"""Listing 1 (Exp-4 audit log, Income): the [run], log1, log2 and [stop] blocks, from the run's action log.

Input under --results (default results/listing1): audit_log_income/, one TRIM run (experiments.exp1_privacy_utility.run)
with config.json, state_history.jsonl and pipeline_selection_actions_*.jsonl. The data files of the config are read
to name retention classes.

- log1 (--log1-iteration, default 0): a committed refinement that lowers Leakage and is therefore charged the floor
  kappa; "evict={seed}" when it evicts every seed row; admit = the classes of the admitted rows at the new level.
- log2 (--log2-iteration, default 4): a committed retention-class inclusion; lga_rank is its rank by LGA / cost among
  the round's inclusions. alt = the runner-up by score, and the inclusion that LGA ranks first if it is not log2's.
Class ID = "RC-" + the first 3 hex digits (upper case) of sha256 of the class's generalized QI signature
"QI=<node id>|QI=<node id>|..." (per QI the leaf's ancestor at the round's level in the tree file). The log names a
class by its per-round index, the order in which classes first appear over the training rows.
Numbers are written with two significant digits; a cost equal to kappa is written "kappa".

    python -m plotting.paper.listing1 [--results results/listing1] [--output figures/listing1]
"""

from __future__ import annotations

import hashlib
import json
import math
from collections import Counter

import pandas as pd
import yaml

from prototype.dataset_registry import build_data_loader
from prototype.release_artifacts import load_dataset_split

from ._common import PROJECT_ROOT, parse_args, read_jsonl, trim_run_dirs

PURPOSE = {"income": "income>50K", "pubcov": "public-coverage", "diabetes": "readmission", "bm": "term-deposit"}
DATA_NAMES = {"income": "Income", "pubcov": "PubCov", "diabetes": "Diabetes", "bm": "BM"}
MODEL_NAMES = {"xgboost": "XGBoost", "mlp": "MLP"}


def sci(value, sign=False):
    """Two significant digits, e.g. 1.3e-2, -3.5e+0 (sign=True: +1.3e-1)."""
    if value == 0:
        return "0"
    exponent = math.floor(math.log10(abs(value)))
    mantissa = round(value / 10 ** exponent, 1)
    if abs(mantissa) >= 10:
        mantissa, exponent = mantissa / 10, exponent + 1
    return f"{mantissa:{'+' if sign else ''}.1f}e{exponent:+d}"


def find(mapping, key):
    """First value of ``key`` anywhere in a nested mapping."""
    if isinstance(mapping, dict):
        if key in mapping:
            return mapping[key]
        for value in mapping.values():
            found = find(value, key)
            if found is not None:
                return found
    return None


class Classes:
    """Generalized QI signatures of the training rows, in the split's row order."""

    def __init__(self, config):
        dataset = find(config, "dataset")
        tree_path = PROJECT_ROOT / find(config, "generalization_tree_path")
        tree_file = yaml.safe_load(tree_path.read_text(encoding="utf-8-sig"))
        self.trees = tree_file["trees"]
        loader = build_data_loader(dataset, data_path=PROJECT_ROOT / find(config, "data_path"))
        split = load_dataset_split(loader, {"val_size": find(config, "val_size") or 0.15,
                                            "test_size": find(config, "test_size") or 0.15,
                                            "random_state": find(config, "random_state"),
                                            "nrows": find(config, "nrows")})
        self.rows = split.X_train_raw
        self.rows.index = self.rows.index.astype(str)
        self.qis = [a for a in self.trees if a in self.rows.columns]
        self.ancestors, self.labels = {}, {}
        for attr, tree in self.trees.items():
            nodes = {n["id"]: n for n in tree["nodes"]}
            self.labels.update({n["id"]: n.get("label") for n in tree["nodes"]})
            table = {}
            for node in tree["nodes"]:
                if node["kind"] != "leaf":
                    continue
                chain, current = [], node
                while current is not None:
                    chain.append((current["height_from_leaf"], current["id"]))
                    current = nodes.get(current["parent"]) if current.get("parent") else None
                table[self.norm(node["value"])] = chain
            self.ancestors[attr] = table
        self.cache = {}

    @staticmethod
    def norm(value):
        try:
            return float(value)
        except (TypeError, ValueError):
            return str(value)

    def node_at(self, attr, value, level):
        best = None  # the highest ancestor whose height does not exceed the level
        for height, node_id in self.ancestors[attr][self.norm(value)]:
            if height <= level:
                best = node_id
        return best

    def signatures(self, level):
        key = json.dumps(level, sort_keys=True)
        if key not in self.cache:
            columns = {}
            for attr in self.qis:
                mapping = {v: self.node_at(attr, v, int(level[attr])) for v in self.rows[attr].unique()}
                columns[attr] = self.rows[attr].map(mapping)
            frame = pd.DataFrame(columns, index=self.rows.index)
            self.cache[key] = frame.apply(lambda r: "|".join(f"{a}={r[a]}" for a in self.qis), axis=1)
        return self.cache[key]

    @staticmethod
    def rc_id(signature):
        return "RC-" + hashlib.sha256(signature.encode()).hexdigest()[:3].upper()

    def ids_of(self, row_ids, level):
        return Counter(self.rc_id(s) for s in self.signatures(level).loc[[str(i) for i in row_ids]])

    def by_key(self, level):
        """Class index of the log (first appearance over the training rows) -> (class ID, class size)."""
        signatures = self.signatures(level)
        sizes = signatures.value_counts()
        return {i: (self.rc_id(s), int(sizes[s])) for i, s in enumerate(dict.fromkeys(signatures.tolist()))}

    def step(self, attr, level):
        text = self.trees[attr]["level_descriptions"][level]
        return text.split(" ", 1)[1].strip().replace(" ", "-") if text.startswith("L") else text


def op_name(event, short=False):
    if event["action"] == "retention_class":
        return "class-inclusion" if short else "retention-class-inclusion"
    return "refine-and-evict" if event.get("eviction_ceiling") is not None else "refine-and-swap"


def main():
    args = parse_args("listing1", __doc__, lambda p: (p.add_argument("--log1-iteration", type=int, default=0),
                                                      p.add_argument("--log2-iteration", type=int, default=4)))
    run = trim_run_dirs(args.results, "audit_log_income")["audit_log_income"]
    # The run's config.json holds the pipeline settings; dataset, data_path and model_name are in the experiment's
    # manifest.json (resolved_runs). find() looks in the run's settings first.
    manifest = next(d / "manifest.json" for d in run.parents if (d / "manifest.json").exists())
    resolved = json.loads(manifest.read_text(encoding="utf-8"))["resolved_runs"]
    if len(resolved) != 1:
        raise ValueError(f"{manifest}: expected one resolved run, found {len(resolved)}")
    config = {"run": json.loads((run / "config.json").read_text(encoding="utf-8")), "task": resolved[0]}
    events = [e for path in sorted(run.glob("pipeline_selection_actions_*.jsonl")) for e in read_jsonl(path)]
    history = read_jsonl(run / "state_history.jsonl")
    kappa = float(find(config, "privacy_cost_floor"))
    classes = Classes(config)
    dataset = find(config, "dataset")
    cost = lambda e: "kappa" if abs(float(e["privacy_cost"]) - kappa) < 1e-12 else sci(float(e["privacy_cost"]))  # noqa: E731
    lines = [f"[run] data={DATA_NAMES.get(dataset, dataset)} purpose={PURPOSE.get(dataset, dataset)} "
             f"target={MODEL_NAMES.get(find(config, 'model_name'), find(config, 'model_name'))} "
             f"epsilon={sci(float(find(config, 'tolerance')))} b={find(config, 'rank_top_k')}"]

    def evaluated(iteration):
        return [e for e in events if e.get("event") == "candidate_evaluation" and e["iteration"] == iteration
                and e.get("utility_gain") is not None]

    def lga_rank(candidate, pool):
        family = [e for e in pool if e["action"] == candidate["action"]
                  and (e.get("eviction_ceiling") is None) == (candidate.get("eviction_ceiling") is None)]
        return 1 + sum(float(e["rank_score"]) > float(candidate["rank_score"]) for e in family)

    # log1
    it = args.log1_iteration
    (chosen,) = [e for e in evaluated(it) if e.get("selected")]
    before, after = history[it], history[it + 1]
    attr = chosen["attribute"]
    seed_rows = set(map(str, history[0].get("bootstrap_row_ids") or history[0]["retained_row_ids"]))
    evicted = set(map(str, after.get("evicted_row_ids") or []))
    admitted = classes.ids_of(after.get("admitted_row_ids") or [], after["generalization_level"])
    evict_text = "{seed}" if evicted and seed_rows <= evicted else \
        "{" + "; ".join(classes.ids_of(evicted, before["generalization_level"])) + "}"
    if float(chosen["leakage_delta"]) >= 0 or cost(chosen) != "kappa":
        print(f"note: log1 (iteration {it}) does not lower Leakage at cost kappa")
    lines += [f"[log1] action=COMMIT op={op_name(chosen)} target={attr}",
              f"       step={classes.step(attr, int(before['generalization_level'][attr]))}->"
              f"{classes.step(attr, int(after['generalization_level'][attr]))}",
              f"       evict={evict_text} admit={{{'; '.join(admitted)}}}",
              f"       gain_est={sci(float(chosen['utility_gain']))} "
              f"leakage_delta={sci(float(chosen['leakage_delta']), sign=True)} cost={cost(chosen)}",
              f"       rho={sci(float(chosen['utility_gain']))}/kappa reason=max-rho" if cost(chosen) == "kappa"
              else f"       rho={sci(float(chosen['score']))} reason=max-rho"]

    # log2
    it = args.log2_iteration
    pool = evaluated(it)
    (chosen,) = [e for e in pool if e.get("selected")]
    level = history[it]["generalization_level"]
    keyed = classes.by_key(level)
    name = lambda e: keyed[int(e["retention_class_key"])][0] if e["action"] == "retention_class" else e["attribute"]  # noqa: E731
    rank = lga_rank(chosen, pool)
    admitted_rows = len(history[it + 1].get("admitted_row_ids") or [])
    scope = "all-class-members" if admitted_rows == keyed[int(chosen["retention_class_key"])][1] else \
        f"{admitted_rows}-class-members"
    lines += [f"[log2] action=COMMIT op={op_name(chosen)} target={name(chosen)} lga_rank={rank}",
              f"       scope={{same-QI-signature; {scope}}}",
              f"       gain_est={sci(float(chosen['utility_gain']))} "
              f"leakage_delta={sci(float(chosen['leakage_delta']), sign=True)} cost={cost(chosen)}",
              f"       rho={sci(float(chosen['score']))} reason=max-rho"]
    others = sorted((e for e in pool if not e.get("selected")), key=lambda e: -float(e["score"]))
    alternatives = others[:1]
    inclusions = [e for e in pool if e["action"] == "retention_class"]
    top = max(inclusions, key=lambda e: float(e["rank_score"]))
    if top is not chosen and top not in alternatives:
        alternatives.append(top)
    for alt in alternatives:
        lines += [f"       alt={{op={op_name(alt, short=True)}; target={name(alt)}; lga_rank={lga_rank(alt, pool)};",
                  f"         gain_est={sci(float(alt['utility_gain']))}; "
                  f"leakage_delta={sci(float(alt['leakage_delta']), sign=True)}; rho={sci(float(alt['score']))}}}"]
    summary = next(e for e in events if e.get("event") == "pipeline_summary")
    passed = summary.get("validation_utility_constraint_met", summary.get("utility_constraint_met"))
    lines.append(f"[stop] state=D[T] check=target-on-validation DeltaU(D[T])<=epsilon "
                 f"result={'PASS' if passed else 'FAIL'}")
    text = "\n".join(lines)
    (args.output / "listing1.txt").write_text(text + "\n", encoding="utf-8")
    print(text)
    print(f"\nfinal Leakage {-math.log(summary['final_leak_k']):.3f}, termination {summary.get('termination_condition')}")


if __name__ == "__main__":
    main()
