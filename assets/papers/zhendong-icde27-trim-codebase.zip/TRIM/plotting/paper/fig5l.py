"""Fig. 5l (selection-rule ablation, PubCov) and its text numbers.

Inputs under --results (default results/fig5l): selection_<rule>_pubcov_seed<s>/
(experiments.exp6_ablation.run_selection): iterations.csv per experiment and state_history.jsonl per run.
Curve at Delta U = x: per rule and seed the lowest leak (top) or leak T (bottom) among the states with test
Delta U <= x, the original data (0, 0) always counting; then the mean over seeds 42-46, up to Delta U 0.10.
Text numbers: per rule, the five-seed mean leak of the release at epsilon (the first state with target validation
Delta U <= epsilon; the original data, leak 0, when none), and how many seeds release the original data.

    python -m plotting.paper.fig5l [--results results/fig5l] [--output figures/fig5l]
"""

from __future__ import annotations

import math
import statistics

from ._common import SEEDS, files, parse_args, read_csv, read_jsonl
from .style import ablation_line

RULES = ("TRIM", "Privacy", "Utility", "Random", "IF")
EPS = (0.02, 0.025, 0.03, 0.04, 0.05, 0.06, 0.07, 0.08, 0.1)


def main():
    args = parse_args("fig5l", __doc__)
    states = {}
    for path in files(args.results, "selection_*_pubcov_seed*", "iterations.csv"):
        for r in read_csv(path):
            states.setdefault(r["method"], {}).setdefault(int(r["random_state"]), []).append(
                (float(r["test_delta_u"]), -math.log(float(r["min_k"]) / float(r["original_leak_k"])),
                 float(r["tail_risk_p99"])))
    for rule in RULES:
        if sorted(states.get(rule, {})) != list(SEEDS):
            raise ValueError(f"{rule}: seeds {sorted(states.get(rule, {}))}, expected {list(SEEDS)}")
    curves = {rule: [states[rule][s] for s in SEEDS] for rule in RULES}
    grid = [round(0.0025 * i, 4) for i in range(0, 41)]
    # Legend: the other rules first, TRIM last.
    ablation_line.draw_mean(curves, list(RULES), grid, args.output, "fig5l",
                            legend_order=list(range(1, len(RULES))) + [0])
    releases = {}
    for path in files(args.results, "selection_*_pubcov_seed*", "state_history.jsonl"):
        name = path.parents[1].name  # <run prefix>_method_<rule>_seed_<seed>
        rule, seed = name.split("_method_")[1].rsplit("_seed_", 1)
        rows = sorted((int(r.get("round", r.get("iteration", 0)) or 0), float(r["target_validation_delta_u"]),
                       -math.log(int(r["mixed_min_k"])))
                      for r in read_jsonl(path)
                      if r.get("target_validation_delta_u") is not None and r.get("mixed_min_k") is not None)
        releases.setdefault(rule, {})[int(seed)] = rows
    print("epsilon " + "".join(f"{rule:>18}" for rule in RULES))
    for eps in EPS:
        cells = []
        for rule in RULES:
            picks = [next(((leak, True) for _, v, leak in releases[rule][s] if v <= eps), (0.0, False))
                     for s in sorted(releases[rule])]
            cells.append(f"{statistics.mean(v for v, _ in picks):8.2f} ({sum(not ok for _, ok in picks)} D)")
        print(f"{eps:<7} " + "".join(f"{c:>18}" for c in cells))


if __name__ == "__main__":
    main()
