"""Find every distinct KAnon (TDS) release between two K values of the Fig. 4 grid (Fig. 5g).

A TDS release whose smallest class has m records is also TDS's release for every K in [K, m]: a larger K only
removes specializations the path never needed. The grid (powers of two) can therefore skip releases that meet the
tolerance. Starting from the most private grid release with test Delta U <= the tolerance (K_lo), this script runs
TDS at K = m + 1, reads the new release's smallest class m, and repeats until K exceeds the next grid value
(K_hi), so every distinct release in (K_lo, K_hi] is evaluated once. Each step is one runner call
(``experiments.exp1_kanon_global.run --k K``) with run label ``walk_<dataset>_<model>_seed<seed>_k<K>``.

    python scripts/tds_k_walk.py --config configs/paper/fig5g/tds_walk.yaml --sweep-results results/fig4/tds \\
        --dataset income --model mlp --seed 42 --tolerance 0.1
"""
import argparse
import json
from pathlib import Path
import subprocess
import sys

import yaml

ROOT = Path(__file__).resolve().parents[1]


def points(directory, dataset, model, seed):
    """Every TDS point of one task under ``directory`` (all runner calls)."""
    rows = []
    for path in sorted(Path(directory).glob("*/raw_results.jsonl")):
        for line in path.read_text(encoding="utf-8").splitlines():
            row = json.loads(line)
            if (row["dataset"], row["model"], int(row["seed"])) == (dataset, model, seed):
                rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True, help="TDS configuration of the walk (results_root).")
    parser.add_argument("--sweep-results", required=True, help="results_root of the Fig. 4 TDS sweep.")
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--model", required=True)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--tolerance", required=True, type=float)
    parser.add_argument("--device")
    args = parser.parse_args()
    config = yaml.safe_load((ROOT / args.config).read_text(encoding="utf-8"))
    grid = sorted(points(ROOT / args.sweep_results, args.dataset, args.model, args.seed), key=lambda r: r["target_k"])
    within = [row for row in grid if row["test_delta_u"] <= args.tolerance]
    if not within:
        raise SystemExit("No grid release meets the tolerance.")
    low = max(within, key=lambda row: row["target_k"])
    above = [row["target_k"] for row in grid if row["target_k"] > low["target_k"]]
    if not above:
        raise SystemExit("The most private grid release meets the tolerance; nothing to walk.")
    high = min(above)
    k = int(low["min_k"]) + 1
    print(f"walk from K {low['target_k']} (min-K {low['min_k']}) to K {high}", flush=True)
    while k <= high:
        label = f"walk_{args.dataset}_{args.model}_seed{args.seed}_k{k}"
        command = [sys.executable, "-u", "-m", "experiments.exp1_kanon_global.run", "--config", args.config,
                   "--dataset", args.dataset, "--model", args.model, "--seed", str(args.seed), "--k", str(k),
                   "--run-label", label]
        if args.device:
            command += ["--device", args.device]
        subprocess.run(command, cwd=ROOT, check=True)
        runs = sorted((ROOT / config["results_root"]).glob(f"*_exp1_kanon_global_{label}"))
        lines = (runs[-1] / "raw_results.jsonl").read_text(encoding="utf-8").splitlines() if runs else []
        new = [row for row in map(json.loads, lines) if int(row["target_k"]) == k]
        if len(new) != 1:
            raise SystemExit(f"{label}: expected one point, found {len(new)}.")
        print(f"K {k}: min-K {new[0]['min_k']}, test Delta U {new[0]['test_delta_u']:.6g}", flush=True)
        k = int(new[0]["min_k"]) + 1


if __name__ == "__main__":
    main()
