"""Exp-2 attacks on the data-minimization baselines' Income releases (Fig. 5a).

The Exp-2 runner attacks TRIM releases only. This script applies the same two attacks
(``experiments.exp2_attacks.attacks``: QI reconstruction and QI inference) with the same settings
to the stored baseline releases of Fig. 4 (``experiments.exp1_baselines``).

Operating point per method and seed, at the Exp-2 tolerance epsilon = 0.05 with the MLP target:
- FeatSel, EntryWise, PAT: among the releases with validation Delta U <= epsilon, the one with the largest
  min-K (ties: lower validation Delta U, then point label);
- FIDO: its own stop size for epsilon (``fido_epsilons`` contains epsilon).

Each release is encoded as the harness encodes it for the MLP (exact cells at level 0, released domains with
TRIM's encoding), the test records follow the method's convention (FeatSel's removed QIs are ROOT, PAT's
buckets apply, FIDO and EntryWise keep exact values), and the attacks see the unstandardized frames, as for
TRIM. Writes ``<method>_seed<seed>.json`` and ``baseline_attacks.csv`` under the configuration's results_root.

    python scripts/attack_baselines.py --config configs/paper/fig5ab/baselines_attacks.yaml
"""

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import yaml

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from experiments.exp1_baselines import pat  # noqa: E402
from experiments.exp1_baselines.encoding import ReleaseEncoder  # noqa: E402
from experiments.exp1_baselines.evaluator import build_context  # noqa: E402
from experiments.exp1_baselines.release import ROOT, DomainColumn, load_release  # noqa: E402
from experiments.exp1_kanon.hierarchy import HierarchySchema  # noqa: E402
from experiments.exp2_attacks.attacks import run_reconstruction_attack, run_strong_linkage_attack  # noqa: E402
from experiments.run_matrix_sweep import expand_matrix  # noqa: E402
from prototype.release_artifacts import MaterializedTRIMRelease  # noqa: E402

METHODS = ("FIDO", "FeatSel", "EntryWise", "PAT")


def pick(rows, method, epsilon):
    if method == "FIDO":
        chosen = [r for r in rows
                  if epsilon in [float(x) for x in str(r["fido_epsilons"]).replace(",", ";").split(";") if x]]
        if len(chosen) != 1:
            raise ValueError(f"FIDO: expected one operating point for epsilon {epsilon}, found {len(chosen)}.")
        return chosen[0]
    feasible = [r for r in rows if float(r["validation_delta_u"]) <= epsilon]
    if not feasible:
        raise ValueError(f"{method}: no release with validation Delta U <= {epsilon}.")
    return min(feasible, key=lambda r: (-float(r["min_k"]), float(r["validation_delta_u"]), r["point"]))


def scalars(prefix, payload):
    return {f"{prefix}_{k}": v for k, v in payload.items() if isinstance(v, (int, float, str, bool)) or v is None}


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--config", required=True)
    parser.add_argument("--device", default="cuda")
    args = parser.parse_args()

    config = yaml.safe_load((ROOT_DIR / args.config).read_text(encoding="utf-8"))
    epsilon = float(config["epsilon"])
    roots = {"main": ROOT_DIR / config["baseline_results"], "pat": ROOT_DIR / config["pat_results"]}
    bucketizations = ROOT_DIR / config["pat_bucketizations"]
    output = ROOT_DIR / config["results_root"]
    output.mkdir(parents=True, exist_ok=False)
    raw = {}
    for part, root in roots.items():
        with (root / "combined" / "raw_results.csv").open(encoding="utf-8") as handle:
            for row in csv.DictReader(handle):
                if row.get("record_type", "point") not in ("point", "") or row["dataset"] != config["dataset"]:
                    continue
                if row["model"] != config["model"] or row["method"] not in METHODS:
                    continue
                raw.setdefault((row["method"], int(row["seed"]), part), []).append(row)
    matrix = yaml.safe_load((ROOT_DIR / config["matrix_config"]).read_text(encoding="utf-8"))
    tasks = [task for task in expand_matrix(matrix)
             if task["dataset"] == config["dataset"] and task.get("model_name") == config["model"]]
    results = []
    for seed in config["seeds"]:
        task = next(task for task in tasks if int(task["pipeline"]["random_state"]) == int(seed))
        context = build_context(task)
        split = context.split
        encoder = ReleaseEncoder(context.generalization, family="mlp")
        train0 = encoder.level0_frame(split.X_train_raw).to_numpy(dtype=np.float64)
        test0 = encoder.level0_frame(split.X_test_raw).to_numpy(dtype=np.float64)
        schema = HierarchySchema(context.generalization)
        for method in METHODS:
            part = "pat" if method == "PAT" else "main"
            root = roots[part]
            row = pick(raw[(method, seed, part)], method, epsilon)
            release, payload, _split = load_release(root / row["release_path"],
                                                    root / "splits" / f"{config['dataset']}_seed{seed}.json.gz")
            test_columns = {}
            if method == "FeatSel":
                removed = [qi for qi in str(row["featsel_removed_qis"]).split(";") if qi]
                test_columns = {qi: DomainColumn.constant(len(split.X_test_raw), ROOT) for qi in removed}
            elif method == "PAT":
                source = (f"{config['dataset']}_seed{seed}_L{int(float(row['pat_max_leaf_nodes'])):03d}"
                          f"_alpha{float(row['pat_alpha']):.2f}.json")
                bucketization = pat.load_pat_bucketization(bucketizations / source, context, schema)
                test_columns = bucketization.evaluation_columns(split.X_test_raw)
            published_ids = split.X_train_raw.index[release.positions]
            train = encoder.apply(train0[release.positions], release.columns, copy=True)
            test = encoder.apply(test0, test_columns or {}, copy=True)
            materialized = MaterializedTRIMRelease(
                published_frame=pd.DataFrame(train, index=published_ids, columns=encoder.column_names),
                published_y=split.y_train.loc[published_ids],
                evaluation_frame=pd.DataFrame(test, index=split.X_test_raw.index, columns=encoder.column_names),
                evaluation_y=split.y_test,
                published_raw=split.X_train_raw.loc[published_ids],
                evaluation_raw=split.X_test_raw,
                evaluation_split="test",
                release={"status": "ok", "min_k": int(float(row["min_k"])), "row_count": len(published_ids)},
            )
            reconstruction = run_reconstruction_attack(
                materialized, context.loader, config["reconstruction"], random_state=seed,
                device=args.device, dtype="float32", allow_cpu_fallback=True)
            linkage = run_strong_linkage_attack(
                materialized, config["linkage"], random_state=seed,
                device=args.device, dtype="float32", allow_cpu_fallback=True)
            record = {"method": method, "seed": seed, "point": row["point"], "epsilon": epsilon,
                      "min_k": row["min_k"], "original_leak_k": row["original_leak_k"],
                      "validation_delta_u": row["validation_delta_u"], "test_delta_u": row["test_delta_u"],
                      "row_count": len(published_ids), "release_path": row["release_path"],
                      **scalars("reconstruction", reconstruction), **scalars("linkage", linkage)}
            results.append(record)
            (output / f"{method}_seed{seed}.json").write_text(
                json.dumps({"record": record, "reconstruction": reconstruction, "linkage": linkage},
                           default=str, indent=1), encoding="utf-8")
            print(method, seed, row["point"], "min_k", row["min_k"],
                  "recon", record.get("reconstruction_test_reconstruction_error_mean"),
                  "link", record.get("linkage_test_linkage_error"), flush=True)
    columns = sorted({key for record in results for key in record})
    with (output / "baseline_attacks.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(results)


if __name__ == "__main__":
    main()
