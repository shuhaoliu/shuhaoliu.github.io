"""Fig. 5b QI inference averaged over every QI (Exp-2).

On every TRIM release of the Fig. 5a/5b attack runs (results/fig5ab/attacks_income_seed<s>/, the newest experiment of
each: rounds from min_iteration on and the final release), each configured QI in turn is inferred from the minimized
values of the other QIs of the configured input set, with the Fig. 5a inference attack and knowledge
(``experiments.exp2_attacks.attacks.run_strong_linkage_attack``: an MLP trained on the raw target of a fifth of the
published records, evaluated on held-out records routed through the release). Fig. 5b averages the attack's gain over
guessing across the targets. Writes inference_average_seed<s>.csv (one row per release point and target) under the
configuration's results_root.

    python scripts/attack_inference_average.py --config configs/paper/fig5ab/inference_average.yaml [--seed S ...]
"""
import argparse
import csv
import sys
from pathlib import Path

import torch
import yaml

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from experiments.common import resolve_project_path  # noqa: E402
from experiments.exp2_attacks.attacks import run_strong_linkage_attack  # noqa: E402
from prototype.dataset_registry import build_data_loader, resolve_generalization_tree  # noqa: E402
from prototype.release_artifacts import load_trim_release, materialize_trim_release  # noqa: E402

COLUMNS = ["seed", "release_point", "iteration", "min_k", "original_leak_k", "target", "a_attributes",
           "training_row_count", "query_count", "test_linkage_error", "baseline_test_linkage_error"]


def main():
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--config", required=True)
    parser.add_argument("--seed", type=int, action="append", help="Run only this seed; repeat for several.")
    args = parser.parse_args()
    config = yaml.safe_load((ROOT_DIR / args.config).read_text(encoding="utf-8"))
    torch.set_num_threads(int(config["threads"]))
    output = ROOT_DIR / config["results_root"]
    output.mkdir(parents=True, exist_ok=True)
    loader = build_data_loader(config["dataset"], data_path=resolve_project_path(config["data_path"]))
    tree = resolve_generalization_tree(config["dataset"],
                                       tree_path=resolve_project_path(config["generalization_tree_path"]))
    for seed in args.seed or config["seeds"]:
        seed = int(seed)
        results = sorted((ROOT_DIR / config["attack_results"]).glob(f"attacks_income_seed{seed}/*/results.csv"))
        if not results:
            raise FileNotFoundError(f"No Fig. 5a/5b attack run for seed {seed} under {config['attack_results']}.")
        rows = list(csv.DictReader(results[-1].open(encoding="utf-8")))
        run_dir = Path(rows[0]["artifact_run_dir"])
        records = []
        for row in rows:
            final = row["release_point"] == "final"
            if not final and int(row["iteration"]) < int(config["min_iteration"]):
                continue
            iteration = None if final else int(row["iteration"])
            released = materialize_trim_release(loader, tree, load_trim_release(run_dir, iteration=iteration),
                                                evaluation_split="test")
            for target in config["targets"]:
                linkage = dict(config["linkage"])
                linkage["a_attributes"] = [a for a in config["a_attributes"] if a != target]
                linkage["b_attributes"] = [target]
                result = run_strong_linkage_attack(released, linkage, random_state=seed, device=config["device"],
                                                   dtype="float32", allow_cpu_fallback=True)
                records.append({"seed": seed, "release_point": row["release_point"], "iteration": row["iteration"],
                                "min_k": row["min_k"], "original_leak_k": row["original_leak_k"], "target": target,
                                "a_attributes": ",".join(linkage["a_attributes"]),
                                "training_row_count": result["training_row_count"], "query_count": result["query_count"],
                                "test_linkage_error": result["test_linkage_error"],
                                "baseline_test_linkage_error": result["baseline_test_linkage_error"]})
            print(seed, row["release_point"], "done", flush=True)
        with (output / f"inference_average_seed{seed}.csv").open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=COLUMNS)
            writer.writeheader()
            writer.writerows(records)
        print("wrote", output / f"inference_average_seed{seed}.csv", flush=True)


if __name__ == "__main__":
    main()
