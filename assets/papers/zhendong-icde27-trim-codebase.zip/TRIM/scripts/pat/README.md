# PAT environment

PAT ([eth-sri/datamin](https://github.com/eth-sri/datamin), MIT License) fits its
trees with a modified scikit-learn that the repository vendors, so it runs in
its own Python environment. `pat_fit.py` runs there; `pat_bridge.py` runs in the
TRIM environment and exchanges files with it.

## Source

Use upstream commit `0736fd2` with `datamin.patch` (this folder) applied:

```bash
git clone https://github.com/eth-sri/datamin.git
cd datamin
git checkout 0736fd2
git apply /path/to/TRIM/scripts/pat/datamin.patch
```

The patch changes eight files: `datamin/classifiers/classifier.py`,
`datamin/dataset.py`, `datamin/datasets/acs.py`,
`datamin/minimizers/tree/tree_minimizer.py`,
`datamin/minimizers/tree/tree_util.py`, `datamin/utils/config.py`, and the
vendored `scikit-learn/sklearn/tree/_classes.py` and `_criterion.pyx`
(scikit-learn is BSD-3-Clause licensed).

## Environment

Python 3.10 with numpy 1.23.5, scipy 1.9.3, Cython 0.29.30, setuptools 59.8,
pandas 1.5.3, torch 1.12.1 (CPU), neptune-client 0.16.15, xgboost 1.5.0,
bunch 1.0.1, PyYAML 6.0, tqdm 4.64.1, textual, and folktables 0.0.12 installed
with `--no-deps` (so that no other scikit-learn is installed). Then, inside the
patched `datamin/` checkout and with pip 23.3.2 (newer pip refuses legacy
editable installs):

```bash
pip install --no-build-isolation -e scikit-learn
```

Do not run `sktree/build.sh`; it overwrites the patched tree files.

## Use

`pat_fit.py --datamin <patched datamin checkout>` puts the checkout on the
path. See `experiments/exp1_baselines/README.md` for the export, fit, check and
evaluation steps.
