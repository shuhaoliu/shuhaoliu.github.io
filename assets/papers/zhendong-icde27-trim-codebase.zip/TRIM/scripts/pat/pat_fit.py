"""PAT-environment side of the PAT baseline: fit PAT's tree minimizer, export its bucketizations.

Runs in PAT's own environment: Python 3.10, numpy 1.23.5 and the vendored
scikit-learn 1.2.dev0 of PAT's ``datamin`` repository (set up as in
``scripts/pat/README.md``: upstream commit 0736fd2 plus ``datamin.patch``,
``pip install --no-build-isolation -e scikit-learn``, not ``sktree/build.sh``),
with ``datamin`` on the path (``--datamin``). The input is one dataset and
seed exported by ``pat_bridge.py export``: the shared split's training rows,
QIs only.

Every configuration of the upstream grid (``datamin/configs/acs/acs_base.yaml``,
minimizer ``tree``: 9 values of max_leaf_nodes x 12 values of alpha,
min_samples_leaf 100) is fitted with PAT's own code
(``datamin.minimizers.tree.tree_minimizer.TreeMinimizer``, criterion
``multi_fair_gini``). PAT's features are the QIs and its sensitive features
are the categorical QIs (``sens_feats: disc``). The rows are preprocessed as
``FolktablesDataset`` does (``SharedSplitDataset`` below): categorical values
coded 1..k in sorted order, continuous features first, MinMax-scaled on the
training rows.

Each bucketization is converted to the harness's format
(``exp1_pat_bucketization.v1``, see ``experiments/exp1_baselines/pat.py``) and
written as ``<dataset>_seed<seed>_L<L>_alpha<alpha>.json``:

- a continuous QI: PAT's bucket of each training row is the one
  ``Bucketization.transform`` assigns (float32 scaled value against the
  borders). The buckets become half-open raw-unit intervals whose ends are the
  midpoints between adjacent training values in different buckets, which
  reproduces PAT's assignment of every training value (buckets without
  training rows disappear);
- a categorical QI: each bucket lists the leaf values of its categories (all
  leaves of a pre-grouped category). A QI with a single bucket lists every
  hierarchy leaf, so the harness releases it as ROOT.

Each conversion is checked to induce PAT's own partition of the training rows
on every QI. The file records PAT's min-K and class count of the bucketized
training rows (``provenance``), which ``pat_bridge.py check`` compares with
the harness's release. Identical bucketizations of different configurations
are marked in the manifest (``manifests/<dataset>_seed<seed>.json``); the
harness evaluates such content once. The manifest also records a fit at
alpha = 1, outside the grid, to check that PAT then makes no split.

    python pat_fit.py --inputs <dir>/<dataset>_seed<seed>.json --datamin <datamin dir> \\
        --output-dir <dir> [--datamin-commit <label>]
"""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import platform
import sys
import time
from pathlib import Path
from typing import Dict, List

import numpy as np

SCHEMA = "exp1_pat_bucketization.v1"
INPUT_SCHEMA = "exp1_pat_inputs.v1"
# Upstream grid: datamin/configs/acs/acs_base.yaml, minimizer "tree".
MAX_LEAF_NODES = (2, 4, 6, 8, 10, 20, 50, 100, 200)
ALPHAS = (0.0, 0.1, 0.3, 0.5, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95)
MIN_SAMPLES_LEAF = 100


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_file(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def sort_key(value):
    """Order of category labels: numbers by value, then strings (mixed label types are allowed)."""
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        return (0, float(value), "")
    return (1, 0.0, str(value))


def json_number(value: float):
    value = float(value)
    return int(value) if value.is_integer() else value


class SharedSplitDataset:
    """What ``TreeMinimizer.fit`` reads from datamin's ``FolktablesDataset``, for the shared training rows.

    ``FolktablesDataset.__init__`` (``datamin/datamin/dataset.py``) loads a
    dataset, codes its categorical features, splits it and builds loaders.
    Here the rows are given (the shared split's training rows), so loading and
    splitting are replaced and no loader is built. The coding, ordering and
    scaling lines are upstream's, copied verbatim (marked below), and
    ``prepare_feat_data`` is upstream's method. ``X_train_oh`` holds only the
    scaled continuous columns, the only ones ``prepare_feat_data`` reads.
    Validation and test folds are empty: ``TreeMinimizer.fit`` does not use
    them.
    """

    def __init__(self, features: np.ndarray, labels: np.ndarray, feature_names, cont_feats):
        from sklearn.preprocessing import MinMaxScaler, OneHotEncoder

        from datamin.dataset import FolktablesDataset
        from datamin.utils.config import SensFeat

        self.task_type = "classification"
        features = np.array(features, dtype=np.float64)
        disc_feats = [i for i in range(features.shape[1]) if i not in cont_feats]
        tot_feats = len(disc_feats) + len(cont_feats)
        sens_feats = SensFeat("disc").get_feats(cont_feats, disc_feats, tot_feats)
        self.nb_out_fts = len(np.unique(labels))
        # The sorted values each categorical code stands for (the loop below replaces them by 1..k).
        self.code_values = {idx: np.unique(features[:, idx]) for idx in disc_feats}

        # --- verbatim: datamin/dataset.py lines 309-316 ---
        # Hand-built ordinal encoder: map all categorical feature values to {1, ..., max} (needed for tree, noop for rest)
        for idx in disc_feats:
            ft_vals = np.unique(features[:, idx])
            new_col = np.zeros_like(features[:, idx], dtype=int)
            for i, val in enumerate(ft_vals):
                new_col[features[:, idx] == val] = i + 1
            features[:, idx] = new_col
            assert new_col.min().item() == 1, "Ordinal encoding must start from 1"
        # --- end verbatim ---

        X_train, y_train = features, labels

        # --- verbatim: datamin/dataset.py lines 358-370, without lines 364-365 (validation and test) ---
        # Permute the order of features such that continuous go first
        perm = cont_feats + disc_feats
        invperm: Dict[int, int] = {}
        for i, idx in enumerate(perm):
            invperm[idx] = i
        X_train = X_train[:, perm]
        self.feature_names: List[str] = [feature_names[i] for i in perm]
        self.cont_feats = [invperm[x] for x in cont_feats]
        self.disc_feats = [invperm[x] for x in disc_feats]
        self.sens_feats = [invperm[x] for x in sens_feats]
        self.tot_feats = tot_feats
        # --- end verbatim ---
        self.invperm = invperm

        scaler = oh_enc = None
        # --- verbatim: datamin/dataset.py lines 372-384 ---
        # Fit a scaler (for continuous) and onehot encoder (for categorical features)
        if scaler is None:
            # NOTE: oh sets all to zero, check
            # NOTE: Preserve order when building _oh
            scaler = MinMaxScaler()
            if len(self.cont_feats) > 0:
                scaler.fit(X_train[:, self.cont_feats])
        if oh_enc is None:
            oh_enc = OneHotEncoder(sparse=False, handle_unknown="ignore")
            oh_enc.fit(X_train[:, self.disc_feats])
        self.categories: List[List[int]] = (
            oh_enc.categories_
        )  # List of present categories for each feature
        # --- end verbatim ---

        # Upstream's subsample at train_percent = bucketization_percent = 1 returns copies in the
        # same order; the copy matters, since both arrays are scaled in place below.
        X_train_buck, y_train_buck = X_train.copy(), y_train.copy()
        self.X_train_buck_orig = X_train_buck
        self.y_train_buck_orig = y_train_buck
        self.X_train_orig = X_train
        self.X_val_orig = X_train[:0]
        self.X_test_orig = X_train[:0]
        self.y_train = y_train
        self.y_val = y_train[:0]
        self.y_test = y_train[:0]
        self.X_train_oh = (
            scaler.transform(X_train[:, self.cont_feats]) if self.cont_feats else np.zeros((len(X_train), 0))
        )
        FolktablesDataset.prepare_feat_data(self)

        # --- verbatim: datamin/dataset.py lines 459-464 ---
        self.X_train_orig[:, self.cont_feats] = scaler.transform(
            self.X_train_orig[:, self.cont_feats]
        )
        self.X_train_buck_orig[:, self.cont_feats] = scaler.transform(
            self.X_train_buck_orig[:, self.cont_feats]
        )
        # --- end verbatim ---
        self.scaler = scaler


def prepare(arrays, metadata) -> tuple[SharedSplitDataset, dict]:
    """PAT's dataset for the exported rows, and per QI what the conversion needs."""
    entries = metadata["qis"]
    n = len(arrays["y"])
    features = np.empty((n, len(entries)), dtype=np.float64)
    orders = {}
    for index, entry in enumerate(entries):
        column = arrays[entry["array"]]
        if entry["type"] == "numeric":
            features[:, index] = column
        else:
            # Category ranks in label order, so that upstream's np.unique codes them in that order.
            order = sorted(range(len(entry["categories"])), key=lambda i: sort_key(entry["categories"][i]))
            rank = np.empty(len(order), dtype=np.int64)
            rank[order] = np.arange(len(order))
            features[:, index] = rank[column]
            orders[index] = order
    cont_feats = [index for index, entry in enumerate(entries) if entry["type"] == "numeric"]
    dataset = SharedSplitDataset(features, arrays["y"].astype(np.int64),
                                 [entry["name"] for entry in entries], cont_feats)
    prepared = {}
    for index, entry in enumerate(entries):
        column = dataset.X_train_buck_orig[:, dataset.invperm[index]]
        if entry["type"] == "numeric":
            prepared[entry["name"]] = {
                "type": "numeric", "raw": np.asarray(arrays[entry["array"]], dtype=np.float64),
                # Bucketization.transform compares torch float32 scaled values.
                "scaled32": column.astype(np.float32),
            }
        else:
            prepared[entry["name"]] = {
                "type": "categorical", "codes": column.astype(np.int64),
                "code_categories": [orders[index][int(rank)] for rank in dataset.code_values[index]],
                "category_leaves": entry["category_leaves"], "all_leaves": entry["all_leaves"],
                "category": np.asarray(arrays[entry["array"]], dtype=np.int64),
            }
    return dataset, prepared


def pat_bucket_index(buckets: dict, prepared: dict) -> dict:
    """PAT's bucket of every training row and QI, as ``Bucketization.transform`` assigns it."""
    index = {}
    for qi, item in prepared.items():
        spec = buckets[qi]
        if item["type"] == "numeric":
            # x < borders[0] -> 0; borders[j-1] <= x < borders[j] -> j; x >= borders[-1] -> last.
            borders = np.asarray(spec["borders"], dtype=np.float32)
            index[qi] = np.searchsorted(borders, item["scaled32"], side="right")
        else:
            index[qi] = np.asarray(spec["mapping"], dtype=np.int64)[item["codes"] - 1]
    return index


def convert(buckets: dict, prepared: dict) -> tuple[dict, dict]:
    """PAT's buckets in the harness's format, and the converted bucket of every training row per QI."""
    pat_index = pat_bucket_index(buckets, prepared)
    output, converted_index = {}, {}
    for qi, item in prepared.items():
        index = pat_index[qi]
        if item["type"] == "numeric":
            values, inverse = np.unique(item["raw"], return_inverse=True)
            value_bucket = np.empty(len(values), dtype=np.int64)
            value_bucket[inverse] = index
            if not np.array_equal(value_bucket[inverse], index) or np.any(np.diff(value_bucket) < 0):
                raise AssertionError(f"{qi}: PAT's buckets are not ranges of the raw values.")
            cuts = [json_number((values[i] + values[i + 1]) / 2) for i in np.flatnonzero(np.diff(value_bucket))]
            bounds = [None, *cuts, None]
            output[qi] = {"type": "numeric", "buckets": [[low, high] for low, high in zip(bounds[:-1], bounds[1:])]}
            converted_index[qi] = np.searchsorted(np.asarray(cuts, dtype=np.float64), item["raw"], side="right")
        else:
            mapping = np.asarray(buckets[qi]["mapping"], dtype=np.int64)
            if len(mapping) != len(item["code_categories"]):
                raise AssertionError(f"{qi}: PAT's mapping does not cover the training categories.")
            used = np.unique(mapping)
            if len(used) == 1:
                output[qi] = {"type": "categorical", "buckets": [list(item["all_leaves"])]}
                converted_index[qi] = np.zeros(len(item["codes"]), dtype=np.int64)
                continue
            category_bucket = {}
            lists = []
            for position, bucket in enumerate(used):
                members = [category for code, category in enumerate(item["code_categories"]) if mapping[code] == bucket]
                lists.append([leaf for category in members for leaf in item["category_leaves"][category]])
                category_bucket.update({category: position for category in members})
            output[qi] = {"type": "categorical", "buckets": lists}
            lookup = np.full(len(item["category_leaves"]), -1, dtype=np.int64)
            for category, position in category_bucket.items():
                lookup[category] = position
            converted_index[qi] = lookup[item["category"]]
        if np.any(converted_index[qi] < 0):
            raise AssertionError(f"{qi}: a training value falls in no converted bucket.")
        pairs = np.unique(np.stack([index, converted_index[qi]]), axis=1).shape[1]
        if not pairs == len(np.unique(index)) == len(np.unique(converted_index[qi])):
            raise AssertionError(f"{qi}: the converted buckets do not reproduce PAT's partition.")
    return output, pat_index


def class_sizes(index: dict) -> np.ndarray:
    """Sizes of the classes of training rows with identical bucket tuples."""
    tokens = np.stack([index[qi] for qi in sorted(index)], axis=1)
    return np.unique(tokens, axis=0, return_counts=True)[1]


def fit_one(dataset, alpha: float, max_leaf_nodes: int):
    from bunch import Bunch

    from datamin.minimizers.tree.tree_minimizer import TreeMinimizer
    from datamin.utils.config import TreeMinimizerConfig
    from datamin.utils.logging_utils import get_print_logger

    config = TreeMinimizerConfig(Bunch({
        "tree_max_leaf_nodes": max_leaf_nodes, "tree_min_sample_leaf": MIN_SAMPLES_LEAF,
        "tree_alpha": alpha, "task_type": "classification",
    }))
    minimizer = TreeMinimizer(config, get_print_logger("Tree-Logger"))
    started = time.perf_counter()
    minimizer.fit(dataset)
    seconds = time.perf_counter() - started
    return minimizer.get_bucketization().buckets, minimizer.tree, seconds


def environment(datamin: Path) -> dict:
    import Cython
    import scipy
    import sklearn

    sources = {
        name: sha256_file(datamin / name) for name in (
            "datamin/dataset.py", "datamin/bucketization.py", "datamin/utils/config.py",
            "datamin/minimizers/tree/tree_minimizer.py", "datamin/minimizers/tree/tree_util.py",
            "scikit-learn/sklearn/tree/_classes.py", "scikit-learn/sklearn/tree/_criterion.pyx",
            "scikit-learn/sklearn/tree/_splitter.pyx", "scikit-learn/sklearn/tree/_tree.pyx",
            "scikit-learn/sklearn/tree/_utils.pyx",
        )
    }
    return {
        "python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
        "scikit_learn": sklearn.__version__, "scikit_learn_path": str(Path(sklearn.__file__).parent),
        "cython": Cython.__version__, "platform": platform.platform(), "datamin_sources_sha256": sources,
    }


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--inputs", required=True, help="<dataset>_seed<seed>.json written by pat_bridge.py export.")
    parser.add_argument("--datamin", required=True, help="The patched datamin checkout (scripts/pat/README.md).")
    parser.add_argument("--datamin-commit", default="", help="Label of the datamin source, recorded in the manifest.")
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--max-leaf-nodes", nargs="+", type=int, default=list(MAX_LEAF_NODES))
    parser.add_argument("--alphas", nargs="+", type=float, default=list(ALPHAS))
    args = parser.parse_args(argv)
    started_at, started = utc_now(), time.perf_counter()
    datamin = Path(args.datamin).resolve()
    sys.path.insert(0, str(datamin))
    inputs = Path(args.inputs)
    metadata = json.loads(inputs.read_text(encoding="utf-8"))
    if metadata.get("schema_version") != INPUT_SCHEMA:
        raise ValueError(f"Expected {INPUT_SCHEMA} inputs.")
    arrays_path = inputs.with_name(metadata["arrays_file"])
    if sha256_file(arrays_path) != metadata["arrays_sha256"]:
        raise ValueError(f"{arrays_path} differs from its recorded SHA-256.")
    with np.load(arrays_path) as stored:
        arrays = {key: stored[key] for key in stored.files}
    dataset_name, seed = metadata["dataset"], int(metadata["seed"])
    dataset, prepared = prepare(arrays, metadata)
    output = Path(args.output_dir)
    (output / "manifests").mkdir(parents=True, exist_ok=True)
    pregroup = {entry["name"]: entry["pregroup"] for entry in metadata["qis"] if "pregroup" in entry}
    provenance_base = {
        "pat_fit_sha256": sha256_file(__file__), "inputs_sha256": sha256_file(inputs),
        "arrays_sha256": metadata["arrays_sha256"], "datamin_commit": args.datamin_commit,
    }
    records, first_file = [], {}
    for max_leaf_nodes in args.max_leaf_nodes:
        for alpha in args.alphas:
            buckets, tree, fit_seconds = fit_one(dataset, alpha, max_leaf_nodes)
            convert_started = time.perf_counter()
            converted, pat_index = convert(buckets, prepared)
            sizes = class_sizes(pat_index)
            digest = hashlib.sha256(json.dumps(converted, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
            name = f"{dataset_name}_seed{seed}_L{max_leaf_nodes:03d}_alpha{alpha:.2f}.json"
            record = {
                "alpha": alpha, "max_leaf_nodes": max_leaf_nodes, "file": name, "bucketization_sha256": digest,
                "duplicate_of": first_file.get(digest),
                "fit_seconds": fit_seconds, "convert_seconds": time.perf_counter() - convert_started,
                "tree_leaves": int(tree.get_n_leaves()), "tree_depth": int(tree.get_depth()),
                "pat_bucket_sizes": {qi: int(spec["size"]) for qi, spec in buckets.items()},
                "nonempty_buckets": {qi: len(spec["buckets"]) for qi, spec in converted.items()},
                "pat_min_k": int(sizes.min()), "pat_class_count": int(len(sizes)),
            }
            first_file.setdefault(digest, name)
            parameters = {
                "alpha": alpha, "max_leaf_nodes": max_leaf_nodes, "min_samples_leaf": MIN_SAMPLES_LEAF,
                "criterion": "multi_fair_gini", "tree_random_state": 43, "initial_split_factor": 1.0,
                "min_bucket_threshold": 0.0, "sensitive_features": "categorical QIs",
                "grid": "datamin/configs/acs/acs_base.yaml (tree)",
            }
            if pregroup:
                parameters["pregroup_levels"] = {qi: spec["level"] for qi, spec in sorted(pregroup.items())}
            payload = {
                "schema_version": SCHEMA, "dataset": dataset_name, "seed": seed,
                "split_sha256": metadata["split_sha256"], "parameters": parameters, "buckets": converted,
                "provenance": {
                    **provenance_base, "pat_min_k": record["pat_min_k"], "pat_class_count": record["pat_class_count"],
                    "pat_bucket_sizes": record["pat_bucket_sizes"], "tree_leaves": record["tree_leaves"],
                    "fit_seconds": fit_seconds, "bucketization_sha256": digest, "fitted_at": utc_now(),
                },
            }
            (output / name).write_text(json.dumps(payload, sort_keys=True, separators=(",", ":")) + "\n",
                                       encoding="utf-8")
            records.append(record)
            print(f"{dataset_name} seed {seed} L={max_leaf_nodes} alpha={alpha:g}: fit {fit_seconds:.1f}s, "
                  f"leaves {record['tree_leaves']}, buckets {record['nonempty_buckets']}, "
                  f"min-K {record['pat_min_k']}" + (f" (= {record['duplicate_of']})" if record["duplicate_of"] else ""),
                  flush=True)
    # Outside the grid: PAT at alpha = 1 should make no split, i.e. a single bucket per QI.
    buckets, tree, fit_seconds = fit_one(dataset, 1.0, max(args.max_leaf_nodes))
    alpha_one = {
        "alpha": 1.0, "max_leaf_nodes": max(args.max_leaf_nodes), "fit_seconds": fit_seconds,
        "tree_leaves": int(tree.get_n_leaves()), "pat_bucket_sizes": {qi: int(spec["size"]) for qi, spec in buckets.items()},
    }
    alpha_one["single_bucket_per_qi"] = all(size == 1 for size in alpha_one["pat_bucket_sizes"].values())
    manifest = {
        "schema_version": "exp1_pat_fit_manifest.v1", "dataset": dataset_name, "seed": seed,
        "split_sha256": metadata["split_sha256"], "training_row_count": int(len(arrays["y"])),
        "inputs": {"file": inputs.name, **provenance_base}, "environment": environment(datamin),
        "grid": {"max_leaf_nodes": args.max_leaf_nodes, "alphas": args.alphas, "min_samples_leaf": MIN_SAMPLES_LEAF,
                 "source": "datamin/configs/acs/acs_base.yaml, minimizer tree"},
        "preprocessing": {
            "feature_order": dataset.feature_names,
            "continuous": [dataset.feature_names[i] for i in dataset.cont_feats],
            "sensitive": [dataset.feature_names[i] for i in dataset.sens_feats],
            "training_categories": {entry["name"]: entry["training_category_count"]
                                    for entry in metadata["qis"] if entry["type"] == "categorical"},
            "pregroup": pregroup,
        },
        "configurations": records, "distinct_bucketizations": len(first_file), "alpha_one_check": alpha_one,
        "started_at": started_at, "finished_at": utc_now(), "total_seconds": time.perf_counter() - started,
    }
    (output / "manifests" / f"{dataset_name}_seed{seed}.json").write_text(
        json.dumps(manifest, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    print(f"{dataset_name} seed {seed}: {len(records)} configurations, {len(first_file)} distinct bucketizations, "
          f"alpha=1 single bucket per QI: {alpha_one['single_bucket_per_qi']}, "
          f"{manifest['total_seconds']:.0f}s", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
