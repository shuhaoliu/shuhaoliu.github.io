"""TRIM-environment side of the PAT baseline: export PAT's inputs, check PAT's outputs.

PAT (``datamin``, see ``scripts/pat/README.md``) needs its own environment, so its trees are
fitted by ``pat_fit.py`` in that environment and exchanged through files.
This script runs in the TRIM environment from the repository root.

``export``: for each dataset and seed, rebuild the training split with TRIM's
loaders exactly as the baseline harness does
(``experiments.exp1_baselines.evaluator.build_context``), check it against the
shared split file the harness wrote (``splits/<dataset>_seed<seed>.json.gz``:
the same training row IDs, split, data and tree hashes), and write the
training rows' QIs and labels in that order (``<dataset>_seed<seed>.npz`` and
``.json``; schema ``exp1_pat_inputs.v1``):

- a numeric QI: its raw values;
- a categorical QI: the index of the row's category, where the categories are
  the hierarchy leaves of the shared tree, each with its leaf value;
- Diabetes ``diag_1``/``diag_2``/``diag_3``: pre-grouped, because PAT's tree
  accepts at most 512 categories per feature. The categories are the nodes of
  the finest level of the shared tree (level h: every leaf's ancestor at
  height h) that has at most 512 distinct values on the training rows. The
  missing-value leaf sits directly under the root, so it is its own group at
  every level. Each group lists all of its leaves.

``check``: load every bucketization that ``pat_fit.py`` wrote with the
harness's loader (``experiments.exp1_baselines.pat``) and check that the
release it defines has the min-K and class count that PAT's own
bucketization of the training rows has (both recorded by ``pat_fit.py``), and
count validation and test values that map to ROOT.

    python scripts/pat/pat_bridge.py export --split-dir <dir> \\
        --output-dir <dir> [--data-root <dir>] [--datasets ...] [--seeds ...]
    python scripts/pat/pat_bridge.py check --inputs-dir <dir> \\
        --pat-dir <dir> --report <file> [--data-root <dir>] [--datasets ...] [--seeds ...]
"""

from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT_DIR = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT_DIR))

from experiments.common import load_yaml_mapping, resolve_project_path  # noqa: E402
from experiments.exp1_baselines import pat  # noqa: E402
from experiments.exp1_baselines.evaluator import build_context  # noqa: E402
from experiments.exp1_baselines.privacy import release_privacy  # noqa: E402
from experiments.exp1_baselines.release import ROOT, json_scalar, read_json_gz, utc_now  # noqa: E402
from experiments.exp1_kanon.hierarchy import HierarchySchema  # noqa: E402
from experiments.run_matrix_sweep import expand_matrix  # noqa: E402
from prototype.dataset_registry import resolve_dataset  # noqa: E402

INPUT_SCHEMA = "exp1_pat_inputs.v1"
# PAT's vendored tree asserts at most 512 categories per categorical feature
# (datamin/scikit-learn/sklearn/tree/_classes.py).
PAT_CATEGORY_LIMIT = 512
PREGROUPED = {"diabetes": ("diag_1", "diag_2", "diag_3")}
DEFAULT_CONFIG = "configs/paper/fig4/baselines.yaml"
DATASETS = ("income", "pubcov", "diabetes", "bm_halfmonth")
SEEDS = (42, 43, 44, 45, 46)


def sha256_file(path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def pregroup(schema, qi: str, observed: np.ndarray) -> tuple[int, dict, list]:
    """The finest level with at most PAT_CATEGORY_LIMIT groups on the training rows.

    Returns (level, distinct groups in training per level, group node ID per leaf).
    """
    nodes, root = schema.nodes[qi], schema.roots[qi]
    counts, groupings = {}, {}
    for level in range(int(nodes[root]["height_from_leaf"])):
        grouping = []
        for leaf in schema.leaves[qi]:
            node = leaf
            # Move up to the ancestor at this height, but never to the root.
            while int(node["height_from_leaf"]) < level and nodes[node["parent"]].get("parent") is not None:
                node = nodes[node["parent"]]
            grouping.append(node["id"])
        groupings[level] = grouping
        counts[level] = len({grouping[position] for position in np.unique(observed)})
    feasible = [level for level, count in counts.items() if count <= PAT_CATEGORY_LIMIT]
    if not feasible:
        raise ValueError(f"{qi}: no hierarchy level has at most {PAT_CATEGORY_LIMIT} groups in training.")
    return min(feasible), counts, groupings[min(feasible)]


def export_inputs(context, split_payload=None) -> tuple[dict, dict]:
    """The training rows of one dataset and seed in PAT's input form: (arrays, metadata)."""
    if split_payload is not None:
        if (split_payload["dataset"], int(split_payload["seed"])) != (context.dataset, context.seed):
            raise ValueError("The split file belongs to another dataset or seed.")
        for key in ("split_sha256", "training_data_sha256", "loaded_input_sha256", "tree_sha256"):
            if split_payload[key] != getattr(context, key):
                raise ValueError(f"The shared split file records another {key}.")
        if split_payload["train_row_ids"] != context.train_ids.tolist():
            raise ValueError("The shared split file lists other training rows.")
    schema = HierarchySchema(context.generalization)
    values = schema.values(context.split.X_train_raw)
    y = context.split.y_train.to_numpy()
    if set(np.unique(y).tolist()) != {0, 1}:
        raise ValueError("PAT's tree minimizer expects binary 0/1 labels.")
    arrays = {"y": y.astype(np.int64)}
    entries = []
    for index, qi in enumerate(context.qi_attributes):
        observed = values[qi]
        entry = {"name": qi, "array": f"qi{index}"}
        if qi in schema.numeric:
            if not np.all(np.isfinite(observed)):
                raise ValueError(f"{qi}: PAT needs a value for every training row.")
            arrays[entry["array"]] = observed.astype(np.float64)
            entry["type"] = "numeric"
        else:
            if np.any(observed < 0):
                raise ValueError(f"{qi}: PAT needs a value for every training row.")
            leaves = [json_scalar(value) for value in schema.leaf_values[qi]]
            if qi in PREGROUPED.get(context.dataset, ()):
                level, counts, grouping = pregroup(schema, qi, observed)
                groups = sorted(set(grouping))
                group_index = {group: position for position, group in enumerate(groups)}
                leaf_category = np.asarray([group_index[group] for group in grouping], dtype=np.int64)
                categories = groups
                category_leaves = [[leaves[position] for position in schema.descendants[qi][group]]
                                   for group in groups]
                entry["pregroup"] = {
                    "level": level, "limit": PAT_CATEGORY_LIMIT,
                    "distinct_in_training_by_level": {str(key): value for key, value in counts.items()},
                    "rule": "ancestor at this height_from_leaf, never the root; the missing-value leaf "
                            "under the root is its own group",
                }
            else:
                leaf_category = np.arange(len(leaves), dtype=np.int64)
                categories = leaves
                category_leaves = [[value] for value in leaves]
            arrays[entry["array"]] = leaf_category[observed]
            entry.update(type="categorical", categories=categories, category_leaves=category_leaves,
                         all_leaves=leaves,
                         training_category_count=int(len(np.unique(arrays[entry["array"]]))))
        entries.append(entry)
    metadata = {
        "schema_version": INPUT_SCHEMA, "dataset": context.dataset, "seed": context.seed,
        "split_sha256": context.split_sha256, "training_data_sha256": context.training_data_sha256,
        "loaded_input_sha256": context.loaded_input_sha256, "tree_sha256": context.tree_sha256,
        "tree_file": context.tree_path.name, "training_row_count": context.training_row_count,
        "label_counts": {str(key): int(value) for key, value in sorted(Counter(y.tolist()).items())},
        "qis": entries,
    }
    return arrays, metadata


def matrix_tasks(config_path):
    _, config = load_yaml_mapping(resolve_project_path(config_path))
    _, matrix = load_yaml_mapping(resolve_project_path(config["matrix_config"]))
    return expand_matrix(matrix)


def task_for(tasks, dataset: str, seed: int) -> dict:
    """Any model's task of a dataset and seed; data, tree and split are shared by the models."""
    for task in tasks:
        if resolve_dataset(task["dataset"]).key == dataset and int(task["pipeline"]["random_state"]) == seed:
            return task
    raise ValueError(f"The matrix has no {dataset} seed {seed} task.")


def run_export(args) -> None:
    tasks = matrix_tasks(args.config)
    output = Path(args.output_dir)
    output.mkdir(parents=True, exist_ok=True)
    for dataset in args.datasets:
        for seed in args.seeds:
            split_path = Path(args.split_dir) / f"{dataset}_seed{seed}.json.gz"
            context = build_context(task_for(tasks, dataset, seed), data_root=args.data_root)
            arrays, metadata = export_inputs(context, read_json_gz(split_path))
            stem = output / f"{dataset}_seed{seed}"
            np.savez_compressed(f"{stem}.npz", **arrays)
            metadata.update(
                arrays_file=f"{stem.name}.npz", arrays_sha256=sha256_file(f"{stem}.npz"),
                split_file=split_path.name, split_file_sha256=sha256_file(split_path),
                bridge_sha256=sha256_file(__file__), created_at=utc_now(),
            )
            Path(f"{stem}.json").write_text(json.dumps(metadata, indent=1, sort_keys=True) + "\n", encoding="utf-8")
            grouped = {entry["name"]: entry["pregroup"]["level"] for entry in metadata["qis"] if "pregroup" in entry}
            print(f"{dataset} seed {seed}: {metadata['training_row_count']} training rows, "
                  f"split {metadata['split_sha256'][:12]}, categories "
                  f"{ {e['name']: e['training_category_count'] for e in metadata['qis'] if e['type'] == 'categorical'} }"
                  + (f", pre-grouped levels {grouped}" if grouped else ""), flush=True)


def run_check(args) -> None:
    tasks = matrix_tasks(args.config)
    files = {}
    for path in sorted(Path(args.pat_dir).glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        files.setdefault((payload["dataset"], int(payload["seed"])), []).append((path, payload))
    report, failures = {"checked_at": utc_now(), "items": {}}, []
    for dataset in args.datasets:
        for seed in args.seeds:
            entries = files.get((dataset, seed), [])
            if not entries:
                failures.append(f"{dataset} seed {seed}: no bucketization")
                continue
            context = build_context(task_for(tasks, dataset, seed), data_root=args.data_root)
            inputs = json.loads((Path(args.inputs_dir) / f"{dataset}_seed{seed}.json").read_text(encoding="utf-8"))
            if inputs["split_sha256"] != context.split_sha256:
                failures.append(f"{dataset} seed {seed}: inputs from another split")
            schema = HierarchySchema(context.generalization)
            item = {"files": len(entries), "distinct_bucketizations": 0, "mismatches": [],
                    "root_values_by_qi": {}}
            seen, root_counts = set(), {}
            for path, payload in entries:
                bucketization = pat.PatBucketization(payload, context, schema)
                privacy = release_privacy(bucketization.release, context.train_ids, context.raw_codes,
                                          context.original)
                expected = payload["provenance"]
                if (privacy["min_k"], privacy["released_class_count"]) != (
                    expected["pat_min_k"], expected["pat_class_count"]
                ):
                    item["mismatches"].append({
                        "file": path.name, "harness": [privacy["min_k"], privacy["released_class_count"]],
                        "pat": [expected["pat_min_k"], expected["pat_class_count"]],
                    })
                if bucketization.bucketization_sha256 in seen:
                    continue
                seen.add(bucketization.bucketization_sha256)
                for split, X in (("validation", context.split.X_val_raw), ("test", context.split.X_test_raw)):
                    for qi, column in bucketization.evaluation_columns(X).items():
                        roots = [code for code, domain in enumerate(column.table) if domain == ROOT]
                        # ROOT values that are not whole-column ROOT (a QI with a single bucket).
                        if roots and len(column.table) > 1:
                            count = int(np.isin(column.codes, roots).sum())
                            key = f"{split}:{qi}"
                            root_counts[key] = max(root_counts.get(key, 0), count)
            item["distinct_bucketizations"] = len(seen)
            item["root_values_by_qi"] = root_counts
            item["validation_rows"], item["test_rows"] = len(context.split.X_val_raw), len(context.split.X_test_raw)
            if item["mismatches"]:
                failures.append(f"{dataset} seed {seed}: {len(item['mismatches'])} privacy mismatches")
            report["items"][f"{dataset}_seed{seed}"] = item
            print(f"{dataset} seed {seed}: {len(entries)} files, {len(seen)} distinct, "
                  f"{len(item['mismatches'])} mismatches", flush=True)
    report["failures"] = failures
    Path(args.report).write_text(json.dumps(report, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    if failures:
        raise SystemExit("PAT check failed: " + "; ".join(failures))


def main(argv=None) -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    commands = parser.add_subparsers(dest="command", required=True)
    for name in ("export", "check"):
        sub = commands.add_parser(name)
        sub.add_argument("--config", default=DEFAULT_CONFIG, help="Baseline configuration (for the matrix).")
        sub.add_argument("--data-root", help="Directory that relative matrix data paths resolve against.")
        sub.add_argument("--datasets", nargs="+", default=list(DATASETS))
        sub.add_argument("--seeds", nargs="+", type=int, default=list(SEEDS))
    commands.choices["export"].add_argument("--split-dir", required=True, help="The harness's splits/ directory.")
    commands.choices["export"].add_argument("--output-dir", required=True)
    commands.choices["check"].add_argument("--inputs-dir", required=True, help="Output directory of export.")
    commands.choices["check"].add_argument("--pat-dir", required=True, help="Bucketization files of pat_fit.py.")
    commands.choices["check"].add_argument("--report", required=True)
    args = parser.parse_args(argv)
    run_export(args) if args.command == "export" else run_check(args)


if __name__ == "__main__":
    main()
