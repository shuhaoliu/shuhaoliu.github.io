"""Time the data-minimization baselines for one dataset and seed on one GPU (Fig. 5c and 5d).

Each step runs as its own subprocess with a time limit (a step over it is killed and recorded as a timeout):

1-3. ``experiments.exp1_baselines.run`` for FIDO, EntryWise and FeatSel, one invocation each, with one target
     model; a method's time is its ``seconds_this_invocation`` (every release of its grid built, privacy-scored,
     stored and fitted, after data loading and the full-data reference fit);
4.   PAT: export the training rows of the shared split (``scripts/pat/pat_bridge.py export``, this environment),
     fit the 108-configuration grid in PAT's environment (``scripts/pat/pat_fit.py``, CPU), check the
     bucketizations (``pat_bridge.py check``) and evaluate them with the harness. PAT's time is the sum of the
     grid's ``fit_seconds`` plus the harness's ``seconds_this_invocation``; export, conversion and check are
     bridge work and not counted.

PAT reads the split file that the harness steps write, so run it after at least one of them (the default order
does). Results go under the configuration's ``results_root``: ``harness/`` (FIDO, EntryWise, FeatSel),
``pat/{inputs,bucketizations,check,harness}/`` and one record per job, ``jobs/<dataset>_seed<seed>_<model>.json``,
with each method's ``seconds``. Run one job per GPU and nothing else on that GPU.

    python scripts/time_baselines.py --config configs/paper/fig5c/baselines.yaml --dataset income --seed 42 \\
        --model mlp --pat-python <PAT environment python> --datamin <patched datamin checkout>
"""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import yaml

ROOT = Path(__file__).resolve().parents[1]
BRIDGE = "scripts/pat/pat_bridge.py"
FIT = "scripts/pat/pat_fit.py"
HARNESS_METHODS = ("fido", "entrywise", "featsel")


def utc_now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def run_step(name, command, extra_env, timeout):
    print(f"== {name}: {' '.join(command)}", flush=True)
    started_at, started = utc_now(), time.perf_counter()
    proc = subprocess.Popen(command, cwd=ROOT, env={**os.environ, **extra_env}, start_new_session=True)
    try:
        code = proc.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid, signal.SIGKILL)
        proc.wait()
        code = "timeout"
    step = {"command": command, "exit": code, "started_at": started_at, "finished_at": utc_now(),
            "wall_seconds": time.perf_counter() - started}
    print(f"== {name}: exit {code}, {step['wall_seconds']:.1f} s", flush=True)
    return step


def last_manifest(directory, stem, method):
    paths = sorted(Path(directory, "manifests").glob(f"{stem}_{method}_*.json"))
    return json.loads(paths[-1].read_text()) if paths else None


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True, help="Harness configuration with results_root.")
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--model", required=True, help="Target model name from the matrix (mlp or xgboost).")
    parser.add_argument("--device", default="cuda:0")
    parser.add_argument("--methods", nargs="+", default=[*HARNESS_METHODS, "pat"],
                        choices=[*HARNESS_METHODS, "pat"])
    parser.add_argument("--pat-python", help="Python of PAT's environment (needed for PAT).")
    parser.add_argument("--datamin", help="The patched datamin checkout (scripts/pat/README.md; needed for PAT).")
    parser.add_argument("--time-limit-seconds", type=int, default=6 * 3600)
    parser.add_argument("--release-limit", type=int, help="Smoke tests only.")
    args = parser.parse_args()
    if "pat" in args.methods and not (args.pat_python and args.datamin):
        raise SystemExit("PAT needs --pat-python and --datamin.")
    config = yaml.safe_load((ROOT / args.config).read_text(encoding="utf-8"))
    out = ROOT / config["results_root"]
    stem = f"{args.dataset}_seed{args.seed}"
    harness = out / "harness"
    pat_inputs, buckets = out / "pat" / "inputs", out / "pat" / "bucketizations" / stem
    pat_check, pat_harness = out / "pat" / "check", out / "pat" / "harness"
    jobs = out / "jobs"
    for path in (harness, pat_inputs, buckets, pat_check, pat_harness, jobs):
        path.mkdir(parents=True, exist_ok=True)
    record_path = jobs / f"{stem}_{args.model}.json"
    record = json.loads(record_path.read_text()) if record_path.exists() else {
        "dataset": args.dataset, "seed": args.seed, "model": args.model, "config": args.config,
        "steps": {}, "methods": {}}
    record.update(device=args.device, cuda_visible_devices=os.environ.get("CUDA_VISIBLE_DEVICES"),
                  release_limit=args.release_limit, time_limit_seconds=args.time_limit_seconds,
                  started_at=utc_now(), status="running")
    limit = ["--release-limit", str(args.release_limit)] if args.release_limit else []
    common = ["--config", args.config, "--dataset", args.dataset, "--seed", str(args.seed), "--model", args.model,
              "--device", args.device]
    failed = []
    for method in [m for m in HARNESS_METHODS if m in args.methods]:
        if record["methods"].get(method, {}).get("status") == "complete":
            continue
        step = run_step(f"{stem} {method}", [sys.executable, "-u", "-m", "experiments.exp1_baselines.run",
                        *common, "--method", method, "--results-dir", str(harness), *limit], {},
                        args.time_limit_seconds)
        record["steps"][method] = step
        entry = {"status": "complete" if step["exit"] == 0 else f"exit {step['exit']}",
                 "wall_seconds": step["wall_seconds"]}
        manifest = last_manifest(harness, stem, method) if step["exit"] == 0 else None
        if manifest:
            summary = next(iter(manifest["methods_summary"].values()))
            entry.update(seconds=summary["seconds_this_invocation"], point_rows=summary["point_rows"],
                         train_size=manifest["train_size"], split_sha256=manifest["split_sha256"])
        record["methods"][method] = entry
        failed += [method] if entry["status"] != "complete" else []
        record_path.write_text(json.dumps(record, indent=1) + "\n")
    if "pat" in args.methods and record["methods"].get("pat", {}).get("status") != "complete":
        if any(buckets.glob("*.json")):
            raise SystemExit(f"{buckets} already holds bucketizations from an unfinished job; check it first.")
        steps = [
            ("pat_export", [sys.executable, "-u", BRIDGE, "export", "--config", args.config, "--split-dir",
                            str(harness / "splits"), "--output-dir", str(pat_inputs), "--datasets", args.dataset,
                            "--seeds", str(args.seed)], {}),
            ("pat_fit", [args.pat_python, "-u", FIT, "--inputs", str(pat_inputs / f"{stem}.json"),
                         "--datamin", args.datamin, "--output-dir", str(buckets)], {"PYTHONWARNINGS": "ignore"}),
            ("pat_check", [sys.executable, "-u", BRIDGE, "check", "--config", args.config, "--inputs-dir",
                           str(pat_inputs), "--pat-dir", str(buckets), "--report", str(pat_check / f"{stem}.json"),
                           "--datasets", args.dataset, "--seeds", str(args.seed)], {}),
            ("pat_evaluate", [sys.executable, "-u", "-m", "experiments.exp1_baselines.run", *common, "--method",
                              "pat", "--pat-dir", str(buckets), "--results-dir", str(pat_harness), *limit], {}),
        ]
        entry = {"status": "complete"}
        for name, command, extra_env in steps:
            step = run_step(f"{stem} {name}", command, extra_env, args.time_limit_seconds)
            record["steps"][name] = step
            record_path.write_text(json.dumps(record, indent=1) + "\n")
            if step["exit"] != 0:
                entry["status"] = f"{name} exit {step['exit']}"
                break
        if entry["status"] == "complete":
            fit = json.loads((buckets / "manifests" / f"{stem}.json").read_text())
            manifest = last_manifest(pat_harness, stem, "pat")
            summary = manifest["methods_summary"]["PAT"]
            entry.update(grid_fit_seconds=sum(c["fit_seconds"] for c in fit["configurations"]),
                         grid_convert_seconds=sum(c["convert_seconds"] for c in fit["configurations"]),
                         configurations=len(fit["configurations"]), distinct=fit["distinct_bucketizations"],
                         harness_seconds=summary["seconds_this_invocation"], point_rows=summary["point_rows"],
                         split_sha256=manifest["split_sha256"])
            entry["seconds"] = entry["grid_fit_seconds"] + entry["harness_seconds"]
        record["methods"]["pat"] = entry
        failed += [] if entry["status"] == "complete" else ["pat"]
    record.update(status="complete" if not failed else f"failed: {' '.join(failed)}", finished_at=utc_now())
    record_path.write_text(json.dumps(record, indent=1) + "\n")
    print(f"{stem} {args.model}: {record['status']}; " + ", ".join(
        f"{m} {e.get('seconds', float('nan')):.1f} s" for m, e in record["methods"].items()), flush=True)
    return 0 if not failed else 1


if __name__ == "__main__":
    raise SystemExit(main())
