"""Check every generalization tree against the values its dataset actually contains.

For each QI of each dataset, the check loads the data with the experiments' loader and the tree file of the dataset,
then verifies the three properties that each tree file records in its ``audit_summary``:

- coverage: every observed value of the QI falls in exactly one leaf, matched as the TRIM encoder matches it
  (interval leaves for continuous QIs, codes or strings for the others), and no two leaves hold the same value;
- parent links: every node's parent exists and lists it as a child, every child points back to its parent, and the
  root is the only node without a parent;
- sibling disjointness: the leaves below sibling nodes are disjoint, and interval leaves do not overlap.

Leaves that no observed value falls in are reported but allowed. The script exits with status 1 if any check fails.

    python scripts/check_generalization_trees.py [--datasets income pubcov ...] [--data-path DATASET=PATH]
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

import pandas as pd
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from prototype.dataloader import _coerce_categorical_leaf_value, _parse_leaf_value  # noqa: E402
from prototype.dataset_registry import DATASETS, build_data_loader, resolve_dataset  # noqa: E402


def parent_link_errors(tree: dict) -> list[str]:
    nodes = {node["id"]: node for node in tree["nodes"]}
    errors = [] if tree["root"] in nodes else [f"root {tree['root']!r} is not a node"]
    if len(nodes) != len(tree["nodes"]):
        errors.append("duplicate node ids")
    for node in tree["nodes"]:
        parent = node.get("parent")
        if parent is None:
            if node["id"] != tree["root"]:
                errors.append(f"{node['id']!r} has no parent")
        elif parent not in nodes or node["id"] not in nodes[parent].get("children", []):
            errors.append(f"{node['id']!r} is not a child of its parent {parent!r}")
        for child in node.get("children", []):
            if child not in nodes or nodes[child].get("parent") != node["id"]:
                errors.append(f"child {child!r} of {node['id']!r} does not point back")
    return errors


def sibling_overlaps(tree: dict) -> list[str]:
    nodes = {node["id"]: node for node in tree["nodes"]}
    below = {}

    def leaves(node_id):
        if node_id not in below:
            node = nodes[node_id]
            below[node_id] = ({node_id} if node["kind"] == "leaf" else
                              set().union(*(leaves(child) for child in node.get("children", []))))
        return below[node_id]

    overlaps = []
    for node in tree["nodes"]:
        children = [child for child in node.get("children", []) if child in nodes]
        if sum(len(leaves(child)) for child in children) != len(set().union(*(leaves(c) for c in children))):
            overlaps.append(node["id"])
    return overlaps


def check_attribute(loader, attribute: str, tree: dict, values: pd.Series) -> dict:
    """The three checks of one QI; ``values`` are the QI's observed values (missing values excluded)."""
    leaves = [node for node in tree["nodes"] if node.get("kind") == "leaf"]
    observed = values.drop_duplicates()
    problems = parent_link_errors(tree)
    problems += [f"leaves below the children of {node!r} overlap" for node in sibling_overlaps(tree)]
    if attribute in loader.numeric_attributes:
        numbers = pd.to_numeric(observed, errors="coerce")
        if numbers.isna().any():
            problems.append(f"non-numeric values {observed[numbers.isna()].head(5).tolist()!r}")
        matches = pd.Series(0, index=observed.index)
        spans = []
        for leaf in leaves:
            parsed = _parse_leaf_value(leaf["value"])
            if parsed[0] == "interval":
                hit = numbers.between(float(parsed[1]), float(parsed[2]), inclusive="both")
                spans.append((float(parsed[1]), float(parsed[2])))
            else:
                hit = numbers == float(parsed[1])
                spans.append((float(parsed[1]), float(parsed[1])))
            matches += hit.astype(int)
        spans.sort()
        problems += [f"leaf intervals {a} and {b} overlap" for a, b in zip(spans, spans[1:]) if b[0] <= a[1]]
        unused = sum(1 for low, high in spans if not numbers.between(low, high, inclusive="both").any())
    else:
        keys = [_coerce_categorical_leaf_value(loader, attribute, leaf["value"]) for leaf in leaves]
        if attribute in getattr(loader, "string_categorical_attributes", ()):
            observed = observed.astype(str)
        counts = pd.Series(keys).value_counts()
        duplicated = counts[counts > 1].index.tolist()
        if duplicated:
            problems.append(f"values in more than one leaf {duplicated[:5]!r}")
        matches = observed.map(counts).fillna(0).astype(int)
        unused = len(set(keys) - set(observed.tolist()))
    uncovered = observed[matches == 0].tolist()
    if uncovered:
        problems.append(f"{len(uncovered)} observed values in no leaf, e.g. {uncovered[:5]!r}")
    multiple = observed[matches > 1].tolist()
    if multiple:
        problems.append(f"{len(multiple)} observed values in more than one leaf, e.g. {multiple[:5]!r}")
    return {"attribute": attribute, "observed": len(observed), "leaves": len(leaves), "unused_leaves": unused,
            "problems": problems}


def check_dataset(dataset: str, data_path: Path | None) -> bool:
    spec = resolve_dataset(dataset)
    loader = build_data_loader(dataset, data_path=data_path)
    features, _labels = loader.load()
    trees = yaml.safe_load(spec.generalization_tree_path.read_text(encoding="utf-8-sig")).get("trees", {})
    ok = True
    print(f"{spec.paper_name}: {spec.generalization_tree_path.relative_to(PROJECT_ROOT)}")
    for attribute in getattr(loader, "qi_attributes", loader.feature_columns):
        if attribute not in trees:
            print(f"  {attribute}: FAIL, no tree")
            ok = False
            continue
        row = check_attribute(loader, attribute, trees[attribute], features[attribute].dropna())
        status = "ok" if not row["problems"] else "FAIL"
        print(f"  {attribute}: {status}, {row['observed']} observed values, {row['leaves']} leaves"
              f" ({row['unused_leaves']} without an observed value)")
        for problem in row["problems"]:
            print(f"    {problem}")
        ok &= not row["problems"]
    return ok


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--datasets", nargs="+", default=list(DATASETS),
                        help="Dataset keys (default: all five).")
    parser.add_argument("--data-path", action="append", default=[], metavar="DATASET=PATH",
                        help="Override one dataset path; repeat for several datasets.")
    args = parser.parse_args(argv)
    data_paths = {}
    for declaration in args.data_path:
        dataset, _, path = declaration.partition("=")
        if not path.strip():
            raise ValueError("--data-path must use DATASET=PATH.")
        data_paths[resolve_dataset(dataset).key] = Path(path).expanduser()
    ok = all([check_dataset(dataset, data_paths.get(resolve_dataset(dataset).key)) for dataset in args.datasets])
    print("all checks pass" if ok else "some checks fail")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
