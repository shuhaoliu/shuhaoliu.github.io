"""Run the data-minimization baselines (FIDO, EntryWise, FeatSel, PAT) over a plan's dataset, method and seed items.

An item is one (dataset, method, seed); each runs as its own ``experiments.exp1_baselines.run``
process that covers every target model of the plan, so the models share every release. Every
process sees exactly one physical GPU as cuda:0 (``CUDA_VISIBLE_DEVICES``); ``workers_per_gpu``
processes may share one GPU. The seed-42 item of a (dataset, method) must be verified before
its other seeds start.

Preflight (also ``--check-only``): input SHA-256, generalization-tree SHA-256, the verbatim
upstream copies, the matrix coverage and the training-split sizes.

Per item: runner exit code 0; a complete manifest written by the code of this checkout; one
split per (dataset, seed) with the planned training size; Delta U of every point measured from
the item's own full-data reference (differences between the reference fits of two items are
flagged); the expected number of points per model; the identity points (FeatSel's full set has
Delta U 0 and min-K = K0; FIDO's 100% prefix equals the reference; PAT's single-bucket and
no-generalization checks pass); and release checksums. ``--resume`` keeps verified items and
continues the evaluation files of the others. Verified items are merged into ``combined/``
(``raw_results.csv``, ``baseline_long.csv``, ``fido_curve.csv``, ``timing_summary.csv``).

PAT items evaluate the bucketization files of ``--pat-dir`` (written by ``scripts/pat/pat_fit.py``
in PAT's environment), one point per file; they use their own plan and results directory
(``configs/paper/fig4/baselines_pat_plan.json``).

    python scripts/run_baselines.py --plan configs/paper/fig4/baselines_plan.json --check-only
    python scripts/run_baselines.py --plan configs/paper/fig4/baselines_plan.json [--resume]
    python scripts/run_baselines.py --plan configs/paper/fig4/baselines_pat_plan.json --pat-dir <dir> [--resume]
"""

import argparse
import csv
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import yaml  # noqa: E402

from experiments.exp1_baselines import entrywise, featsel  # noqa: E402
from experiments.exp1_baselines.evaluator import resolve_data_path  # noqa: E402
from experiments.exp1_baselines.release import read_json_gz  # noqa: E402
from experiments.exp1_baselines.run import METHODS, implementation_sha256  # noqa: E402
from experiments.exp1_baselines.upstream import verify_upstream_copies  # noqa: E402
from experiments.run_matrix_sweep import expand_matrix  # noqa: E402
from prototype.dataset_registry import build_data_loader  # noqa: E402
from prototype.release_artifacts import load_dataset_split  # noqa: E402

DEFAULT_PLAN = ROOT / "configs/paper/fig4/baselines_plan.json"


def utc_now():
    return datetime.now(timezone.utc).isoformat()


parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
parser.add_argument("--plan", default=str(DEFAULT_PLAN))
parser.add_argument("--results-dir", help="Default: the plan's results_root under the project root.")
parser.add_argument("--data-root", help="Directory that relative data paths resolve against (default: project root).")
parser.add_argument("--check-only", action="store_true")
parser.add_argument("--resume", action="store_true", help="Keep verified items and continue the others.")
parser.add_argument("--datasets", nargs="+", help="Restrict to these datasets.")
parser.add_argument("--methods", nargs="+", choices=["fido", "entrywise", "featsel", "pat"],
                    help="Restrict to these methods.")
parser.add_argument("--pat-dir", help="PAT bucketization files (pat_fit.py); required for PAT items.")
parser.add_argument("--seeds", nargs="+", type=int, help="Restrict to these seeds, for example 42.")
parser.add_argument("--release-limit", type=int, help="Pass --release-limit to every runner (smoke tests only).")
parser.add_argument("--gpus", nargs="+", type=int, help="Override the plan's GPU list.")
parser.add_argument("--workers-per-gpu", type=int, help="Override the plan's workers_per_gpu.")
args = parser.parse_args()
PLAN_PATH = Path(args.plan).resolve()
PLAN = json.loads(PLAN_PATH.read_text(encoding="utf-8"))
OUTPUT = Path(args.results_dir).resolve() if args.results_dir else ROOT / PLAN["results_root"]
CONFIG_PATH = ROOT / PLAN["baselines_config"]
CONFIG = yaml.safe_load(CONFIG_PATH.read_text(encoding="utf-8"))
GPUS = args.gpus or PLAN["gpus"]
WORKERS_PER_GPU = args.workers_per_gpu or int(PLAN.get("workers_per_gpu", 1))
DATASETS = [d for d in PLAN["dataset_order"] if not args.datasets or d in args.datasets]
METHOD_ORDER = [m for m in PLAN["method_order"] if not args.methods or m in args.methods]
SEEDS = [s for s in PLAN["seeds"] if not args.seeds or s in args.seeds]
state = {"plan": str(PLAN_PATH), "items": {}}
PAT_FILES = {}
if "pat" in METHOD_ORDER:
    if not args.pat_dir:
        raise SystemExit("PAT items need --pat-dir.")
    for path in sorted(Path(args.pat_dir).glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        PAT_FILES.setdefault((payload["dataset"], int(payload["seed"])), []).append(path)


def save_status(phase, **updates):
    state.update(updates, status=phase, updated_at=utc_now())
    temporary = OUTPUT / "status.json.partial"
    temporary.write_text(json.dumps(state, indent=2) + "\n", encoding="utf-8")
    temporary.replace(OUTPUT / "status.json")


def expected_point_count(dataset, method, qi_count, seed):
    """Points per model, or None when the count is data-dependent (FIDO)."""
    if method == "pat":
        count = len(PAT_FILES.get((dataset, seed), []))
    elif method == "featsel":
        search = CONFIG["featsel"]["search"][dataset]
        count = len(featsel.enumerate_kept_sets(range(qi_count), mode=search["mode"], m=search.get("m")))
    elif method == "entrywise":
        settings = CONFIG.get("entrywise") or {}
        count = len(entrywise.configurations(
            qi_count, adjustments=tuple(settings.get("adjustments", ("reid", "recon"))),
            mults=tuple(settings.get("mults", (2, 5, 10))), fraction_count=settings.get("fraction_count"),
        ))
    else:
        return None
    return min(count, args.release_limit) if args.release_limit else count


def read_csv(path):
    with Path(path).open(encoding="utf-8", newline="") as handle:
        return list(csv.DictReader(handle))


def verify(item):
    """Check one finished item; return its summary or raise."""
    dataset, method, seed = item["dataset"], item["method"], item["seed"]
    manifests = sorted((OUTPUT / "manifests").glob(f"{dataset}_seed{seed}_{method}_*Z.json"))
    if not manifests:
        raise RuntimeError("No runner manifest was written.")
    manifest = json.loads(manifests[-1].read_text(encoding="utf-8"))
    if manifest["status"] != "complete" or manifest["implementation_sha256"] != CODE_HASH:
        raise RuntimeError(f"Incomplete run or a run of other code: {manifests[-1]}")
    if manifest["train_size"] != PLAN["train_size"][dataset]:
        raise RuntimeError("The training split size differs from the plan.")
    split_key = f"{dataset}_seed{seed}"
    known = state.setdefault("split_sha256", {}).setdefault(split_key, manifest["split_sha256"])
    if known != manifest["split_sha256"]:
        raise RuntimeError("Items of one dataset and seed recorded different splits.")
    summary = {"manifest": str(manifests[-1].relative_to(OUTPUT)), "references": {}, "flags": []}
    for model in PLAN["models"]:
        # The reference this item's own process fitted and measured Delta U from.
        reference = manifest["references"][model]
        summary["references"][model] = {"test": reference["test"], "validation": reference["validation"],
                                        "device_name": reference.get("device_name")}
        if reference.get("previous_record_difference"):
            summary["flags"].append(
                f"{model} reference differs from another process's fit of the same task by "
                f"{reference['previous_record_difference']:.3g}"
            )
    rows = read_csv(OUTPUT / "tables" / f"{dataset}_seed{seed}_{method}_raw.csv")
    split = read_json_gz(OUTPUT / "splits" / f"{dataset}_seed{seed}.json.gz")
    if split["split_sha256"] != manifest["split_sha256"] or split["train_size"] != PLAN["train_size"][dataset]:
        raise RuntimeError("The stored split differs from the item's split.")
    expected_points = expected_point_count(dataset, method, len(split["qi_attributes"]), seed)
    for model in PLAN["models"]:
        model_rows = [row for row in rows if row["model"] == model]
        if len({row["point"] for row in model_rows}) != len(model_rows):
            raise RuntimeError(f"{model}: duplicate points")
        if expected_points is not None and len(model_rows) != expected_points:
            raise RuntimeError(f"{model}: {len(model_rows)} points, expected {expected_points}")
        if not model_rows:
            raise RuntimeError(f"{model}: no points")
        # Rows of an earlier attempt (resume) were measured from that attempt's reference fit.
        drift = max(abs(float(row["baseline_test_loss"]) - summary["references"][model]["test"]) for row in model_rows)
        if drift > PLAN["reference_tolerance"][model]:
            raise RuntimeError(f"{model}: Delta U measured from references that differ by {drift:.3g}")
        if drift > 0:
            summary["flags"].append(f"{model}: rows measured from reference fits that differ by {drift:.3g}")
    method_name = METHODS[method]
    checks = manifest["identity_checks"].get(method_name, {})
    if method in ("featsel", "fido"):
        # FeatSel lists its full set first and FIDO's grid ends at 100%, so both always exist.
        for model in PLAN["models"]:
            if model not in checks or not checks[model]["passed"]:
                raise RuntimeError(f"{method_name} identity point missing or failed for {model}: {checks.get(model)}")
    if method == "pat":
        for name in ("single_bucket", "no_generalization"):
            if name not in checks or not checks[name]["passed"]:
                raise RuntimeError(f"PAT {name} check missing or failed: {checks.get(name)}")
    checked = set()
    for row in rows:
        if row["release_key"] in checked:
            continue
        path = OUTPUT / row["release_path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != row["release_sha256"]:
            raise RuntimeError(f"Release checksum mismatch: {path}")
        checked.add(row["release_key"])
    summary.update(point_count=len(rows), release_count=len(checked), identity_checks=checks)
    return summary


OUTPUT.mkdir(parents=True, exist_ok=True)
if (OUTPUT / "status.json").exists():
    previous_state = json.loads((OUTPUT / "status.json").read_text(encoding="utf-8"))
    if previous_state.get("status") != "prepared":
        if args.check_only or not args.resume:
            raise SystemExit("A run already exists. Inspect it, then restart with --resume to keep verified items.")
        state["items"] = previous_state.get("items", {})
        state["split_sha256"] = previous_state.get("split_sha256", {})

items = [
    {"id": f"{dataset}_{method}_seed{seed}", "dataset": dataset, "method": method, "seed": seed}
    for seed in SEEDS for method in METHOD_ORDER for dataset in DATASETS
]
items.sort(key=lambda item: (item["seed"] != 42, METHOD_ORDER.index(item["method"]), DATASETS.index(item["dataset"]), item["seed"]))
for item in items:
    record = state["items"].setdefault(item["id"], {"status": "pending", "attempts": 0})
    if record["status"] != "verified":
        record["status"] = "pending"


def gate_status(item):
    if item["seed"] == 42 or 42 not in SEEDS:
        return "verified"
    return state["items"][f"{item['dataset']}_{item['method']}_seed42"]["status"]


try:
    verify_upstream_copies()
    for path, expected in PLAN["data_sha256"].items():
        resolved = resolve_data_path(path, args.data_root)
        if hashlib.sha256(resolved.read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"Input checksum mismatch: {resolved}")
    for path, expected in PLAN["generalization_trees_sha256"].items():
        if hashlib.sha256((ROOT / path).read_bytes()).hexdigest() != expected:
            raise RuntimeError(f"Generalization tree differs from the plan: {path}")
    CODE_HASH = code_hash = implementation_sha256()
    matrix = yaml.safe_load((ROOT / CONFIG["matrix_config"]).read_text(encoding="utf-8"))
    tasks = expand_matrix(matrix)
    planned = {(d, m, s) for d in PLAN["dataset_order"] for m in PLAN["models"] for s in PLAN["seeds"]}
    if "pat" in METHOD_ORDER:
        missing = [f"{d} seed {s}" for d in DATASETS for s in SEEDS if not PAT_FILES.get((d, s))]
        if missing:
            raise RuntimeError(f"No PAT bucketization for {missing}")
        digest = hashlib.sha256()
        for key in sorted(PAT_FILES):
            for path in PAT_FILES[key]:
                digest.update(path.name.encode("utf-8") + path.read_bytes())
        state["pat_bucketizations"] = {
            "directory": str(Path(args.pat_dir).resolve()), "files": sum(map(len, PAT_FILES.values())),
            "sha256_of_names_and_contents": digest.hexdigest(),
        }
    if {(t["dataset"], t["model_name"], int(t["pipeline"]["random_state"])) for t in tasks} != planned:
        raise RuntimeError("The matrix does not contain exactly the planned dataset, model and seed tasks.")
    for dataset in DATASETS:
        task = next(t for t in tasks if t["dataset"] == dataset)
        loader = build_data_loader(dataset, data_path=resolve_data_path(task["data_path"], args.data_root))
        if len(load_dataset_split(loader, task["pipeline"]).X_train_raw) != PLAN["train_size"][dataset]:
            raise RuntimeError(f"{dataset}: training split size differs from the plan")
    state.update(
        implementation_sha256=code_hash,
        input_sha256=PLAN["data_sha256"], generalization_trees_sha256=PLAN["generalization_trees_sha256"],
        launcher_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        configuration_sha256={str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in (PLAN_PATH, CONFIG_PATH, ROOT / CONFIG["matrix_config"]) if p.is_relative_to(ROOT)},
        versions={name: importlib.metadata.version(name)
                  for name in ("torch", "xgboost", "numpy", "pandas", "scikit-learn", "scipy", "PyYAML")},
        selection={"datasets": DATASETS, "methods": METHOD_ORDER, "seeds": SEEDS,
                   "release_limit": args.release_limit, "gpus": GPUS, "workers_per_gpu": WORKERS_PER_GPU},
    )
    if args.check_only:
        save_status("prepared")
        print(json.dumps(state, indent=2), flush=True)
        sys.exit(0)

    (OUTPUT / "logs").mkdir(exist_ok=True)
    save_status("running", started_at=state.get("started_at") or utc_now())
    slots = [(gpu, worker) for gpu in GPUS for worker in range(WORKERS_PER_GPU)]
    running = {}
    while True:
        for slot, (item, process) in list(running.items()):
            code = process.poll()
            if code is None:
                continue
            del running[slot]
            record = state["items"][item["id"]]
            record.update(exit_code=code, ended_at=utc_now())
            try:
                if code != 0:
                    raise RuntimeError(f"Runner exited with code {code}; inspect {record['log']}")
                record.update(verify(item), status="verified", error=None)
            except Exception as exc:
                record.update(status="failed", error=str(exc))
            print(f"{item['id']}: {record['status']} on GPU {slot[0]}", flush=True)
            save_status("running")
        for item in items:
            record = state["items"][item["id"]]
            if record["status"] == "pending" and gate_status(item) == "failed":
                record.update(status="blocked", error=f"the seed-42 item of {item['dataset']} {item['method']} failed")
        pending = [item for item in items if state["items"][item["id"]]["status"] == "pending"]
        if not pending and not running:
            break
        memory = subprocess.check_output(
            ["nvidia-smi", "--query-gpu=index,memory.free", "--format=csv,noheader,nounits"], text=True)
        free = {int(index): int(value) for index, value in csv.reader(memory.splitlines())}
        for slot in slots:
            ready = [item for item in pending if gate_status(item) == "verified"]
            if slot in running or not ready or free.get(slot[0], 0) < PLAN["minimum_free_memory_mib"]:
                continue
            item = ready[0]
            pending.remove(item)
            record = state["items"][item["id"]]
            record["attempts"] += 1
            label = f"{item['id']}_attempt{record['attempts']}"
            command = [sys.executable, "-u", "-m", "experiments.exp1_baselines.run",
                       "--config", str(CONFIG_PATH), "--dataset", item["dataset"], "--seed", str(item["seed"]),
                       "--method", item["method"], "--device", "cuda:0", "--results-dir", str(OUTPUT), "--resume"]
            for model in PLAN["models"]:
                command += ["--model", model]
            if args.release_limit:
                command += ["--release-limit", str(args.release_limit)]
            if args.data_root:
                command += ["--data-root", args.data_root]
            if item["method"] == "pat":
                command += ["--pat-dir", str(Path(args.pat_dir).resolve())]
            log_path = OUTPUT / "logs" / f"{label}.log"
            environment = dict(os.environ, CUDA_VISIBLE_DEVICES=str(slot[0]), PYTHONFAULTHANDLER="1", TZ="UTC")
            with log_path.open("x", encoding="utf-8") as handle:
                process = subprocess.Popen(command, cwd=ROOT, env=environment, stdout=handle, stderr=subprocess.STDOUT)
            running[slot] = (item, process)
            record.update(status="running", run_label=label, log=str(log_path.relative_to(OUTPUT)), pid=process.pid,
                          physical_gpu=slot[0], worker=slot[1], CUDA_VISIBLE_DEVICES=str(slot[0]), device="cuda:0",
                          started_at=utc_now(), exit_code=None, error=None)
            print(f"Started {item['id']} on GPU {slot[0]} (worker {slot[1]}), pid={process.pid}", flush=True)
            save_status("running")
        time.sleep(15)

    # Merge verified items into plot-ready tables and a timing summary.
    combined = {"raw_results.csv": [], "baseline_long.csv": [], "fido_curve.csv": []}
    for item in items:
        if state["items"][item["id"]]["status"] != "verified":
            continue
        stem = OUTPUT / "tables" / f"{item['dataset']}_seed{item['seed']}_{item['method']}"
        for name, suffix in (("raw_results.csv", "_raw.csv"), ("baseline_long.csv", "_long.csv"), ("fido_curve.csv", "_curve.csv")):
            path = Path(f"{stem}{suffix}")
            if path.exists():
                combined[name].extend(read_csv(path))
    groups = {}
    for row in combined["raw_results.csv"]:
        groups.setdefault((row["method"], row["dataset"], row["model"]), []).append(row)
    combined["timing_summary.csv"] = [{
        "method": method, "dataset": dataset, "model": model, "point_rows": len(rows),
        "seeds": " ".join(sorted({row["seed"] for row in rows})),
        "median_fit_seconds": statistics.median(float(row["fit_seconds"]) for row in rows),
        "median_model_evaluation_seconds": statistics.median(float(row["model_evaluation_seconds"]) for row in rows),
        "total_model_evaluation_seconds": sum(float(row["model_evaluation_seconds"]) for row in rows),
    } for (method, dataset, model), rows in sorted(groups.items())]
    (OUTPUT / "combined").mkdir(exist_ok=True)
    for name, rows in combined.items():
        if rows:
            fieldnames = list(dict.fromkeys(key for row in rows for key in row))
            with (OUTPUT / "combined" / name).open("w", encoding="utf-8", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                writer.writerows(rows)
    counts = {status: sum(record["status"] == status for record in state["items"].values())
              for status in ("verified", "failed", "blocked")}
    complete = counts["verified"] == len(items)
    save_status("complete" if complete else "finished_with_failures", counts=counts,
                combined_point_count=len(combined["raw_results.csv"]), ended_at=utc_now())
    print(f"Baselines {'complete' if complete else 'finished with failures'}: {counts}", flush=True)
    sys.exit(0 if complete else 1)
except Exception as exc:
    save_status("failed", error=str(exc))
    raise
