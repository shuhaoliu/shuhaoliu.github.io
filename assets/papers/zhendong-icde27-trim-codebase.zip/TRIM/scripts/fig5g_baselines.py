"""Fig. 5g baselines: the adversary-knowledge sweep of TRIM's panel on each baseline's most private release.

Release per method and seed (the configured dataset, MLP target, among the points with test Delta U <= the tolerance):
- PAT, FeatSel, EntryWise, FIDO: the most private release by the harness privacy (largest min-K, then lowest P99
  tail risk, then fewest released classes), then the lowest test Delta U; FeatSel keeps at least one QI;
- KAnon (TDS): the same rule over the grid and walk points (largest min-K, lowest P99 tail risk, fewest classes,
  lowest test Delta U).

For each release, every published row's released QI tuple (an exact value or the released domain) is coded, and
for each configured number of known QIs the candidate-set sizes over every QI subset are summarized by TRIM's own function
(``experiments.exp5_sensitivity.run_background._summarize_known_attributes``: worst-case success, strongest mean
success over subsets). The data and split are rebuilt from the matrix and must match the stored split file.
Writes ``fig5g_baselines.csv`` and ``selection.json`` under the configuration's results_root.

    python scripts/fig5g_baselines.py --config configs/paper/fig5g/baselines.yaml
"""
import argparse
import gzip
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd
import yaml

ROOT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT_DIR))

from experiments.exp1_baselines.evaluator import build_context  # noqa: E402
from experiments.exp1_baselines.release import domain_label, load_release  # noqa: E402
from experiments.exp5_sensitivity.run_background import _summarize_known_attributes  # noqa: E402
from experiments.run_matrix_sweep import expand_matrix  # noqa: E402

HARNESS = {"FIDO": ("main", "fido"), "FeatSel": ("main", "featsel"), "EntryWise": ("main", "entrywise"),
           "PAT": ("pat", "pat")}


def harness_pick(table, method, model, tolerance):
    df = pd.read_csv(table, low_memory=False)
    df = df[(df.model == model) & (df.method == method)]
    ok = df[df.test_delta_u <= tolerance]
    if method == "FeatSel":
        ok = ok[ok.featsel_kept_count > 0]
    if ok.empty:
        raise ValueError(f"{method} has no release with test Delta U <= {tolerance}.")
    return ok.sort_values(["min_k", "tail_risk_p99", "released_class_count", "test_delta_u"],
                          ascending=[False, True, True, True]).iloc[0]


def report(method, seed, summary):
    print(method, seed, "worst success by known QIs:",
          " ".join(f"{row['worst_success_probability']:.3g}" for row in summary), flush=True)


def tds_points(directories, dataset, model, seed):
    rows = []
    for directory in directories:
        for path in sorted((ROOT_DIR / directory).glob("*/raw_results.jsonl")):
            for line in path.read_text(encoding="utf-8").splitlines():
                row = json.loads(line)
                if (row["dataset"], row["model"], int(row["seed"])) == (dataset, model, seed):
                    rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    config = yaml.safe_load((ROOT_DIR / args.config).read_text(encoding="utf-8"))
    dataset, model, tolerance = config["dataset"], config["model"], float(config["tolerance"])
    counts = [int(count) for count in config["known_qi_counts"]]
    roots = {"main": ROOT_DIR / config["baseline_results"], "pat": ROOT_DIR / config["pat_results"]}
    output = ROOT_DIR / config["results_root"]
    output.mkdir(parents=True, exist_ok=True)
    matrix = yaml.safe_load((ROOT_DIR / config["matrix_config"]).read_text(encoding="utf-8"))
    tasks = [task for task in expand_matrix(matrix) if task["dataset"] == dataset and task.get("model_name") == model]
    rows, selection = [], []
    for seed in config["seeds"]:
        seed = int(seed)
        context = build_context(next(task for task in tasks if int(task["pipeline"]["random_state"]) == seed))
        for method, (part, stem) in HARNESS.items():
            root = roots[part]
            table = root / "tables" / f"{dataset}_seed{seed}_{stem}_raw.csv"
            pick = harness_pick(table, method, model, tolerance)
            release, _payload, split = load_release(root / pick.release_path,
                                                    root / "splits" / f"{dataset}_seed{seed}.json.gz")
            if split["split_sha256"] != context.split_sha256:
                raise ValueError(f"{method} seed {seed}: the stored split differs from the rebuilt one.")
            published = context.split.X_train_raw.iloc[release.positions]
            codes = {}
            for qi in release.qi_attributes:
                column = release.columns[qi]
                labels = np.asarray(["d:" + domain_label(d) for d in column.table], dtype=object)
                keys = np.asarray(["v:" + str(v) for v in published[qi].to_numpy()], dtype=object)
                generalized = column.codes >= 0
                keys[generalized] = labels[column.codes[generalized]]
                codes[qi] = pd.factorize(keys, sort=False)[0].astype(np.int64)
            frame = pd.DataFrame(codes, index=published.index)
            attributes = release.qi_attributes
            selection.append({"method": method, "seed": seed, "point": pick.point,
                              "test_delta_u": float(pick.test_delta_u), "min_k": int(pick.min_k),
                              "release_path": str(root / pick.release_path)})
            summary = _summarize_known_attributes(frame, attributes, f"{method}_s{seed}", counts)
            for row in summary:
                row.update(method=method, seed=seed, point=pick.point, test_delta_u=float(pick.test_delta_u),
                           release_min_k=int(pick.min_k), published_rows=len(frame))
            rows += summary
            report(method, seed, summary)
        within = [p for p in tds_points(config["tds_results"], dataset, model, seed) if p["test_delta_u"] <= tolerance]
        if not within:
            raise ValueError(f"KAnon seed {seed}: no release with test Delta U <= {tolerance}.")
        pick = min(within, key=lambda p: (-p["min_k"], p["tail_risk_p99"], p["partition_count"], p["test_delta_u"]))
        with gzip.open(pick["shared_release_path"], "rt", encoding="utf-8") as handle:
            release = json.load(handle)
        attributes = list(context.loader.qi_attributes)
        sizes = [part["size"] for part in release["partitions"]]
        if sum(sizes) != pick["row_count"] or pick["suppressed_row_count"] != 0:
            raise ValueError(f"KAnon seed {seed}: the release does not publish every training row once.")
        # Rows of one partition share every released value; repeat each partition's codes by its size.
        domains = {qi: [json.dumps(part["release"][qi], sort_keys=True) for part in release["partitions"]]
                   for qi in attributes}
        frame = pd.DataFrame({qi: np.repeat(pd.factorize(np.asarray(values, dtype=object))[0], sizes)
                              for qi, values in domains.items()})
        selection.append({"method": "TDS", "seed": seed, "point": f"K={pick['target_k']}",
                          "test_delta_u": float(pick["test_delta_u"]), "min_k": int(pick["min_k"]),
                          "release_path": pick["shared_release_path"]})
        summary = _summarize_known_attributes(frame, attributes, f"TDS_s{seed}", counts)
        for row in summary:
            row.update(method="TDS", seed=seed, point=f"K={pick['target_k']}", test_delta_u=float(pick["test_delta_u"]),
                       release_min_k=int(pick["min_k"]), published_rows=len(frame))
        rows += summary
        report("TDS", seed, summary)
    pd.DataFrame(rows).to_csv(output / "fig5g_baselines.csv", index=False)
    (output / "selection.json").write_text(json.dumps(selection, indent=1) + "\n", encoding="utf-8")
    print("wrote", output / "fig5g_baselines.csv")


if __name__ == "__main__":
    main()
