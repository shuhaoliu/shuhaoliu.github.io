"""Fig. 5i: LGA-based candidate ranking against IF, Random and Retrain (Exp-6)."""
