"""Run Fig. 5e: TRIM at each evaluation budget b (rank_top_k)."""

from __future__ import annotations

import argparse

from .._runner import run_matrix_config


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Exp-5: varying the evaluation budget b (Fig. 5e).")
    parser.add_argument("--config", required=True)
    parser.add_argument("--device")
    parser.add_argument("--run-label")
    args = parser.parse_args()

    output = run_matrix_config(
        args.config,
        expected_kind="exp5_topk",
        device=args.device,
        run_label=args.run_label,
    )
    print(output)


if __name__ == "__main__":
    main()
