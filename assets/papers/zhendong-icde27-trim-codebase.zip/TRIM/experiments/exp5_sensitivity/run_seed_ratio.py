"""Run Fig. 5f: TRIM at each initial-sample (seed) ratio, timed up to the stop of its final check."""

from __future__ import annotations

import argparse

from .._runner import run_matrix_config
from ..exp3_runtime._metrics import extract_runtime_to_stop


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Run Exp-5 initial-sample-ratio sensitivity."
    )
    parser.add_argument("--config", required=True)
    parser.add_argument("--device")
    parser.add_argument("--run-label")
    args = parser.parse_args()

    output = run_matrix_config(
        args.config,
        expected_kind="exp5_seed_ratio",
        device=args.device,
        run_label=args.run_label,
        after_task=extract_runtime_to_stop,
    )
    print(output)


if __name__ == "__main__":
    main()
