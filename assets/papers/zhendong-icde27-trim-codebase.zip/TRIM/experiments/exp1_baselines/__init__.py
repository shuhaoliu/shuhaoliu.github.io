"""Exp-1 data-minimization baselines (FIDO, FeatSel, EntryWise, PAT input) on the shared protocol."""
