"""Evaluation records with resume, and the raw and long tables written from them.

Each (dataset, seed, method) has one append-only JSONL file. A record is one
target model evaluated on one release (``record_type`` "point"), or one FIDO
learning-curve evaluation ("curve"). A killed process can leave only the last
line incomplete; it is dropped on reopening, and completed records are never
recomputed.

The long table follows the TDS ``baseline_long.csv`` schema read by
``plotting/paper/style/privacy_utility.py`` (Fig. 4): every point row is repeated with
``x_metric = test_delta_u`` and ``y_metric`` ``min_k`` (``y_reference`` = K0)
or ``tail_risk_p99`` (``y_reference`` = the original tail).
"""

from __future__ import annotations

import csv
import fcntl
import json
import math
import os
from pathlib import Path

RAW_COLUMNS = [
    "experiment", "method", "variant", "dataset", "model", "seed", "point", "evaluation_split",
    "validation_loss", "validation_delta_u", "baseline_validation_loss",
    "test_loss", "baseline_test_loss", "test_delta_u",
    "min_k", "original_leak_k", "privacy_delta_h",
    "tail_risk_p99", "tail_risk_percentile", "tail_risk_percentile_method", "tail_risk_population",
    "tail_risk_population_size", "tail_risk_released_population_size", "tail_risk_semantics",
    "original_tail_risk_p99", "privacy_counter", "released_class_count",
    "row_count", "training_row_count", "coverage_fraction", "suppressed_row_count",
    "generalized_cell_count", "root_cell_count", "generalized_cell_fraction",
    "method_parameters",
    "fido_epsilons", "fido_bounds", "fido_prefix_size", "fido_prefix_fraction",
    "fido_forecast_validation_loss", "fido_bound_reached",
    "featsel_search", "featsel_kept_count", "featsel_kept_qis", "featsel_removed_qis",
    "entrywise_fraction", "entrywise_fraction_index", "entrywise_adjustment", "entrywise_mult",
    "pat_alpha", "pat_max_leaf_nodes", "pat_bucketization_sha256", "pat_bucket_counts",
    "release_key", "release_path", "release_sha256", "release_reused", "release_content_sha256",
    "release_seconds", "release_store_seconds", "privacy_seconds", "encode_seconds", "fit_seconds",
    "model_evaluation_seconds", "evaluation_reused_from",
    "implementation_sha256", "protocol_sha256", "split_sha256", "device", "device_name",
    "started_at", "finished_at",
]
CURVE_COLUMNS = [
    "method", "dataset", "model", "seed", "point", "prefix_size", "prefix_fraction",
    "validation_loss", "validation_delta_u", "test_loss", "test_delta_u",
    "baseline_validation_loss", "baseline_test_loss", "min_k", "tail_risk_p99",
    "release_key", "release_path", "fit_seconds", "model_evaluation_seconds",
    "implementation_sha256", "started_at", "finished_at",
]
PLOT_METRICS = (("min_k", "original_leak_k"), ("tail_risk_p99", "original_tail_risk_p99"))


def record_key(record: dict) -> tuple:
    return (record["record_type"], record["method"], record["dataset"], int(record["seed"]),
            record["model"], str(record["point"]))


class EvaluationStore:
    """Append-only JSONL of evaluation records for one (dataset, seed, method)."""

    def __init__(self, path, *, resume: bool):
        self.path = Path(path)
        self.records = {}
        if self.path.exists():
            if not resume:
                raise FileExistsError(f"{self.path} exists; pass --resume to continue it.")
            data = self.path.read_bytes()
            complete = data[: data.rfind(b"\n") + 1]
            if len(complete) != len(data):
                # Only the last line can be incomplete (killed during a write).
                with self.path.open("r+b") as handle:
                    handle.truncate(len(complete))
            for number, line in enumerate(complete.decode("utf-8").splitlines(), start=1):
                record = json.loads(line)
                self.records[record_key(record)] = record
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def get(self, key):
        return self.records.get(key)

    def append(self, record: dict) -> None:
        key = record_key(record)
        if key in self.records:
            raise ValueError(f"Duplicate evaluation record {key}.")
        line = json.dumps(record, sort_keys=True, default=_json_default) + "\n"
        with self.path.open("a", encoding="utf-8") as handle:
            handle.write(line)
            handle.flush()
            os.fsync(handle.fileno())
        self.records[key] = record

    def points(self) -> list[dict]:
        return [record for record in self.records.values() if record["record_type"] == "point"]

    def curve(self) -> list[dict]:
        return [record for record in self.records.values() if record["record_type"] == "curve"]


def _json_default(value):
    if hasattr(value, "item"):
        return value.item()
    raise TypeError(f"Not JSON serializable: {value!r}")


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, sort_keys=True)
    if isinstance(value, float) and math.isinf(value):
        return "-inf" if value < 0 else "inf"
    return value


def write_table(path, rows, columns) -> None:
    """Write rows with a fixed column order (extra keys follow, sorted); atomic replace."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    extra = sorted({key for row in rows for key in row} - set(columns) - {"record_type"})
    fieldnames = list(columns) + extra
    temporary = path.with_name(f".{path.name}.{os.getpid()}.partial")
    with temporary.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, extrasaction="ignore")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: _cell(row.get(key)) for key in fieldnames})
    temporary.replace(path)


def long_rows(points) -> list[dict]:
    """Two plot rows per point: min_k against K0 and the P99 tail against the original tail."""
    rows = []
    for point in points:
        for metric, reference in PLOT_METRICS:
            rows.append({
                **point, "x_metric": "test_delta_u", "x_value": point["test_delta_u"],
                "y_metric": metric, "y_value": point[metric], "y_reference": point[reference],
            })
    return rows


def write_tables(store: EvaluationStore, directory, stem: str) -> dict:
    """Write <stem>_raw.csv, <stem>_long.csv and, for FIDO, <stem>_curve.csv."""
    directory = Path(directory)
    points = sorted(store.points(), key=lambda row: (row["model"], row["point"]))
    written = {}
    if points:
        write_table(directory / f"{stem}_raw.csv", points, RAW_COLUMNS)
        write_table(directory / f"{stem}_long.csv", long_rows(points),
                    RAW_COLUMNS + ["x_metric", "x_value", "y_metric", "y_value", "y_reference"])
        written.update(raw=str(directory / f"{stem}_raw.csv"), long=str(directory / f"{stem}_long.csv"))
    curve = sorted(store.curve(), key=lambda row: (row["model"], int(row["prefix_size"])))
    if curve:
        write_table(directory / f"{stem}_curve.csv", curve, CURVE_COLUMNS)
        written["curve"] = str(directory / f"{stem}_curve.csv")
    return written


class ItemLock:
    """An exclusive, non-blocking lock so one process owns a (dataset, seed, method)."""

    def __init__(self, path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.handle = self.path.open("a")
        try:
            fcntl.flock(self.handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            self.handle.close()
            raise RuntimeError(f"Another process holds {self.path}.") from error

    def release(self) -> None:
        fcntl.flock(self.handle, fcntl.LOCK_UN)
        self.handle.close()
