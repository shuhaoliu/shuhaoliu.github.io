"""Verbatim copies of upstream baseline code and the hashes of their source text.

Each copied file starts with a provenance header. ``verify_upstream_copies``
recomputes the SHA-256 of the copied source text and compares it with the
hash of the original source recorded here, so an accidental edit is caught.
"""

from __future__ import annotations

import hashlib
from pathlib import Path

HERE = Path(__file__).resolve().parent

# learning_to_limit/curve_models.py (with the two changes in its header), whole file.
FIDO_CURVE_MODELS_SHA256 = "3285ee3a2389a1fff7d17cf2a0083c002b82b334ebfd8f8e2e8efb73d3690cac"
# data-minimization-principle/baselines.py lines 44-60.
ENTRYWISE_SUBSAMPLING_SHA256 = "e73a0d478c80c8fd562d1db8d82b07af358ce9158340812b93b20351e023bef0"
# data-minimization-principle/attacks.py lines 152-194 (end of file,
# which has no final newline).
ENTRYWISE_SCALE_MIN_SHA256 = "cb273802bdfed6bcd8e3684d3bb0a3d7e6837ae223d69fe0c31b23fa372b6c71"
SEPARATOR = "# " + "-" * 78 + "\n"


def _sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def verify_upstream_copies() -> dict[str, str]:
    """Return the verified hashes; raise if a copied segment was edited."""
    fido = (HERE / "fido_curve_models.py").read_text(encoding="utf-8")
    fido_body = fido.split(SEPARATOR, 1)[1]
    entrywise = (HERE / "entrywise.py").read_text(encoding="utf-8")
    lines = entrywise.split(SEPARATOR, 1)[1].splitlines(keepends=True)
    start = next(i for i, line in enumerate(lines) if line.startswith("def personalized_random_subsampling"))
    subsampling = "".join(lines[start:start + 17])
    start = next(i for i, line in enumerate(lines) if line.startswith("def scale_min_reid"))
    scale_min = "".join(lines[start:])
    if scale_min.endswith("\n"):
        scale_min = scale_min[:-1]
    observed = {
        "fido_curve_models": _sha256(fido_body),
        "entrywise_personalized_random_subsampling": _sha256(subsampling),
        "entrywise_scale_min": _sha256(scale_min),
    }
    expected = {
        "fido_curve_models": FIDO_CURVE_MODELS_SHA256,
        "entrywise_personalized_random_subsampling": ENTRYWISE_SUBSAMPLING_SHA256,
        "entrywise_scale_min": ENTRYWISE_SCALE_MIN_SHA256,
    }
    changed = sorted(name for name in expected if observed[name] != expected[name])
    if changed:
        raise RuntimeError(f"Upstream copies differ from their sources: {changed}")
    return observed
