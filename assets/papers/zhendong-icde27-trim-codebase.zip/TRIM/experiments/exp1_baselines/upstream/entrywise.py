# Verbatim copies of EntryWise's minimizer and privacy-score adjustment.
#
# Source: https://github.com/prakharg24/data-minimization-principle at a61ba73
# (Ganesh et al., FAccT 2025):
# - personalized_random_subsampling: baselines.py lines 44-60;
# - scale_min_reid and scale_min_recon: attacks.py lines 152-194.
# The upstream modules are not imported because they pull in tqdm, opacus and
# torch-based attacks that the evaluation environment does not provide. The
# function bodies below the separator line are byte-identical to the source
# lines; their SHA-256 values are recorded in
# experiments/exp1_baselines/upstream/__init__.py. Only the three imports the
# functions need are added here.
import copy

import numpy as np
from scipy.stats import pearsonr

# ------------------------------------------------------------------------------
def personalized_random_subsampling(X_train, y_train, fraction, inplace=False, seed=0):
    if inplace:
        X_train_local, y_train_local = X_train, y_train
    else:
        X_train_local, y_train_local = copy.deepcopy(X_train), copy.deepcopy(y_train)

    np.random.seed(seed)
    overall_size = X_train_local.size
    keepdata_size = int(fraction*overall_size)
    empty_mask = np.array([False] * keepdata_size + [True] * (overall_size - keepdata_size))
    np.random.shuffle(empty_mask)
    empty_mask = empty_mask.reshape(X_train_local.shape)
    
    # empty_mask = np.random.choice([False, True], size=X_train_local.shape, p=[fraction, 1-fraction]).reshape(X_train_local.shape)
    X_train_local[empty_mask] = np.nan

    return X_train_local, y_train_local


def scale_min_reid(X_mem, fraction, Bu, mult):
    scores = np.zeros(X_mem.shape)
    for i in range(X_mem.shape[1]):
        scores[:,i] = len(np.unique(X_mem[:,i]))
    scores = scores/np.max(scores)

    comb_scores = -mult*scores -Bu
    sorted_indices = np.argsort(comb_scores, axis=None)

    current_removal_size = int((1-fraction)*len(sorted_indices))
    indices_to_remove = sorted_indices[:current_removal_size]

    Bnew = np.zeros(Bu.shape)
    np.put_along_axis(Bnew, indices_to_remove, 1, axis=None)

    return Bnew

def scale_min_recon(X_mem, fraction, Bu, mult):
    sum_corr_dict = {}
    for i in range(X_mem.shape[1]):
        max_, min_ = np.max(X_mem[:,i]), np.min(X_mem[:,i])
        if max_ == min_:
            # print('you need to remove this constant column feature = {}'.format(i))
            sum_corr_dict[i] = -1
        else:
            sum_corr_dict[i] = np.nansum([ abs(pearsonr(X_mem[:,i], X_mem[:,j])[0]) for j in range(X_mem.shape[1]) if j!=i])
    
    scores = np.zeros(X_mem.shape)
    for i in range(X_mem.shape[1]):
        scores[:,i] = sum_corr_dict[i]
    scores[scores==-1] = np.max(scores)
    scores = scores/np.max(scores)

    comb_scores = -mult*scores -Bu
    sorted_indices = np.argsort(comb_scores, axis=None)

    current_removal_size = int((1-fraction)*len(sorted_indices))
    indices_to_remove = sorted_indices[:current_removal_size]

    Bnew = np.zeros(Bu.shape)
    np.put_along_axis(Bnew, indices_to_remove, 1, axis=None)

    return Bnew
