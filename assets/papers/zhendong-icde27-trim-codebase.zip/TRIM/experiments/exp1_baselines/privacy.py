"""Privacy of a baseline release under rule (B), identical released tuples.

For a published row i, k_i is the number of published rows whose released QI
tuple equals i's: an exact cell contributes the row's raw value, a generalized
cell its released domain, and ROOT ('*') counts as an ordinary value. Missing
raw values are values of their own (no row is dropped). min-K is the minimum
over published rows; the P99 tail uses prototype.privacy_metrics with every
unpublished training row at -inf. K0 comes from the raw training QIs.
"""

from __future__ import annotations

import math

import numpy as np
import pandas as pd

from prototype.privacy_metrics import individual_tail_risk_stats, original_equivalence_class_sizes


def raw_value_codes(X_train_raw: pd.DataFrame, qi_attributes) -> dict:
    """Integer codes of every training row's raw QI value; missing values get their own code."""
    codes = {}
    for qi in qi_attributes:
        values, uniques = pd.factorize(X_train_raw[qi], sort=False, use_na_sentinel=False)
        codes[qi] = (values.astype(np.int64), len(uniques))
    return codes


def released_class_sizes(positions, columns, raw_codes, qi_attributes) -> np.ndarray:
    """k_i for each published row, in the order of ``positions``."""
    positions = np.asarray(positions, dtype=np.int64)
    if not len(positions):
        raise ValueError("A release must publish at least one row.")
    if not len(qi_attributes):
        return np.full(len(positions), len(positions), dtype=np.int64)
    tokens = np.empty((len(positions), len(qi_attributes)), dtype=np.int64)
    for column_index, qi in enumerate(qi_attributes):
        values, value_count = raw_codes[qi]
        token = values[positions].copy()
        codes = columns[qi].codes
        generalized = codes >= 0
        # Released domains get codes after every raw value of this QI.
        token[generalized] = value_count + codes[generalized]
        tokens[:, column_index] = token
    _, inverse, counts = np.unique(tokens, axis=0, return_inverse=True, return_counts=True)
    return counts[np.asarray(inverse).reshape(-1)].astype(np.int64)


def original_privacy(X_train_raw: pd.DataFrame, qi_attributes) -> dict:
    """K0 and the original P99 tail on the raw training QIs (TRIM's definition)."""
    sizes = original_equivalence_class_sizes(X_train_raw, qi_attributes)
    return {
        "original_leak_k": int(sizes.min()),
        "original_tail_risk_p99": individual_tail_risk_stats(X_train_raw.index, sizes)["tail_risk_p99"],
    }


def release_privacy(release, train_ids: pd.Index, raw_codes, original: dict) -> dict:
    """min-K, the P99 tail and related counts of one release under rule (B)."""
    sizes = released_class_sizes(release.positions, release.columns, raw_codes, release.qi_attributes)
    per_record = pd.Series(sizes, index=train_ids[release.positions])
    tail = individual_tail_risk_stats(train_ids, per_record)
    min_k = int(sizes.min())
    return {
        "min_k": min_k,
        "original_leak_k": original["original_leak_k"],
        "privacy_delta_h": -math.log(min_k / original["original_leak_k"]),
        **tail,
        "original_tail_risk_p99": original["original_tail_risk_p99"],
        "released_class_count": int(np.sum(1.0 / sizes).round()),
        "row_count": release.row_count,
        "training_row_count": release.training_row_count,
        "coverage_fraction": release.row_count / release.training_row_count,
        "suppressed_row_count": release.training_row_count - release.row_count,
        "privacy_counter": "B_identical_released_tuples",
    }
