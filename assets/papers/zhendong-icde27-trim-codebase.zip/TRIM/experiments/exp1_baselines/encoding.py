"""TRIM's shared model inputs for baseline releases.

Exact cells keep the level-0 encoding that the full-data reference model uses,
so a release that publishes every row exactly reproduces the reference input.
A generalized cell is replaced by the encoding of its released domain:

- MLP: a categorical domain is spread evenly over its leaves' one-hot columns;
  a numeric domain becomes the mean of its leaf values (the mean of the scalar
  leaves, or of every integer in the union of interval leaves), as TRIM
  encodes a hierarchy node.
- XGBoost: TRIM's leaf space (``encode_xgboost_leaf_space``), i.e. uniform
  weights over the domain's leaves plus the QI's height column, which holds
  the height of the released node.

ROOT ('*') is the root node. A leaf set that is not a hierarchy node (a PAT
bucket) is encoded by the minimal extension of these rules: weights spread
over its member leaves, the mean of the member leaf values, and the height of
the smallest hierarchy node containing every member. The members of a numeric
interval [a, b) are the leaves that overlap it; their full leaf values enter
the mean (no clipping to the interval).
"""

from __future__ import annotations

import numpy as np

from experiments.exp1_kanon.hierarchy import HierarchySchema
from prototype.dataloader import _interval_union_mean, _parse_leaf_value
from prototype.gpu_math import to_device_tensor

from .release import canonical_domain, canonical_json


class ReleaseEncoder:
    """Level-0 encodings plus per-cell overwrites for released domains."""

    def __init__(self, generalization, *, family: str):
        if family not in {"mlp", "xgboost"}:
            raise ValueError("Baseline releases support the shared mlp and xgboost encodings.")
        self.generalization = generalization
        self.loader = generalization.data_loader
        self.family = family
        self.schema = HierarchySchema(generalization)
        self.qi_attributes = self.schema.attributes
        self._representations = {}
        self._numeric_parsed = {}
        for qi in self.schema.numeric:
            parsed = [_parse_leaf_value(leaf["value"]) for leaf in self.schema.leaves[qi]]
            self._numeric_parsed[qi] = parsed
        self.blocks = self._mlp_blocks() if family == "mlp" else self._xgboost_blocks()

    # Column layout -------------------------------------------------------------------
    def _mlp_blocks(self):
        """Column positions of each QI in ``generalization.encode`` output."""
        columns = list(self.loader.numeric_attributes)
        for attribute in self.loader.categorical_attributes:
            columns += [f"{attribute}={category}" for category in self.loader.category_maps[attribute]]
        self.column_names = columns
        position = {name: index for index, name in enumerate(columns)}
        blocks = {}
        for qi in self.qi_attributes:
            if qi in self.schema.numeric:
                blocks[qi] = {"start": position[qi], "width": 1}
            else:
                categories = self.loader.category_maps[qi]
                start = position[f"{qi}={next(iter(categories))}"]
                if [position[f"{qi}={category}"] for category in categories] != list(
                    range(start, start + len(categories))
                ):
                    raise AssertionError(f"{qi}: one-hot columns are not contiguous.")
                # Leaf position -> category column offset inside the block.
                offsets = np.asarray(
                    [categories[value] for value in self.schema.leaf_values[qi]], dtype=np.int64,
                )
                blocks[qi] = {"start": start, "width": len(categories), "leaf_offsets": offsets}
        return blocks

    def _xgboost_blocks(self):
        """Column positions of each QI's leaf block and height column in the leaf space."""
        offset, blocks = 0, {}
        for attribute in self.loader.feature_columns:
            if attribute not in self.qi_attributes:
                offset += 1 if attribute in self.loader.numeric_attributes else len(
                    self.loader.category_maps[attribute]
                )
                continue
            width = len(self.schema.leaves[attribute])
            blocks[attribute] = {"start": offset, "width": width + 1}
            offset += width + 1
        self.column_count = offset
        return blocks

    # Level-0 inputs ------------------------------------------------------------------
    def level0_frame(self, X):
        """The reference model's level-0 MLP frame (float64; the standardizer is fit on it)."""
        if self.family != "mlp":
            raise ValueError("level0_frame is the MLP encoding.")
        frame = self.generalization.encode(X)
        if list(frame.columns) != self.column_names:
            raise AssertionError("The shared MLP column layout changed.")
        return frame

    def level0(self, X) -> np.ndarray:
        """Float32 level-0 matrix: the full-data reference input for these rows."""
        if self.family == "mlp":
            return self.level0_frame(X).to_numpy(dtype=np.float32)
        encoded = np.ascontiguousarray(
            self.generalization.encode_xgboost_leaf_space(X).toarray(), dtype=np.float32,
        )
        if encoded.shape[1] != self.column_count:
            raise AssertionError("The shared XGBoost leaf-space width changed.")
        return encoded

    # Domains -------------------------------------------------------------------------
    def members(self, qi: str, domain) -> tuple[list[int], int]:
        """Leaf positions of a released domain and the height of its released node."""
        domain = canonical_domain(domain)
        leaves = self.schema.leaves[qi]
        kind = domain["kind"]
        if kind == "root":
            root = self.schema.roots[qi]
            return list(range(len(leaves))), int(self.schema.nodes[qi][root]["height_from_leaf"])
        if kind == "node":
            node = domain["node"]
            if node not in self.schema.nodes[qi]:
                raise ValueError(f"{qi}: unknown hierarchy node {node!r}.")
            return sorted(self.schema.descendants[qi][node]), int(self.schema.nodes[qi][node]["height_from_leaf"])
        if kind == "leaves":
            if qi in self.schema.numeric:
                raise ValueError(f"{qi}: numeric QIs release intervals, not leaf-value sets.")
            lookup = self.schema.lookup[qi]
            unknown = [value for value in domain["values"] if value not in lookup]
            if unknown:
                raise ValueError(f"{qi}: leaf values outside the hierarchy: {unknown[:5]!r}")
            positions = sorted(lookup[value] for value in domain["values"])
        else:
            if qi not in self.schema.numeric:
                raise ValueError(f"{qi}: categorical QIs release leaf sets, not intervals.")
            low, high = domain["low"], domain["high"]
            positions = [
                position for position, (leaf_low, leaf_high) in enumerate(self.schema.leaf_values[qi])
                if (low is None or leaf_high >= low) and (high is None or leaf_low < high)
            ]
            if not positions:
                raise ValueError(f"{qi}: interval [{low}, {high}) overlaps no hierarchy leaf.")
        return positions, self._smallest_containing_height(qi, positions)

    def _smallest_containing_height(self, qi: str, positions) -> int:
        nodes = self.schema.nodes[qi]
        common = None
        for position in positions:
            ancestors, current = set(), self.schema.leaves[qi][position]["id"]
            while current is not None:
                ancestors.add(current)
                current = nodes[current].get("parent")
            common = ancestors if common is None else common & ancestors
        return min(int(nodes[node]["height_from_leaf"]) for node in common)

    def representation(self, qi: str, domain) -> np.ndarray:
        """The block written for every cell of ``qi`` released as ``domain``."""
        key = (qi, canonical_json(canonical_domain(domain)))
        cached = self._representations.get(key)
        if cached is not None:
            return cached
        positions, height = self.members(qi, domain)
        block = self.blocks[qi]
        if self.family == "mlp":
            if qi in self.schema.numeric:
                parsed = [self._numeric_parsed[qi][position] for position in positions]
                if any(item[0] == "interval" for item in self._numeric_parsed[qi]):
                    value = _interval_union_mean([(item[1], item[2]) for item in parsed if item[0] == "interval"])
                else:
                    value = sum(item[1] for item in parsed) / len(parsed)
                vector = np.asarray([value], dtype=np.float64)
            else:
                vector = np.zeros(block["width"], dtype=np.float64)
                vector[block["leaf_offsets"][positions]] = 1.0 / len(positions)
        else:
            vector = np.zeros(block["width"], dtype=np.float64)
            vector[positions] = 1.0 / len(positions)
            vector[-1] = height
        vector = vector.astype(np.float32)
        self._representations[key] = vector
        return vector

    def apply(self, matrix: np.ndarray, columns, *, copy: bool = True) -> np.ndarray:
        """Overwrite the generalized cells of a level-0 matrix whose rows align with ``columns``."""
        generalized = [qi for qi in self.qi_attributes if qi in columns and columns[qi].table]
        if not generalized:
            return matrix
        output = matrix.copy() if copy else matrix
        for qi in generalized:
            column = columns[qi]
            if len(column) != len(output):
                raise ValueError(f"{qi}: domain column and matrix rows differ.")
            start, width = self.blocks[qi]["start"], self.blocks[qi]["width"]
            for code, domain in enumerate(column.table):
                rows = np.flatnonzero(column.codes == code)
                output[rows, start:start + width] = self.representation(qi, domain)
        return output

    def model_input(self, matrix: np.ndarray, *, standardizer=None, device=None, dtype=None,
                    allow_cpu_fallback=True):
        """The tensor or array that the shared model wrappers consume, as in the TDS runner."""
        if self.family == "xgboost":
            return np.ascontiguousarray(matrix, dtype=np.float32)
        return standardizer.transform(to_device_tensor(
            matrix, device=device, dtype=dtype, allow_cpu_fallback=allow_cpu_fallback,
        ))
