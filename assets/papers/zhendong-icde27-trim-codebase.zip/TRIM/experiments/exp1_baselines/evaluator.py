"""Shared data, split, reference and evaluation layer of the data-minimization baselines.

Data, split, model factory and encodings are those of TRIM and TDS:
``build_data_loader`` + ``load_dataset_split`` (shuffle, then a stratified
70/15/15 split), the level-0 generalization of the shared tree, the frozen
standardizer fit on the level-0 training encoding, and the downstream model
factory with the model seed equal to the task seed. The full-data reference
is the target model trained on every training row at level 0, exactly as in
``experiments/exp1_kanon_global/run.py``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
from pathlib import Path
import time
from typing import Any

import numpy as np
import pandas as pd

from experiments.common import resolve_project_path
from prototype.TRIM_prototype_pipeline import _loaded_input_sha256
from prototype.backend_training import fit_standardizer
from prototype.dataloader import load_generalization_rules_from_file
from prototype.dataset_registry import build_data_loader, resolve_dataset, resolve_generalization_tree
from prototype.gpu_math import classification_log_loss_tensor, to_device_tensor
from prototype.model_factory import build_model_factory
from prototype.release_artifacts import load_dataset_split

from .encoding import ReleaseEncoder
from .privacy import original_privacy, raw_value_codes
from .release import SPLIT_SCHEMA, split_hash, utc_now

SPLIT_KEYS = (("nrows", None), ("val_size", 0.15), ("test_size", 0.15), ("random_state", 42))


def resolve_data_path(value, data_root=None):
    """A matrix ``data_path``: relative paths resolve against ``data_root`` or the project root."""
    if value is None:
        return None
    path = Path(value).expanduser()
    if path.is_absolute():
        return path
    return Path(data_root).expanduser() / path if data_root is not None else resolve_project_path(path)


@dataclass
class DatasetContext:
    """One dataset and seed: loaded data, split, tree, hashes and original privacy."""

    dataset: str
    seed: int
    task: dict
    loader: Any
    split: Any
    tree_path: Path
    tree_sha256: str
    generalization: Any
    loaded_input_sha256: str
    training_data_sha256: str
    split_sha256: str
    original: dict
    raw_codes: dict = field(repr=False)

    @property
    def qi_attributes(self) -> tuple:
        return tuple(self.loader.qi_attributes)

    @property
    def train_ids(self) -> pd.Index:
        return self.split.X_train_raw.index

    @property
    def training_row_count(self) -> int:
        return len(self.split.X_train_raw)

    def hashes(self, implementation_sha256: str) -> dict:
        return {
            "split_sha256": self.split_sha256, "training_data_sha256": self.training_data_sha256,
            "loaded_input_sha256": self.loaded_input_sha256, "tree_sha256": self.tree_sha256,
            "implementation_sha256": implementation_sha256,
        }

    def split_payload(self) -> dict:
        split_config = dict(self.task.get("pipeline") or {})
        return {
            "schema_version": SPLIT_SCHEMA, "dataset": self.dataset, "seed": self.seed,
            "split_config": {key: split_config.get(key, default) for key, default in SPLIT_KEYS},
            "split_sha256": self.split_sha256, "loaded_input_sha256": self.loaded_input_sha256,
            "training_data_sha256": self.training_data_sha256, "tree_sha256": self.tree_sha256,
            "qi_attributes": list(self.qi_attributes),
            "preprocessing": getattr(self.loader, "preprocessing_metadata", {}),
            "train_size": self.training_row_count,
            "train_row_ids": self.split.X_train_raw.index.tolist(),
            "validation_row_ids": self.split.X_val_raw.index.tolist(),
            "test_row_ids": self.split.X_test_raw.index.tolist(),
            "created_at": utc_now(),
        }


def build_context(task: dict, *, data_root=None) -> DatasetContext:
    """Load and split one matrix task's dataset as the TRIM and TDS runners do."""
    dataset = resolve_dataset(task["dataset"]).key
    split_config = dict(task.get("pipeline") or {})
    seed = int(split_config.get("random_state", 42))
    loader = build_data_loader(dataset, data_path=resolve_data_path(task.get("data_path"), data_root))
    split = load_dataset_split(loader, split_config)
    if not split.X_train_raw.index.is_unique:
        raise ValueError("Training row IDs must be unique.")
    # Load the tree after the split, as the TRIM and TDS runners do: the tree
    # sets the QI category maps of the loader.
    tree_path = resolve_generalization_tree(dataset, resolve_project_path(task.get("generalization_tree_path")))
    generalization = load_generalization_rules_from_file(tree_path, loader, generalization_level=0)
    ids = [split.X_train_raw.index.tolist(), split.X_val_raw.index.tolist(), split.X_test_raw.index.tolist()]
    return DatasetContext(
        dataset=dataset, seed=seed, task=task, loader=loader, split=split, tree_path=tree_path,
        tree_sha256=hashlib.sha256(tree_path.read_bytes()).hexdigest(), generalization=generalization,
        loaded_input_sha256=_loaded_input_sha256(loader.X_raw, loader.y),
        training_data_sha256=_loaded_input_sha256(split.X_train_raw, split.y_train),
        split_sha256=split_hash(*ids),
        original=original_privacy(split.X_train_raw, loader.qi_attributes),
        raw_codes=raw_value_codes(split.X_train_raw, loader.qi_attributes),
    )


class ModelEvaluator:
    """Train the target model on a release and score validation and test log loss."""

    def __init__(self, context: DatasetContext, *, model_name: str, model_spec: dict, device: str,
                 dtype: str = "float32", allow_cpu_fallback: bool = False):
        self.context, self.model_name = context, model_name
        self.model_spec = dict(model_spec)
        self.family = self.model_spec["family"]
        if self.family not in {"mlp", "xgboost"}:
            raise ValueError("Exp-1 baselines support MLP and XGBoost target models.")
        if self.model_spec.get("warm_start"):
            raise ValueError("Every release must train a fresh model; warm_start must be false.")
        self.device, self.dtype, self.allow_cpu_fallback = device, dtype, allow_cpu_fallback
        split = context.split
        self.classes = np.unique(split.y_train.to_numpy())
        if len(self.classes) < 2:
            raise ValueError("The target model needs at least two training classes.")
        self.encoder = ReleaseEncoder(context.generalization, family=self.family)
        self.standardizer = None
        if self.family == "mlp":
            train_frame = self.encoder.level0_frame(split.X_train_raw)
            self.standardizer = fit_standardizer(train_frame, context.loader)
            train = train_frame.to_numpy(dtype=np.float32)
            del train_frame
        else:
            train = self.encoder.level0(split.X_train_raw)
        self.level0 = {
            "train": train,
            "validation": self.encoder.level0(split.X_val_raw),
            "test": self.encoder.level0(split.X_test_raw),
        }
        self.factory = build_model_factory(
            self.model_spec, device=device, dtype=dtype, allow_cpu_fallback=allow_cpu_fallback,
            random_state=context.seed, role="downstream",
        )
        started = time.perf_counter()
        self.reference = self._fit_and_score(
            self.level0["train"], split.y_train, self.level0["validation"], self.level0["test"],
        )
        self.reference_seconds = time.perf_counter() - started

    def _input(self, matrix):
        return self.encoder.model_input(
            matrix, standardizer=self.standardizer, device=self.device, dtype=self.dtype,
            allow_cpu_fallback=self.allow_cpu_fallback,
        )

    def _fit_and_score(self, train, y_train, validation, test) -> dict:
        model = self.factory()
        model.set_classes(self.classes)
        model.fit(self._input(train), y_train)
        output = {}
        for name, labels, matrix in (
            ("validation", self.context.split.y_val, validation), ("test", self.context.split.y_test, test),
        ):
            probabilities = model.predict_proba_tensor(self._input(matrix))
            target = to_device_tensor(labels, device=probabilities.device, dtype=probabilities.dtype)
            output[name] = float(classification_log_loss_tensor(
                target, probabilities, classes=self.classes, n_classes=len(self.classes),
            ).detach().cpu())
            if not np.isfinite(output[name]):
                raise ValueError(f"{name} loss is nonfinite; check model inputs and training.")
        return output

    def reference_record(self) -> dict:
        return {
            "dataset": self.context.dataset, "model": self.model_name, "seed": self.context.seed,
            "validation": self.reference["validation"], "test": self.reference["test"],
            "train_size": self.context.training_row_count, "model_spec": self.model_spec,
            "device": self.device, "dtype": self.dtype, "reference_seconds": self.reference_seconds,
            "standardizer_mean": getattr(self.standardizer, "mean", np.array([])).tolist(),
            "standardizer_std": getattr(self.standardizer, "std", np.array([])).tolist(),
            "original_leak_k": self.context.original["original_leak_k"],
            "original_tail_risk_p99": self.context.original["original_tail_risk_p99"],
        }

    def evaluate(self, release, validation_columns=None, test_columns=None) -> dict:
        """Losses of the target model trained on ``release``.

        Validation and test records are encoded with ``validation_columns`` and
        ``test_columns`` (per-QI domain columns over every validation or test
        row; ``None`` keeps exact values), following each method's convention.
        """
        started = time.perf_counter()
        base = self.level0["train"]
        if release.publishes_all_rows:
            train = self.encoder.apply(base, release.columns)
        else:
            train = self.encoder.apply(base[release.positions], release.columns, copy=False)
        validation = self.encoder.apply(self.level0["validation"], validation_columns or {})
        test = self.encoder.apply(self.level0["test"], test_columns or {})
        y_train = self.context.split.y_train.iloc[release.positions]
        encoded = time.perf_counter()
        losses = self._fit_and_score(train, y_train, validation, test)
        finished = time.perf_counter()
        return {
            "validation_loss": losses["validation"],
            "validation_delta_u": losses["validation"] - self.reference["validation"],
            "baseline_validation_loss": self.reference["validation"],
            "test_loss": losses["test"],
            "test_delta_u": losses["test"] - self.reference["test"],
            "baseline_test_loss": self.reference["test"],
            "encode_seconds": encoded - started,
            "fit_seconds": finished - encoded,
            "model_evaluation_seconds": finished - started,
        }
