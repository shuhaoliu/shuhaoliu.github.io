# Data-minimization baselines

This package runs FIDO, FeatSel and EntryWise, and evaluates PAT
bucketizations fitted in PAT's own environment, on the protocol of TRIM and
KAnon (TDS): the same data, split, full-data reference, model encodings,
target models and privacy measures.

## Design

One evaluator scores every method:

1. **Data, split and reference** (`evaluator.py`). Data loaders, the split
   (`load_dataset_split`: shuffle, then a stratified 70/15/15 split), the
   level-0 encodings, the frozen standardizer and the downstream model factory
   are TRIM's. The model seed is the task seed. The full-data reference is the
   target trained on every training row at level 0, exactly as in
   `experiments/exp1_kanon_global/run.py`.
2. **Release** (`release.py`). The published training row IDs, and per
   published row and QI one domain: the exact value, a set of leaves (a
   hierarchy node, a categorical leaf set or a numeric interval [a, b), the
   last two for PAT buckets) or ROOT, written '*'. Non-QIs pass through.
3. **Model input** (`encoding.py`). Exact cells keep the reference's level-0
   encoding, so a release of every row with exact values reproduces the
   reference input bit for bit. A generalized cell takes TRIM's encoding of its
   domain: MLP categoricals spread evenly over the leaves' one-hot columns, MLP
   numerics the mean of the leaf values; XGBoost uses TRIM's leaf space
   (`encode_xgboost_leaf_space`) with the height column. ROOT is the root
   node. A leaf set that is not a hierarchy node (a PAT bucket) uses the
   minimal extension: weights over its member leaves, the mean of the member
   leaf values, and the height of the smallest hierarchy node that contains
   every member. A numeric interval's members are the leaves it overlaps.
4. **Validation and test records** follow each method's convention: FeatSel's
   removed QIs are ROOT there too; PAT applies the same buckets and maps
   categories unseen in training (or values outside every bucket) to ROOT;
   FIDO and EntryWise use exact values.
5. **Utility.** The target is trained on the release; validation and test log
   loss are reported, and Delta U = loss - the reference loss of the same
   dataset, model and seed.
6. **Privacy** (`privacy.py`). k_i is the size of i's class of identical
   released QI tuples among the published rows, with '*' an ordinary value and
   a missing raw value a value of its own. min-K is the minimum over published
   rows; the P99 tail is `prototype.privacy_metrics.individual_tail_risk_stats`
   with unpublished training rows at -inf; K0 is the raw training QIs'.

Releases are generated once per (dataset, seed, method parameters), stored in
full, and evaluated by every target model. When a release has the same content
as one already evaluated for a model (published rows, released domains and
evaluation domains; `release_content_sha256`), its losses are copied instead of
refitting (`evaluation_reused_from`, model time 0).

## Methods

| Method | Release | Grid |
|---|---|---|
| FIDO (`fido.py`) | The prefix of a random order of the training rows (`numpy.random.default_rng(seed).permutation`), exact values | Learning curve at 16 geometric prefix sizes from 0.5% to 100% of the training split; FIDO's `BrokenCurve` (`upstream/fido_curve_models.py`) is fitted to (size, validation loss); for each epsilon in {0.005, 0.01, 0.02, 0.05, 0.1}, the stop size is the smallest size in [0.5%, 100%] whose forecast is at most the full-data validation loss + epsilon (the whole split if never). The distinct stop sizes are the operating points; each records its epsilons. |
| FeatSel (`featsel.py`) | A subset of the QIs; removed QIs are ROOT for all rows; every row published | Income and BM: every subset of the QIs; PubCov: the subsets that keep or remove at most 3 QIs; Diabetes and BNG: at most 2. |
| EntryWise (`entrywise.py`) | Upstream `personalized_random_subsampling` on the QI cells, RNG seeded by the task seed, optionally adjusted by upstream `scale_min_reid` or `scale_min_recon` (`upstream/entrywise.py`); a suppressed cell is ROOT; every row published | Kept fractions linspace(1/d, (d-1)/d, d-1) for d QIs, each with no adjustment and with reid or recon at mult 2, 5 and 10: 7(d-1) releases |
| PAT (`pat.py`) | A bucketization fitted in PAT's environment (`scripts/pat/`), applied to every row | The upstream grid (`datamin/configs/acs/acs_base.yaml`, minimizer `tree`): max_leaf_nodes in {2, 4, 6, 8, 10, 20, 50, 100, 200} x alpha in {0, 0.1, 0.3, 0.5, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95}, min_samples_leaf 100: 108 files per (dataset, seed) |

FIDO, FeatSel and EntryWise read their grids from
`configs/paper/fig4/baselines.yaml` (BNG: `configs/paper/fig5d/baselines_n*.yaml`);
PAT's grid is set in `scripts/pat/pat_fit.py` (`--max-leaf-nodes`, `--alphas`).

The scores of `scale_min_*` read the training QIs as the upstream runner codes
them: numeric QIs and numeric codes as they are, text categories label-encoded
(fitted on the training split only).

### PAT pipeline

PAT needs its own environment (`scripts/pat/README.md`), so its trees are
fitted apart from the harness and exchanged through files:

1. `scripts/pat/pat_bridge.py export` (TRIM environment) rebuilds each training
   split with the harness's `build_context`, checks it against the harness's
   split file (`splits/<dataset>_seed<seed>.json.gz`: row IDs, split, data and
   tree hashes) and writes the training rows' QIs and labels: raw values of
   numeric QIs and hierarchy-leaf categories of categorical QIs. Diabetes
   `diag_1/2/3` are pre-grouped to the finest level of the tree with at most
   512 distinct values on the training rows (PAT's per-feature category limit);
   the missing-value leaf, which sits under the root, is its own group. The
   level is recorded in the inputs and in each file's
   `parameters.pregroup_levels`.
2. `scripts/pat/pat_fit.py` (PAT environment) fits every grid configuration
   with PAT's `TreeMinimizer` (criterion `multi_fair_gini`) on the QIs, the
   categorical QIs being PAT's sensitive features, after PAT's own
   preprocessing. Each bucketization is converted to the format in `pat.py`:
   a continuous QI's buckets become raw-unit intervals cut at the midpoints
   between adjacent training values in different buckets, which reproduces
   PAT's assignment of every training value; a categorical bucket lists the
   leaves of its categories. The conversion is checked to induce PAT's
   partition of the training rows on every QI, and the file records PAT's
   min-K and class count of the bucketized training rows. A manifest per
   (dataset, seed) records fit times and duplicate bucketizations.
3. `scripts/pat/pat_bridge.py check` (TRIM environment) builds every file's
   release with `PatBucketization` (`pat.py`) and checks that the release has
   PAT's min-K and class count.
4. The harness evaluates the files (`--method pat --pat-dir <dir>`).

## Running

Commands run from the repository root in the TRIM environment;
`<pat-python>` is the Python of PAT's environment and `<datamin>` the patched
checkout.

**Fig. 4.** FIDO, EntryWise and FeatSel over the plan's (dataset, method, seed)
items, two GPUs, both target models per item:

```bash
python scripts/run_baselines.py --plan configs/paper/fig4/baselines_plan.json --check-only
python scripts/run_baselines.py --plan configs/paper/fig4/baselines_plan.json
```

PAT, on the splits the first run wrote:

```bash
python scripts/pat/pat_bridge.py export --config configs/paper/fig4/baselines.yaml \
  --split-dir results/fig4/baselines/splits --output-dir results/fig4/baselines_pat/inputs
for d in income pubcov diabetes bm_halfmonth; do for s in 42 43 44 45 46; do
  <pat-python> scripts/pat/pat_fit.py --inputs results/fig4/baselines_pat/inputs/${d}_seed${s}.json \
    --datamin <datamin> --output-dir results/fig4/baselines_pat/bucketizations
done; done
python scripts/pat/pat_bridge.py check --config configs/paper/fig4/baselines.yaml \
  --inputs-dir results/fig4/baselines_pat/inputs --pat-dir results/fig4/baselines_pat/bucketizations \
  --report results/fig4/baselines_pat/check.json
python scripts/run_baselines.py --plan configs/paper/fig4/baselines_pat_plan.json \
  --pat-dir results/fig4/baselines_pat/bucketizations
```

`run_baselines.py` checks the input and tree hashes and training sizes first,
verifies every item (identity points, point counts, release checksums) and
merges the verified items into `combined/`. `--resume` keeps verified items.
A single item can also be run directly:

```bash
CUDA_VISIBLE_DEVICES=0 python -m experiments.exp1_baselines.run --config configs/paper/fig4/baselines.yaml \
  --dataset bm_halfmonth --seed 42 --model mlp --model xgboost --method fido --device cuda:0
```

**Fig. 5a.** The Exp-2 attacks on each method's Income release at
epsilon 0.05 (MLP target), after the Fig. 4 runs:

```bash
python scripts/attack_baselines.py --config configs/paper/fig5ab/baselines_attacks.yaml
```

**Fig. 5c.** One timing job per (dataset, seed), MLP target, one job per GPU
with nothing else on it:

```bash
CUDA_VISIBLE_DEVICES=0 python scripts/time_baselines.py --config configs/paper/fig5c/baselines.yaml \
  --dataset income --seed 42 --model mlp --pat-python <pat-python> --datamin <datamin>
```

for datasets income, pubcov, diabetes and bm_halfmonth and seeds 42-46.

**Fig. 5d.** The same on BNG, XGBoost target, per size N in 120000, 240000,
360000, 480000, 600000, 720000 and 950000:

```bash
CUDA_VISIBLE_DEVICES=0 python scripts/time_baselines.py --config configs/paper/fig5d/baselines_n120000.yaml \
  --dataset bng --seed 42 --model xgboost --pat-python <pat-python> --datamin <datamin>
```

Each step of a timing job has a 6-hour limit (`--time-limit-seconds`); a
method's time is its `seconds_this_invocation` (every release of its grid
built, privacy-scored, stored and fitted, after data loading and the reference
fit), PAT's the sum of its grid fit seconds and its harness run (which also
evaluates PAT's two identity bucketizations).

**Fig. 5g.** After the Fig. 4 runs and the KAnon walk
(`experiments/exp1_kanon_global/README.md`):

```bash
python scripts/fig5g_baselines.py --config configs/paper/fig5g/baselines.yaml
```

Tests: `python -m pytest -q tests/test_exp1_baselines.py` (CPU, synthetic data).

## Output layout

Under a results directory:

| Path | Content |
|---|---|
| `splits/<dataset>_seed<seed>.json.gz` | Train, validation and test row IDs, split and data hashes |
| `references/<dataset>_seed<seed>_<model>.json` | Full-data validation and test losses, device and standardizer |
| `releases/<dataset>/seed<seed>/<method>/<release_key>.json.gz` | Every release in full (below) |
| `evaluations/<dataset>_seed<seed>_<method>.jsonl` | Append-only evaluation records (resume) |
| `tables/<dataset>_seed<seed>_<method>_{raw,long,curve}.csv` | Raw rows, plot-ready long rows, FIDO learning curve |
| `fido/<dataset>_seed<seed>_<model>.json` | FIDO curve points, fitted parameters and stop sizes |
| `manifests/*.json` | One per runner invocation: settings, hashes, references, identity checks, status, UTC times, per-method `seconds_this_invocation` |
| `combined/` | (`run_baselines.py`) `raw_results.csv`, `baseline_long.csv`, `fido_curve.csv` and `timing_summary.csv` of the verified items |

The long table has one `min_k` row (`y_reference` = K0) and one
`tail_risk_p99` row (`y_reference` = the original tail) per point, with
`x_metric = test_delta_u`, and `baseline_test_loss`, as the TDS runner's
`baseline_long.csv`. Further columns: `validation_loss`, `validation_delta_u`,
`baseline_validation_loss`, `test_loss`; `method_parameters` (JSON) and
readable `fido_*`, `featsel_*`, `entrywise_*` and `pat_*` columns;
`row_count`, `coverage_fraction`, `suppressed_row_count`, generalized and root
cell counts, `released_class_count`; `release_key`, `release_path` (relative to
the results directory), `release_sha256`, `release_content_sha256`,
`evaluation_reused_from`; `release_seconds`, `release_store_seconds`,
`privacy_seconds`, `encode_seconds`, `fit_seconds`,
`model_evaluation_seconds`; `implementation_sha256`, `protocol_sha256`,
`split_sha256`, `device_name`; `started_at` and `finished_at` (UTC). A tail of
-inf (a release of at most 1% of the training rows) is written as `-inf`.

### Stored releases

A release file is gzip-compressed JSON, schema `exp1_baseline_release.v1`:

- `identity` (method, dataset, seed, parameters, QIs, and the split,
  training-data, loaded-input, tree and implementation hashes) and
  `release_key`, its SHA-256;
- `published`: `{"kind": "all"}` or `{"kind": "row_ids", "row_ids": [...]}`
  in training-split order;
- `columns`: per QI one of `{"kind": "exact"}`, `{"kind": "constant",
  "domain": D}`, `{"kind": "mask", "domain": D, "bits": ...}` (D where the
  little-endian packed bit is 1, exact elsewhere) or `{"kind": "codes",
  "table": [D, ...], "dtype": ..., "data": ...}` (base64 little-endian codes;
  -1 exact, j the table entry), with domains `{"kind": "root"}`,
  `{"kind": "node", "node": id}`, `{"kind": "leaves", "values": [...]}` or
  `{"kind": "interval", "low": a, "high": b}`;
- `parameters`, `summary` (cell counts) and `created_at`.

Exact cells hold the raw values of the training rows, identified by their row
IDs in the split file, whose hashes the identity pins. To load one:

```python
from experiments.exp1_baselines.release import load_release, released_qi_frame
release, payload, split = load_release(
    "releases/bm_halfmonth/seed42/entrywise/<key>.json.gz", "splits/bm_halfmonth_seed42.json.gz")
# release.positions index the split's train_row_ids; release.columns[qi].codes
# and .table give each published cell's domain. With the loaded training frame
# (same split), released_qi_frame(release, X_train_raw) lists the released
# values ('*' for ROOT, node IDs, {a|b} sets, [a, b) intervals).
```
