"""FIDO (Shanmugam et al.): learning-curve forecast of the smallest sufficient random subset.

Per (dataset, seed) the training rows get one random prefix order. For each
target model, nested prefixes at geometric sizes give (size, validation loss)
points, to which FIDO's two-segment power law ``BrokenCurve`` is fitted
(upstream code, copied verbatim). For each loss bound epsilon, the stop size
is the smallest prefix size, between the smallest grid size and the full
training split, whose forecast validation loss is at most the full-data
validation loss plus epsilon; if the forecast never reaches the bound the
stop size is the whole training split. The release is that prefix with exact
values. The distinct stop sizes are FIDO's operating points.

The forecast is made offline from the whole learning curve (every loss bound
is evaluated on the same nested prefixes), instead of upstream's online
acquisition loop. A release keeps the training-split order of its rows, so
the 100% prefix is exactly the full-data reference input.
"""

from __future__ import annotations

import numpy as np

from .release import DomainColumn, Release
from .upstream.fido_curve_models import get_curve_model

METHOD = "FIDO"
ORDER_RULE = "numpy.random.default_rng(seed).permutation(training_row_count)"


def prefix_order(training_row_count: int, seed: int) -> np.ndarray:
    """The random acquisition order of training positions for one seed."""
    return np.random.default_rng(int(seed)).permutation(int(training_row_count))


def grid_sizes(training_row_count: int, *, start_fraction: float, end_fraction: float, points: int) -> list[int]:
    """Distinct prefix sizes at geometric fractions of the training split."""
    if not 0 < start_fraction < end_fraction <= 1 or int(points) < 2:
        raise ValueError("The FIDO size grid needs 0 < start < end <= 1 and at least two points.")
    fractions = np.geomspace(start_fraction, end_fraction, int(points))
    sizes = sorted({max(1, int(round(fraction * training_row_count))) for fraction in fractions})
    if end_fraction == 1:
        sizes[-1] = training_row_count
    return sizes


def prefix_release(context, order: np.ndarray, size: int) -> Release:
    """The first ``size`` rows of the acquisition order, published with exact values."""
    positions = np.sort(order[: int(size)])
    return Release(
        method=METHOD, dataset=context.dataset, seed=context.seed,
        parameters={"prefix_size": int(size), "order": ORDER_RULE, "order_seed": int(context.seed)},
        qi_attributes=context.qi_attributes, training_row_count=context.training_row_count,
        positions=positions,
        columns={qi: DomainColumn.exact(len(positions)) for qi in context.qi_attributes},
    )


def fit_curve(sizes, validation_losses, curve_model: str = "FIDO"):
    """Fit the upstream curve model to the learning-curve points."""
    model = get_curve_model(curve_model)
    model.fit(np.asarray(sizes, dtype=float), np.asarray(validation_losses, dtype=float))
    return model


def curve_parameters(model) -> dict:
    """The fitted BrokenCurve parameters, for the record."""
    return {
        "name": model.name, "thresh": float(model.thresh), "xscale": float(model.xscale),
        "yscale": float(model.yscale), "p1": {key: float(value) for key, value in model.p1.items()},
        "p2": {key: float(value) for key, value in model.p2.items()},
    }


def forecast(model, sizes) -> np.ndarray:
    """Forecast validation loss at each size (upstream ``pred`` takes one size at a time)."""
    return np.asarray([float(model.pred(float(size))) for size in sizes], dtype=float)


def stop_sizes(model, bounds, *, smallest: int, largest: int) -> list[dict]:
    """For each bound, the smallest size in [smallest, largest] whose forecast is within it."""
    candidates = np.arange(int(smallest), int(largest) + 1)
    predicted = forecast(model, candidates)
    stops = []
    for bound in bounds:
        within = np.flatnonzero(predicted <= bound)
        reached = bool(len(within))
        size = int(candidates[within[0]]) if reached else int(largest)
        stops.append({
            "bound": float(bound), "size": size, "bound_reached": reached,
            "forecast_validation_loss": float(predicted[size - int(smallest)]),
        })
    return stops
