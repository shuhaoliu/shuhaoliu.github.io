"""FeatSel: release a subset of the QIs; every training row is published.

A removed QI is ROOT ('*') for every row, and also for validation and test
records; kept QIs and all non-QI features are released exactly. The search
evaluates every enumerated subset with both target models:

- ``all``: every subset of the QIs, including the empty and the full set;
- ``bounded`` with m: every subset that keeps at most m QIs or removes at
  most m QIs (the empty and the full set included).

Subsets are listed full set first, then by the number of removed QIs, then in
lexicographic order of QI positions, so a truncated list keeps the identity
point.
"""

from __future__ import annotations

from itertools import combinations

import numpy as np

from .release import ROOT, DomainColumn, Release

METHOD = "FeatSel"


def enumerate_kept_sets(qi_attributes, *, mode: str, m: int | None = None) -> list[tuple[str, ...]]:
    """Kept QI subsets in the listing order described in the module docstring."""
    qis = tuple(qi_attributes)
    d = len(qis)
    if mode == "all":
        removed_sizes = range(d + 1)
        allowed = lambda removed: True  # noqa: E731
    elif mode == "bounded":
        if m is None or int(m) < 0:
            raise ValueError("A bounded FeatSel search needs m >= 0.")
        m = int(m)
        removed_sizes = range(d + 1)
        allowed = lambda removed: removed <= m or d - removed <= m  # noqa: E731
    else:
        raise ValueError(f"Unknown FeatSel search mode {mode!r}.")
    subsets = []
    for removed_count in removed_sizes:
        if not allowed(removed_count):
            continue
        for removed in combinations(range(d), removed_count):
            subsets.append(tuple(qi for index, qi in enumerate(qis) if index not in removed))
    return subsets


def point_label(qi_attributes, kept) -> str:
    """'keep_' plus one bit per QI in QI order, for example keep_1101."""
    kept = set(kept)
    return "keep_" + "".join("1" if qi in kept else "0" for qi in qi_attributes)


def columns_for(qi_attributes, kept, length: int) -> dict:
    kept = set(kept)
    return {
        qi: DomainColumn.exact(length) if qi in kept else DomainColumn.constant(length, ROOT)
        for qi in qi_attributes
    }


def featsel_release(context, kept) -> Release:
    """The release that keeps the QIs in ``kept``; the search is recorded with each point."""
    unknown = set(kept) - set(context.qi_attributes)
    if unknown:
        raise ValueError(f"Kept QIs outside the dataset's QIs: {sorted(unknown)}")
    kept = tuple(qi for qi in context.qi_attributes if qi in set(kept))
    return Release(
        method=METHOD, dataset=context.dataset, seed=context.seed,
        parameters={"kept_qis": list(kept)},
        qi_attributes=context.qi_attributes, training_row_count=context.training_row_count,
        positions=np.arange(context.training_row_count),
        columns=columns_for(context.qi_attributes, kept, context.training_row_count),
    )
