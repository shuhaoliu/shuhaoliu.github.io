"""PAT input: bucketizations fitted in PAT's own environment, evaluated here.

PAT (``datamin``, see ``scripts/pat/README.md``) needs its own Python
environment, so its trees are fitted there (``scripts/pat/pat_fit.py``) and
handed over as one JSON file per (dataset, seed, configuration), in this format
(schema ``exp1_pat_bucketization.v1``):

    {
      "schema_version": "exp1_pat_bucketization.v1",
      "dataset": "income",
      "seed": 42,
      "split_sha256": "<split_sha256 of splits/<dataset>_seed<seed>.json.gz>",
      "parameters": {"alpha": 0.5, "max_leaf_nodes": 50, ...},
      "buckets": {
        "SCHL": {"type": "categorical", "buckets": [[1, 2, 3], [4, 5], ...]},
        "AGEP": {"type": "numeric", "buckets": [[null, 25.5], [25.5, 40.5], [40.5, null]]}
      }
    }

Rules:

- ``split_sha256`` names the split the trees were fitted on; PAT must use the
  training rows of that split file (its ``train_row_ids``).
- ``parameters`` must hold ``alpha`` and ``max_leaf_nodes``; any other PAT
  setting may be added and is kept with the results.
- Every QI of the dataset appears exactly once, and no non-QI appears.
- A categorical bucket is a list of hierarchy leaf values, written as in the
  tree YAML (numbers for coded ACS attributes, strings otherwise). Buckets are
  disjoint. A bucket holding every leaf is ROOT ('*').
- A numeric bucket is a half-open interval [low, high) in raw units, with
  null for an unbounded side, which is how PAT's borders split values
  (``Bucketization.transform``). Intervals are disjoint; [null, null] is ROOT.
- Every training row's value must fall in exactly one bucket. Every training
  row is published.
- Validation and test records pass through the same buckets. A categorical
  value that no training row has, or a value outside every bucket, maps to
  ROOT.
"""

from __future__ import annotations

import json
from pathlib import Path

import numpy as np

from .release import ROOT, DomainColumn, Release, canonical_domain, canonical_json, json_scalar, sha256_text

METHOD = "PAT"
PAT_SCHEMA = "exp1_pat_bucketization.v1"


class PatBucketization:
    """One validated PAT bucketization over the shared hierarchies."""

    def __init__(self, payload: dict, context, schema):
        if payload.get("schema_version") != PAT_SCHEMA:
            raise ValueError(f"Expected schema_version {PAT_SCHEMA!r}.")
        if (payload.get("dataset"), int(payload.get("seed", -1))) != (context.dataset, context.seed):
            raise ValueError("The bucketization belongs to another dataset or seed.")
        if payload.get("split_sha256") != context.split_sha256:
            raise ValueError("The bucketization was fitted on another split.")
        parameters = dict(payload.get("parameters") or {})
        if "alpha" not in parameters or "max_leaf_nodes" not in parameters:
            raise ValueError("PAT parameters must include alpha and max_leaf_nodes.")
        buckets = payload.get("buckets") or {}
        if set(buckets) != set(context.qi_attributes):
            raise ValueError("The bucketization must list every QI exactly once and nothing else.")
        self.context, self.schema, self.parameters = context, schema, parameters
        self.domains, self.assign = {}, {}
        train_values = schema.values(context.split.X_train_raw)
        self.train_leaves = {}
        for qi in context.qi_attributes:
            spec = buckets[qi]
            if qi in schema.numeric:
                if spec.get("type") != "numeric":
                    raise ValueError(f"{qi} is numeric and needs numeric buckets.")
                intervals = []
                for bucket in spec["buckets"]:
                    low, high = bucket
                    canonical_domain({"kind": "interval", "low": low, "high": high})
                    intervals.append((-np.inf if low is None else float(low), np.inf if high is None else float(high)))
                ordered = sorted(intervals)
                if any(left[1] > right[0] for left, right in zip(ordered, ordered[1:])):
                    raise ValueError(f"{qi}: numeric buckets overlap.")
                self.domains[qi] = [
                    canonical_domain({"kind": "interval", "low": bucket[0], "high": bucket[1]})
                    for bucket in spec["buckets"]
                ]
                self.assign[qi] = intervals
            else:
                if spec.get("type") != "categorical":
                    raise ValueError(f"{qi} is categorical and needs leaf-value buckets.")
                position_bucket = np.full(len(schema.leaves[qi]), -1, dtype=np.int64)
                domains = []
                for index, bucket in enumerate(spec["buckets"]):
                    values = [json_scalar(value) for value in bucket]
                    unknown = [value for value in values if value not in schema.lookup[qi]]
                    if unknown or not values:
                        raise ValueError(f"{qi}: bucket {index} has no or unknown leaf values {unknown[:5]!r}.")
                    positions = [schema.lookup[qi][value] for value in values]
                    if np.any(position_bucket[positions] >= 0) or len(set(positions)) != len(positions):
                        raise ValueError(f"{qi}: categorical buckets overlap.")
                    position_bucket[positions] = index
                    domains.append(
                        dict(ROOT) if len(positions) == len(schema.leaves[qi])
                        else canonical_domain({"kind": "leaves", "values": values})
                    )
                self.domains[qi] = domains
                self.assign[qi] = position_bucket
                self.train_leaves[qi] = np.unique(train_values[qi][train_values[qi] >= 0])
        self.bucketization_sha256 = sha256_text(canonical_json(
            {qi: self.domains[qi] for qi in context.qi_attributes}
        ))
        codes = self._codes(train_values, training=True)
        self.release = Release(
            method=METHOD, dataset=context.dataset, seed=context.seed,
            parameters={**parameters, "bucketization_sha256": self.bucketization_sha256},
            qi_attributes=context.qi_attributes, training_row_count=context.training_row_count,
            positions=np.arange(context.training_row_count),
            columns={qi: DomainColumn.from_codes(codes[qi], self.domains[qi]) for qi in context.qi_attributes},
        )

    def _codes(self, values, *, training: bool) -> dict:
        """Bucket index per row and QI; -2 marks a value that maps to ROOT."""
        codes = {}
        for qi in self.context.qi_attributes:
            if qi in self.schema.numeric:
                observed = values[qi]
                code = np.full(len(observed), -2, dtype=np.int64)
                for index, (low, high) in enumerate(self.assign[qi]):
                    code[(observed >= low) & (observed < high)] = index
            else:
                leaves = values[qi]
                code = np.where(leaves >= 0, self.assign[qi][np.maximum(leaves, 0)], -2)
                if not training:
                    code[~np.isin(leaves, self.train_leaves[qi])] = -2
            if training and np.any(code < 0):
                raise ValueError(f"{qi}: some training values fall in no bucket.")
            codes[qi] = code
        return codes

    def evaluation_columns(self, X) -> dict:
        """Released domains of validation or test records (ROOT for unseen or unbucketed values)."""
        codes = self._codes(self.schema.values(X), training=False)
        columns = {}
        for qi, code in codes.items():
            table = list(self.domains[qi]) + [dict(ROOT)]
            columns[qi] = DomainColumn.from_codes(np.where(code == -2, len(table) - 1, code), table)
        return columns

    @property
    def point_label(self) -> str:
        return f"alpha{float(self.parameters['alpha']):g}_L{self.parameters['max_leaf_nodes']}"


def load_pat_bucketization(path, context, schema) -> PatBucketization:
    return PatBucketization(json.loads(Path(path).read_text(encoding="utf-8")), context, schema)


def _identity_check_payload(context, buckets: dict, name: str) -> dict:
    return {
        "schema_version": PAT_SCHEMA, "dataset": context.dataset, "seed": context.seed,
        "split_sha256": context.split_sha256,
        "parameters": {"alpha": None, "max_leaf_nodes": None, "identity_check": name}, "buckets": buckets,
    }


def single_bucket_payload(context, schema) -> dict:
    """One bucket per QI, PAT's tree without a split: every QI is ROOT, so min-K = N_train."""
    return _identity_check_payload(context, {
        qi: {"type": "numeric", "buckets": [[None, None]]} if qi in schema.numeric
        else {"type": "categorical", "buckets": [list(schema.leaf_values[qi])]}
        for qi in context.qi_attributes
    }, "single_bucket")


def identity_payload(context, schema) -> dict:
    """Buckets that generalize nothing.

    Every hierarchy leaf of a categorical QI is its own bucket. A numeric QI's
    leaves are cut after every training value, so each bucket lies inside one
    leaf and holds at most one training value. Training rows then keep the
    classes of their raw QIs (min-K = K0) and the reference's model input;
    validation and test records differ from it only where a categorical value
    is unseen in training (ROOT). A QI with a single hierarchy leaf can only be
    ROOT, whose XGBoost height column is the root's height in every row.
    """
    observed = schema.values(context.split.X_train_raw)
    buckets = {}
    for qi in context.qi_attributes:
        if qi not in schema.numeric:
            buckets[qi] = {"type": "categorical", "buckets": [[value] for value in schema.leaf_values[qi]]}
            continue
        values = np.unique(observed[qi][np.isfinite(observed[qi])])
        cuts = []
        for low, high in sorted(schema.leaf_values[qi]):
            cuts += [float(value) + 0.5 for value in values if low <= value < high]
            cuts.append(float(high) + 0.5)
        bounds = [None, *cuts[:-1], None]
        buckets[qi] = {"type": "numeric", "buckets": [[low, high] for low, high in zip(bounds[:-1], bounds[1:])]}
    return _identity_check_payload(context, buckets, "no_generalization")
