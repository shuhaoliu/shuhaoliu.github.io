"""EntryWise (Ganesh et al.): random per-cell suppression of QI cells.

For a kept fraction f, upstream's ``personalized_random_subsampling`` (copied
verbatim) keeps int(f * cells) randomly chosen QI cells of the training split
and suppresses the rest, with its RNG seeded by the task seed. Optionally the
privacy-score adjustment ``scale_min_reid`` (per-column count of distinct
values) or ``scale_min_recon`` (per-column summed absolute correlation), also
copied verbatim, moves suppression toward high-score columns with strength
``mult``. A suppressed cell is released as ROOT ('*'); there is no imputation
and no re-identification or reconstruction metric. Every training row is
published, non-QI features are exact, and validation and test records keep
exact values.

The kept fractions are linspace(1/d, (d-1)/d, d-1) for d QIs, unless ``fraction_count`` sets another number of points.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder

from .release import ROOT, DomainColumn, Release
from .upstream.entrywise import personalized_random_subsampling, scale_min_recon, scale_min_reid

METHOD = "EntryWise"
ADJUSTMENTS = ("none", "reid", "recon")


def fraction_grid(qi_count: int, fraction_count: int | None = None) -> np.ndarray:
    if qi_count < 2:
        raise ValueError("EntryWise needs at least two QIs.")
    count = qi_count - 1 if fraction_count is None else int(fraction_count)
    return np.linspace(1.0 / qi_count, (qi_count - 1.0) / qi_count, count)


def configurations(qi_count: int, *, adjustments=("reid", "recon"), mults=(2, 5, 10),
                   fraction_count: int | None = None) -> list[dict]:
    """Kept fractions x {no adjustment, each adjustment x each mult}, fractions outermost."""
    unknown = set(adjustments) - set(ADJUSTMENTS[1:])
    if unknown:
        raise ValueError(f"Unknown EntryWise adjustments: {sorted(unknown)}")
    fractions = fraction_grid(qi_count, fraction_count)
    configs = []
    for index, fraction in enumerate(fractions, start=1):
        common = {"fraction": float(fraction), "fraction_index": index, "fraction_count": len(fractions)}
        configs.append({**common, "adjustment": "none", "mult": None})
        for adjustment in adjustments:
            for mult in mults:
                configs.append({**common, "adjustment": adjustment, "mult": float(mult)})
    return configs


def point_label(config: dict) -> str:
    label = f"frac{config['fraction_index']:02d}of{config['fraction_count']}_{config['adjustment']}"
    return label if config["mult"] is None else f"{label}x{config['mult']:g}"


def score_matrix(X_train_raw: pd.DataFrame, qi_attributes, numeric_attributes) -> np.ndarray:
    """The training QI matrix the privacy scores read, coded as upstream's runner codes them:
    numeric QIs and numeric codes as they are, text categories label-encoded."""
    columns = []
    for qi in qi_attributes:
        column = X_train_raw[qi]
        if qi in set(numeric_attributes):
            values = pd.to_numeric(column).to_numpy(dtype=float)
        elif not pd.api.types.is_numeric_dtype(column):  # object, category or string dtype (BNG)
            values = LabelEncoder().fit_transform(column.astype(str)).astype(float)
        else:
            values = column.to_numpy(dtype=float)
        if np.isnan(values).any():
            raise ValueError(f"{qi}: the privacy scores need a QI column without missing values.")
        columns.append(values)
    return np.column_stack(columns)


def suppression_mask(scores_input: np.ndarray, *, fraction: float, adjustment: str, mult, seed: int) -> np.ndarray:
    """Boolean (rows x QIs) mask of suppressed cells."""
    # The base mask depends only on the shape, the fraction and the seed; a
    # zero matrix keeps raw missing values from being read as suppressed.
    masked, _ = personalized_random_subsampling(
        np.zeros(scores_input.shape), np.zeros(len(scores_input)), fraction, seed=seed,
    )
    base = np.isnan(masked)
    if adjustment == "none":
        return base
    if adjustment == "reid":
        return scale_min_reid(scores_input, fraction, base, mult) != 0
    if adjustment == "recon":
        return scale_min_recon(scores_input, fraction, base, mult) != 0
    raise ValueError(f"Unknown EntryWise adjustment {adjustment!r}.")


def entrywise_release(context, scores_input: np.ndarray, config: dict) -> Release:
    mask = suppression_mask(
        scores_input, fraction=config["fraction"], adjustment=config["adjustment"],
        mult=config["mult"], seed=context.seed,
    )
    return Release(
        method=METHOD, dataset=context.dataset, seed=context.seed,
        parameters={
            "fraction": config["fraction"], "adjustment": config["adjustment"], "mult": config["mult"],
            "mask_seed": int(context.seed), "cells": "qi_cells_of_training_split",
        },
        qi_attributes=context.qi_attributes, training_row_count=context.training_row_count,
        positions=np.arange(context.training_row_count),
        columns={qi: DomainColumn.from_mask(mask[:, index], ROOT) for index, qi in enumerate(context.qi_attributes)},
    )
