"""Baseline releases in TRIM's output space, and their storage.

A release publishes a subset of the training rows. For every published row and
every QI it releases one domain:

- exact: the row's own value (column code -1);
- ROOT, written '*' (``{"kind": "root"}``): a removed column or a suppressed
  cell;
- a set of hierarchy leaves: a hierarchy node ``{"kind": "node", "node": id}``,
  a categorical leaf set ``{"kind": "leaves", "values": [...]}`` that need not
  be a node (a PAT bucket), or a numeric half-open interval
  ``{"kind": "interval", "low": a, "high": b}`` meaning [a, b), where null is
  unbounded (a PAT bucket).

Non-QI features are always released unchanged and are not stored. A stored
release refers to exact values through the training row IDs of its split file;
the hashes in its identity pin the data, split and code it was built from.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime, timezone
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
from typing import Any, Mapping, Sequence

import numpy as np
import pandas as pd

RELEASE_SCHEMA = "exp1_baseline_release.v1"
SPLIT_SCHEMA = "exp1_baseline_split.v1"
ROOT = {"kind": "root"}
ROOT_LABEL = "*"


def utc_now() -> str:
    """ISO 8601 timestamp in UTC with its offset."""
    return datetime.now(timezone.utc).isoformat()


def canonical_json(payload: Any) -> str:
    return json.dumps(payload, sort_keys=True, separators=(",", ":"))


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def json_scalar(value):
    """A leaf value or bound as a plain JSON scalar (integral floats become ints)."""
    if isinstance(value, (bool, np.bool_)):
        raise ValueError("Boolean domain values are not supported.")
    if isinstance(value, np.integer):
        return int(value)
    if isinstance(value, (float, np.floating)):
        value = float(value)
        if not math.isfinite(value):
            raise ValueError("Domain values must be finite; use null for an unbounded side.")
        return int(value) if value.is_integer() else value
    if isinstance(value, (int, str)):
        return value
    raise ValueError(f"Unsupported domain value {value!r}.")


def canonical_domain(domain: Mapping) -> dict:
    """Validate a non-exact released domain and return its canonical form."""
    if not isinstance(domain, Mapping):
        raise ValueError(f"A released domain must be a mapping: {domain!r}")
    kind, keys = domain.get("kind"), set(domain)
    if kind == "root" and keys == {"kind"}:
        return dict(ROOT)
    if kind == "node" and keys == {"kind", "node"} and isinstance(domain["node"], str) and domain["node"]:
        return {"kind": "node", "node": domain["node"]}
    if kind == "leaves" and keys == {"kind", "values"} and not isinstance(domain["values"], (str, bytes)):
        values = {}
        for value in domain["values"]:
            value = json_scalar(value)
            values[canonical_json(value)] = value
        if not values:
            raise ValueError("A leaf-set domain needs at least one leaf value.")
        return {"kind": "leaves", "values": [values[key] for key in sorted(values)]}
    if kind == "interval" and keys == {"kind", "low", "high"}:
        bounds = []
        for side in ("low", "high"):
            value = domain[side]
            if value is not None:
                value = json_scalar(value)
                if isinstance(value, str):
                    raise ValueError("Interval bounds must be numbers or null.")
            bounds.append(value)
        low, high = bounds
        if low is None and high is None:
            return dict(ROOT)
        if low is not None and high is not None and not low < high:
            raise ValueError(f"Empty interval [{low}, {high}).")
        return {"kind": "interval", "low": low, "high": high}
    raise ValueError(f"Invalid released domain: {domain!r}")


def domain_key(domain: Mapping) -> str:
    return canonical_json(canonical_domain(domain))


def domain_label(domain: Mapping) -> str:
    """Readable released value: '*', a node ID, '{a|b}' or '[a, b)'."""
    domain = canonical_domain(domain)
    if domain["kind"] == "root":
        return ROOT_LABEL
    if domain["kind"] == "node":
        return domain["node"]
    if domain["kind"] == "leaves":
        return "{" + "|".join(str(value) for value in domain["values"]) + "}"
    low = "-inf" if domain["low"] is None else str(domain["low"])
    high = "inf" if domain["high"] is None else str(domain["high"])
    return f"[{low}, {high})"


def _b64(array: np.ndarray) -> str:
    return base64.b64encode(np.ascontiguousarray(array).tobytes()).decode("ascii")


@dataclass(frozen=True)
class DomainColumn:
    """Released domains of one QI for a sequence of rows.

    ``codes[i] == -1`` releases row i's exact value; ``codes[i] == j >= 0``
    releases ``table[j]``. Table entries are canonical, distinct and used.
    """

    codes: np.ndarray
    table: tuple

    def __post_init__(self):
        codes = np.asarray(self.codes)
        if codes.ndim != 1 or not np.issubdtype(codes.dtype, np.integer):
            raise ValueError("Domain codes must be a one-dimensional integer array.")
        if len(codes) and (codes.min() < -1 or codes.max() >= len(self.table)):
            raise ValueError("Domain codes must be -1 or index the domain table.")
        keys = [domain_key(domain) for domain in self.table]
        if len(set(keys)) != len(keys):
            raise ValueError("Domain table entries must be distinct.")
        if any(canonical_domain(domain) != domain for domain in self.table):
            raise ValueError("Domain table entries must be canonical.")
        if len(self.table) and len(np.unique(codes[codes >= 0])) != len(self.table):
            raise ValueError("Every domain table entry must be used.")
        object.__setattr__(self, "codes", codes.astype(np.int32, copy=False))

    @classmethod
    def exact(cls, length: int) -> "DomainColumn":
        return cls(np.full(int(length), -1, dtype=np.int32), ())

    @classmethod
    def constant(cls, length: int, domain: Mapping) -> "DomainColumn":
        if not length:
            return cls.exact(0)
        return cls(np.zeros(int(length), dtype=np.int32), (canonical_domain(domain),))

    @classmethod
    def from_mask(cls, mask, domain: Mapping) -> "DomainColumn":
        """Release ``domain`` where ``mask`` is true and exact values elsewhere."""
        mask = np.asarray(mask, dtype=bool)
        if not mask.any():
            return cls.exact(len(mask))
        return cls(np.where(mask, 0, -1).astype(np.int32), (canonical_domain(domain),))

    @classmethod
    def from_codes(cls, codes, table: Sequence[Mapping]) -> "DomainColumn":
        """Canonicalize the table, merge equal domains and drop unused ones."""
        codes = np.asarray(codes, dtype=np.int64)
        if codes.ndim != 1 or (len(codes) and (codes.min() < -1 or codes.max() >= len(table))):
            raise ValueError("Domain codes must be -1 or index the domain table.")
        canonical = [canonical_domain(domain) for domain in table]
        order, remap = {}, np.full(len(canonical) + 1, -1, dtype=np.int64)
        used = np.zeros(len(canonical), dtype=bool)
        used[np.unique(codes[codes >= 0])] = True
        for position, domain in enumerate(canonical):
            if used[position]:
                remap[position] = order.setdefault(canonical_json(domain), len(order))
        merged = {key: json.loads(key) for key in order}
        new_codes = np.where(codes >= 0, remap[np.maximum(codes, 0)], -1)
        return cls(new_codes.astype(np.int32), tuple(merged[key] for key in order))

    def __len__(self) -> int:
        return len(self.codes)

    @property
    def generalized_count(self) -> int:
        return int(np.count_nonzero(self.codes >= 0))

    @property
    def root_count(self) -> int:
        roots = [position for position, domain in enumerate(self.table) if domain["kind"] == "root"]
        return int(np.count_nonzero(np.isin(self.codes, roots))) if roots else 0

    def take(self, positions) -> "DomainColumn":
        return DomainColumn.from_codes(self.codes[np.asarray(positions, dtype=np.int64)], self.table)

    def equals(self, other: "DomainColumn") -> bool:
        return self.table == other.table and np.array_equal(self.codes, other.codes)

    def to_payload(self) -> dict:
        """Compact JSON form: exact, constant, a bit mask, or packed codes."""
        if not self.table:
            return {"kind": "exact"}
        if len(self.table) == 1 and bool(np.all(self.codes == 0)):
            return {"kind": "constant", "domain": self.table[0]}
        if len(self.table) == 1:
            return {
                "kind": "mask", "domain": self.table[0],
                "bits": _b64(np.packbits(self.codes == 0, bitorder="little")),
            }
        dtype = "<i1" if len(self.table) < 127 else "<i2" if len(self.table) < 32767 else "<i4"
        return {
            "kind": "codes", "table": list(self.table), "dtype": dtype,
            "data": _b64(self.codes.astype(dtype)),
        }

    @classmethod
    def from_payload(cls, payload: Mapping, length: int) -> "DomainColumn":
        kind = payload.get("kind")
        if kind == "exact":
            return cls.exact(length)
        if kind == "constant":
            return cls.constant(length, payload["domain"])
        if kind == "mask":
            bits = np.frombuffer(base64.b64decode(payload["bits"]), dtype=np.uint8)
            mask = np.unpackbits(bits, count=length, bitorder="little").astype(bool)
            return cls.from_mask(mask, payload["domain"])
        if kind == "codes":
            codes = np.frombuffer(base64.b64decode(payload["data"]), dtype=np.dtype(payload["dtype"]))
            if len(codes) != length:
                raise ValueError("Stored domain codes have the wrong length.")
            return cls(codes.astype(np.int32), tuple(payload["table"]))
        raise ValueError(f"Unknown stored domain column kind {kind!r}.")


@dataclass
class Release:
    """Published training rows and their released QI domains.

    ``positions`` are sorted positions into the training split, so published
    rows always keep the training-split order (a release of every row then
    has exactly the reference model's input). ``parameters`` hold the
    method's release-defining parameters.
    """

    method: str
    dataset: str
    seed: int
    parameters: dict
    qi_attributes: tuple
    training_row_count: int
    positions: np.ndarray
    columns: dict

    def __post_init__(self):
        self.qi_attributes = tuple(self.qi_attributes)
        positions = np.asarray(self.positions, dtype=np.int64)
        if positions.ndim != 1 or not len(positions):
            raise ValueError("A release must publish at least one training row.")
        if np.any(np.diff(positions) <= 0) or positions[0] < 0 or positions[-1] >= self.training_row_count:
            raise ValueError("Published positions must be sorted, unique training positions.")
        self.positions = positions
        if set(self.columns) != set(self.qi_attributes):
            raise ValueError("A release needs one domain column per QI.")
        if any(len(column) != len(positions) for column in self.columns.values()):
            raise ValueError("Domain columns must align with the published rows.")
        json.dumps(self.parameters)

    @property
    def row_count(self) -> int:
        return len(self.positions)

    @property
    def publishes_all_rows(self) -> bool:
        return self.row_count == self.training_row_count

    def cell_counts(self) -> dict:
        generalized = {qi: self.columns[qi].generalized_count for qi in self.qi_attributes}
        roots = {qi: self.columns[qi].root_count for qi in self.qi_attributes}
        cells = self.row_count * len(self.qi_attributes)
        return {
            "generalized_cell_count": sum(generalized.values()),
            "root_cell_count": sum(roots.values()),
            "generalized_cell_fraction": sum(generalized.values()) / cells if cells else 0.0,
            "generalized_cells_by_qi": generalized,
            "root_cells_by_qi": roots,
        }

    def equals(self, other: "Release") -> bool:
        return (
            (self.method, self.dataset, self.seed, self.qi_attributes, self.training_row_count)
            == (other.method, other.dataset, other.seed, other.qi_attributes, other.training_row_count)
            and canonical_json(self.parameters) == canonical_json(other.parameters)
            and np.array_equal(self.positions, other.positions)
            and all(self.columns[qi].equals(other.columns[qi]) for qi in self.qi_attributes)
        )


def content_sha256(release: Release, validation_columns=None, test_columns=None) -> str:
    """Hash of what a target model sees: published rows, released domains and evaluation domains.

    Two releases with equal content train and score identically, whatever
    parameters produced them (exact evaluation columns may be given or omitted).
    """
    digest = hashlib.sha256()
    digest.update(np.asarray(release.positions, dtype="<i8").tobytes())

    def add(name, columns, qis, skip_exact):
        for qi in qis:
            column = (columns or {}).get(qi)
            if column is None or (skip_exact and not column.table):
                continue
            digest.update(canonical_json([name, qi, list(column.table), len(column)]).encode("utf-8"))
            digest.update(column.codes.astype("<i4").tobytes())

    add("train", release.columns, release.qi_attributes, False)
    add("validation", validation_columns, sorted(validation_columns or {}), True)
    add("test", test_columns, sorted(test_columns or {}), True)
    return digest.hexdigest()


def release_identity(release: Release, hashes: Mapping[str, str]) -> dict:
    """What determines a release: method, parameters, data, split and code."""
    return {
        "schema_version": RELEASE_SCHEMA, "method": release.method, "dataset": release.dataset,
        "seed": release.seed, "parameters": release.parameters,
        "qi_attributes": list(release.qi_attributes), **dict(hashes),
    }


def release_key(identity: Mapping) -> str:
    return sha256_text(canonical_json(identity))


def release_payload(release: Release, identity: Mapping, train_ids: Sequence) -> dict:
    if len(train_ids) != release.training_row_count:
        raise ValueError("Training IDs do not match the release's training split.")
    if release.publishes_all_rows:
        published = {"kind": "all"}
    else:
        published = {"kind": "row_ids", "row_ids": [train_ids[int(position)] for position in release.positions]}
    return {
        "schema_version": RELEASE_SCHEMA, "release_key": release_key(identity), "identity": dict(identity),
        "method": release.method, "dataset": release.dataset, "seed": release.seed,
        "parameters": release.parameters, "qi_attributes": list(release.qi_attributes),
        "training_row_count": release.training_row_count, "published_row_count": release.row_count,
        "published": published,
        "columns": {qi: release.columns[qi].to_payload() for qi in release.qi_attributes},
        "summary": release.cell_counts(), "created_at": utc_now(),
    }


def write_json_gz(path: str | Path, payload: Any) -> str:
    """Write gzip-compressed JSON atomically; return the file's SHA-256."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.partial")
    with open(temporary, "wb") as raw, gzip.GzipFile(fileobj=raw, mode="wb", mtime=0, compresslevel=6) as handle:
        handle.write((canonical_json(payload) + "\n").encode("utf-8"))
    temporary.replace(path)
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json_atomic(path: str | Path, payload: Any) -> None:
    """Write indented JSON through a temporary file, so concurrent readers never see half a file."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.partial")
    temporary.write_text(json.dumps(payload, indent=2, sort_keys=True, default=str) + "\n", encoding="utf-8")
    temporary.replace(path)


def read_json_gz(path: str | Path) -> Any:
    with gzip.open(Path(path), "rt", encoding="utf-8") as handle:
        return json.load(handle)


def release_from_payload(payload: Mapping, train_ids: Sequence) -> Release:
    """Rebuild a release; ``train_ids`` are the split file's training row IDs."""
    if payload.get("schema_version") != RELEASE_SCHEMA:
        raise ValueError("Unsupported baseline release schema.")
    if len(train_ids) != payload["training_row_count"]:
        raise ValueError("The split's training rows differ from the release's training split.")
    if payload["published"]["kind"] == "all":
        positions = np.arange(len(train_ids), dtype=np.int64)
    else:
        lookup = pd.Index(train_ids)
        positions = lookup.get_indexer(payload["published"]["row_ids"])
        if np.any(positions < 0):
            raise ValueError("The release publishes rows outside the training split.")
    release = Release(
        method=payload["method"], dataset=payload["dataset"], seed=int(payload["seed"]),
        parameters=payload["parameters"], qi_attributes=tuple(payload["qi_attributes"]),
        training_row_count=int(payload["training_row_count"]), positions=positions,
        columns={
            qi: DomainColumn.from_payload(payload["columns"][qi], len(positions))
            for qi in payload["qi_attributes"]
        },
    )
    if release_key(payload["identity"]) != payload["release_key"]:
        raise ValueError("Stored release key does not match its identity.")
    return release


def load_release(release_path: str | Path, split_path: str | Path) -> tuple[Release, dict, dict]:
    """Load a stored release with its split file: (release, release payload, split payload)."""
    payload = read_json_gz(release_path)
    split = read_json_gz(split_path)
    if split.get("schema_version") != SPLIT_SCHEMA:
        raise ValueError("Unsupported split file schema.")
    identity = payload["identity"]
    if identity.get("split_sha256") != split["split_sha256"] or (payload["dataset"], payload["seed"]) != (
        split["dataset"], split["seed"],
    ):
        raise ValueError("The release was built on a different split.")
    return release_from_payload(payload, split["train_row_ids"]), payload, split


def released_qi_frame(release: Release, X_train_raw: pd.DataFrame) -> pd.DataFrame:
    """Released QI values of the published rows: raw exact values, or domain labels."""
    published = X_train_raw.iloc[release.positions]
    output = {}
    for qi in release.qi_attributes:
        column = release.columns[qi]
        values = published[qi].astype(object).to_numpy(copy=True)
        labels = np.asarray([domain_label(domain) for domain in column.table], dtype=object)
        generalized = column.codes >= 0
        values[generalized] = labels[column.codes[generalized]]
        output[qi] = values
    return pd.DataFrame(output, index=published.index)


def split_hash(train_ids: Sequence, validation_ids: Sequence, test_ids: Sequence) -> str:
    return sha256_text(canonical_json({
        "train": list(train_ids), "validation": list(validation_ids), "test": list(test_ids),
    }))
