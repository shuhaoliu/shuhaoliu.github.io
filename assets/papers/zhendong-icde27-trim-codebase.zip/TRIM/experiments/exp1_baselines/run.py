"""Run the data-minimization baselines (FIDO, FeatSel, EntryWise, PAT) for one dataset and seed.

    python -m experiments.exp1_baselines.run \
      --config configs/paper/fig4/baselines.yaml \
      --dataset bm_halfmonth --seed 42 --model mlp --model xgboost \
      --method fido --method featsel --method entrywise \
      --device cuda:0 [--results-dir <results directory>] [--resume]

The results directory defaults to the configuration's ``results_root``.

Every method's releases are generated once and shared by the target models;
each release is stored in full under ``releases/``. Evaluations are appended
to ``evaluations/<dataset>_seed<seed>_<method>.jsonl`` as they finish, so an
interrupted run continues with ``--resume``. See the package README for the
output layout and schema.
"""

from __future__ import annotations

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np

from experiments.common import load_yaml_mapping, resolve_project_path
from experiments.exp1_kanon.hierarchy import HierarchySchema
from experiments.run_matrix_sweep import expand_matrix
from prototype.dataset_registry import resolve_dataset

from . import entrywise, featsel, fido, pat
from .evaluator import SPLIT_KEYS, ModelEvaluator, build_context
from .privacy import release_privacy
from .release import (
    ROOT, DomainColumn, canonical_json, content_sha256, read_json_gz, release_from_payload, release_identity,
    release_key, release_payload, utc_now, write_json_atomic, write_json_gz,
)
from .results import EvaluationStore, ItemLock, write_tables
from .upstream import verify_upstream_copies

METHODS = {"fido": fido.METHOD, "featsel": featsel.METHOD, "entrywise": entrywise.METHOD, "pat": pat.METHOD}
ENCODING = "shared_leaf_space_with_level_or_shared_mlp_means"
LOSS_KEYS = ("validation_loss", "validation_delta_u", "baseline_validation_loss",
             "test_loss", "test_delta_u", "baseline_test_loss")
CONVENTIONS = {
    "FIDO": "prefix of the seed's random order; validation and test exact",
    "FeatSel": "removed QIs are ROOT for training, validation and test",
    "EntryWise": "suppressed training QI cells are ROOT; validation and test exact",
    "PAT": "same buckets for validation and test; unseen categories and unbucketed values are ROOT",
}


def implementation_sha256() -> str:
    """Hash of the code that builds, encodes and scores the releases."""
    from prototype import (
        backend_training, dataloader, dataset_registry, gpu_math, gpu_mlp, gpu_xgboost, model_factory,
        privacy_metrics, release_artifacts,
    )
    from experiments.exp1_kanon import hierarchy

    package = Path(__file__).resolve().parent
    files = sorted(path for path in package.rglob("*.py") if "__pycache__" not in path.parts)
    files += [Path(module.__file__) for module in (
        hierarchy, backend_training, dataloader, dataset_registry, gpu_math, gpu_mlp, gpu_xgboost,
        model_factory, privacy_metrics, release_artifacts,
    )]
    digest = hashlib.sha256()
    root = package.parents[1]
    for path in files:
        digest.update(str(path.resolve().relative_to(root)).encode("utf-8"))
        digest.update(path.read_bytes())
    return digest.hexdigest()


def _model_name(task) -> str:
    return task.get("model_name", task["model"]["downstream"]["family"])


def _device_name(device: str) -> str:
    import torch

    if str(device).startswith("cuda") and torch.cuda.is_available():
        return torch.cuda.get_device_name(torch.device(device))
    return "cpu"


class BaselineRun:
    """One runner invocation: a dataset, a seed, target models and methods."""

    def __init__(self, args, config, tasks_by_model, results_dir: Path):
        self.args, self.config, self.results_dir = args, config, results_dir
        self.tasks_by_model = tasks_by_model
        self.models = list(tasks_by_model)
        self.code_hash = implementation_sha256()
        first = next(iter(tasks_by_model.values()))
        self.context = build_context(first, data_root=args.data_root)
        self.dataset, self.seed = self.context.dataset, self.context.seed
        self.train_id_list = self.context.train_ids.tolist()
        self.manifest = {
            "schema_version": "exp1_baselines_run.v1", "status": "running", "started_at": utc_now(),
            "dataset": self.dataset, "seed": self.seed, "models": self.models,
            "methods": args.method, "argv": sys.argv, "configuration": config,
            "implementation_sha256": self.code_hash, "upstream_sha256": verify_upstream_copies(),
            "tasks": tasks_by_model, "train_size": self.context.training_row_count,
            "split_sha256": self.context.split_sha256, "loaded_input_sha256": self.context.loaded_input_sha256,
            "training_data_sha256": self.context.training_data_sha256, "tree_sha256": self.context.tree_sha256,
            "tree_path": str(self.context.tree_path), "original": self.context.original,
            "references": {}, "identity_checks": {}, "methods_summary": {},
            "privacy_counter": "B_identical_released_tuples", "encoding": ENCODING,
            "release_limit": args.release_limit,
        }
        self.manifest_path = results_dir / "manifests" / (
            f"{self.dataset}_seed{self.seed}_{'-'.join(args.method)}_"
            f"{self.manifest['started_at'][:19].replace(':', '').replace('-', '')}Z.json"
        )

    # Shared artifacts ----------------------------------------------------------------
    def write_split(self) -> None:
        path = self.results_dir / "splits" / f"{self.dataset}_seed{self.seed}.json.gz"
        payload = self.context.split_payload()
        if path.exists():
            stored = read_json_gz(path)
            for key in ("split_sha256", "training_data_sha256", "loaded_input_sha256", "train_row_ids"):
                if stored[key] != payload[key]:
                    raise ValueError(f"{path} records another split ({key} differs).")
        else:
            write_json_gz(path, payload)
        self.manifest["split_path"] = str(path.relative_to(self.results_dir))

    def build_evaluators(self) -> None:
        self.evaluators, self.protocols, self.device_names = {}, {}, {}
        for model, task in self.tasks_by_model.items():
            device = self.args.device or task.get("device", "cuda")
            evaluator = ModelEvaluator(
                self.context, model_name=model, model_spec=task["model"]["downstream"], device=device,
                dtype=task.get("dtype", "float32"), allow_cpu_fallback=bool(task.get("allow_cpu_fallback", False)),
            )
            self.evaluators[model] = evaluator
            self.device_names[model] = _device_name(device)
            split_config = dict(task.get("pipeline") or {})
            protocol = {
                "dataset": self.dataset, "seed": self.seed, "model": evaluator.model_spec, "device": device,
                "dtype": evaluator.dtype, "allow_cpu_fallback": evaluator.allow_cpu_fallback,
                "split": {key: split_config.get(key, default) for key, default in SPLIT_KEYS},
                "loaded_input_sha256": self.context.loaded_input_sha256, "tree_sha256": self.context.tree_sha256,
                "encoding": ENCODING, "privacy_counter": "B_identical_released_tuples",
                "tail_population": "training_split",
            }
            self.protocols[model] = hashlib.sha256(canonical_json(protocol).encode()).hexdigest()
            record = {**evaluator.reference_record(), "device_name": self.device_names[model],
                      "protocol_sha256": self.protocols[model], "implementation_sha256": self.code_hash,
                      "split_sha256": self.context.split_sha256, "recorded_at": utc_now()}
            path = self.results_dir / "references" / f"{self.dataset}_seed{self.seed}_{model}.json"
            if path.exists():
                stored = json.loads(path.read_text(encoding="utf-8"))
                record["previous_record_difference"] = max(
                    abs(stored[split] - record[split]) for split in ("validation", "test")
                )
            write_json_atomic(path, record)
            self.manifest["references"][model] = {
                key: record[key] for key in ("validation", "test", "reference_seconds", "device_name")
                if key in record
            } | {"previous_record_difference": record.get("previous_record_difference")}
            print(f"{self.dataset} seed {self.seed} {model}: reference validation={record['validation']!r} "
                  f"test={record['test']!r} ({record['reference_seconds']:.1f} s on {self.device_names[model]})",
                  flush=True)

    def persist(self, release) -> dict:
        """Store a release (or check the stored copy) and return its file reference."""
        started = time.perf_counter()
        identity = release_identity(release, self.context.hashes(self.code_hash))
        key = release_key(identity)
        relative = Path("releases") / self.dataset / f"seed{self.seed}" / release.method.lower() / f"{key}.json.gz"
        path = self.results_dir / relative
        if path.exists():
            payload = read_json_gz(path)
            if canonical_json(payload["identity"]) != canonical_json(identity) or not release_from_payload(
                payload, self.train_id_list,
            ).equals(release):
                raise ValueError(f"Stored release {path} differs from the regenerated release.")
            digest, reused = hashlib.sha256(path.read_bytes()).hexdigest(), True
        else:
            digest, reused = write_json_gz(path, release_payload(release, identity, self.train_id_list)), False
        return {
            "release_key": key, "release_path": str(relative), "release_sha256": digest,
            "release_reused": reused, "release_store_seconds": time.perf_counter() - started,
        }

    def privacy(self, release) -> tuple[dict, float]:
        started = time.perf_counter()
        metrics = release_privacy(release, self.context.train_ids, self.context.raw_codes, self.context.original)
        return metrics, time.perf_counter() - started

    def base_row(self, method: str, model: str, point: str, record_type: str) -> dict:
        return {
            "record_type": record_type, "experiment": "exp1_privacy_utility", "method": method,
            "dataset": self.dataset, "model": model, "seed": self.seed, "point": point,
            "evaluation_split": "test", "implementation_sha256": self.code_hash,
            "protocol_sha256": self.protocols[model], "split_sha256": self.context.split_sha256,
            "device": self.evaluators[model].device, "device_name": self.device_names[model],
        }

    # Generic release loop ------------------------------------------------------------
    def evaluate_specs(self, store, method: str, variant: str, specs) -> None:
        """Evaluate releases shared by every model; ``specs`` yields (point, builder, fields)."""
        # Freshly evaluated points by (model, content hash), for releases that repeat.
        evaluated = {
            (record["model"], record["release_content_sha256"]): record for record in store.points()
            if record["method"] == method and record.get("release_content_sha256")
            and not record.get("evaluation_reused_from")
        }
        for point, build, fields in specs:
            pending = [model for model in self.models
                       if store.get(("point", method, self.dataset, self.seed, model, point)) is None]
            if not pending:
                continue
            started = time.perf_counter()
            release, validation_columns, test_columns = build()
            release_seconds = time.perf_counter() - started
            stored = self.persist(release)
            privacy, privacy_seconds = self.privacy(release)
            counts = release.cell_counts()
            content = content_sha256(release, validation_columns, test_columns)
            # "_parameters" adds point-level settings (such as the search) to the release parameters.
            parameters = {**release.parameters, **fields.get("_parameters", {})}
            readable = {key: value for key, value in fields.items() if key != "_parameters"}
            for model in pending:
                started_at = utc_now()
                source = evaluated.get((model, content))
                if source is None:
                    result, reused_from = self.evaluators[model].evaluate(release, validation_columns, test_columns), None
                else:
                    # Training and scoring are deterministic, so an identical release gives identical losses.
                    result = {**{key: source[key] for key in LOSS_KEYS}, "encode_seconds": 0.0, "fit_seconds": 0.0,
                              "model_evaluation_seconds": 0.0}
                    reused_from = source["point"]
                row = {
                    **self.base_row(method, model, point, "point"), "variant": variant, **result,
                    **privacy, **{key: counts[key] for key in (
                        "generalized_cell_count", "root_cell_count", "generalized_cell_fraction")},
                    "method_parameters": parameters, **readable, **stored,
                    "release_content_sha256": content, "evaluation_reused_from": reused_from,
                    "release_seconds": release_seconds, "privacy_seconds": privacy_seconds,
                    "started_at": started_at, "finished_at": utc_now(),
                }
                store.append(row)
                if source is None:
                    evaluated[(model, content)] = row
                self._report(row)

    def _report(self, row) -> None:
        print(
            f"{row['method']} {self.dataset} seed {self.seed} {row['model']} {row['point']}: "
            f"validation_delta={row['validation_delta_u']:.6g} test_delta={row['test_delta_u']:.6g} "
            f"min_k={row['min_k']} tail={row['tail_risk_p99']:.4g} rows={row['row_count']} "
            f"fit={row['fit_seconds']:.2f}s total={row['model_evaluation_seconds']:.2f}s"
            + (f" (reused {row['evaluation_reused_from']})" if row.get("evaluation_reused_from") else ""),
            flush=True,
        )

    def limited(self, items: list) -> list:
        return items[: self.args.release_limit] if self.args.release_limit else items

    # Methods -------------------------------------------------------------------------
    def run_featsel(self, store) -> None:
        search = dict((self.config.get("featsel") or {}).get("search", {}).get(self.dataset) or {})
        if search.get("mode") not in {"all", "bounded"}:
            raise ValueError(f"No FeatSel search is configured for {self.dataset}.")
        kept_sets = self.limited(featsel.enumerate_kept_sets(
            self.context.qi_attributes, mode=search["mode"], m=search.get("m"),
        ))
        variant = "all_subsets" if search["mode"] == "all" else f"bounded_m{search['m']}"
        qis = self.context.qi_attributes
        val_rows, test_rows = len(self.context.split.X_val_raw), len(self.context.split.X_test_raw)

        def specs():
            for kept in kept_sets:
                removed = [qi for qi in qis if qi not in kept]

                def build(kept=kept, removed=removed):
                    release = featsel.featsel_release(self.context, kept)
                    return (release,
                            {qi: DomainColumn.constant(val_rows, ROOT) for qi in removed},
                            {qi: DomainColumn.constant(test_rows, ROOT) for qi in removed})

                yield featsel.point_label(qis, kept), build, {
                    "featsel_search": search, "featsel_kept_count": len(kept),
                    "featsel_kept_qis": ";".join(kept), "featsel_removed_qis": ";".join(removed),
                    "_parameters": {"search": search},
                }

        self.evaluate_specs(store, featsel.METHOD, variant, specs())
        self._featsel_identity(store)

    def _featsel_identity(self, store) -> None:
        point = featsel.point_label(self.context.qi_attributes, self.context.qi_attributes)
        checks = {}
        for model in self.models:
            row = store.get(("point", featsel.METHOD, self.dataset, self.seed, model, point))
            if row is not None:
                checks[model] = {
                    "point": point, "validation_delta_u": row["validation_delta_u"],
                    "test_delta_u": row["test_delta_u"], "min_k": row["min_k"],
                    "original_leak_k": row["original_leak_k"],
                    "passed": row["validation_delta_u"] == 0.0 and row["test_delta_u"] == 0.0
                    and row["min_k"] == row["original_leak_k"],
                }
        self.manifest["identity_checks"][featsel.METHOD] = checks

    def run_entrywise(self, store) -> None:
        settings = self.config.get("entrywise") or {}
        qis = self.context.qi_attributes
        configs = self.limited(entrywise.configurations(
            len(qis), adjustments=tuple(settings.get("adjustments", ("reid", "recon"))),
            mults=tuple(settings.get("mults", (2, 5, 10))), fraction_count=settings.get("fraction_count"),
        ))
        scores_input = None

        def specs():
            for config in configs:
                def build(config=config):
                    nonlocal scores_input
                    if scores_input is None:
                        scores_input = entrywise.score_matrix(
                            self.context.split.X_train_raw, qis, self.context.loader.numeric_attributes,
                        )
                    return entrywise.entrywise_release(self.context, scores_input, config), None, None

                yield entrywise.point_label(config), build, {
                    "entrywise_fraction": config["fraction"], "entrywise_fraction_index": config["fraction_index"],
                    "entrywise_adjustment": config["adjustment"], "entrywise_mult": config["mult"],
                    "_parameters": {"fraction_count": config["fraction_count"]},
                }

        self.evaluate_specs(store, entrywise.METHOD, "personalized_random_subsampling", specs())

    def run_pat(self, store) -> None:
        if not self.args.pat_dir:
            raise ValueError("--pat-dir is required for PAT.")
        schema = HierarchySchema(self.context.generalization)
        files = []
        for path in sorted(Path(self.args.pat_dir).glob("*.json")):
            payload = json.loads(path.read_text(encoding="utf-8"))
            if (payload.get("dataset"), int(payload.get("seed", -1))) == (self.dataset, self.seed):
                files.append(path)
        if not files:
            raise ValueError(f"No PAT bucketization for {self.dataset} seed {self.seed} in {self.args.pat_dir}.")

        def specs():
            for path in self.limited(files):
                bucketization = pat.load_pat_bucketization(path, self.context, schema)
                yield bucketization.point_label, lambda b=bucketization: (
                    b.release, b.evaluation_columns(self.context.split.X_val_raw),
                    b.evaluation_columns(self.context.split.X_test_raw),
                ), {
                    "pat_alpha": bucketization.parameters["alpha"],
                    "pat_max_leaf_nodes": bucketization.parameters["max_leaf_nodes"],
                    "pat_bucketization_sha256": bucketization.bucketization_sha256,
                    "pat_bucket_counts": ";".join(
                        f"{qi}:{len(bucketization.domains[qi])}" for qi in self.context.qi_attributes
                    ),
                    "_parameters": {"source_file": path.name},
                }

        self.evaluate_specs(store, pat.METHOD, "tree_minimizer", specs())
        self._pat_identity(store, schema)

    def _pat_identity(self, store, schema) -> None:
        """PAT's identity points: one bucket per QI, and buckets that generalize nothing.

        ``single_bucket``: every QI is ROOT, so min-K is the training size; also
        checked on every grid point that releases every QI as ROOT.
        ``no_generalization`` (``pat.identity_payload``): min-K is K0; the
        training input equals the reference input; validation and test inputs
        differ only in rows with a categorical value unseen in training; a fit
        on it gives Delta U 0 when no such row exists (and is reported
        otherwise). Inputs are compared without the XGBoost height columns of
        QIs that have a single hierarchy leaf (always ROOT, a constant column).
        """
        context, n = self.context, self.context.training_row_count
        qis = context.qi_attributes
        single = pat.PatBucketization(pat.single_bucket_payload(context, schema), context, schema)
        single_min_k = self.privacy(single.release)[0]["min_k"]
        collapsed = [row for row in store.points()
                     if row["method"] == pat.METHOD and row["root_cell_count"] == n * len(qis)]
        checks = {"single_bucket": {
            "min_k": single_min_k, "training_row_count": n,
            "grid_points": sorted({row["point"] for row in collapsed}),
            "grid_point_min_k": sorted({row["min_k"] for row in collapsed}),
            "passed": single_min_k == n and all(row["min_k"] == n for row in collapsed),
        }}
        identity = pat.PatBucketization(pat.identity_payload(context, schema), context, schema)
        identity_min_k = self.privacy(identity.release)[0]["min_k"]
        columns = {"validation": identity.evaluation_columns(context.split.X_val_raw),
                   "test": identity.evaluation_columns(context.split.X_test_raw)}
        unseen = {}
        for split, split_columns in columns.items():
            rows = np.zeros(len(split_columns[qis[0]]), dtype=bool)
            for qi in qis:
                if qi in schema.numeric or len(schema.leaves[qi]) == 1:
                    continue
                roots = [code for code, domain in enumerate(split_columns[qi].table) if domain == ROOT]
                rows |= np.isin(split_columns[qi].codes, roots)
            unseen[split] = rows
        no_generalization = {"min_k": identity_min_k, "original_leak_k": context.original["original_leak_k"],
                             "unseen_category_rows": {split: int(rows.sum()) for split, rows in unseen.items()},
                             "models": {}}
        passed = identity_min_k == context.original["original_leak_k"]
        for model, evaluator in self.evaluators.items():
            keep = np.ones(evaluator.level0["train"].shape[1], dtype=bool)
            if evaluator.family == "xgboost":
                for qi in qis:
                    if len(schema.leaves[qi]) == 1:
                        block = evaluator.encoder.blocks[qi]
                        keep[block["start"] + block["width"] - 1] = False
            reference = evaluator.level0["train"]
            train = evaluator.encoder.apply(reference, identity.release.columns)
            train[:, ~keep] = reference[:, ~keep]
            record = {"train_input_equal": bool(np.array_equal(train, reference))}
            del train
            for split in ("validation", "test"):
                reference = evaluator.level0[split]
                encoded = evaluator.encoder.apply(reference, columns[split])
                encoded[:, ~keep] = reference[:, ~keep]
                differs = np.any(encoded != reference, axis=1)
                record[f"{split}_rows_differing"] = int(differs.sum())
                record[f"{split}_differing_rows_unseen"] = bool(np.all(unseen[split][differs]))
            result = evaluator.evaluate(identity.release, columns["validation"], columns["test"])
            record.update({key: result[key] for key in ("validation_delta_u", "test_delta_u", "fit_seconds")})
            exact = not unseen["validation"].any() and not unseen["test"].any()
            record["delta_u_checked"] = exact
            record["passed"] = record["train_input_equal"] and record["validation_differing_rows_unseen"] and (
                record["test_differing_rows_unseen"]
            ) and (not exact or result["validation_delta_u"] == 0.0 and result["test_delta_u"] == 0.0)
            passed = passed and record["passed"]
            no_generalization["models"][model] = record
        no_generalization["passed"] = passed
        checks["no_generalization"] = no_generalization
        self.manifest["identity_checks"][pat.METHOD] = checks

    def run_fido(self, store) -> None:
        settings = self.config.get("fido") or {}
        grid = dict(settings.get("size_grid") or {"start_fraction": 0.005, "end_fraction": 1.0, "points": 16})
        if self.args.fido_grid_points:
            grid["points"] = self.args.fido_grid_points
        epsilons = [float(value) for value in settings.get("epsilons", (0.005, 0.01, 0.02, 0.05, 0.1))]
        curve_model = settings.get("curve_model", "FIDO")
        n = self.context.training_row_count
        order = fido.prefix_order(n, self.seed)
        sizes = fido.grid_sizes(n, **grid)
        checks = {}
        for model in self.models:
            evaluator = self.evaluators[model]
            curve = []
            for size in sizes:
                key = ("curve", fido.METHOD, self.dataset, self.seed, model, f"grid_n{size}")
                record = store.get(key)
                if record is None:
                    started_at, started = utc_now(), time.perf_counter()
                    release = fido.prefix_release(self.context, order, size)
                    release_seconds = time.perf_counter() - started
                    stored = self.persist(release)
                    privacy, privacy_seconds = self.privacy(release)
                    result = evaluator.evaluate(release)
                    record = {
                        **self.base_row(fido.METHOD, model, f"grid_n{size}", "curve"), **result,
                        "prefix_size": size, "prefix_fraction": size / n, "min_k": privacy["min_k"],
                        "tail_risk_p99": privacy["tail_risk_p99"], **stored,
                        "release_seconds": release_seconds, "privacy_seconds": privacy_seconds,
                        "started_at": started_at, "finished_at": utc_now(),
                    }
                    store.append(record)
                    print(f"FIDO {self.dataset} seed {self.seed} {model} curve n={size}: "
                          f"validation={record['validation_loss']:.6g} fit={record['fit_seconds']:.2f}s", flush=True)
                curve.append(record)
            full = next(record for record in curve if record["prefix_size"] == n)
            checks[model] = {
                "point": f"grid_n{n}",
                "validation_difference": full["validation_loss"] - evaluator.reference["validation"],
                "test_difference": full["test_loss"] - evaluator.reference["test"],
            }
            checks[model]["passed"] = checks[model]["validation_difference"] == 0.0 and (
                checks[model]["test_difference"] == 0.0
            )
            fitted = fido.fit_curve([r["prefix_size"] for r in curve], [r["validation_loss"] for r in curve],
                                    curve_model)
            bounds = [evaluator.reference["validation"] + epsilon for epsilon in epsilons]
            stops = fido.stop_sizes(fitted, bounds, smallest=sizes[0], largest=n)
            for stop, epsilon in zip(stops, epsilons):
                stop["epsilon"] = epsilon
            parameters = fido.curve_parameters(fitted)
            write_json_atomic(self.results_dir / "fido" / f"{self.dataset}_seed{self.seed}_{model}.json", {
                "dataset": self.dataset, "seed": self.seed, "model": model, "size_grid": grid,
                "grid_sizes": sizes, "order": fido.ORDER_RULE, "curve_model": curve_model,
                "curve": parameters, "reference_validation_loss": evaluator.reference["validation"],
                "points": [{"prefix_size": r["prefix_size"], "validation_loss": r["validation_loss"],
                            "test_loss": r["test_loss"]} for r in curve],
                "forecast_at_grid": fido.forecast(fitted, sizes).tolist(), "stops": stops,
                "implementation_sha256": self.code_hash, "written_at": utc_now(),
            })
            by_size = defaultdict(list)
            for stop in stops:
                by_size[stop["size"]].append(stop)
            curve_by_size = {record["prefix_size"]: record for record in curve}
            for size, group in sorted(by_size.items()):
                point = f"n{size}"
                if store.get(("point", fido.METHOD, self.dataset, self.seed, model, point)) is not None:
                    continue
                started_at, started = utc_now(), time.perf_counter()
                release = fido.prefix_release(self.context, order, size)
                release_seconds = time.perf_counter() - started
                stored = self.persist(release)
                privacy, privacy_seconds = self.privacy(release)
                if size in curve_by_size:
                    # The same release and model were evaluated for the curve.
                    source = curve_by_size[size]
                    result = {**{key: source[key] for key in LOSS_KEYS}, "encode_seconds": 0.0, "fit_seconds": 0.0,
                              "model_evaluation_seconds": 0.0}
                    reused_from = source["point"]
                else:
                    result, reused_from = evaluator.evaluate(release), None
                row = {
                    **self.base_row(fido.METHOD, model, point, "point"), "variant": "brokencurve_offline_bound",
                    **result, **privacy, "generalized_cell_count": 0, "root_cell_count": 0,
                    "generalized_cell_fraction": 0.0,
                    "method_parameters": {
                        **release.parameters, "epsilons": [stop["epsilon"] for stop in group],
                        "bounds": [stop["bound"] for stop in group], "size_grid": grid, "grid_sizes": sizes,
                        "curve_model": curve_model, "curve": parameters,
                    },
                    "fido_epsilons": ";".join(f"{stop['epsilon']:g}" for stop in group),
                    "fido_bounds": ";".join(repr(stop["bound"]) for stop in group),
                    "fido_prefix_size": size, "fido_prefix_fraction": size / n,
                    "fido_forecast_validation_loss": group[0]["forecast_validation_loss"],
                    "fido_bound_reached": all(stop["bound_reached"] for stop in group),
                    **stored, "release_seconds": release_seconds, "privacy_seconds": privacy_seconds,
                    "evaluation_reused_from": reused_from, "started_at": started_at, "finished_at": utc_now(),
                }
                store.append(row)
                self._report(row)
        self.manifest["identity_checks"][fido.METHOD] = checks

    # Driver --------------------------------------------------------------------------
    def run(self) -> None:
        self.write_split()
        self.build_evaluators()
        for method in self.args.method:
            started = time.perf_counter()
            name = METHODS[method]
            store = EvaluationStore(
                self.results_dir / "evaluations" / f"{self.dataset}_seed{self.seed}_{method}.jsonl",
                resume=self.args.resume,
            )
            getattr(self, f"run_{method}")(store)
            tables = write_tables(store, self.results_dir / "tables", f"{self.dataset}_seed{self.seed}_{method}")
            points = [row for row in store.points() if row["model"] in self.models]
            self.manifest["methods_summary"][name] = {
                "point_rows": len(points), "points_per_model": {
                    model: sum(row["model"] == model for row in points) for model in self.models
                },
                "curve_rows": len(store.curve()), "tables": tables,
                "seconds_this_invocation": time.perf_counter() - started,
            }
            write_json_atomic(self.manifest_path, self.manifest)


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", required=True, help="Baseline configuration YAML.")
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--seed", required=True, type=int)
    parser.add_argument("--model", action="append", help="Target model name from the matrix; repeat.")
    parser.add_argument("--method", action="append", choices=sorted(METHODS), help="Repeat; default: config methods.")
    parser.add_argument("--device", help="Override the matrix device, for example cuda:0 or cpu.")
    parser.add_argument("--results-dir", help="Results directory shared by all items of a run "
                        "(default: the configuration's results_root).")
    parser.add_argument("--resume", action="store_true", help="Continue existing evaluation files.")
    parser.add_argument("--release-limit", type=int, help="Evaluate only the first N releases per method (smoke tests).")
    parser.add_argument("--fido-grid-points", type=int, help="Override the FIDO size-grid point count.")
    parser.add_argument("--data-root", help="Directory that relative matrix data paths resolve against.")
    parser.add_argument("--pat-dir", help="Directory of PAT bucketization JSON files.")
    args = parser.parse_args(argv)
    config_path, config = load_yaml_mapping(resolve_project_path(args.config))
    if config.get("experiment_kind") != "exp1_baselines":
        raise ValueError("Expected experiment_kind: exp1_baselines.")
    args.method = args.method or list(config.get("methods") or ("fido", "featsel", "entrywise"))
    if len(set(args.method)) != len(args.method):
        raise ValueError("--method contains duplicates.")
    matrix_path, matrix = load_yaml_mapping(resolve_project_path(config["matrix_config"]))
    if matrix.get("experiment_kind") != "exp1_privacy_utility":
        raise ValueError("matrix_config must declare the shared Exp-1 matrix.")
    dataset = resolve_dataset(args.dataset).key
    tasks = [
        task for task in expand_matrix(matrix)
        if resolve_dataset(task["dataset"]).key == dataset
        and int((task.get("pipeline") or {}).get("random_state", 42)) == args.seed
    ]
    models = args.model or list(dict.fromkeys(_model_name(task) for task in tasks))
    tasks_by_model = {model: next((task for task in tasks if _model_name(task) == model), None) for model in models}
    missing = [model for model, task in tasks_by_model.items() if task is None]
    if missing or not tasks_by_model:
        raise ValueError(f"The matrix has no {dataset} seed {args.seed} task for models {missing or models}.")
    shared = {
        canonical_json({
            "data_path": task.get("data_path"), "tree": task.get("generalization_tree_path"),
            "split": {key: (task.get("pipeline") or {}).get(key, default) for key, default in SPLIT_KEYS},
        })
        for task in tasks_by_model.values()
    }
    if len(shared) != 1:
        raise ValueError("Tasks of one dataset and seed must share data, tree and split settings.")
    if not (args.results_dir or config.get("results_root")):
        raise ValueError("Set --results-dir or results_root in the configuration.")
    results_dir = resolve_project_path(args.results_dir or config["results_root"])
    results_dir.mkdir(parents=True, exist_ok=True)
    locks = []
    try:
        for method in args.method:
            locks.append(ItemLock(results_dir / "locks" / f"{dataset}_seed{args.seed}_{method}.lock"))
        run = BaselineRun(args, {**config, "config_path": str(config_path), "matrix_path": str(matrix_path)},
                          tasks_by_model, results_dir)
        try:
            run.run()
            run.manifest.update(status="complete", ended_at=utc_now())
        except BaseException as error:
            run.manifest.update(status="failed", error=repr(error), ended_at=utc_now())
            raise
        finally:
            write_json_atomic(run.manifest_path, run.manifest)
            print(run.manifest_path, flush=True)
    finally:
        for lock in locks:
            lock.release()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
