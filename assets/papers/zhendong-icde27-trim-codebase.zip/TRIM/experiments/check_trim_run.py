"""Replay retained states and verify TRIM candidate, privacy and swap invariants."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from collections import Counter, defaultdict
from pathlib import Path

from prototype import dataloader
from prototype.TRIM_prototype_pipeline import _loaded_input_sha256, _operation_privacy_cost
from prototype.dataset_registry import build_data_loader, resolve_generalization_tree
from prototype.enumeration_horizontal import select_encoded_attributes
from prototype.release_artifacts import load_dataset_split
from prototype.state_history import retained_ids_sha256


def replay_states(records, training_ids):
    if not records or records[0]["round"] != 0:
        raise ValueError("State history must start with initialization.")
    allowed = {str(rid) for rid in training_ids}
    current = set()
    for number, record in enumerate(records):
        if record["round"] != number or record["iteration"] != number - 1:
            raise ValueError("State rounds are not contiguous.")
        previous = set(current)
        if number == 0:
            listed = record["retained_row_ids"]
            current = set(listed)
            if len(listed) != len(current):
                raise ValueError("Duplicate initial retained IDs.")
        else:
            admitted, evicted = record["admitted_row_ids"], record["evicted_row_ids"]
            if len(set(admitted)) != len(admitted) or len(set(evicted)) != len(evicted):
                raise ValueError("Duplicate delta IDs.")
            if set(admitted) & current or not set(evicted) <= current or set(admitted) & set(evicted):
                raise ValueError("Invalid retained-state delta.")
            if retained_ids_sha256(current) != record["previous_retained_ids_sha256"]:
                raise ValueError("Previous retained-state hash mismatch.")
            current = (current - set(evicted)) | set(admitted)
        if not current or not current <= allowed:
            raise ValueError("Retained IDs must belong to the training split.")
        if len(current) != record["retained_count"] or retained_ids_sha256(current) != record["retained_ids_sha256"]:
            raise ValueError("Retained count/hash mismatch.")
        yield record, previous, set(current)


def _check_shortlist(pool, config, top_k):
    """Per-pool bounds of one round's proxy-certified candidates; top_k None allows every candidate."""
    if top_k is None:
        return
    # Each action type has its own top-k pool; eviction variants have their own pool.
    shortlist_pools = Counter(
        (candidate["action"], candidate.get("eviction_ceiling") is not None) for candidate in pool)
    if config.get("eviction_shortlist") == "union":
        # Eviction variants are certified for the certified refinements (at most
        # top-k x ratios) and for the variants' own LGA top-k, so at most top-k
        # variants may lack a certified parent refinement.
        parents = {c["candidate_id"] for c in pool if c["action"] == "vertical_refinement"
                   and c.get("eviction_ceiling") is None}
        variants = [c for c in pool if c.get("eviction_ceiling") is not None]
        orphans = [c for c in variants if str(c["candidate_id"]).rpartition("~k")[0] not in parents]
        if len(orphans) > top_k:
            raise ValueError("An eviction variant was certified without its refinement.")
        if len(variants) - len(orphans) > top_k * len(config["refinement_eviction_ratios"]):
            raise ValueError("More eviction variants were certified than top-k refinements allow.")
        shortlist_pools = Counter({key: n for key, n in shortlist_pools.items() if not key[1]})
    if max(shortlist_pools.values(), default=0) > top_k:
        raise ValueError("More than top-k candidates were proxy-certified per type.")


def check_run(run_dir, data_loader, tree_path=None):
    run_dir = Path(run_dir)
    config = json.loads((run_dir / "config.json").read_text())
    metrics = json.loads((run_dir / "metrics.json").read_text())
    tree_path = Path(tree_path or config["generalization_tree_path"])
    if hashlib.sha256(tree_path.read_bytes()).hexdigest() != config["generalization_tree_sha256"]:
        raise ValueError("Generalization tree differs from the run.")
    X_raw, y = data_loader.load(nrows=config.get("nrows"))
    if _loaded_input_sha256(X_raw, y) != config["input_data_sha256"]:
        raise ValueError("Loaded data differs from the run.")
    split = load_dataset_split(data_loader, config)
    train = split.X_train_raw
    ids = {str(rid): rid for rid in train.index}
    if len(ids) != len(train):
        raise ValueError("Ambiguous training row IDs.")
    records = [json.loads(line) for line in (run_dir / "state_history.jsonl").read_text().splitlines()]
    action_files = list(run_dir.glob("pipeline_selection_actions_*.jsonl"))
    if len(action_files) != 1:
        raise ValueError("Expected one action log.")
    actions = [json.loads(line) for line in action_files[0].read_text().splitlines()]
    candidates = defaultdict(list)
    for action in actions:
        if action.get("event") == "candidate_evaluation":
            candidates[int(action["iteration"])].append(action)
    attributes = config["qi_attributes"]
    normal_pool = config.get("candidate_shortlist") is None
    normal_swap = config["ablation_actions"]["vertical_postprocessing"] == "full_swap"
    cap_hits = []
    previous_levels = None
    previous_k = None
    for record, previous, retained in replay_states(records, train.index):
        round_number = record["round"]
        levels = record["generalization_level"]
        generalization = dataloader.load_generalization_rules_from_file(
            file_path=tree_path, data_loader=data_loader, generalization_level=levels)
        encoded = select_encoded_attributes(generalization.encode(train), attributes)
        row_ids = [ids[rid] for rid in retained]
        selected_counts = encoded.loc[row_ids].value_counts(sort=False)
        actual_k = int(selected_counts.min())
        if actual_k != int(record["min_k"]):
            raise ValueError(f"Recomputed min-K mismatch at round {round_number}.")
        if round_number:
            pool = candidates[round_number - 1]
            selected = [candidate for candidate in pool if candidate["selected"]]
            if len(selected) != 1:
                raise ValueError("Each committed round must select exactly one operation.")
            chosen = selected[0]
            if normal_pool:
                # The widening stall rule certifies every candidate of the round it
                # rescues, or the top stall_widen_top_k of each pool.
                widened = config.get("stall_rule") == "widen" and any(
                    stalled["iteration"] == round_number - 1 and stalled["action"] is not None
                    for stalled in config.get("stall_rule_rounds", ()))
                _check_shortlist(pool, config,
                                 config.get("stall_widen_top_k") if widened else int(config["rank_top_k"]))
            for candidate in pool:
                if candidate["eligible"] != (float(candidate["utility_gain"]) > 0):
                    raise ValueError("Eligibility differs from positive gain.")
                cost, delta = _operation_privacy_cost(
                    candidate["current_k"], candidate["next_k"],
                    config["privacy_cost_floor"])
                if not math.isclose(cost, float(candidate["privacy_cost"]), rel_tol=1e-10, abs_tol=1e-12):
                    raise ValueError("Candidate privacy cost mismatch.")
                if candidate.get("leakage_delta") is not None and not math.isclose(delta, float(candidate["leakage_delta"]), abs_tol=1e-12):
                    raise ValueError("Candidate leakage delta mismatch.")
                if config.get("selection_score") is None and not math.isclose(
                        float(candidate["score"]), float(candidate["utility_gain"]) / cost, abs_tol=1e-10):
                    raise ValueError("Candidate score differs from gain/cost.")
            if not chosen["eligible"] or float(chosen["utility_gain"]) <= 0:
                raise ValueError("Committed operation has no positive gain.")
            eligible = [c for c in pool if c["eligible"]]
            step = config.get("max_privacy_step")
            if step is not None:
                # max_privacy_step: bounded positive-gain candidates come first.
                for c in pool:
                    if bool(c.get("within_privacy_step")) != (int(c["next_k"]) * float(step) >= int(c["current_k"])):
                        raise ValueError("Privacy-step flag differs from the candidate's min-K change.")
                bounded = [c for c in eligible if c.get("within_privacy_step")]
                if bounded and not chosen.get("within_privacy_step"):
                    raise ValueError("An unbounded step was committed although a bounded one had a positive gain.")
                eligible = bounded or eligible
            if float(chosen["score"]) < max(float(c["score"]) for c in eligible):
                raise ValueError("Committed operation does not maximize the eligible score.")
            if chosen["action"] != record["operation"] or chosen["next_generalization_level"] != levels:
                raise ValueError("Committed operation differs from state history.")
            for field in ("utility_gain", "privacy_cost", "score", "current_k", "next_k"):
                if not math.isclose(float(chosen[field]), float(record[field]), abs_tol=1e-10):
                    raise ValueError(f"Committed {field} differs from the action log.")
            if record["current_k"] != previous_k or record["next_k"] != actual_k:
                raise ValueError("Operation min-K differs from consecutive retained states.")
            if chosen["action"] == "retention_class":
                if levels != previous_levels or not previous <= retained:
                    raise ValueError("Horizontal admission changed levels or evicted rows.")
                if not config.get("fixed_row_candidate_builder"):
                    added_ids = [ids[rid] for rid in retained - previous]
                    if not added_ids or len(encoded.loc[added_ids].drop_duplicates()) != 1:
                        raise ValueError("Horizontal operation does not admit one equivalence class.")
                    key = tuple(encoded.loc[added_ids[0]].tolist())
                    matches = encoded.eq(list(key), axis="columns").all(axis=1)
                    group_ids = {str(rid) for rid in encoded.index[matches]}
                    if group_ids - previous != retained - previous:
                        raise ValueError("Horizontal operation did not admit the whole remaining class.")
            elif chosen["action"] == "vertical_refinement":
                changed = [name for name in levels if levels[name] != previous_levels[name]]
                if changed != [record["attribute"]]:
                    raise ValueError("Vertical operation must refine exactly one QI.")
                # A refinement eviction variant ("<id>~k<ceiling>") evicts the
                # post-swap classes below its ceiling; the swap checks below
                # then apply to the post-swap set (retained plus evicted rows).
                ceiling = record.get("eviction_ceiling")
                base_id = chosen["candidate_id"]
                post_swap = retained
                if ceiling is not None:
                    ratios = config.get("refinement_eviction_ratios") or []
                    if int(ceiling) not in {math.ceil(int(record["current_k"]) / float(r)) for r in ratios}:
                        raise ValueError("Eviction ceiling does not follow a configured ratio.")
                    base_id, _, suffix = str(chosen["candidate_id"]).rpartition("~k")
                    if suffix != str(ceiling) or int(chosen.get("eviction_ceiling", -1)) != int(ceiling):
                        raise ValueError("Eviction candidate ID differs from the committed ceiling.")
                    evicted_by_ceiling = set(record["ceiling_evicted_row_ids"])
                    if not evicted_by_ceiling or evicted_by_ceiling & retained:
                        raise ValueError("Invalid ceiling eviction.")
                    post_swap = retained | evicted_by_ceiling
                    frame = encoded.loc[[ids[rid] for rid in post_swap]]
                    sizes = frame.groupby(list(frame.columns), sort=False, dropna=False,
                                          observed=True)[frame.columns[0]].transform("size")
                    kept = {str(rid) for rid, size in sizes.items() if size >= int(ceiling)}
                    if kept != retained or actual_k < int(ceiling):
                        raise ValueError("Ceiling eviction kept a class below, or evicted one at or above, the ceiling.")
                elif record.get("ceiling_evicted_row_ids"):
                    raise ValueError("Evicted rows recorded without a ceiling.")
                if not 0 <= levels[changed[0]] < previous_levels[changed[0]]:
                    raise ValueError("Vertical operation must move to a finer level.")
                if base_id != f"{changed[0]}@{levels[changed[0]]}":
                    raise ValueError("Vertical candidate ID differs from the committed level.")
                if normal_swap:
                    before = encoded.loc[[ids[rid] for rid in previous]]
                    post_swap_k = int(encoded.loc[[ids[rid] for rid in post_swap]].value_counts(sort=False).min())
                    if len(post_swap) < len(previous) or post_swap_k < int(before.value_counts(sort=False).min()):
                        raise ValueError("Swap reduced retention or refined-state min-K.")
                    cap_hit = record["swap_break_reason"] == "max_iterations"
                    if cap_hit != record["swap_cap_hit"]:
                        raise ValueError("Swap cap flag mismatch.")
                    if cap_hit:
                        if record["swap_iterations"] != record["swap_iteration_cap"]:
                            raise ValueError("Swap cap count mismatch.")
                        cap_hits.append(round_number)
                    else:
                        remaining = encoded.loc[[rid for rid in train.index if str(rid) not in post_swap]]
                        if not remaining.empty and int(remaining.value_counts(sort=False).max()) > post_swap_k:
                            raise ValueError("Swap stopped while a larger remaining class exists.")
            else:
                raise ValueError("Unknown committed operation.")
        previous_levels, previous_k = levels, actual_k
    stalls = config.get("stall_rule_rounds") or []
    if (normal_pool and config.get("stall_widen_top_k") is not None and stalls
            and stalls[-1]["action"] is None and int(stalls[-1]["iteration"]) == len(records) - 1):
        # The capped widening stage that ended the run certified at most
        # stall_widen_top_k per pool too.
        _check_shortlist(candidates[len(records) - 1], config, int(config["stall_widen_top_k"]))
    if len(records) != int(metrics["iteration_count"]) + 1:
        raise ValueError("Iteration count differs from state history.")
    stop_k = config.get("stop_at_release_min_k")
    if stop_k is not None:
        reached = [record["round"] for record in records[1:]
                   if record.get("mixed_min_k") is not None and int(record["mixed_min_k"]) <= int(stop_k)]
        if (metrics["termination_condition"] == "release_min_k_reached") != bool(reached) or (
                reached and reached[0] != records[-1]["round"]):
            raise ValueError("Run did not stop at the first round whose release reached stop_at_release_min_k.")
    stop_unmet = config.get("stop_unmet_at_release_min_k")
    if stop_unmet is not None and metrics["termination_condition"] == "release_min_k_reached_unmet":
        # The search ends at the first release with min-K <= k while epsilon is unmet, and TRIM returns D.
        reached = [record["round"] for record in records[1:]
                   if record.get("mixed_min_k") is not None and int(record["mixed_min_k"]) <= int(stop_unmet)]
        if not reached or reached[0] != records[-1]["round"] or not metrics["infeasible"]:
            raise ValueError("Run did not stop at its first unmet release with min-K <= stop_unmet_at_release_min_k.")
    if config.get("stop_on_utility"):
        # Final check: a round retrains the target only when the proxy's Delta U on D_t is within the tolerance,
        # and a utility-stopped run ends at the first round whose final check passes.
        rows = json.loads((run_dir / "trim_iterations.json").read_text())["iterations"]
        tolerance = float(config["tolerance"])
        initial = records[0]
        if bool(initial["final_check"]) != (float(initial["proxy_delta_u"]) <= tolerance):
            raise ValueError("The initial final check does not follow the proxy Delta U of D_0.")
        initial_passed = bool(initial["final_check"]) and bool(initial["target_validation_utility_constraint_met"])
        if initial_passed != (not rows and metrics["termination_condition"] == "loss_threshold_met"):
            raise ValueError("The run must stop in the initial state exactly when the initial final check passes.")
        for row in rows:
            if bool(row["final_check"]) != (float(row["search_proxy_delta_u"]) <= tolerance):
                raise ValueError("A round's final check does not follow its proxy Delta U.")
        passed = [i for i, row in enumerate(rows)
                  if row["final_check"] and row["target_validation_utility_constraint_met"]]
        if metrics["termination_condition"] == "loss_threshold_met":
            if rows and (not passed or passed[0] != len(rows) - 1):
                raise ValueError("Run did not stop at its first round whose final check passed.")
        elif passed:
            raise ValueError("Run continued after a passed final check.")
    final_ids = json.loads((run_dir / "ordinary_selected_row_ids.json").read_text())["ordinary_selected_row_ids"]
    if set(final_ids) != retained:
        raise ValueError("Final retained IDs differ from replayed state.")
    if metrics["infeasible"]:
        raw_k = int(train.loc[:, attributes].value_counts(sort=False).min())
        for mode, release in metrics["output_comparisons"].items():
            if set(release["assigned_row_ids"]) != set(ids) or release["min_k"] != raw_k:
                raise ValueError(f"{mode} infeasible fallback does not publish original training D.")
    if config.get("validation_only"):
        if metrics.get("test_evaluated") is not False or any(metrics.get(key) is not None for key in (
                "baseline_test_loss", "loss_threshold_test", "final_actual_model_loss")):
            raise ValueError("Validation-only metrics contain test evaluation.")
    return {"status": "ok", "states_checked": len(records), "commits_checked": len(records) - 1,
            "swap_cap_hit_rounds": cap_hits, "test_evaluated": metrics["test_evaluated"]}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run-dir", required=True)
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--data-path")
    parser.add_argument("--tree-path")
    args = parser.parse_args()
    loader = build_data_loader(args.dataset, data_path=args.data_path)
    tree_path = resolve_generalization_tree(args.dataset, tree_path=args.tree_path)
    print(json.dumps(check_run(args.run_dir, loader, tree_path), indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
