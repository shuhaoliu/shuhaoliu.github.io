"""Synthetic ACSIncome-shaped data drawn from the real Income hierarchy.

The rows only exercise code paths; they are not a substitute for the census
data. Every raw value is a leaf of the shipped generalization tree, drawn with
a skewed distribution so that both large and singleton classes occur.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import yaml

PROJECT_ROOT = Path(__file__).resolve().parents[2]
INCOME_TREE = PROJECT_ROOT / "configs/generalization_trees/acs_income_generalization_trees.yaml"


def _leaf_values(tree):
    return [node["value"] for node in tree["nodes"] if node.get("kind") == "leaf"]


def write_income_like_csvs(directory, *, rows=3000, seed=0, state="CA", year=2014):
    """Write ACSIncome_<state>_<year>_{X,y}.csv and return the directory."""
    import pandas as pd

    from prototype.dataloader import ACS_INCOME_FEATURE_COLUMNS

    trees = yaml.safe_load(INCOME_TREE.read_text(encoding="utf-8-sig"))["trees"]
    generator = np.random.default_rng(seed)
    columns = {}
    for attribute in ACS_INCOME_FEATURE_COLUMNS:
        values = _leaf_values(trees[attribute])
        weights = 1.0 / np.arange(1, len(values) + 1) ** 1.1
        weights = weights[generator.permutation(len(values))]
        draws = generator.choice(len(values), size=rows, p=weights / weights.sum())
        columns[attribute] = [values[index] for index in draws]
    frame = pd.DataFrame(columns, columns=list(ACS_INCOME_FEATURE_COLUMNS))
    score = (
        0.04 * (frame["AGEP"].astype(float) - 40)
        + 0.03 * (frame["WKHP"].astype(float) - 38)
        + 0.15 * (frame["SCHL"].astype(float) - 16)
        + 0.4 * (frame["SEX"].astype(float) == 1)
    )
    probability = 1.0 / (1.0 + np.exp(-score.to_numpy()))
    labels = (generator.random(rows) < probability).astype(int)
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    frame.to_csv(directory / f"ACSIncome_{state}_{year}_X.csv", index=False)
    pd.DataFrame({"PINCP": labels}).to_csv(
        directory / f"ACSIncome_{state}_{year}_y.csv", index=False,
    )
    return directory
