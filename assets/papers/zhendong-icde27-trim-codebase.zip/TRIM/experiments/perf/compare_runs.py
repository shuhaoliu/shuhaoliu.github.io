"""Compare two TRIM run directories, ignoring only timings and paths.

Exit status 0 means every compared record is identical. Floats are compared
exactly unless --float-tolerance is given.

Full runs:     python -m experiments.perf.compare_runs REF CAND
Round prefix:  python -m experiments.perf.compare_runs REF CAND --rounds 3

With --rounds N only the per-round logs of rounds 0..N are compared, so a short
capped run can be checked against the first rounds of a longer run. Each
--ignore-key K also ignores K wherever it appears, e.g. a configuration key in
which the two runs differ on purpose.
"""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import sys

IGNORED_KEYS = {
    "timings", "action_log_path", "generalization_tree_path", "run_dir",
    "results_dir", "run_tag", "selection_cache", "fast_path_usage",
}
IGNORED_SUFFIXES = ("_seconds", "_time")
FINAL_FILES = (
    "metrics.json", "trim_release.json", "trim_iterations.json",
    "output_comparisons.json", "leak_distribution.json", "selected_row_ids.json",
    "ordinary_selected_row_ids.json", "generalization_level.json", "config.json",
)


def _ignored(key, extra=frozenset()):
    return key in IGNORED_KEYS or key in extra or key.endswith(IGNORED_SUFFIXES)


def normalize(value, extra=frozenset()):
    if isinstance(value, dict):
        return {key: normalize(item, extra) for key, item in value.items() if not _ignored(key, extra)}
    if isinstance(value, list):
        return [normalize(item, extra) for item in value]
    return value


def first_difference(left, right, tolerance=0.0, path="$"):
    if isinstance(left, dict) and isinstance(right, dict):
        for key in sorted(set(left) | set(right)):
            if key not in left or key not in right:
                return f"{path}.{key}: present in only one run"
            found = first_difference(left[key], right[key], tolerance, f"{path}.{key}")
            if found:
                return found
        return None
    if isinstance(left, list) and isinstance(right, list):
        if len(left) != len(right):
            return f"{path}: length {len(left)} != {len(right)}"
        for index, (a, b) in enumerate(zip(left, right)):
            found = first_difference(a, b, tolerance, f"{path}[{index}]")
            if found:
                return found
        return None
    if isinstance(left, float) and isinstance(right, float) and tolerance > 0:
        if math.isclose(left, right, rel_tol=tolerance, abs_tol=tolerance) or (
                math.isnan(left) and math.isnan(right)):
            return None
    if left != right and not (isinstance(left, float) and isinstance(right, float)
                              and math.isnan(left) and math.isnan(right)):
        return f"{path}: {left!r} != {right!r}"
    return None


def _jsonl(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines() if line.strip()]


def _action_log(run_dir):
    paths = sorted(Path(run_dir).glob("pipeline_selection_actions_*.jsonl"))
    if len(paths) != 1:
        raise FileNotFoundError(f"Expected one action log in {run_dir}, found {len(paths)}.")
    return _jsonl(paths[0])


def _round_of_action(record):
    iteration = record.get("iteration")
    return None if iteration is None else int(iteration)


def compare_runs(reference, candidate, *, rounds=None, tolerance=0.0, ignore_keys=()):
    """Return a list of human-readable differences (empty when identical)."""
    extra = frozenset(ignore_keys)
    differences = []
    ref_states = _jsonl(Path(reference) / "state_history.jsonl")
    cand_states = _jsonl(Path(candidate) / "state_history.jsonl")
    if rounds is not None:
        ref_states = [row for row in ref_states if row["round"] <= rounds]
        cand_states = [row for row in cand_states if row["round"] <= rounds]
    found = first_difference(normalize(ref_states, extra), normalize(cand_states, extra), tolerance,
                             "state_history")
    if found:
        differences.append(found)

    ref_actions, cand_actions = _action_log(reference), _action_log(candidate)
    if rounds is not None:
        def keep(record):
            if record.get("event") == "pipeline_summary":
                return False
            iteration = _round_of_action(record)
            return iteration is None or iteration < rounds
        ref_actions = [record for record in ref_actions if keep(record)]
        cand_actions = [record for record in cand_actions if keep(record)]
    found = first_difference(normalize(ref_actions, extra), normalize(cand_actions, extra), tolerance,
                             "action_log")
    if found:
        differences.append(found)

    if rounds is None:
        for name in FINAL_FILES:
            ref_path, cand_path = Path(reference) / name, Path(candidate) / name
            if not ref_path.exists() and not cand_path.exists():
                continue
            if not ref_path.exists() or not cand_path.exists():
                differences.append(f"{name}: present in only one run")
                continue
            found = first_difference(
                normalize(json.loads(ref_path.read_text()), extra),
                normalize(json.loads(cand_path.read_text()), extra), tolerance, name)
            if found:
                differences.append(found)
    return differences


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("reference")
    parser.add_argument("candidate")
    parser.add_argument("--rounds", type=int, help="Compare only rounds 0..N of the per-round logs.")
    parser.add_argument("--float-tolerance", type=float, default=0.0)
    parser.add_argument("--ignore-key", action="append", default=[],
                        help="Also ignore this key everywhere; repeatable.")
    args = parser.parse_args(argv)
    differences = compare_runs(args.reference, args.candidate, rounds=args.rounds,
                               tolerance=args.float_tolerance, ignore_keys=args.ignore_key)
    if differences:
        print("DIFFERENT")
        for line in differences:
            print("  " + line)
        return 1
    scope = "all outputs" if args.rounds is None else f"rounds 0..{args.rounds}"
    ignored = "".join(f", {key}" for key in args.ignore_key)
    print(f"IDENTICAL ({scope}; timings and paths{ignored} ignored)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
