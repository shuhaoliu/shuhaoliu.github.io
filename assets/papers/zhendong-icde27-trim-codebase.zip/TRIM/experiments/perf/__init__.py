"""Equivalence tools for the tests of the TRIM search: run comparison and synthetic Income-shaped data."""
