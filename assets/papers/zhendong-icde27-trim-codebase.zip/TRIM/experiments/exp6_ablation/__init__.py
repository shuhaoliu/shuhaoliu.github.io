"""Exp-6 ablations (Fig. 5h, 5k and 5l) built on the hooks of the TRIM pipeline."""
