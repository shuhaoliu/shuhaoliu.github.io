"""Declared Exp-6 candidate builders and selection rules."""

from __future__ import annotations

from dataclasses import dataclass, field
import math
import random

from prototype import (
    RETENTION_CLASS_ACTION,
    VERTICAL_REFINEMENT_ACTION,
    CandidateScorerRunContext,
    CandidateShortlistContext,
    CandidateStateScoreContext,
    SelectionScoreContext,
)

from ..ranking_models import FixedOriginalInfluence
from .enumeration import KMeansClusterRingBuilder


@dataclass
class SeededUniformShortlist:
    """Select one candidate uniformly from the complete H+V action pool."""

    seed: int
    _random: random.Random = field(init=False, repr=False)

    def __post_init__(self):
        self.seed = int(self.seed)
        self._random = random.Random(self.seed)

    def __call__(self, context: CandidateShortlistContext) -> tuple[int, ...]:
        if not context.candidates:
            return ()
        selected = self._random.randrange(len(context.candidates))
        return (context.candidates[selected].position,)


def _pool_top_k(context: CandidateShortlistContext, key) -> list:
    """The rank_top_k candidates of each core pool with the smallest key, all ordered by key."""

    by_pool = {}
    for candidate in context.candidates:
        by_pool.setdefault(candidate.pool, []).append(candidate)
    chosen = [candidate for members in by_pool.values()
              for candidate in sorted(members, key=key)[:context.rank_top_k]]
    return sorted(chosen, key=key)


def utility_only_shortlist(context: CandidateShortlistContext) -> tuple[int, ...]:
    """Utility-only rule at the shortlist: the top-k of each pool by LGA, ignoring privacy cost."""

    return tuple(c.position for c in _pool_top_k(context, lambda c: -c.lga_score))


@dataclass
class PrivacyOnlyShortlist:
    """Privacy-only rule at the shortlist: the top-k of each pool by smallest privacy cost.

    Ties at the cost floor are broken by the smaller raw leak change, then by a seeded
    draw. privacy_only_score keeps the first maximum in this order, so the committed
    candidate is the cheapest one with a positive gain.
    """

    seed: int
    _random: random.Random = field(init=False, repr=False)

    def __post_init__(self):
        self._random = random.Random(int(self.seed))

    def __call__(self, context: CandidateShortlistContext) -> tuple[int, ...]:
        draws = {c.position: self._random.random() for c in context.candidates}
        return tuple(c.position for c in _pool_top_k(
            context, lambda c: (c.privacy_cost, c.leakage_delta, draws[c.position])))


@dataclass
class SeededRandomShortlist:
    """Random rule at the shortlist: a seeded draw of k candidates from each pool."""

    seed: int
    _random: random.Random = field(init=False, repr=False)

    def __post_init__(self):
        self._random = random.Random(int(self.seed))

    def __call__(self, context: CandidateShortlistContext) -> tuple[int, ...]:
        by_pool = {}
        for candidate in context.candidates:
            by_pool.setdefault(candidate.pool, []).append(candidate.position)
        return tuple(position for members in by_pool.values()
                     for position in self._random.sample(members, min(context.rank_top_k, len(members))))


@dataclass
class SeededUniformImprovingScore:
    """Reservoir-sample uniformly after normal top-k proxy certification.

    A replacement receives a larger score, so the pipeline's usual maximum
    selects the reservoir winner. Non-improving candidates consume no draws.
    """

    seed: int
    _iteration: int | None = field(default=None, init=False, repr=False)
    _count: int = field(default=0, init=False, repr=False)
    _random: random.Random = field(init=False, repr=False)

    def __post_init__(self):
        self._random = random.Random(int(self.seed))

    def __call__(self, context: SelectionScoreContext) -> float:
        if context.iteration != self._iteration:
            self._iteration, self._count = context.iteration, 0
        if context.utility_gain <= 0:
            return 0.0
        self._count += 1
        return float(self._count) if self._random.randrange(self._count) == 0 else 0.0


def privacy_only_score(context: SelectionScoreContext) -> float:
    """Ignore utility and prefer the smallest privacy cost."""

    return 1.0 / context.privacy_cost


def utility_only_score(context: SelectionScoreContext) -> float:
    """Ignore privacy cost and use the latest TRIM validation utility gain."""

    return context.utility_gain


def yang_if_utility_privacy_score(context: SelectionScoreContext) -> float:
    """Use Yang-style validation Utility Delta as TRIM's utility term."""

    if context.candidate_state_score is None:
        raise RuntimeError(
            "Yang-style IF selection requires candidate_state_scorer_factory."
        )
    return context.candidate_state_score / context.privacy_cost


@dataclass
class YangIFSelectionScorer:
    """IF utility estimate of a candidate state at the fixed original-data MLP, as in Fig. 5j."""

    horizontal: FixedOriginalInfluence
    vertical: FixedOriginalInfluence
    _current_states: dict = field(default_factory=dict, init=False, repr=False)
    _current_losses: dict = field(default_factory=dict, init=False, repr=False)

    def __call__(self, context: CandidateStateScoreContext) -> float:
        if context.candidate_type == RETENTION_CLASS_ACTION:
            reference = self.horizontal
            scope = "last_layer"
        elif context.candidate_type == VERTICAL_REFINEMENT_ACTION:
            reference = self.vertical
            scope = "all"
        else:
            raise ValueError(
                f"Unsupported Yang-style candidate type: {context.candidate_type!r}."
            )
        cache_key = (int(context.iteration), scope)
        if cache_key not in self._current_states:
            current_state = reference.state(
                context.current_encode,
                context.current_y,
            )
            self._current_states[cache_key] = current_state
            self._current_losses[cache_key] = reference.estimated_validation_loss(
                current_state,
                context.current_validation_encode,
                context.validation_y,
            )
        candidate_state = reference.state(
            context.candidate_encode,
            context.candidate_y,
        )
        next_loss = reference.estimated_validation_loss(
            candidate_state,
            context.candidate_validation_encode,
            context.validation_y,
        )
        utility_delta = float(self._current_losses[cache_key] - next_loss)
        if not math.isfinite(utility_delta):
            raise ValueError("Yang-style IF produced a non-finite Utility Delta.")
        return utility_delta


@dataclass(frozen=True)
class YangIFSelectionScorerFactory:
    """Fit the original-data MLP and freeze the IF references of Fig. 5i and 5j."""

    model_factory: object
    horizontal_last: dict
    vertical_all: dict

    def __call__(
        self,
        context: CandidateScorerRunContext,
    ) -> YangIFSelectionScorer:
        model = self.model_factory()
        model.fit(context.train_original_encode, context.train_y)
        if getattr(model, "network_", None) is None:
            raise ValueError(
                "Fig. 5l Yang-style IF requires an explicit fitted MLP "
                "selection estimator; incompatible models are not accepted."
            )
        required = {"damping", "cg_max_iter", "cg_tolerance"}
        for name, values in (
            ("horizontal_last", self.horizontal_last),
            ("vertical_all", self.vertical_all),
        ):
            missing = sorted(required - set(values))
            if missing:
                raise ValueError(f"{name} is missing solver values: {missing}.")
        horizontal = FixedOriginalInfluence(
            model,
            context.train_original_encode,
            context.train_y,
            parameter_scope="last_layer",
            damping=float(self.horizontal_last["damping"]),
            cg_max_iter=int(self.horizontal_last["cg_max_iter"]),
            cg_tolerance=float(self.horizontal_last["cg_tolerance"]),
        )
        vertical = FixedOriginalInfluence(
            model,
            context.train_original_encode,
            context.train_y,
            parameter_scope="all",
            damping=float(self.vertical_all["damping"]),
            cg_max_iter=int(self.vertical_all["cg_max_iter"]),
            cg_tolerance=float(self.vertical_all["cg_tolerance"]),
        )
        return YangIFSelectionScorer(horizontal=horizontal, vertical=vertical)


__all__ = [
    "KMeansClusterRingBuilder",
    "SeededUniformShortlist",
    "SeededUniformImprovingScore",
    "YangIFSelectionScorerFactory",
    "privacy_only_score",
    "utility_only_score",
    "yang_if_utility_privacy_score",
]
