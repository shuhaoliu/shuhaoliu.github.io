"""Exp-1: TRIM's privacy--utility trajectories (Fig. 4)."""
