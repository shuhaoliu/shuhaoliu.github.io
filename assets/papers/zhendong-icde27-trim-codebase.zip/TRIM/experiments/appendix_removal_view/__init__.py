"""Fig. 7 (appendix): the removal view of TRIM and its runner."""

from .pipeline import RemovalViewResult, run_removal_view

__all__ = ["RemovalViewResult", "run_removal_view"]
