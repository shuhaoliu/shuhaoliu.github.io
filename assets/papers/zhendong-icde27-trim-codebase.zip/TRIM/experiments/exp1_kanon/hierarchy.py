"""Shared QI hierarchy schema of the KAnon (TDS) and data-minimization baselines.

Released values are hierarchy nodes, leaf sets or intervals. The schema maps
them to TRIM's model encodings, so a record released at a hierarchy node gets
the same model input as in TRIM at that node.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

from prototype.dataloader import (
    _coerce_categorical_leaf_value,
    _interval_union_mean,
    _parse_leaf_value,
)


MISSING_NODE = "__mondrian_missing__"


def _entropy(counts):
    counts = np.asarray(counts, dtype=np.float64)
    total = counts.sum(axis=-1, keepdims=True)
    probabilities = np.divide(counts, total, out=np.zeros_like(counts), where=total > 0)
    return -(probabilities * np.log2(np.maximum(probabilities, np.finfo(float).tiny))).sum(axis=-1)


class HierarchySchema:
    """Precompute audited leaf domains, descendants and model-column positions."""

    def __init__(self, generalization):
        self.generalization = generalization
        self.loader = generalization.data_loader
        self.attributes = tuple(self.loader.qi_attributes)
        self.numeric = set(self.loader.numeric_attributes) & set(self.attributes)
        self.nodes = {}
        self.leaves = {}
        self.descendants = {}
        self.children = {}
        self.child_lookup = {}
        self.roots = {}
        self.leaf_values = {}
        self.lookup = {}
        self.categorical_membership = {}
        for attribute in self.attributes:
            node_list = generalization.trees[attribute]["nodes"]
            nodes = {node["id"]: node for node in node_list}
            if len(nodes) != len(node_list):
                raise ValueError(f"{attribute}: duplicate hierarchy node IDs.")
            roots = [key for key, node in nodes.items() if node.get("parent") is None]
            if len(roots) != 1 or MISSING_NODE in nodes:
                raise ValueError(f"{attribute}: expected one root and no reserved missing ID.")
            self.nodes[attribute] = nodes
            self.roots[attribute] = roots[0]
            leaves = [node for node in nodes.values() if node.get("kind") == "leaf"]
            self.leaves[attribute] = leaves
            self.children[attribute] = {key: [] for key in nodes}
            for child_id, child in nodes.items():
                if child.get("parent") is not None:
                    if child["parent"] not in nodes:
                        raise ValueError(f"{attribute}: missing hierarchy parent.")
                    self.children[attribute][child["parent"]].append(child_id)
            descendants = {key: [] for key in nodes}
            for position, leaf in enumerate(leaves):
                current = leaf["id"]
                visited = set()
                while current is not None:
                    if current in visited or current not in nodes:
                        raise ValueError(f"{attribute}: cyclic or invalid hierarchy parent.")
                    visited.add(current)
                    descendants[current].append(position)
                    current = nodes[current].get("parent")
                if roots[0] not in visited:
                    raise ValueError(f"{attribute}: disconnected leaf.")
            if any(not values for values in descendants.values()):
                raise ValueError(f"{attribute}: hierarchy has a node without leaves.")
            self.descendants[attribute] = descendants
            self.child_lookup[attribute] = {}
            for node_id, children in self.children[attribute].items():
                lookup = np.full(len(leaves), -1, dtype=np.int64)
                for child_position, child_id in enumerate(children):
                    lookup[descendants[child_id]] = child_position
                self.child_lookup[attribute][node_id] = lookup
            if attribute in self.numeric:
                parsed = [_parse_leaf_value(leaf["value"]) for leaf in leaves]
                intervals = [
                    (float(value[1]), float(value[2] if value[0] == "interval" else value[1]))
                    for value in parsed
                ]
                if any(lo > hi or not lo.is_integer() or not hi.is_integer() for lo, hi in intervals):
                    raise ValueError(f"{attribute}: numeric QIs require finite integer leaf domains.")
                ordered = sorted(intervals)
                if any(left[1] >= right[0] for left, right in zip(ordered, ordered[1:])):
                    raise ValueError(f"{attribute}: overlapping numeric leaves.")
                self.leaf_values[attribute] = intervals
            else:
                values = [
                    _coerce_categorical_leaf_value(self.loader, attribute, leaf["value"])
                    for leaf in leaves
                ]
                if len(set(values)) != len(values):
                    raise ValueError(f"{attribute}: duplicate categorical leaves.")
                self.leaf_values[attribute] = values
                self.lookup[attribute] = {value: position for position, value in enumerate(values)}
                self.categorical_membership[attribute] = {}
                for node_id, positions in descendants.items():
                    membership = np.zeros(len(leaves), dtype=bool)
                    membership[positions] = True
                    self.categorical_membership[attribute][node_id] = membership

    def values(self, X):
        """Return numeric values or categorical leaf positions; missing is -1."""
        output = {}
        for attribute in self.attributes:
            column = X[attribute]
            if attribute in self.numeric:
                values = pd.to_numeric(column, errors="raise").to_numpy(dtype=float, na_value=np.nan)
                valid = np.isnan(values)
                for lo, hi in self.leaf_values[attribute]:
                    valid |= (values >= lo) & (values <= hi)
                if np.any(~valid) or np.any(np.isfinite(values) & (values != np.floor(values))):
                    raise ValueError(f"{attribute}: value outside the fixed integer leaf schema.")
                output[attribute] = values
            else:
                if attribute in getattr(self.loader, "string_categorical_attributes", ()):
                    column = column.astype("string")
                mapped = column.map(self.lookup[attribute])
                if (mapped.isna() & column.notna()).any():
                    bad = column.loc[mapped.isna() & column.notna()].unique()[:5].tolist()
                    raise ValueError(f"{attribute}: values outside the fixed hierarchy: {bad!r}")
                output[attribute] = mapped.fillna(-1).to_numpy(dtype=np.int64)
        return output

    def root_domain(self):
        domains = {}
        for attribute in self.attributes:
            if attribute in self.numeric:
                intervals = self.leaf_values[attribute]
                domains[attribute] = {
                    "node": self.roots[attribute],
                    "low": min(lo for lo, _ in intervals),
                    "high": max(hi for _, hi in intervals),
                    "missing": True,
                }
            else:
                domains[attribute] = {"node": self.roots[attribute], "missing": True}
        return domains

    def contains(self, attribute, domain, values):
        if attribute in self.numeric:
            missing = np.isnan(values)
            if domain.get("missing_only"):
                return missing
            return ((values >= domain["low"]) & (values <= domain["high"])) | (
                missing & domain.get("missing", False)
            )
        if domain["node"] == MISSING_NODE:
            return values == -1
        return self.categorical_membership[attribute][domain["node"]][np.maximum(values, 0)] & (values >= 0) | (
            (values == -1) & domain.get("missing", False)
        )

    def numeric_representation(self, attribute, domain):
        if domain.get("missing_only"):
            return np.nan, [], 0
        lo, hi = domain["low"], domain["high"]
        intervals = self.leaf_values[attribute]
        positions = [i for i, (a, b) in enumerate(intervals) if a <= hi and b >= lo]
        if not positions:
            raise ValueError(f"{attribute}: released range contains no hierarchy leaves.")
        covered = [(max(lo, intervals[i][0]), min(hi, intervals[i][1])) for i in positions]
        # Scalar-leaf trees may be sparse; do not invent integers in the gaps.
        if all(a == b for a, b in intervals):
            mean = sum(intervals[i][0] for i in positions) / len(positions)
        else:
            mean = _interval_union_mean(covered)
        if "node" in domain:
            # The global fallback publishes the actual numeric hierarchy root,
            # including its height when the tree has a unary root.
            level = int(self.nodes[attribute][domain["node"]]["height_from_leaf"])
        else:
            common = set(self.nodes[attribute])
            for position in positions:
                ancestors = set()
                current = self.leaves[attribute][position]["id"]
                while current is not None:
                    ancestors.add(current)
                    current = self.nodes[attribute][current].get("parent")
                common &= ancestors
            level = min(int(self.nodes[attribute][key]["height_from_leaf"]) for key in common)
        return mean, positions, level

    def encode(self, X, groups, *, family):
        """Replace QI blocks in the existing level-0 schema; retain non-QIs."""
        rows_by_group = [np.asarray(group["positions"], dtype=np.intp) for group in groups]
        if family == "mlp":
            encoded = self.generalization.encode(X).copy()
            for attribute in self.attributes:
                codes = np.empty(len(X), dtype=np.intp)
                representations, lookup = [], {}
                for group, rows in zip(groups, rows_by_group):
                    domain = group["release"][attribute]
                    key = tuple(sorted(domain.items()))
                    if key in lookup:
                        codes[rows] = lookup[key]
                        continue
                    lookup[key] = len(representations)
                    codes[rows] = lookup[key]
                    if attribute in self.numeric:
                        mean, _, _ = self.numeric_representation(attribute, domain)
                        representations.append(mean)
                    else:
                        categories = self.loader.category_maps[attribute]
                        vector = np.zeros(len(categories), dtype=np.float64)
                        if domain["node"] != MISSING_NODE:
                            positions = self.descendants[attribute][domain["node"]]
                            for position in positions:
                                vector[categories[self.leaf_values[attribute][position]]] = 1.0 / len(positions)
                        representations.append(vector)
                if not len(X):
                    continue
                values = np.asarray(representations, dtype=np.float64)[codes]
                if attribute in self.numeric:
                    encoded[attribute] = values
                else:
                    columns = [f"{attribute}={value}" for value in self.loader.category_maps[attribute]]
                    encoded.loc[:, columns] = values
            return encoded
        if family != "xgboost":
            raise ValueError("Mondrian supports the shared mlp and xgboost encodings.")
        encoded = self.generalization.encode_xgboost_leaf_space(X).toarray()
        offset = 0
        for attribute in self.loader.feature_columns:
            if attribute not in self.attributes:
                offset += 1 if attribute in self.loader.numeric_attributes else len(self.loader.category_maps[attribute])
                continue
            width = len(self.leaves[attribute])
            codes = np.empty(len(X), dtype=np.intp)
            representations, lookup = [], {}
            for group, rows in zip(groups, rows_by_group):
                domain = group["release"][attribute]
                key = tuple(sorted(domain.items()))
                if key in lookup:
                    codes[rows] = lookup[key]
                    continue
                lookup[key] = len(representations)
                codes[rows] = lookup[key]
                if attribute in self.numeric:
                    _, positions, level = self.numeric_representation(attribute, domain)
                elif domain["node"] == MISSING_NODE:
                    positions, level = [], 0
                else:
                    positions = self.descendants[attribute][domain["node"]]
                    level = int(self.nodes[attribute][domain["node"]]["height_from_leaf"])
                vector = np.zeros(width + 1, dtype=np.float32)
                if positions:
                    vector[positions] = 1.0 / len(positions)
                vector[width] = level
                representations.append(vector)
            if len(X):
                encoded[:, offset:offset + width + 1] = np.asarray(representations)[codes]
            offset += width + 1
        if offset != encoded.shape[1]:
            raise AssertionError("Shared XGBoost schema width changed.")
        return np.ascontiguousarray(encoded, dtype=np.float32)
