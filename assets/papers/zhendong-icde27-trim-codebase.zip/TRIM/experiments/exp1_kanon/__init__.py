"""Shared QI hierarchy schema of the KAnon and data-minimization baselines."""
