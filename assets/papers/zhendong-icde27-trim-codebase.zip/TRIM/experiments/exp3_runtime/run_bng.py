"""Run Fig. 5d: TRIM on BNG(credit-g) at each row count (Exp-3 scalability)."""

from __future__ import annotations

import argparse

from .._runner import run_matrix_config
from ._metrics import extract_runtime_to_stop


def main() -> None:
    parser = argparse.ArgumentParser(description="Run Exp-3 BNG scalability.")
    parser.add_argument("--config", required=True)
    parser.add_argument("--device")
    parser.add_argument("--run-label")
    args = parser.parse_args()

    output = run_matrix_config(
        args.config,
        expected_kind="exp3_bng_scalability",
        device=args.device,
        run_label=args.run_label,
        after_task=extract_runtime_to_stop,
    )
    print(output)


if __name__ == "__main__":
    main()
