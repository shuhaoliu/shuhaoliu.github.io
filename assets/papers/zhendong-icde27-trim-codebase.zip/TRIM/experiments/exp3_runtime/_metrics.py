"""Extract TRIM's algorithm time from one completed run that stops on utility (Fig. 5c, 5d, 5f, the Fig. 7 retention
view): the run totals of retention-class enumeration, candidate selection, privacy accounting and model retraining,
i.e. everything TRIM computes up to the stop of its final check except data loading, the full-data reference fits, the
final test evaluation and recorded observations."""

from __future__ import annotations

import json
import math
from pathlib import Path

from ..common import write_json


ALGORITHM_TIME_FIELDS = (
    "candidate_enumeration_total_time_seconds",
    "selection_time_seconds",
    "privacy_accounting_time_seconds",
    "backend_retraining_certification_time_seconds",
)


def extract_runtime_to_stop(task, summary, _experiment_dir):
    """Return the algorithm time of a run that stops on utility (the module's rule).

    The retraining total holds the estimator and proxy fits on D_0, the proxy reference fit and every final check.
    A run that ends before a final check passes is recorded with `stopped` false and no time.
    """
    run_dir = Path(summary["run_dir"])
    config = json.loads((run_dir / "config.json").read_text(encoding="utf-8"))
    metrics = json.loads((run_dir / "metrics.json").read_text(encoding="utf-8"))
    if not config["stop_on_utility"]:
        raise ValueError(f"Task {summary['run_id']!r}: timing runs must stop on utility (stop_on_utility true).")
    tolerance = float(config["tolerance"])
    report_tolerance = task.get("report_tolerance")
    if report_tolerance is not None and float(report_tolerance) != tolerance:
        raise ValueError(f"Task {summary['run_id']!r}: report_tolerance {report_tolerance} differs from the "
                         f"pipeline tolerance {tolerance} of a utility-stopped run.")
    timings = metrics["timings"]
    components = {field: float(timings[field]) for field in ALGORITHM_TIME_FIELDS}
    rounds = int(metrics["iteration_count"])
    stopped = metrics["termination_condition"] == "loss_threshold_met"
    seconds = math.fsum(components.values())
    runtime = {
        "schema_version": "trim_runtime_stop.v2",
        "run_id": summary["run_id"],
        "run_dir": str(run_dir),
        "tolerance": tolerance,
        "termination_condition": metrics["termination_condition"],
        "stopped": stopped,
        "stop_iteration": rounds - 1 if stopped else None,
        "algorithm_time_seconds": seconds if stopped else None,
        **{field: components[field] if stopped else None for field in ALGORITHM_TIME_FIELDS},
        "final_test_delta_u": (None if metrics.get("final_actual_model_loss") is None
                               else float(metrics["final_actual_model_loss"]) - float(metrics["baseline_test_loss"])),
        "final_validation_delta_u": (None if metrics.get("target_validation_loss") is None
                                     else float(metrics["target_validation_loss"]) - float(metrics["baseline_val_loss"])),
    }
    write_json(run_dir / "paper_runtime.json", runtime)
    return {
        "report_tolerance": tolerance,
        "runtime_stopped": stopped,
        "runtime_stop_iteration": runtime["stop_iteration"],
        "paper_algorithm_time_seconds": runtime["algorithm_time_seconds"],
    }
