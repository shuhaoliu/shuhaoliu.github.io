"""Exp-3 runners: real-data runtime (Fig. 5c) and BNG scalability (Fig. 5d)."""
