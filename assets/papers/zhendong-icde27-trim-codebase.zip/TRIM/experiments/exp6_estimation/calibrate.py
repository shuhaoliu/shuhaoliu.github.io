"""Fit eta on seeds 47--49, freeze it, then evaluate seeds 42--46.

Calibration minimizes pooled candidate utility absolute error. Reporting pools
candidates within a seed, then gives each evaluation seed equal weight.
Neither TRIM nor IF is calibrated. This compares empirical estimators, not
equivalent theoretical quantities or a guaranteed conservative advantage.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
from collections import defaultdict
from pathlib import Path

CALIBRATION_SEEDS = {47, 48, 49}
EVALUATION_SEEDS = {42, 43, 44, 45, 46}
METHODS = {"trim", "if", "lga", "retrain"}


def fit_eta(rows):
    """Lower weighted median of b/a, with weights |a|; zero a adds a constant."""
    if {int(row["seed"]) for row in rows} != CALIBRATION_SEEDS:
        raise ValueError("Fit eta only on independent calibration seeds 47--49.")
    pairs = [(float(row["raw_lga_score"]), float(row["actual_utility_delta"]))
             for row in rows if row["method"] == "lga"]
    if not pairs or any(not math.isfinite(a) or not math.isfinite(b) for a, b in pairs):
        raise ValueError("Calibration requires finite paired LGA and target gains.")
    ratios = sorted((b / a, abs(a)) for a, b in pairs if a != 0.0)
    if any(not math.isfinite(ratio) for ratio, _ in ratios):
        raise ValueError("Calibration ratios overflowed.")
    result = {
        "objective": "pooled_candidate_utility_absolute_error",
        "tie_rule": "lower_weighted_median",
        "candidate_count": len(pairs),
        "zero_score_count": sum(a == 0.0 for a, _ in pairs),
    }
    if not ratios:
        return {**result, "status": "failed", "eta": None,
                "reason": "all_raw_lga_scores_zero"}
    half = math.fsum(weight for _, weight in ratios) / 2.0
    cumulative = 0.0
    eta = None
    for ratio, weight in ratios:
        cumulative += weight
        if cumulative >= half:
            eta = ratio
            break
    if eta is None or eta <= 0.0:
        # In a tied interval there may be positive minimizers. This is a
        # failure of the specified lower-median rule, not proof none exist.
        return {**result, "status": "failed", "eta": None,
                "lower_minimizer": eta, "reason": "nonpositive_lower_minimizer"}
    return {**result, "status": "ok", "eta": eta,
            "calibration_utility_mae": math.fsum(abs(eta * a - b) for a, b in pairs) / len(pairs)}


def read_experiment(directory, expected_seeds):
    directory = Path(directory)
    manifest = json.loads((directory / "manifest.json").read_text())
    phase = "calibration" if expected_seeds == CALIBRATION_SEEDS else "evaluation"
    if manifest.get("calibration", {}).get("protocol") != "independent_seeds" or manifest["calibration"].get("phase") != phase:
        raise ValueError(f"Expected the independent-seed {phase} phase.")
    runs = manifest["runs"]
    if {int(run["seed"]) for run in runs} != expected_seeds or len(runs) != len(expected_seeds):
        raise ValueError(f"Expected exactly seeds {sorted(expected_seeds)}.")
    if manifest.get("experiment") != "exp6_estimation":
        raise ValueError("Expected a Fig. 5j estimation experiment.")
    rows, summaries, hashes, protocols = [], [], {}, []
    for run in runs:
        seed = int(run["seed"])
        candidate_path = directory / f"seed_{seed}_estimates_candidate_estimates.csv"
        summary_path = directory / f"seed_{seed}_estimates.csv"
        hashes[candidate_path.name] = hashlib.sha256(candidate_path.read_bytes()).hexdigest()
        hashes[summary_path.name] = hashlib.sha256(summary_path.read_bytes()).hexdigest()
        with candidate_path.open(newline="", encoding="utf-8") as handle:
            seed_rows = list(csv.DictReader(handle))
        with summary_path.open(newline="", encoding="utf-8") as handle:
            seed_summaries = list(csv.DictReader(handle))
        if not seed_rows or any(int(row["seed"]) != seed for row in seed_rows + seed_summaries):
            raise ValueError("Empty or mislabeled seed CSV.")
        groups = defaultdict(dict)
        for row in seed_rows:
            key = (int(row["iteration"]), row["candidate_type"], row["candidate_id"])
            method = row["method"]
            if method not in METHODS or method in groups[key]:
                raise ValueError("Unknown or duplicate paired candidate method.")
            if row["candidate_pool"] != "paired_proxy_evaluated_candidates":
                raise ValueError("Unexpected candidate measurement pool.")
            for field in ("raw_lga_score", "actual_utility_delta", "actual_rho", "privacy_cost"):
                if not math.isfinite(float(row[field])):
                    raise ValueError(f"Non-finite {field}.")
            if float(row["privacy_cost"]) <= 0:
                raise ValueError("Privacy cost must be positive.")
            groups[key][method] = row
        for group in groups.values():
            if set(group) != METHODS:
                raise ValueError("Methods do not share the same candidate pool.")
            for field in ("raw_lga_score", "actual_utility_delta", "actual_rho", "privacy_cost"):
                if len({float(row[field]) for row in group.values()}) != 1:
                    raise ValueError(f"Paired candidate mismatch: {field}.")
        run_dir = directory / "runs" / f"seed_{seed}" / Path(run["run_dir"]).name
        config = json.loads((run_dir / "config.json").read_text())
        if config.get("test_evaluated") is not False or config.get("validation_only") is not True:
            raise ValueError("Calibration and evaluation must use validation_only runs.")
        protocols.append({
            "dataset": manifest["dataset"], "model": config["model"],
            "tree_sha256": config["generalization_tree_sha256"],
            "input_sha256": config["input_data_sha256"],
            **{key: config.get(key) for key in (
                "nrows", "val_size", "test_size", "tolerance", "privacy_cost_floor",
                "rank_top_k", "max_iterations",
                "initial_sample_fraction", "initial_sample_size", "release_target_k",
                "stop_on_utility", "device", "dtype")},
            "influence_model": manifest.get("influence_model"),
            "influence_solver": manifest.get("influence_solver"),
            "oracle_candidate_limit_per_type": manifest.get("oracle_candidate_limit_per_type"),
        })
        rows.extend(seed_rows)
        summaries.extend(seed_summaries)
    if any(protocol != protocols[0] for protocol in protocols):
        raise ValueError("Seed runs use different experimental settings.")
    return rows, summaries, hashes, protocols[0]


def apply_eta(rows, summaries, calibration):
    if calibration.get("status") != "ok" or not math.isfinite(float(calibration["eta"])) or float(calibration["eta"]) <= 0:
        raise ValueError("Calibration failed; no positive eta is available.")
    if set(calibration["calibration_seeds"]) != CALIBRATION_SEEDS:
        raise ValueError("Eta must be fitted independently on seeds 47--49.")
    if {int(row["seed"]) for row in rows} != EVALUATION_SEEDS:
        raise ValueError("Apply the frozen eta only to seeds 42--46.")
    if {int(row["seed"]) for row in summaries} != EVALUATION_SEEDS:
        raise ValueError("Summary CSVs must contain evaluation seeds 42--46 only.")
    eta = float(calibration["eta"])
    calibrated = []
    by_iteration = defaultdict(list)
    for original in rows:
        row = dict(original)
        if row["method"] == "lga":
            estimate = eta * float(row["raw_lga_score"])
            rho = estimate / float(row["privacy_cost"])
            row.update(estimated_utility_delta=estimate, estimated_rho=rho,
                       utility_abs_error=abs(estimate - float(row["actual_utility_delta"])),
                       score_abs_error=abs(rho - float(row["actual_rho"])),
                       calibration_status="independent_seeds", eta=eta)
        else:
            row["eta"] = None
        calibrated.append(row)
        by_iteration[(int(row["seed"]), int(row["iteration"]), row["method"])].append(row)
    output = []
    seen = set()
    for original in summaries:
        row = dict(original)
        key = (int(row["seed"]), int(row["iteration"]), row["method"])
        if key in seen or key not in by_iteration:
            raise ValueError("Missing or duplicate summary group.")
        seen.add(key)
        group = by_iteration[key]
        if int(row["evaluated_candidate_count"]) != len(group):
            raise ValueError("Summary count differs from paired candidate CSV.")
        row["utility_mae"] = math.fsum(float(r["utility_abs_error"]) for r in group) / len(group)
        row["score_mae"] = math.fsum(float(r["score_abs_error"]) for r in group) / len(group)
        row["calibration_status"] = "independent_seeds" if row["method"] == "lga" else "uncalibrated"
        row["eta"] = eta if row["method"] == "lga" else None
        if row["method"] == "lga":
            selected = next((r for r in group if
                             r["candidate_type"] == row["selected_candidate_type"] and
                             r["candidate_id"] == row["selected_candidate_id"]), None)
            if selected is None:
                raise ValueError("Selected LGA diagnostic is outside the paired pool.")
            for field in ("estimated_utility_delta", "estimated_rho", "utility_abs_error", "score_abs_error"):
                row[field] = selected[field]
        output.append(row)
    if seen != set(by_iteration):
        raise ValueError("Incomplete summary matrix.")
    return calibrated, output


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    fit = commands.add_parser("fit")
    fit.add_argument("--calibration-dir", required=True)
    fit.add_argument("--output", required=True)
    apply = commands.add_parser("apply")
    apply.add_argument("--calibration", required=True)
    apply.add_argument("--evaluation-dir", required=True)
    apply.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    if args.command == "fit":
        rows, _, hashes, protocol = read_experiment(args.calibration_dir, CALIBRATION_SEEDS)
        calibration = {**fit_eta(rows), "schema_version": "exp6_estimation_eta.v1",
                       "calibration_seeds": sorted(CALIBRATION_SEEDS),
                       "evaluation_seeds": sorted(EVALUATION_SEEDS),
                       "input_sha256": hashes, "protocol": protocol}
        with Path(args.output).open("x", encoding="utf-8") as handle:
            json.dump(calibration, handle, indent=2, sort_keys=True)
            handle.write("\n")
        print(json.dumps({"status": calibration["status"], "eta": calibration["eta"]}))
        if calibration["status"] != "ok":
            raise SystemExit(2)
    else:
        calibration = json.loads(Path(args.calibration).read_text())
        rows, summaries, hashes, protocol = read_experiment(args.evaluation_dir, EVALUATION_SEEDS)
        if protocol != calibration["protocol"]:
            raise ValueError("Calibration and evaluation settings differ.")
        candidates, summary = apply_eta(rows, summaries, calibration)
        output_dir = Path(args.output_dir)
        output_dir.mkdir(parents=True, exist_ok=False)
        for name, data in (("candidate_estimates.csv", candidates), ("estimates.csv", summary)):
            columns = list(dict.fromkeys(key for row in data for key in row))
            with (output_dir / name).open("w", newline="", encoding="utf-8") as handle:
                writer = csv.DictWriter(handle, fieldnames=columns)
                writer.writeheader()
                writer.writerows(data)
        (output_dir / "calibration.json").write_text(json.dumps(calibration, indent=2, sort_keys=True) + "\n")
        (output_dir / "manifest.json").write_text(json.dumps({
            "test_evaluated": False, "eta_refitted_on_evaluation": False,
            "evaluation_seeds": sorted(EVALUATION_SEEDS), "input_sha256": hashes,
            "calibration_artifact_sha256": hashlib.sha256(Path(args.calibration).read_bytes()).hexdigest(),
            "reporting": "candidate_mean_per_seed_then_equal_seed_mean",
            "lga_label": "LGA (calibrated)", "other_estimators": "uncalibrated",
        }, indent=2, sort_keys=True) + "\n")
        print(output_dir)


if __name__ == "__main__":
    main()
