"""Fig. 5j: end-to-end utility estimation of TRIM, LGA, IF and Retrain (Exp-6)."""
