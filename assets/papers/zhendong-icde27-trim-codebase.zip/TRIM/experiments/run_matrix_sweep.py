"""Expand the named axes of a matrix configuration into its Cartesian product of tasks."""

from __future__ import annotations

from itertools import product
import re

from .common import merge_mappings


def _safe_token(value) -> str:
    token = re.sub(r"[^A-Za-z0-9_-]+", "_", str(value)).strip("_")
    if not token:
        raise ValueError(f"Axis label cannot be converted to a run-id token: {value!r}")
    return token


def expand_matrix(config: dict) -> list[dict]:
    base_task = config.get("base_task") or {}
    if not isinstance(base_task, dict):
        raise ValueError("base_task must be a YAML mapping.")
    axes = config.get("axes")
    if not isinstance(axes, list) or not axes:
        raise ValueError("Matrix config must contain a non-empty axes list.")

    normalized_axes = []
    for axis in axes:
        if not isinstance(axis, dict):
            raise ValueError("Every axis must be a YAML mapping.")
        name = _safe_token(axis.get("name", ""))
        values = axis.get("values")
        if not isinstance(values, list) or not values:
            raise ValueError(f"Axis {name!r} must have a non-empty values list.")
        normalized_values = []
        for value in values:
            if not isinstance(value, dict):
                raise ValueError(
                    f"Every value in axis {name!r} must contain label and patch."
                )
            if "label" not in value or "patch" not in value:
                raise ValueError(
                    f"Every value in axis {name!r} must contain label and patch."
                )
            if not isinstance(value["patch"], dict):
                raise ValueError(f"Axis {name!r} value patch must be a mapping.")
            normalized_values.append(
                {
                    "label": _safe_token(value["label"]),
                    "patch": value["patch"],
                }
            )
        normalized_axes.append((name, normalized_values))

    run_prefix = _safe_token(config.get("run_prefix") or config.get("experiment_id"))
    tasks = []
    for combination in product(*(values for _name, values in normalized_axes)):
        task = merge_mappings({}, base_task)
        run_parts = [run_prefix]
        axis_values = {}
        for (axis_name, _values), selected in zip(normalized_axes, combination):
            task = merge_mappings(task, selected["patch"])
            run_parts.extend((axis_name, selected["label"]))
            axis_values[axis_name] = selected["label"]
        task["run_id"] = "_".join(run_parts)
        task["axis_values"] = axis_values
        tasks.append(task)

    run_ids = [task["run_id"] for task in tasks]
    if len(run_ids) != len(set(run_ids)):
        raise ValueError("Matrix expansion produced duplicate run IDs.")
    return tasks
