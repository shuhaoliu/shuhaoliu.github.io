"""Run the global-recoding KAnon baseline (TDS) on the shared Exp-1 matrix."""

from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import os
from pathlib import Path
import time

import numpy as np

from experiments.common import (
    append_jsonl, create_experiment_dir, load_yaml_mapping, resolve_project_path,
    write_csv_rows, write_json,
)
from experiments.exp1_kanon.hierarchy import HierarchySchema
from experiments.run_matrix_sweep import expand_matrix
from prototype.TRIM_prototype_pipeline import _loaded_input_sha256
from prototype.backend_training import fit_standardizer
from prototype.dataloader import load_generalization_rules_from_file
from prototype.dataset_registry import build_data_loader, resolve_dataset, resolve_generalization_tree
from prototype.gpu_math import classification_log_loss_tensor, to_device_tensor
from prototype.model_factory import build_model_factory
from prototype.privacy_metrics import individual_tail_risk_stats, original_equivalence_class_sizes
from prototype.release_artifacts import load_dataset_split

from .tds import EVALUATION_POLICY, FittedTDS


def k_grid(n_train, *, extras=(12, 235), explicit=None):
    """Powers of two through N_train/2, additional comparison Ks, and N_train."""
    if n_train < 2:
        raise ValueError("The sweep needs at least two training records.")
    if explicit is not None:
        values = list(explicit)
    else:
        values = [n_train]
        value = 2
        while value <= n_train // 2:
            values.append(value)
            value *= 2
        values.extend(value for value in extras if 2 <= value <= n_train)
    if not values or any(isinstance(value, bool) or int(value) != value or not 2 <= value <= n_train for value in values):
        raise ValueError("Sweep Ks must be integers in [2, N_train]; raw reference is separate.")
    return sorted({int(value) for value in values})


def load_release_payload(path):
    """Read a compressed shared release, or the per-model reference that points to one."""
    path = Path(path)
    if path.suffix == ".gz":
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            payload = json.load(handle)
    else:
        payload = json.loads(path.read_text(encoding="utf-8"))
    if payload.get("schema_version") == "kanon_release_reference.v1":
        shared_path = Path(payload["shared_release_path"])
        if not shared_path.is_absolute():
            shared_path = path.parent / shared_path
        digest = hashlib.sha256(shared_path.read_bytes()).hexdigest()
        if digest != payload["shared_release_sha256"]:
            raise ValueError("Shared KAnon release checksum differs from its reference.")
        shared = load_release_payload(shared_path)
        if shared.get("cache_key") != payload["cache_key"]:
            raise ValueError("Shared KAnon release identity differs from its reference.")
        return shared
    return payload


def implementation_sha256():
    """Identify the anonymizer, the shared hierarchy schema and the shared protocol."""
    from prototype import backend_training, dataloader, gpu_math, gpu_mlp, gpu_xgboost, model_factory, privacy_metrics, release_artifacts
    from experiments.exp1_kanon import hierarchy
    from . import tds

    digest = hashlib.sha256()
    digest.update(Path(__file__).read_bytes())
    for module in (
        tds, hierarchy, backend_training, dataloader, gpu_math, gpu_mlp,
        gpu_xgboost, model_factory, privacy_metrics, release_artifacts,
    ):
        digest.update(Path(module.__file__).read_bytes())
    return digest.hexdigest()


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    parser.add_argument("--device")
    parser.add_argument("--run-label")
    parser.add_argument("--k", action="append", type=int, help="Explicit K; repeat to replace the grid.")
    parser.add_argument("--dataset", action="append", help="Run only this dataset; repeat for several.")
    parser.add_argument("--model", action="append", help="Run only this model name; repeat for several.")
    parser.add_argument("--seed", action="append", type=int, help="Run only this seed; repeat for several.")
    args = parser.parse_args(argv)
    config_path, config = load_yaml_mapping(args.config)
    if config.get("experiment_kind") != "exp1_kanon_global":
        raise ValueError("Expected experiment_kind: exp1_kanon_global.")
    matrix_path, matrix_config = load_yaml_mapping(resolve_project_path(config["matrix_config"]))
    if matrix_config.get("experiment_kind") != "exp1_privacy_utility":
        raise ValueError("matrix_config must declare the shared Exp-1 matrix.")
    code_hash = implementation_sha256()
    datasets = {resolve_dataset(name).key for name in args.dataset} if args.dataset else None
    tasks = [
        task for task in expand_matrix(matrix_config)
        if (datasets is None or resolve_dataset(task["dataset"]).key in datasets)
        and (not args.model or task.get("model_name", task["model"]["downstream"]["family"]) in args.model)
        and (not args.seed or int((task.get("pipeline") or {}).get("random_state", 42)) in args.seed)
    ]
    if not tasks:
        raise ValueError("No matrix task matches the dataset, model and seed filters.")
    experiment_dir = create_experiment_dir(config["results_root"], "exp1_kanon_global", run_label=args.run_label)
    manifest = {
        "schema_version": "kanon_global_sweep.v1", "status": "running",
        "method": "KAnonGlobal", "variant": "tds", "algorithm": "top_down_specialization",
        "config_path": str(config_path), "matrix_path": str(matrix_path),
        "configuration": config, "matrix_configuration": matrix_config,
        "filters": {"dataset": args.dataset, "model": args.model, "seed": args.seed, "k": args.k},
        "implementation_sha256": code_hash, "tasks": tasks,
        "tail_risk_population": "training_split",
        "original_privacy_population": "training_split",
        "release_storage": "shared_compact_json_gzip_with_per_model_references",
        "evaluation_policy": EVALUATION_POLICY,
    }
    write_json(experiment_dir / "manifest.json", manifest)
    release_dir = experiment_dir / "shared_releases"
    release_dir.mkdir()
    raw_rows, plot_rows = [], []
    try:
        for task in tasks:
            dataset = resolve_dataset(task["dataset"]).key
            split_config = dict(task.get("pipeline") or {})
            seed = int(split_config.get("random_state", 42))
            family = task["model"]["downstream"]["family"]
            if family not in {"mlp", "xgboost"}:
                raise ValueError("Exp-1 KAnon supports MLP and XGBoost downstream models.")
            device = args.device or task.get("device", "cuda")
            dtype = task.get("dtype", "float32")
            cpu_fallback = bool(task.get("allow_cpu_fallback", True))
            loader = build_data_loader(dataset, data_path=resolve_project_path(task.get("data_path")))
            split = load_dataset_split(loader, split_config)
            original_X, original_y = loader.X_raw, loader.y
            classes = np.unique(split.y_train.to_numpy())
            if len(classes) < 2:
                raise ValueError("The downstream classification reference needs at least two training classes.")
            tree_path = resolve_generalization_tree(
                dataset, resolve_project_path(task.get("generalization_tree_path")),
            )
            tree_hash = hashlib.sha256(tree_path.read_bytes()).hexdigest()
            generalization = load_generalization_rules_from_file(tree_path, loader, generalization_level=0)
            schema = HierarchySchema(generalization)
            input_hash = _loaded_input_sha256(original_X, original_y)
            training_hash = _loaded_input_sha256(split.X_train_raw, split.y_train)
            model_spec = dict(task["model"]["downstream"])
            if model_spec.get("warm_start"):
                raise ValueError("Every K point must train a fresh model; warm_start must be false.")
            protocol = {
                "loaded_input_sha256": input_hash, "tree_sha256": tree_hash,
                "model": model_spec, "device": device, "dtype": dtype,
                "allow_cpu_fallback": cpu_fallback,
                "split": {key: split_config.get(key, default) for key, default in (
                    ("nrows", None), ("val_size", 0.15), ("test_size", 0.15),
                )},
                "encoding": "shared_leaf_space_with_level_or_shared_mlp_means",
                "anonymizer": "tds_global_recoding",
                "evaluation_policy": EVALUATION_POLICY,
                "privacy_population": "training_split",
                "original_privacy_encoding": "raw_qis",
            }
            signature = hashlib.sha256(json.dumps(protocol, sort_keys=True).encode()).hexdigest()
            task_dir = experiment_dir / task["run_id"]
            task_dir.mkdir()
            write_json(task_dir / "config.json", {
                "task": task, "protocol": protocol, "protocol_sha256": signature,
                "seed": seed, "preprocessing": getattr(loader, "preprocessing_metadata", {}),
                "qi_attributes": list(loader.qi_attributes),
                "train_row_ids": split.X_train_raw.index.tolist(),
                "validation_row_ids": split.X_val_raw.index.tolist(),
                "test_row_ids": split.X_test_raw.index.tolist(),
            })
            original_sizes = original_equivalence_class_sizes(split.X_train_raw, loader.qi_attributes)
            original_k = int(original_sizes.min())
            original_tail = individual_tail_risk_stats(split.X_train_raw.index, original_sizes)["tail_risk_p99"]
            level0_train = generalization.encode(split.X_train_raw)
            standardizer = fit_standardizer(level0_train, loader)
            # Match TRIM's tensor dtype before standardization for MLP.
            def model_input(frame, groups=None):
                encoded = (
                    schema.encode(frame, groups, family=family) if groups is not None
                    else generalization.encode_xgboost_leaf_space(frame).toarray() if family == "xgboost"
                    else generalization.encode(frame)
                )
                if family == "xgboost":
                    return np.ascontiguousarray(encoded, dtype=np.float32)
                return standardizer.transform(to_device_tensor(
                    encoded, device=device, dtype=dtype, allow_cpu_fallback=cpu_fallback,
                ))

            factory = build_model_factory(
                model_spec, device=device, dtype=dtype, allow_cpu_fallback=cpu_fallback,
                random_state=seed, role="downstream",
            )
            def losses(train_input, validation_input, test_input):
                model = factory()
                model.set_classes(classes)
                model.fit(train_input, split.y_train)
                output = {}
                for name, labels, encoded in [
                    ("validation", split.y_val, validation_input),
                    ("test", split.y_test, test_input),
                ]:
                    probabilities = model.predict_proba_tensor(encoded)
                    target = to_device_tensor(labels, device=probabilities.device, dtype=probabilities.dtype)
                    output[name] = float(classification_log_loss_tensor(
                        target, probabilities, classes=classes, n_classes=len(classes),
                    ).detach().cpu())
                    if not np.isfinite(output[name]):
                        raise ValueError(f"{name} loss is nonfinite; check model inputs and training.")
                return output

            reference = losses(
                model_input(split.X_train_raw), model_input(split.X_val_raw), model_input(split.X_test_raw),
            )
            write_json(task_dir / "reference.json", {
                **reference, "original_leak_k": original_k, "original_tail_risk_p99": original_tail,
                "train_size": len(split.X_train_raw), "loaded_size": len(original_X),
                "privacy_population": "training_split", "privacy_population_size": len(split.X_train_raw),
                "standardizer_mean": getattr(standardizer, "mean", np.array([])).tolist(),
                "standardizer_std": getattr(standardizer, "std", np.array([])).tolist(),
            })
            sweep = config.get("sweep") or {}
            ks = k_grid(len(split.X_train_raw), extras=sweep.get("extra_k", [12, 235]), explicit=args.k or sweep.get("k_values"))
            for k in ks:
                # MLP and XGBoost tasks with the same data, tree and K share one release.
                identity = {
                    "dataset": dataset, "seed": seed, "algorithm": "tds", "k": k,
                    "training_data_sha256": training_hash, "tree_sha256": tree_hash,
                    "implementation_sha256": code_hash,
                }
                cache_key = hashlib.sha256(json.dumps(identity, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
                release_path = release_dir / f"{cache_key}.json.gz"
                cache_hit = release_path.exists()
                started = time.perf_counter()
                if cache_hit:
                    payload = load_release_payload(release_path)
                    if payload.get("cache_identity") != identity or payload["training_row_ids"] != split.X_train_raw.index.tolist():
                        raise ValueError("Cached TDS release has a different training protocol.")
                    fitted = FittedTDS.from_dict(schema, payload)
                else:
                    fitted = FittedTDS(schema, k=k).fit(split.X_train_raw, split.y_train)
                    payload = {
                        **fitted.to_dict(), "cache_identity": identity, "cache_key": cache_key,
                        "partition_seconds": time.perf_counter() - started,
                    }
                    partial_path = release_path.with_suffix(release_path.suffix + ".partial")
                    with gzip.open(partial_path, "wt", encoding="utf-8", compresslevel=6) as handle:
                        json.dump(payload, handle, sort_keys=True, separators=(",", ":"))
                    partial_path.replace(release_path)
                tree_cache_seconds = time.perf_counter() - started
                point_dir = task_dir / "tds" / f"k_{k}"
                write_json(point_dir / "release.json", {
                    "schema_version": "kanon_release_reference.v1",
                    "shared_release_path": os.path.relpath(release_path, point_dir),
                    "shared_release_sha256": hashlib.sha256(release_path.read_bytes()).hexdigest(),
                    "cache_key": cache_key, "protocol_sha256": signature,
                    "tree_sha256": tree_hash, "loaded_input_sha256": input_hash,
                })
                sizes = fitted.per_record_k(split.X_train_raw.index)
                tail = individual_tail_risk_stats(split.X_train_raw.index, sizes)
                val_groups = fitted.transform_groups(split.X_val_raw)
                test_groups = fitted.transform_groups(split.X_test_raw)
                val_stats = fitted.evaluation_stats(val_groups, len(split.X_val_raw))
                test_stats = fitted.evaluation_stats(test_groups, len(split.X_test_raw))
                write_json(point_dir / "evaluation_diagnostics.json", {
                    "policy": EVALUATION_POLICY, "validation": val_stats, "test": test_stats,
                })
                started = time.perf_counter()
                outcome = losses(
                    model_input(split.X_train_raw, fitted.partitions),
                    model_input(split.X_val_raw, val_groups),
                    model_input(split.X_test_raw, test_groups),
                )
                row = {
                    "experiment": "exp1_privacy_utility", "method": "KAnonGlobal", "variant": "tds",
                    "dataset": dataset, "model": task.get("model_name", family),
                    "seed": seed, "point": k, "target_k": k, "evaluation_split": "test",
                    "validation_loss": outcome["validation"],
                    "validation_delta_u": outcome["validation"] - reference["validation"],
                    "baseline_validation_loss": reference["validation"],
                    "test_loss": outcome["test"], "baseline_test_loss": reference["test"],
                    "test_delta_u": outcome["test"] - reference["test"],
                    "min_k": int(sizes.min()), "original_leak_k": original_k,
                    "privacy_delta_h": -float(np.log(sizes.min() / original_k)),
                    **tail, "original_tail_risk_p99": original_tail,
                    "row_count": len(sizes), "coverage_fraction": 1.0,
                    "suppressed_row_count": 0, "partition_count": len(fitted.partitions),
                    "specialization_count": len(fitted.history),
                    **{
                        f"{split_name}_{field}": stats[field]
                        for split_name, stats in [("validation", val_stats), ("test", test_stats)]
                        for field in ("group_count", "unseen_class_record_count", "unseen_class_record_fraction")
                    },
                    "evaluation_policy": EVALUATION_POLICY,
                    "partition_seconds": 0.0 if cache_hit else payload["partition_seconds"],
                    "tree_cache_hit": cache_hit,
                    "tree_cache_seconds": tree_cache_seconds,
                    "original_partition_seconds": payload["partition_seconds"],
                    "shared_release_bytes": release_path.stat().st_size,
                    "shared_release_path": str(release_path),
                    "model_evaluation_seconds": time.perf_counter() - started,
                    "protocol_sha256": signature, "release_path": str(point_dir / "release.json"),
                }
                write_json(point_dir / "metrics.json", row)
                append_jsonl(experiment_dir / "raw_results.jsonl", row)
                raw_rows.append(row)
                for metric, value, reference_value in [
                    ("min_k", row["min_k"], original_k),
                    ("tail_risk_p99", tail["tail_risk_p99"], original_tail),
                ]:
                    plot_rows.append({
                        **row, "x_metric": "test_delta_u", "x_value": row["test_delta_u"],
                        "y_metric": metric, "y_value": value, "y_reference": reference_value,
                    })
                print(
                    f'{task["run_id"]} TDS K={k}: test_delta={row["test_delta_u"]:.6g}, '
                    f'min_k={row["min_k"]}, steps={row["specialization_count"]}',
                    flush=True,
                )
            # Save incrementally so completed tasks remain reviewable after interruption.
            write_csv_rows(experiment_dir / "raw_results.csv", raw_rows)
            write_csv_rows(experiment_dir / "baseline_long.csv", plot_rows)
        manifest["status"] = "complete"
        manifest["raw_point_count"] = len(raw_rows)
        write_json(experiment_dir / "manifest.json", manifest)
    except Exception as exc:
        manifest.update({"status": "failed", "error": str(exc)})
        write_json(experiment_dir / "manifest.json", manifest)
        raise
    print(experiment_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
