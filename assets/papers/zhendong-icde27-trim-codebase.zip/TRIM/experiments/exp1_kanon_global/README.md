# Global-recoding KAnon baseline (TDS)

This package is the k-anonymization baseline (KAnon) whose releases lie in
TRIM's output space: every QI value is replaced by a node of the shared
hierarchy, and equal raw values always receive the same released node (global
recoding). `tds_maxsup.py` adds a suppression budget for the DPSGD table
(`experiments/exp1_dp`).

## Algorithm

Top-down specialization (TDS), Fung, Wang and Yu, ICDE 2005:

1. Start with every QI of every training record at its hierarchy root.
2. A specialization replaces one released node by its children for all
   records under it. Once a root is specialized, missing values form their
   own branch.
3. A specialization is valid if every equivalence class over all QIs keeps at
   least K records, and beneficial if the node's records carry more than one
   label.
4. Take the valid and beneficial specialization with the highest
   Score = InfoGain / (AnonyLoss + 1), where InfoGain is the reduction of
   label entropy (bits) among the node's records and AnonyLoss is the drop of
   the smallest class size. Ties prefer the larger InfoGain, then the earlier
   QI and node in the hierarchy file.
5. Stop when no valid and beneficial specialization remains. A step with zero
   InfoGain is still taken while one remains.

Deviation from the original TDS: numeric QIs use the fixed shared hierarchies
instead of intervals grown during the search, so that releases are hierarchy
nodes, as in TRIM. Cuts may still differ in depth across branches of one
hierarchy, as in the original algorithm.

There is no suppression: every training record is published once. Labels and
non-QI predictors are unchanged.

## Evaluation

Validation and test records are released through the same fitted cut. A
record whose value never occurred in training receives the cut node that
contains it. `evaluation_diagnostics.json` counts evaluation records whose
released QI vector matches no training class.

Encodings are those of `experiments/exp1_kanon/hierarchy.py`
(`HierarchySchema`): the shared XGBoost leaf space with one level column per
QI, and the shared MLP means. A record at a hierarchy node therefore has the
same model input as in TRIM at that node. Privacy uses the same training-split
population and P99 tail risk as TRIM.

## Running

The K grid is the powers of two from 2 to N_train/2, 12, 235 and N_train;
`--k` replaces it. Every runner call starts with an empty release cache, so
every K is fitted.

```bash
# Fig. 4: all datasets, models and seeds of the matrix
python -m experiments.exp1_kanon_global.run --config configs/paper/fig4/tds.yaml

# Fig. 5c: one timed call per dataset and seed, MLP target, one call per GPU
CUDA_VISIBLE_DEVICES=0 python -m experiments.exp1_kanon_global.run --config configs/paper/fig5c/tds.yaml \
  --dataset income --model mlp --seed 42

# Fig. 5d: one timed call per BNG size and seed, XGBoost target
CUDA_VISIBLE_DEVICES=0 python -m experiments.exp1_kanon_global.run --config configs/paper/fig5d/tds_n120000.yaml \
  --dataset bng --model xgboost --seed 42

# Fig. 5g: one call per seed, every distinct release between the most private grid release within
# test Delta U <= 0.07 and the next grid K (PubCov, MLP target), after the Fig. 4 sweep
python scripts/tds_k_walk.py --config configs/paper/fig5g/tds_walk.yaml --sweep-results results/fig4/tds \
  --dataset pubcov --model mlp --seed 42 --tolerance 0.07
```

A TDS release for K whose smallest class has m records is also TDS's release
for every K' in [K, m], so `tds_k_walk.py` steps K = m + 1 and meets every
distinct release in that range once.

Fig. 5c and 5d use the K loop's time: from the task's `reference.json` to the
last K's `metrics.json` (both under the run directory), which leaves out start
up, data loading and the reference fit, as for the other baselines.

Each call writes a run directory under the configuration's `results_root`
with `manifest.json`, `raw_results.csv` and `raw_results.jsonl` (one row per
task and K, `method=KAnonGlobal`, `variant=tds`), `baseline_long.csv` (the
plotter's long rows), and per task `reference.json` and
`tds/k_<K>/{metrics.json,release.json,evaluation_diagnostics.json}`. The shared
release in `shared_releases/` holds the final cut per QI, the partitions and
the ordered list of specializations with their scores.

Tests are in `tests/test_kanon_global_tds.py` and
`tests/test_kanon_global_tds_maxsup.py`.
