"""Global-recoding KAnon by top-down specialization with a suppression budget (TDS + MaxSup).

KAnon with full coverage only generalizes, while TRIM may leave records out. This variant of
`tds.FittedTDS` (the KAnon row with a suppression budget in the DPSGD table) keeps TDS's search
(Fung, Wang and Yu, ICDE 2005; same hierarchies, same Score = InfoGain / (AnonyLoss + 1)) and adds
Samarati's MaxSup: a specialization is valid when the records of the classes that fall below k after
it, added to those already suppressed, number at most `max_suppressed` (a fraction of the training
rows). Records of classes below k are suppressed (not published); the anonymity loss is measured on
the published classes. With `max_suppressed = 0` it equals TDS.
"""

from __future__ import annotations

from copy import deepcopy

import numpy as np
import pandas as pd

from experiments.exp1_kanon.hierarchy import _entropy
from experiments.exp1_kanon_global.tds import FittedTDS


class FittedTDSMaxSup(FittedTDS):
    def __init__(self, schema, *, k, max_suppressed_fraction):
        super().__init__(schema, k=k)
        if not 0.0 <= float(max_suppressed_fraction) < 1.0:
            raise ValueError("max_suppressed_fraction must lie in [0, 1).")
        self.max_suppressed_fraction = float(max_suppressed_fraction)
        self.published_partitions, self.suppressed_positions = [], []

    def fit(self, X, y):
        if not X.index.is_unique or len(X) < self.k:
            raise ValueError("Training IDs must be unique and N_train must be at least k.")
        if not isinstance(y, pd.Series) or not y.index.equals(X.index) or y.isna().any():
            raise ValueError("Labels must be nonmissing and aligned with training IDs.")
        budget = int(np.floor(self.max_suppressed_fraction * len(X)))
        leaf = self._leaf_positions(X)
        labels, classes = pd.factorize(y, sort=True)
        label_count = len(classes)
        attributes = self.schema.attributes
        current = {a: np.full(len(X), self.trees[a]["root"], dtype=np.int64) for a in attributes}
        cut = {a: {self.trees[a]["root"]} for a in attributes}
        class_ids = np.zeros(len(X), dtype=np.int64)
        unset = np.iinfo(np.int64).max
        self.history = []
        while True:
            class_sizes = np.bincount(class_ids)
            retained = class_sizes >= self.k
            suppressed_now = int(class_sizes[~retained].sum())
            current_k = int(class_sizes[retained].min())
            best = None
            for order, attribute in enumerate(attributes):
                tree = self.trees[attribute]
                node_count = len(tree["ids"])
                nodes = current[attribute]
                child = self._children_of(attribute, nodes, leaf[attribute])
                movable = child >= 0
                if not movable.any():
                    continue
                class_nodes = np.empty(len(class_sizes), dtype=np.int64)
                class_nodes[class_ids] = nodes
                keys, counts = np.unique(class_ids[movable] * node_count + child[movable], return_counts=True)
                piece_class = keys // node_count
                piece_node = class_nodes[piece_class]
                from_retained = retained[piece_class]
                # Records of retained classes that fall below k under each node are newly suppressed.
                newly = np.zeros(node_count, dtype=np.int64)
                small = from_retained & (counts < self.k)
                np.add.at(newly, piece_node[small], counts[small])
                # Smallest published piece under each node, and smallest published class elsewhere.
                piece_min = np.full(node_count, unset, dtype=np.int64)
                kept = from_retained & (counts >= self.k)
                np.minimum.at(piece_min, piece_node[kept], counts[kept])
                node_min = np.full(node_count, unset, dtype=np.int64)
                np.minimum.at(node_min, class_nodes[retained], class_sizes[retained])
                smallest, second = np.argsort(node_min, kind="stable")[:2]
                other_min = np.full(node_count, node_min[smallest], dtype=np.int64)
                other_min[smallest] = node_min[second]
                after = np.minimum(other_min, piece_min)
                parent_counts = np.bincount(
                    nodes[movable] * label_count + labels[movable], minlength=node_count * label_count,
                ).reshape(node_count, label_count)
                child_counts = np.bincount(
                    child[movable] * label_count + labels[movable], minlength=node_count * label_count,
                ).reshape(node_count, label_count)
                child_sizes = child_counts.sum(axis=1)
                occupied = np.flatnonzero(child_sizes)
                weighted = np.zeros(node_count)
                np.add.at(weighted, tree["parent"][occupied], child_sizes[occupied] * _entropy(child_counts[occupied]))
                parent_sizes = parent_counts.sum(axis=1)
                candidates = np.flatnonzero(parent_sizes)
                gains = np.maximum(_entropy(parent_counts[candidates]) - weighted[candidates] / parent_sizes[candidates], 0.0)
                after_c = after[candidates]
                losses = np.maximum(current_k - np.where(after_c == unset, current_k, after_c), 0)
                scores = gains / (losses + 1.0)
                eligible = (
                    (suppressed_now + newly[candidates] <= budget)
                    & (after_c != unset)
                    & ((parent_counts[candidates] > 0).sum(axis=1) >= 2)
                )
                for position in np.flatnonzero(eligible):
                    node = int(candidates[position])
                    key = (float(scores[position]), float(gains[position]), -order, -node)
                    if best is None or key > best["key"]:
                        best = {
                            "key": key, "attribute": attribute, "node": node,
                            "score": float(scores[position]), "information_gain": float(gains[position]),
                            "anonymity_loss": int(losses[position]), "min_k_after": int(after_c[position]),
                            "suppressed_after": int(suppressed_now + newly[node]),
                        }
            if best is None:
                break
            attribute, node = best["attribute"], best["node"]
            tree = self.trees[attribute]
            child = self._children_of(attribute, current[attribute], leaf[attribute])
            moved = current[attribute] == node
            if np.any(child[moved] < 0):
                raise AssertionError("Every record under a specialized node must move to one of its children.")
            current[attribute][moved] = child[moved]
            cut[attribute].discard(node)
            cut[attribute].update(tree["children"][node])
            class_ids = np.unique(class_ids * len(tree["ids"]) + current[attribute], return_inverse=True)[1].reshape(-1)
            self.history.append({
                "step": len(self.history) + 1, "attribute": attribute, "node": tree["ids"][node],
                "moved_row_count": int(moved.sum()),
                **{key: best[key] for key in ("score", "information_gain", "anonymity_loss", "min_k_after",
                                              "suppressed_after")},
            })
        self.cut = {a: sorted(self.trees[a]["ids"][n] for n in cut[a]) for a in attributes}
        self.training_ids = X.index.tolist()
        self.partitions = []
        order = np.argsort(class_ids, kind="stable")
        for rows in np.split(order, np.flatnonzero(np.diff(class_ids[order])) + 1):
            self.partitions.append({
                "positions": rows.tolist(), "size": len(rows), "row_ids": X.index.take(rows).tolist(),
                "release": deepcopy({a: self.trees[a]["domains"][current[a][rows[0]]] for a in attributes}),
            })
        self.published_partitions = [group for group in self.partitions if group["size"] >= self.k]
        self.suppressed_positions = sorted(
            position for group in self.partitions if group["size"] < self.k for position in group["positions"])
        if len(self.suppressed_positions) > budget:
            raise AssertionError("TDS + MaxSup suppressed more records than its budget.")
        if not self.published_partitions:
            raise AssertionError("TDS + MaxSup published no class.")
        return self
