"""Global-recoding KAnon by top-down specialization (TDS).

Fung, Wang and Yu, "Top-Down Specialization for Information and Privacy
Preservation", ICDE 2005. Every QI starts at its hierarchy root. One step
replaces a released hierarchy node by its children for every training record,
so equal raw values always share one released node (global recoding). Among
valid steps (every equivalence class keeps at least K records) and beneficial
steps (the node's records carry more than one label), TDS takes the step with
the highest Score = InfoGain / (AnonyLoss + 1) and stops when none remains.
Numeric QIs use the fixed shared hierarchies rather than splits grown during
the search, so every release stays in TRIM's output space.
"""

from __future__ import annotations

from copy import deepcopy
import json

import numpy as np
import pandas as pd

from experiments.exp1_kanon.hierarchy import MISSING_NODE, _entropy


SCHEMA_VERSION = "global_tds.v1"
EVALUATION_POLICY = "same_global_cut"


class FittedTDS:
    """TDS fitted exclusively to training records over a HierarchySchema."""

    def __init__(self, schema, *, k):
        if isinstance(k, bool) or int(k) != k or k < 1:
            raise ValueError("k must be a positive integer.")
        self.schema, self.k = schema, int(k)
        self.cut, self.history, self.partitions, self.training_ids = {}, [], [], []
        root_domain = schema.root_domain()
        # Integer node indices per QI; the missing branch is the last index and
        # becomes a child of the root once the root is specialized.
        self.trees = {}
        for attribute in schema.attributes:
            nodes = schema.nodes[attribute]
            ids = [*nodes, MISSING_NODE]
            index = {node_id: position for position, node_id in enumerate(ids)}
            root = index[schema.roots[attribute]]
            parent = np.array([
                *(index[node["parent"]] if node.get("parent") is not None else -1 for node in nodes.values()),
                root,
            ], dtype=np.int64)
            depth = np.zeros(len(ids), dtype=np.int64)
            for position in range(len(ids)):
                current = parent[position]
                while current >= 0:
                    depth[position] += 1
                    current = parent[current]
            leaves = schema.leaves[attribute]
            path = np.full((len(leaves), int(depth.max()) + 1), -1, dtype=np.int64)
            for position, leaf in enumerate(leaves):
                current = index[leaf["id"]]
                while current >= 0:
                    path[position, depth[current]] = current
                    current = parent[current]
            children = {index[node_id]: [index[child] for child in schema.children[attribute][node_id]] for node_id in nodes}
            children[root].append(index[MISSING_NODE])
            children[index[MISSING_NODE]] = []
            domains = []
            for node_id in nodes:
                if node_id == schema.roots[attribute]:
                    domains.append(deepcopy(root_domain[attribute]))
                elif attribute in schema.numeric:
                    positions = schema.descendants[attribute][node_id]
                    intervals = schema.leaf_values[attribute]
                    low = min(intervals[position][0] for position in positions)
                    high = max(intervals[position][1] for position in positions)
                    covered = [position for position, (lo, hi) in enumerate(intervals) if lo <= high and hi >= low]
                    # The shared encoding reads a numeric node through [low, high].
                    if sorted(covered) != sorted(positions):
                        raise ValueError(f"{attribute}: node {node_id} does not cover a contiguous leaf range.")
                    domains.append({"node": node_id, "low": low, "high": high, "missing": False})
                else:
                    domains.append({"node": node_id, "missing": False})
            domains.append({"missing_only": True} if attribute in schema.numeric else {"node": MISSING_NODE, "missing": True})
            self.trees[attribute] = {
                "ids": ids, "index": index, "root": root, "missing": index[MISSING_NODE],
                "parent": parent, "depth": depth, "path": path, "children": children, "domains": domains,
            }

    def _leaf_positions(self, X):
        """Map every QI value to its hierarchy leaf position; missing is -1."""
        values = self.schema.values(X)
        for attribute in self.schema.numeric:
            column = values[attribute]
            positions = np.full(len(column), -1, dtype=np.int64)
            for position, (low, high) in enumerate(self.schema.leaf_values[attribute]):
                positions[(column >= low) & (column <= high)] = position
            values[attribute] = positions
        return values

    def _children_of(self, attribute, current, leaf):
        """Return the node below each record's released node, or -1 at a leaf."""
        tree = self.trees[attribute]
        child = np.full(len(current), -1, dtype=np.int64)
        present = leaf >= 0
        below = tree["depth"][current] + 1
        inside = present & (below < tree["path"].shape[1])
        child[inside] = tree["path"][leaf[inside], below[inside]]
        child[~present & (current == tree["root"])] = tree["missing"]
        return child

    def fit(self, X, y):
        if not X.index.is_unique or len(X) < self.k:
            raise ValueError("Training IDs must be unique and N_train must be at least k.")
        if not isinstance(y, pd.Series) or not y.index.equals(X.index) or y.isna().any():
            raise ValueError("Labels must be nonmissing and aligned with training IDs.")
        leaf = self._leaf_positions(X)
        labels, classes = pd.factorize(y, sort=True)
        label_count = len(classes)
        attributes = self.schema.attributes
        current = {attribute: np.full(len(X), self.trees[attribute]["root"], dtype=np.int64) for attribute in attributes}
        cut = {attribute: {self.trees[attribute]["root"]} for attribute in attributes}
        class_ids = np.zeros(len(X), dtype=np.int64)
        unset = np.iinfo(np.int64).max
        self.history = []
        while True:
            class_sizes = np.bincount(class_ids)
            current_k = int(class_sizes.min())
            best = None
            for order, attribute in enumerate(attributes):
                tree = self.trees[attribute]
                node_count = len(tree["ids"])
                nodes = current[attribute]
                child = self._children_of(attribute, nodes, leaf[attribute])
                movable = child >= 0
                if not movable.any():
                    continue
                # Every class lies under one released node of this QI.
                class_nodes = np.empty(len(class_sizes), dtype=np.int64)
                class_nodes[class_ids] = nodes
                keys, counts = np.unique(class_ids[movable] * node_count + child[movable], return_counts=True)
                new_min = np.full(node_count, unset, dtype=np.int64)
                np.minimum.at(new_min, class_nodes[keys // node_count], counts)
                node_min = np.full(node_count, unset, dtype=np.int64)
                np.minimum.at(node_min, class_nodes, class_sizes)
                smallest, second = np.argsort(node_min, kind="stable")[:2]
                other_min = np.full(node_count, node_min[smallest], dtype=np.int64)
                other_min[smallest] = node_min[second]
                after = np.minimum(other_min, new_min)
                parent_counts = np.bincount(
                    nodes[movable] * label_count + labels[movable], minlength=node_count * label_count,
                ).reshape(node_count, label_count)
                child_counts = np.bincount(
                    child[movable] * label_count + labels[movable], minlength=node_count * label_count,
                ).reshape(node_count, label_count)
                child_sizes = child_counts.sum(axis=1)
                occupied = np.flatnonzero(child_sizes)
                weighted = np.zeros(node_count)
                np.add.at(weighted, tree["parent"][occupied], child_sizes[occupied] * _entropy(child_counts[occupied]))
                parent_sizes = parent_counts.sum(axis=1)
                candidates = np.flatnonzero(parent_sizes)
                gains = np.maximum(_entropy(parent_counts[candidates]) - weighted[candidates] / parent_sizes[candidates], 0.0)
                losses = current_k - after[candidates]
                scores = gains / (losses + 1.0)
                eligible = (new_min[candidates] >= self.k) & ((parent_counts[candidates] > 0).sum(axis=1) >= 2)
                for position in np.flatnonzero(eligible):
                    node = int(candidates[position])
                    key = (float(scores[position]), float(gains[position]), -order, -node)
                    if best is None or key > best["key"]:
                        best = {
                            "key": key, "attribute": attribute, "node": node,
                            "score": float(scores[position]), "information_gain": float(gains[position]),
                            "anonymity_loss": int(losses[position]), "min_k_after": int(after[node]),
                        }
            if best is None:
                break
            attribute, node = best["attribute"], best["node"]
            tree = self.trees[attribute]
            child = self._children_of(attribute, current[attribute], leaf[attribute])
            moved = current[attribute] == node
            if np.any(child[moved] < 0):
                raise AssertionError("Every record under a specialized node must move to one of its children.")
            current[attribute][moved] = child[moved]
            cut[attribute].discard(node)
            cut[attribute].update(tree["children"][node])
            class_ids = np.unique(class_ids * len(tree["ids"]) + current[attribute], return_inverse=True)[1].reshape(-1)
            self.history.append({
                "step": len(self.history) + 1, "attribute": attribute, "node": tree["ids"][node],
                "occupied_children": sorted({tree["ids"][position] for position in np.unique(current[attribute][moved])}),
                "moved_row_count": int(moved.sum()),
                **{key: best[key] for key in ("score", "information_gain", "anonymity_loss", "min_k_after")},
            })
        self.cut = {
            attribute: sorted(self.trees[attribute]["ids"][node] for node in cut[attribute]) for attribute in attributes
        }
        self.training_ids = X.index.tolist()
        self.partitions = []
        order = np.argsort(class_ids, kind="stable")
        for rows in np.split(order, np.flatnonzero(np.diff(class_ids[order])) + 1):
            self.partitions.append({
                "positions": rows.tolist(), "size": len(rows), "row_ids": X.index.take(rows).tolist(),
                "release": deepcopy({
                    attribute: self.trees[attribute]["domains"][current[attribute][rows[0]]] for attribute in attributes
                }),
            })
        covered = [position for group in self.partitions for position in group["positions"]]
        if sorted(covered) != list(range(len(X))) or any(group["size"] < self.k for group in self.partitions):
            raise AssertionError("TDS must publish every training record exactly once in classes of size >= k.")
        return self

    def transform_groups(self, X):
        """Release evaluation records through the fitted cut; no routing is needed."""
        if not self.cut:
            raise ValueError("Fit TDS before transforming evaluation records.")
        leaf = self._leaf_positions(X)
        attributes = self.schema.attributes
        codes = np.empty((len(X), len(attributes)), dtype=np.int64)
        for column, attribute in enumerate(attributes):
            tree = self.trees[attribute]
            in_cut = np.zeros(len(tree["ids"]), dtype=bool)
            in_cut[[tree["index"][node_id] for node_id in self.cut[attribute]]] = True
            # The cut is an antichain covering every leaf: one cut node per path.
            hits = (tree["path"] >= 0) & in_cut[np.maximum(tree["path"], 0)]
            if np.any(hits.sum(axis=1) != 1):
                raise AssertionError("The fitted cut must contain exactly one node on every leaf path.")
            leaf_cut = tree["path"][np.arange(len(tree["path"])), hits.argmax(axis=1)]
            present = leaf[attribute] >= 0
            codes[present, column] = leaf_cut[leaf[attribute][present]]
            codes[~present, column] = tree["root"] if in_cut[tree["root"]] else tree["missing"]
        if not len(X):
            return []
        inverse = np.unique(codes, axis=0, return_inverse=True)[1].reshape(-1)
        order = np.argsort(inverse, kind="stable")
        return [
            {
                "positions": rows.tolist(),
                "release": deepcopy({
                    attribute: self.trees[attribute]["domains"][codes[rows[0], column]]
                    for column, attribute in enumerate(attributes)
                }),
            }
            for rows in np.split(order, np.flatnonzero(np.diff(inverse[order])) + 1)
        ]

    def evaluation_stats(self, groups, population_size):
        """Count evaluation records whose released QI vector has no training class."""
        positions = [position for group in groups for position in group["positions"]]
        if sorted(positions) != list(range(population_size)):
            raise AssertionError("Evaluation release must assign each record exactly once.")
        published = {json.dumps(group["release"], sort_keys=True) for group in self.partitions}
        unseen = sum(
            len(group["positions"]) for group in groups
            if json.dumps(group["release"], sort_keys=True) not in published
        )
        return {
            "population_size": population_size, "group_count": len(groups),
            "unseen_class_record_count": unseen,
            "unseen_class_record_fraction": unseen / population_size if population_size else 0.0,
        }

    def per_record_k(self, index):
        """Group canonical published QI values into privacy classes."""
        keys = {}
        for partition in self.partitions:
            key = json.dumps(partition["release"], sort_keys=True, separators=(",", ":"))
            keys.setdefault(key, []).extend(partition["row_ids"])
        result = pd.Series(0, index=index, dtype=np.int64)
        for row_ids in keys.values():
            result.loc[row_ids] = len(row_ids)
        if (result < self.k).any():
            raise AssertionError("Published QI equivalence classes do not meet requested k.")
        return result

    def to_dict(self):
        return {
            "schema_version": SCHEMA_VERSION, "algorithm": "top_down_specialization",
            "score": "information_gain / (anonymity_loss + 1)", "k": self.k,
            "row_semantics": "every_training_row_once", "suppression": False,
            "evaluation_policy": EVALUATION_POLICY, "training_row_ids": self.training_ids,
            "cut": self.cut, "history": self.history, "partitions": self.partitions,
        }

    @classmethod
    def from_dict(cls, schema, payload):
        if payload.get("schema_version") != SCHEMA_VERSION or payload.get("evaluation_policy") != EVALUATION_POLICY:
            raise ValueError("Unsupported fitted TDS schema.")
        fitted = cls(schema, k=payload["k"])
        if set(payload["cut"]) != set(schema.attributes):
            raise ValueError("Fitted TDS cut and hierarchy QIs differ.")
        fitted.cut = {attribute: list(nodes) for attribute, nodes in payload["cut"].items()}
        fitted.history = deepcopy(payload["history"])
        fitted.partitions = deepcopy(payload["partitions"])
        fitted.training_ids = list(payload["training_row_ids"])
        return fitted
