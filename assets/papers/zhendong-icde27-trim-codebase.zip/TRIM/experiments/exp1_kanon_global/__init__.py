"""Global-recoding KAnon baseline (top-down specialization) for Exp-1."""
