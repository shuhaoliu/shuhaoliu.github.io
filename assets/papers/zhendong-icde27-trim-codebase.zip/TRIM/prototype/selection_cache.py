"""Run-level caches that make TRIM's candidate selection cheaper.

Nothing here computes a new kind of value. Every rule, encoded vector and group
key is produced by the original ``DatasetGeneralization`` code, evaluated once
per distinct raw value instead of once per row:

* Rules are built per (attribute, level) with ``load_generalization_rules``
  restricted to that attribute; ``change_level`` reuses them.
* ``_generalized_numeric_series`` and ``_generalized_categorical_frame`` look
  each row's value up in a table that the original methods computed for the
  distinct raw values, so ``encode`` keeps its own column assembly.
* ``privacy_frame`` replaces each QI's encoded block by the rank of that block
  among all blocks the attribute can take. Equal blocks get equal ranks, and
  rank order is the lexicographic order of the blocks, so groupby, value_counts,
  drop_duplicates and isin on the rank columns give the same groups, sizes and
  group order as on the encoded QI columns.

A cache declines (returns ``None``) whenever it cannot guarantee identical
output: NaN inside an encoded QI block (a missing numeric value), raw values it
has not seen, tables that are not float, or empty inputs. Callers then use the
original code path.

Opt-in (``memo_codes``, set by ``run_trim_pipeline(exact_speedups=True)``):
the value codes of each indexed frame are computed once per attribute, and
``CachedGeneralization.encode_rows_tensor`` builds the model encoding of rows
of an indexed frame on the device by gathering from the same value tables, cast
to the target dtype by numpy as ``encode_array`` casts them. Both only copy
values the original path computes, so the outputs are bitwise identical.
"""

from __future__ import annotations

import numpy as np

from .dataloader import DatasetGeneralization, load_generalization_rules


class _SingleAttributeLoader:
    """The fields ``load_generalization_rules`` reads, with one QI active."""

    def __init__(self, data_loader, attribute):
        self.feature_columns = tuple(data_loader.feature_columns)
        self.qi_attributes = (attribute,)
        self.numeric_attributes = tuple(data_loader.numeric_attributes)
        self.categorical_attributes = tuple(data_loader.categorical_attributes)
        self.category_maps = dict(data_loader.category_maps)
        strings = getattr(data_loader, "string_categorical_attributes", None)
        if strings is not None:
            self.string_categorical_attributes = strings


class SelectionCache:
    """Caches shared by every generalization of one TRIM run."""

    def __init__(self, base_generalization, data_loader, frames, qi_attributes):
        import pandas as pd

        self._loader = data_loader
        self._trees = base_generalization.trees
        self._qi = tuple(qi_attributes)
        self._numeric = tuple(base_generalization.numeric_attributes)
        self._categorical = tuple(base_generalization.categorical_attributes)
        self._category_maps = base_generalization.category_maps
        self._reference = base_generalization
        self._rules = {}
        self._tables = {}
        self._ranks = {}
        self._uniques = {}
        self._frame_ids = {id(frame) for frame in frames}
        self._frames = list(frames)
        # Opt-in memo of each indexed frame's value codes (exact_speedups).
        self.memo_codes = False
        self._frame_codes = {}
        self._device_codes = {}
        self._device_tables = {}
        attributes = self._numeric + self._categorical
        known = True
        for attribute in attributes:
            columns = [frame[attribute] for frame in frames]
            dtypes = {str(column.dtype) for column in columns}
            values = pd.concat(columns, ignore_index=True)
            uniques = pd.Index(values.drop_duplicates())
            if len(dtypes) != 1 or not uniques.is_unique:
                known = False
            self._uniques[attribute] = uniques
        self.encode_enabled = known
        self._seed_rules(base_generalization)
        # A missing categorical value encodes to an all-zero block, which groups
        # like any other block; a NaN inside an encoded block (a missing numeric
        # value) would not, so _build_ranks turns ranks off in that case.
        self.privacy_enabled = known
        self._rank_of = {}
        if self.privacy_enabled:
            self._build_ranks()

    # --- Generalizations ------------------------------------------------------

    def wrap(self, generalization):
        """Return a cached view of a generalization built by the original code."""
        self._seed_rules(generalization)
        return CachedGeneralization(generalization, self)

    def _seed_rules(self, generalization):
        for attribute in self._qi:
            level = int(generalization.generalization_level[attribute])
            self._rules.setdefault(
                (attribute, level), generalization.generalization_rules[attribute])

    def attribute_rules(self, attribute, level):
        key = (attribute, int(level))
        if key not in self._rules:
            built = load_generalization_rules(
                trees={attribute: self._trees[attribute]},
                data_loader=_SingleAttributeLoader(self._loader, attribute),
                generalization_level={attribute: int(level)},
            )
            self._rules[key] = built.generalization_rules[attribute]
        return self._rules[key]

    def generalization(self, generalization_level):
        """Mirror ``load_generalization_rules`` level normalization and output."""
        if isinstance(generalization_level, dict):
            levels = {attribute: int(generalization_level.get(attribute, 0))
                      for attribute in self._qi}
        else:
            levels = {attribute: int(generalization_level) for attribute in self._qi}
        rules = {attribute: self.attribute_rules(attribute, levels[attribute])
                 for attribute in self._qi}
        built = DatasetGeneralization(
            generalization_level=levels,
            generalization_rules=rules,
            numeric_attributes=self._loader.numeric_attributes,
            categorical_attributes=self._loader.categorical_attributes,
            category_maps=self._category_maps,
            trees=self._trees,
            data_loader=self._loader,
        )
        return CachedGeneralization(built, self)

    # --- Value tables ---------------------------------------------------------

    def _codes(self, attribute, values):
        if not self.encode_enabled or attribute not in self._uniques:
            return None
        codes = self._uniques[attribute].get_indexer(values)
        return None if (codes < 0).any() else codes

    def frame_codes(self, X, attribute):
        """``_codes(attribute, X[attribute])``; computed once per indexed frame when ``memo_codes`` is set.

        The indexed frames are kept alive by the cache, so their ids are not reused.
        """
        if not (self.memo_codes and id(X) in self._frame_ids):
            return self._codes(attribute, X[attribute])
        key = (id(X), attribute)
        if key not in self._frame_codes:
            self._frame_codes[key] = self._codes(attribute, X[attribute])
        return self._frame_codes[key]

    def device_frame_codes(self, X, attribute, device):
        """The codes of every row of an indexed frame X, as a device tensor (cached), or None."""
        import torch

        if id(X) not in self._frame_ids:
            return None
        key = (id(X), attribute, str(device))
        if key not in self._device_codes:
            codes = self.frame_codes(X, attribute)
            self._device_codes[key] = (None if codes is None else torch.as_tensor(
                np.asarray(codes, dtype=np.int64), device=device))
        return self._device_codes[key]

    def device_table(self, attribute, rules, numeric, np_dtype, device):
        """``_table(attribute, rules)`` as a 2-D device tensor of ``np_dtype``, or None.

        Numeric tables become one column, as in ``encode_array``. ``astype``
        casts each float64 value to ``np_dtype`` exactly as the assignment into
        ``encode_array``'s output array does.
        """
        import torch

        table = self._table(attribute, rules)
        if table is None:
            return None
        key = (attribute, id(rules) if rules else None, bool(numeric), np.dtype(np_dtype).str, str(device))
        entry = self._device_tables.get(key)
        if entry is not None and (not rules or entry[0] is rules):
            return entry[1]
        values = table[0][:, None] if numeric else table
        tensor = torch.as_tensor(np.ascontiguousarray(values.astype(np_dtype)), device=device)
        self._device_tables[key] = (rules, tensor)
        return tensor

    def _table(self, attribute, rules):
        """Encoded output for each distinct raw value, from the original code."""
        import pandas as pd

        key = (attribute, id(rules) if rules else None)
        entry = self._tables.get(key)
        if entry is not None and (not rules or entry[0] is rules):
            return entry[1]
        uniques = self._uniques[attribute]
        reference = self._reference
        if attribute in self._numeric:
            frame = pd.DataFrame({attribute: uniques})
            series = DatasetGeneralization._generalized_numeric_series(
                reference, frame, attribute, rules)
            table = ((series.to_numpy(dtype=np.float64), series.name)
                     if series.dtype == np.float64 else None)
        else:
            rows = DatasetGeneralization._generalized_categorical_rows(
                reference, pd.Series(uniques), attribute, rules)
            width = len(reference.category_maps[attribute])
            valid = all(len(row) == width and all(isinstance(value, float) for value in row)
                        for row in rows)
            table = np.asarray(rows, dtype=np.float64).reshape(len(rows), width) if valid else None
        self._tables[key] = (rules, table)
        return table

    def numeric_series(self, attribute, values, rules):
        import pandas as pd

        if len(values) == 0:
            return None
        codes = self._codes(attribute, values)
        table = None if codes is None else self._table(attribute, rules)
        if table is None:
            return None
        array, name = table
        return pd.Series(array[codes], index=values.index, name=name)

    def categorical_frame(self, attribute, values, rules, columns):
        import pandas as pd

        if len(values) == 0:
            return None
        codes = self._codes(attribute, values)
        table = None if codes is None else self._table(attribute, rules)
        if table is None:
            return None
        return pd.DataFrame(table[codes], columns=columns, index=values.index)

    # --- Privacy ranks --------------------------------------------------------

    def _vectors(self, attribute, rules):
        table = self._table(attribute, rules)
        if table is None:
            return None
        if attribute in self._numeric:
            return [(float(value),) for value in table[0]]
        return [tuple(float(value) for value in row) for row in table]

    def _build_ranks(self):
        for attribute in self._qi:
            nodes = self._trees.get(attribute, {}).get("nodes", [])
            highest = max((int(node.get("height_from_leaf", 0)) for node in nodes), default=0)
            blocks = set()
            for level in range(highest + 1):
                vectors = self._vectors(attribute, self.attribute_rules(attribute, level))
                if vectors is None or any(value != value for vector in vectors for value in vector):
                    self.privacy_enabled = False
                    return
                blocks.update(vectors)
            self._rank_of[attribute] = {block: rank for rank, block in enumerate(sorted(blocks))}

    def _rank_table(self, attribute, rules):
        key = (attribute, id(rules))
        entry = self._ranks.get(key)
        if entry is not None and entry[0] is rules:
            return entry[1]
        vectors = self._vectors(attribute, rules)
        rank_of = self._rank_of[attribute]
        if vectors is None or any(vector not in rank_of for vector in vectors):
            ranks = None
        else:
            ranks = np.asarray([rank_of[vector] for vector in vectors], dtype=np.int64)
        self._ranks[key] = (rules, ranks)
        return ranks

    def covers(self, X):
        """Whether X is one of the frames whose raw values the cache indexed."""
        return id(X) in self._frame_ids

    def supports_privacy(self, generalization, attributes):
        """Whether ``privacy_frame`` answers for every subset of a covered frame."""
        if (not self.privacy_enabled or tuple(attributes) != self._qi
                or getattr(generalization, "selection_cache", None) is not self):
            return False
        for attribute in self._qi:
            rules = generalization.generalization_rules.get(attribute)
            if rules is None or self._rank_table(attribute, rules) is None:
                return False
        return True

    def privacy_frame(self, generalization, X, attributes):
        """Rank columns grouping exactly like the encoded QI columns, or None."""
        import pandas as pd

        if not self.privacy_enabled or tuple(attributes) != self._qi or len(X) == 0:
            return None
        columns = {}
        for attribute in self._qi:
            rules = generalization.generalization_rules.get(attribute)
            if rules is None:
                return None
            ranks = self._rank_table(attribute, rules)
            codes = None if ranks is None else self.frame_codes(X, attribute)
            if codes is None:
                return None
            columns[attribute] = ranks[codes]
        return pd.DataFrame(columns, index=X.index)


class CachedGeneralization(DatasetGeneralization):
    """A ``DatasetGeneralization`` whose row-level work uses a ``SelectionCache``."""

    def __init__(self, generalization, cache):
        super().__init__(
            generalization_level=generalization.generalization_level,
            generalization_rules=generalization.generalization_rules,
            numeric_attributes=generalization.numeric_attributes,
            categorical_attributes=generalization.categorical_attributes,
            category_maps=generalization.category_maps,
            trees=generalization.trees,
            data_loader=generalization.data_loader,
        )
        self.selection_cache = cache

    def change_level(self, generalization_level):
        return self.selection_cache.generalization(generalization_level)

    def _generalized_numeric_series(self, X, attribute, rules):
        series = self.selection_cache.numeric_series(attribute, X[attribute], rules)
        if series is None:
            return super()._generalized_numeric_series(X, attribute, rules)
        return series

    def _generalized_categorical_frame(self, X, attribute):
        rules = self.generalization_rules.get(attribute, {})
        columns = [f"{attribute}={category}" for category in self.category_maps[attribute]]
        frame = self.selection_cache.categorical_frame(attribute, X[attribute], rules, columns)
        if frame is None:
            return super()._generalized_categorical_frame(X, attribute)
        return frame

    def privacy_frame(self, X, attributes):
        return self.selection_cache.privacy_frame(self, X, attributes)

    def encode_array(self, X, dtype):
        """``np.asarray(self.encode(X), dtype=dtype)`` without building the frame.

        ``encode`` concatenates one float64 block per numeric and categorical
        attribute, each looked up from the same tables used here; numpy casts
        every float64 element to ``dtype`` the same way in both paths. Returns
        None whenever any block would come from the original per-row code.
        """
        cache = self.selection_cache
        if type(self).encode is not DatasetGeneralization.encode or len(X) == 0:
            return None
        blocks = []
        for attribute in tuple(self.numeric_attributes) + tuple(self.categorical_attributes):
            codes = cache.frame_codes(X, attribute)
            table = (None if codes is None
                     else cache._table(attribute, self.generalization_rules.get(attribute, {})))
            if table is None:
                return None
            # Numeric tables are (values, series name); categorical ones are 2-D.
            values = table[0][:, None] if attribute in self.numeric_attributes else table
            blocks.append((values, codes))
        out = np.empty((len(X), sum(values.shape[1] for values, _ in blocks)), dtype=dtype)
        start = 0
        for values, codes in blocks:
            out[:, start:start + values.shape[1]] = values[codes]
            start += values.shape[1]
        return out

    def encode_rows_tensor(self, X, positions, *, device, dtype):
        """``encode_array(X.iloc[positions], ...)`` as a device tensor, gathered on the device.

        ``X`` must be a frame the selection cache indexed and ``positions`` the
        row positions to encode, in order (None: every row). Each row's value
        codes and each value table (cast to ``dtype`` as ``encode_array`` casts
        it) stay on the device, so the output holds the same values as
        ``to_device_tensor(encode_array(X.iloc[positions], dtype), dtype=dtype)``
        and is built without the host array and its copy. Returns None whenever
        ``encode_array`` would, for an unindexed frame, for dtypes other than
        float32 and float64, and for positions outside X.
        """
        import torch

        cache = self.selection_cache
        np_dtype = {torch.float32: np.float32, torch.float64: np.float64}.get(dtype)
        if (np_dtype is None or type(self).encode is not DatasetGeneralization.encode
                or not cache.covers(X)):
            return None
        index = None
        if positions is not None:
            positions = np.asarray(positions, dtype=np.int64)
            if positions.ndim != 1 or len(positions) == 0 or (
                    positions.min() < 0 or positions.max() >= len(X)):
                return None
            index = torch.as_tensor(positions, device=device)
        elif len(X) == 0:
            return None
        blocks = []
        for attribute in tuple(self.numeric_attributes) + tuple(self.categorical_attributes):
            codes = cache.device_frame_codes(X, attribute, device)
            values = None if codes is None else cache.device_table(
                attribute, self.generalization_rules.get(attribute, {}),
                attribute in self.numeric_attributes, np_dtype, device)
            if values is None:
                return None
            blocks.append(values.index_select(0, codes if index is None else codes.index_select(0, index)))
        return torch.cat(blocks, dim=1)
