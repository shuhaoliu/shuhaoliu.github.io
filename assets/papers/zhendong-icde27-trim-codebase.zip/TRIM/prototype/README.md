# TRIM core

This directory contains the core TRIM implementation. The Python entry point is
`TRIM_prototype_pipeline.run_trim_pipeline(...)`; the configuration-driven
command-line entry point is `run_prototype.py`.

TRIM uses three separately configured model roles:

- `model.estimator` performs first-stage LGA ranking.
- `model.proxy` performs second-stage candidate certification.
- `model.downstream` performs final utility evaluation.

Model specifications are validated against the requirements of each role.

Each round offers one inclusion per remaining retention class and one
refine-and-swap per finer level of each QI, ranks them by LGA per privacy cost,
and proxy-checks the top `rank_top_k` (the evaluation budget b) of each pool by
retraining the proxy on the candidate's retained rows. The pipeline options of
the paper's runs are documented in the docstring of `run_trim_pipeline`:
refine-and-evict variants (`refinement_eviction_ratios`, `eviction_scoring`,
`eviction_shortlist`), the privacy-step bound (`max_privacy_step`), widening
(`stall_rule: widen`, `stall_widen_top_k`) and the trajectory stops. The cost
floor kappa (`privacy_cost_floor`) has no default and must be set; the paper
uses log(1.05).

## Supported datasets

- Income (ACS Income)
- PubCov (ACS Public Coverage)
- Diabetes (Diabetes 130-US Hospitals)
- BM (Bank Marketing)
- BNG (synthetic credit-g)

The five generalization trees are stored in
`../configs/generalization_trees/`. See `../data/README.md` for data sources
and expected file locations.

## Running TRIM

Run from the project root:

```bash
python -m prototype.run_prototype --config configs/prototype.template.yaml
```

Relative paths in configuration files are resolved from the project root.
Select `cuda`, `cpu`, or another supported device through the configuration
or command line. Results are written only when `results_dir` is set.

`initial_sample_fraction` is applied to the training rows after loading,
cleaning, and the train/validation/test split. The seed of D_0 is a stratified
sample that contains every training label. It is mutually exclusive with
`initial_sample_size`.

## Modules

- `TRIM_prototype_pipeline.py`: search, candidate selection, publication, and metrics.
- `experiment_hooks.py`: ablation controls and the hooks of the Exp-6 variants.
- `dataset_registry.py` and `dataloader.py`: datasets and generalization-tree encoding.
- `enumeration_horizontal.py`: retention-class enumeration.
- `greedy_selection.py`: search state, logs, and generalization-level utilities.
- `lga.py`: LGA candidate scoring.
- `gpu_*.py` and `model_factory.py`: model implementations.
- `backend_training.py`: training-feature standardization.

## Experiment interfaces

`run_trim_pipeline(...)` provides the following experiment controls:

```python
run_trim_pipeline(
    ...,
    ablation_actions=None,
    fixed_row_candidate_builder=None,
    candidate_shortlist=None,
    candidate_state_scorer_factory=None,
    selection_score=None,
    stop_on_utility=True,
    record_iteration_test_metrics=False,
    validation_only=False,
    record_iteration_validation_metrics=False,
)
```

Validation-only runs keep the same partitions, discard test objects behind
access guards, and save `test_evaluated=false`. They never encode or evaluate
the test split. The published output is the mixed release.
Per-round target validation can be enabled independently of utility stopping.
Saved runs append `state_history.jsonl` for retained-set replay and min-K audits.

`AblationActions` supports:

- `enabled_action_types`: `retention_class`, `vertical_refinement`, or both.
- `initialization`: `s0` or `all_rows_at_max_generalization`.
- `vertical_postprocessing`: `full_swap`, `none`, or `evict_low_k`.
- `move_out_threshold`: a positive integer used by `evict_low_k`.

The structural variants of Fig. 5k use them as follows: TRIM_H enables only
`retention_class` and admits the groups of a fixed k-means cluster-ring
partition of the training rows at exact QI values (`fixed_row_candidate_builder`,
below), starting from the largest group; TRIM_V enables only `vertical_refinement`,
starts from `all_rows_at_max_generalization` and uses `full_swap`; RefineOnly
uses `none`; RefineEvict uses `evict_low_k`. For example:

```python
from prototype import AblationActions, run_trim_pipeline

refine_evict = AblationActions(
    vertical_postprocessing="evict_low_k",
    move_out_threshold=30,
)
result = run_trim_pipeline(..., ablation_actions=refine_evict)
```

`fixed_row_candidate_builder(context)` supplies a fixed, non-overlapping
partition of training rows. It may be combined with vertical refinement only
when `vertical_postprocessing="none"`, so refinement cannot move rows across
the fixed candidate groups.

`candidate_shortlist(context)` selects positions from the complete horizontal
and vertical candidate pool. By default, TRIM takes the top `rank_top_k` of each
pool by LGA per privacy cost.

`candidate_state_scorer_factory(context)` constructs a numerical scorer for
the current and candidate states. Its output is available to
`selection_score(context)`. Incompatible scorers and non-finite values raise
an error.

With `stop_on_utility=False`, TRIM continues until `max_iterations`, until a
round's release reaches min-K <= `stop_at_release_min_k` (if set), or until no
valid action remains. With `record_iteration_test_metrics=True`, TRIM retrains
the downstream model for each committed snapshot and writes the measurements
to `trim_iterations.json`. This observation cost is reported separately
as `experiment_observation_time_seconds`.
