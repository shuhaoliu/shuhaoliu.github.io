"""Incremental retained-state records shared by the pipeline and audit tools."""

from __future__ import annotations

import hashlib
import json


class TestSplitGuard:
    """Replace discarded holdout objects in validation-only runs."""

    def __getattribute__(self, name):
        raise RuntimeError("Test split access is forbidden in validation_only mode.")

    def __len__(self):
        raise RuntimeError("Test split access is forbidden in validation_only mode.")

    def __iter__(self):
        raise RuntimeError("Test split access is forbidden in validation_only mode.")

    def __getitem__(self, key):
        raise RuntimeError("Test split access is forbidden in validation_only mode.")


def retained_ids_sha256(row_ids):
    ids = sorted(str(row_id) for row_id in row_ids)
    if len(ids) != len(set(ids)):
        raise ValueError("Retained row IDs must have unique string representations.")
    return hashlib.sha256(json.dumps(ids, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def append_state_record(path, record):
    if path is not None:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True, default=str) + "\n")
