"""Retention-class enumeration used by TRIM."""

from __future__ import annotations

import numpy as np


def _retention_group_columns(generalized_encode, selected_attributes=None):
    if selected_attributes is None:
        return list(generalized_encode.columns)

    group_columns = []
    seen_columns = set()
    missing_attributes = []
    for attribute in selected_attributes:
        if attribute in generalized_encode.columns:
            matching_columns = [attribute]
        else:
            matching_columns = [
                column
                for column in generalized_encode.columns
                if column.startswith(f"{attribute}=")
            ]
            if not matching_columns:
                missing_attributes.append(attribute)
                continue

        for column in matching_columns:
            if column not in seen_columns:
                group_columns.append(column)
                seen_columns.add(column)

    if missing_attributes:
        raise KeyError(
            "Selected attributes are not present in generalized_encode: "
            f"{missing_attributes}"
        )

    return group_columns


def _tuple_group_key(group_key):
    if not isinstance(group_key, tuple):
        return (group_key,)
    return group_key


def select_encoded_attributes(generalized_encode, attributes):
    """Return the encoded columns belonging to the requested raw attributes."""

    columns = _retention_group_columns(
        generalized_encode,
        selected_attributes=attributes,
    )
    return generalized_encode.loc[:, columns]


def build_retention_class_groups(
    generalized_encode,
    selected_attributes=None,
    *,
    sort_keys=True,
):
    """Group rows by generalized values of the selected attributes."""
    group_columns = _retention_group_columns(
        generalized_encode,
        selected_attributes=selected_attributes,
    )

    if not group_columns:
        return {(): generalized_encode.copy()}

    groups = {}
    for group_key, group in generalized_encode.groupby(
        group_columns,
        sort=sort_keys,
        dropna=False,
    ):
        groups[_tuple_group_key(group_key)] = group.copy()

    return groups


build_retention_class_groups.method_name = "qi_level_based"


def build_retention_class_index_groups(
    generalized_encode,
    selected_attributes=None,
    *,
    sort_keys=True,
):
    """Group rows by retention class and return only row indexes."""
    group_columns = _retention_group_columns(
        generalized_encode,
        selected_attributes=selected_attributes,
    )

    if not group_columns:
        return {(): generalized_encode.index.copy()}

    groups = {}
    grouped = generalized_encode.groupby(
        group_columns,
        sort=sort_keys,
        dropna=False,
    )
    for group_key, index in grouped.groups.items():
        groups[_tuple_group_key(group_key)] = index

    return groups


def build_retention_class_position_index(
    generalized_encode,
    selected_attributes=None,
    *,
    sort_keys=True,
):
    """Build a fixed row-position index for retention classes."""
    index_groups = build_retention_class_index_groups(
        generalized_encode,
        selected_attributes=selected_attributes,
        sort_keys=sort_keys,
    )
    row_ids = list(generalized_encode.index)
    row_id_to_position = {
        row_id: position
        for position, row_id in enumerate(row_ids)
    }
    row_class_ids = np.empty(len(row_ids), dtype=np.intp)
    class_keys = []
    class_member_positions = []

    ordered_index_groups = sorted(
        index_groups.items(),
        key=lambda item: row_id_to_position[item[1][0]],
    )

    for class_id, (class_key, class_index) in enumerate(ordered_index_groups):
        positions = np.fromiter(
            (row_id_to_position[row_id] for row_id in class_index),
            dtype=np.intp,
            count=len(class_index),
        )
        class_keys.append(class_key)
        class_member_positions.append(positions)
        row_class_ids[positions] = class_id

    return {
        "row_ids": np.asarray(row_ids, dtype=object),
        "row_id_to_position": row_id_to_position,
        "row_class_ids": row_class_ids,
        "class_keys": class_keys,
        "class_member_positions": class_member_positions,
        "class_total_sizes": np.asarray(
            [len(positions) for positions in class_member_positions],
            dtype=np.intp,
        ),
    }


def _unique_rows(values):
    """``np.unique(values, axis=0, return_index=True, return_inverse=True)[1:]`` for integer rows, faster.

    Each column's offset values become one digit of a mixed-radix row key,
    compacted to sorted ranks before it could overflow, so keys order like
    the rows (lexicographically) and are equal exactly when the rows are: the
    same first rows and labels as the structured-row sort of np.unique.
    """
    key = np.zeros(len(values), dtype=np.int64)
    span = 1
    for column in values.T:
        low = int(column.min())
        width = int(column.max()) - low + 1
        if span * width >= 2 ** 62:
            key = np.unique(key, return_inverse=True)[1].reshape(-1).astype(np.int64)
            span = int(key.max()) + 1
        key = key * width + (column.astype(np.int64) - low)
        span *= width
    _unique, first_rows, inverse = np.unique(key, return_index=True, return_inverse=True)
    return first_rows, np.asarray(inverse).reshape(-1)


_ROW_ID_TABLES = {}


def _row_id_tables(index):
    """``(list(index), {row id: position})``, built once per index object (kept alive here, never mutated)."""
    entry = _ROW_ID_TABLES.get(id(index))
    if entry is None or entry[0] is not index:
        row_ids = list(index)
        entry = (index, row_ids, {row_id: position for position, row_id in enumerate(row_ids)})
        if len(_ROW_ID_TABLES) > 8:
            _ROW_ID_TABLES.clear()
        _ROW_ID_TABLES[id(index)] = entry
    return entry[1], entry[2]


def build_retention_class_position_index_numpy(
    generalized_encode,
    selected_attributes=None,
    *,
    with_class_keys=True,
    share_row_tables=False,
):
    """``build_retention_class_position_index(..., sort_keys=False)`` with numpy grouping.

    For integer group columns (the selection cache's rank columns) and a unique
    row index, rows with equal column values form one class, classes are
    numbered by first row, and each class lists its row positions in order:
    the same classes, numbering, member positions and keys as the pandas
    version. Any other input goes to the pandas version. ``with_class_keys=False``
    leaves ``class_keys`` None for callers that never read them (a swap and its
    eviction variants); ``share_row_tables=True`` reuses one ``row_ids`` array
    and ``row_id_to_position`` dict per index object, for callers that only read
    them.
    """
    group_columns = _retention_group_columns(
        generalized_encode,
        selected_attributes=selected_attributes,
    )
    values = generalized_encode.loc[:, group_columns].to_numpy() if group_columns else None
    if (values is None or len(values) == 0 or values.dtype.kind not in "iu"
            or not generalized_encode.index.is_unique):
        return build_retention_class_position_index(
            generalized_encode, selected_attributes=selected_attributes, sort_keys=False)
    first_rows, inverse = _unique_rows(values)
    class_order = np.argsort(first_rows, kind="stable")
    class_of_unique = np.empty(len(class_order), dtype=np.intp)
    class_of_unique[class_order] = np.arange(len(class_order), dtype=np.intp)
    row_class_ids = class_of_unique[inverse]
    class_total_sizes = np.bincount(row_class_ids, minlength=len(class_order)).astype(np.intp)
    ordered_positions = np.argsort(row_class_ids, kind="stable").astype(np.intp)
    class_member_positions = np.split(ordered_positions, np.cumsum(class_total_sizes)[:-1])
    if share_row_tables:
        row_ids, row_id_to_position = _row_id_tables(generalized_encode.index)
    else:
        row_ids = list(generalized_encode.index)
        row_id_to_position = {row_id: position for position, row_id in enumerate(row_ids)}
    # pandas keys each group by its rows' values as Python scalars (one-tuples
    # after _tuple_group_key for a single column), like itertuples here.
    class_keys = (list(generalized_encode.loc[:, group_columns].iloc[first_rows[class_order]]
                       .itertuples(index=False, name=None)) if with_class_keys else None)
    return {
        "row_ids": np.asarray(row_ids, dtype=object),
        "row_id_to_position": row_id_to_position,
        "row_class_ids": row_class_ids,
        "class_keys": class_keys,
        "class_member_positions": class_member_positions,
        "class_total_sizes": class_total_sizes,
    }


def build_retention_class_row_groups_from_codes(
    generalized_encode,
    codes,
    row_ids,
    selected_attributes,
):
    """``build_retention_class_groups(generalized_encode.loc[row_ids], selected_attributes)``
    as ``[(key, row ids)]``, with the rows partitioned by integer codes.

    ``codes`` must have, for every selected attribute, an integer column that
    numbers the distinct values of that attribute's encoded columns (the swap
    encode cache keeps such codes in step with its encoding). Rows then share
    every code exactly when they share the encoded values of the selected
    attributes, so the classes and their rows (in ``row_ids`` order) are those
    of the pandas groupby. A class key is its first row's encoded values, as
    numpy floats like the groupby keys, and classes are ordered by key as
    ``groupby(sort=True)`` orders them. Returns None, so the caller uses the
    pandas path, for non-float or NaN keys (NaN orders differently) and when two
    classes have equal keys (codes that do not match the encoding).
    """
    group_columns = _retention_group_columns(
        generalized_encode,
        selected_attributes=selected_attributes,
    )
    attributes = list(selected_attributes)
    if not group_columns or len(row_ids) == 0 or not set(attributes) <= set(codes.columns):
        return None
    code_values = codes.loc[row_ids, attributes].to_numpy()
    if code_values.dtype.kind not in "iu":
        return None
    first_rows, inverse = _unique_rows(code_values)
    ids = np.asarray(row_ids, dtype=object)
    representatives = generalized_encode.loc[ids[first_rows].tolist(), group_columns].to_numpy()
    if representatives.dtype.kind != "f" or np.isnan(representatives).any():
        return None
    keys = [tuple(row) for row in representatives]
    if len(set(keys)) != len(keys):
        return None
    sizes = np.bincount(inverse, minlength=len(keys))
    members = np.split(np.argsort(inverse, kind="stable"), np.cumsum(sizes)[:-1])
    return [(keys[c], ids[members[c]].tolist()) for c in sorted(range(len(keys)), key=keys.__getitem__)]
