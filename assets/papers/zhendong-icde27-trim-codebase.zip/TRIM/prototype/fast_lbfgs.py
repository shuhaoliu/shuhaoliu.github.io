"""Opt-in exact speed-up of torch.optim.LBFGS on CUDA: the two-loop recursion replayed as a CUDA graph.

A small dense fit, such as TRIM's proxy and estimator logistic regressions, spends most of its
torch.optim.LBFGS time in the two-loop recursion: per history entry (up to 100), a dot product,
scalar products and an ``add_`` whose ``alpha`` is a GPU scalar, which costs a host synchronization,
so the GPU waits on Python. ``graph_lbfgs_class()`` returns the installed ``torch.optim.lbfgs.LBFGS``
compiled from its own source with only that recursion replaced by ``_two_loop``, which replays a
CUDA graph of the same kernels on the same values:

* the history lives in fixed device buffers whose rows start 512-byte aligned, like fresh
  allocations, and are updated by copies when LBFGS appends or drops an entry;
* ``q.add_(x, alpha=a)`` becomes ``fma(a, x, q)`` with ``a`` read on the device: the add kernel
  computes ``q + a * x`` as one fused multiply-add, so the values are the same
  (``tests/test_exact_speedups.py`` checks this elementwise and on whole fits, bitwise);
* one graph per history length is captured on first use; all graphs share one memory pool,
  which is safe because each replay writes every intermediate it reads;
* for float32, each history step's scalar products, difference and update run as one kernel:
  ``__fmul_rn``/``__fsub_rn`` round every product and difference to float32 as the separate
  kernels do (they are never contracted into a fused multiply-add), negation is exact, and the
  update is the same ``fma``.

Everything else (line search, stopping rules) is the installed code. The original recursion runs
instead whenever the graph does not apply: tensors not on CUDA or not float32/float64, an empty
history, a nested call, or a failed capture. ``graph_lbfgs_class()`` returns None, and callers keep
torch.optim.LBFGS, when the installed source does not contain the replaced lines verbatim or the
CUDA jiterator is unavailable.
"""

from __future__ import annotations

from pathlib import Path

import torch
import torch.optim.lbfgs as _lbfgs_module

# The recursion as torch 2.9.1 writes it (torch/optim/lbfgs.py, LBFGS.step).
_TWO_LOOP_SOURCE = """                # iteration in L-BFGS loop collapsed to use just one buffer
                q = flat_grad.neg()
                for i in range(num_old - 1, -1, -1):
                    al[i] = old_stps[i].dot(q) * ro[i]
                    q.add_(old_dirs[i], alpha=-al[i])

                # multiply by initial Hessian
                # r/d is the final direction
                d = r = torch.mul(q, H_diag)
                for i in range(num_old):
                    be_i = old_dirs[i].dot(r) * ro[i]
                    r.add_(old_stps[i], alpha=al[i] - be_i)
"""
_TWO_LOOP_REPLACEMENT = """                d = r = _two_loop(flat_grad, old_dirs, old_stps, ro, H_diag, num_old, al)
"""
_ROW_ALIGN_ELEMENTS = 128  # rows start at multiples of 512 bytes (float32) or 1024 bytes (float64)

_state = {"class": None, "built": False, "fma": None, "fused": None, "use_fused": True}
# float32 only: __fmul_rn/__fsub_rn are float intrinsics.
_FUSED_Q_SOURCE = ("template <typename T> T lbfgs_two_loop_q(T q, T y, T dot, T rho) "
                   "{ return fma(-__fmul_rn(dot, rho), y, q); }")
_FUSED_R_SOURCE = ("template <typename T> T lbfgs_two_loop_r(T r, T s, T dot_q, T dot_r, T rho) "
                   "{ return fma(__fsub_rn(__fmul_rn(dot_q, rho), __fmul_rn(dot_r, rho)), s, r); }")
_workspaces = {}


def _eager_two_loop(flat_grad, old_dirs, old_stps, ro, H_diag, num_old, al):
    """The installed recursion, verbatim."""
    q = flat_grad.neg()
    for i in range(num_old - 1, -1, -1):
        al[i] = old_stps[i].dot(q) * ro[i]
        q.add_(old_dirs[i], alpha=-al[i])
    d = r = torch.mul(q, H_diag)
    for i in range(num_old):
        be_i = old_dirs[i].dot(r) * ro[i]
        r.add_(old_stps[i], alpha=al[i] - be_i)
    return d


class _TwoLoopWorkspace:
    """Fixed device buffers and captured graphs for one (size, dtype, device, history) shape."""

    def __init__(self, numel, dtype, device, history_size):
        stride = -(-numel // _ROW_ALIGN_ELEMENTS) * _ROW_ALIGN_ELEMENTS
        self.numel = numel
        self.dirs = torch.zeros((history_size, stride), dtype=dtype, device=device)
        self.stps = torch.zeros((history_size, stride), dtype=dtype, device=device)
        self.ro = torch.zeros((history_size,), dtype=dtype, device=device)
        self.grad = torch.zeros((numel,), dtype=dtype, device=device)
        self.h_diag = torch.zeros((), dtype=dtype, device=device)
        self.out = torch.zeros((numel,), dtype=dtype, device=device)
        self.mirrored = []  # (y, s, rho) tensors whose values the rows hold, in order
        self.graphs = {}
        self.pool = None
        self.stream = None
        self.busy = False
        self.broken = False
        self.fused = (_state["fused"] if dtype == torch.float32 and _state["use_fused"] else None)

    def _write_row(self, row, entry):
        y, s, rho = entry
        self.dirs[row, :self.numel].copy_(y)
        self.stps[row, :self.numel].copy_(s)
        self.ro[row].copy_(rho)

    def sync(self, old_dirs, old_stps, ro, num_old):
        """Make rows 0..num_old-1 hold the history, copying only what changed."""
        entries = list(zip(old_dirs[:num_old], old_stps[:num_old], ro[:num_old]))
        mirrored = self.mirrored

        def same(left, right):
            return all(a[0] is b[0] and a[1] is b[1] and a[2] is b[2] for a, b in zip(left, right))

        if len(mirrored) == num_old and same(mirrored, entries):
            pass
        elif len(mirrored) == num_old - 1 and same(mirrored, entries[:-1]):
            self._write_row(num_old - 1, entries[-1])
        elif len(mirrored) == num_old and num_old > 1 and same(mirrored[1:], entries[:-1]):
            # LBFGS dropped its oldest entry and appended one.
            for buffer in (self.dirs, self.stps, self.ro):
                buffer[:num_old - 1].copy_(buffer[1:num_old].clone())
            self._write_row(num_old - 1, entries[-1])
        else:
            for row, entry in enumerate(entries):
                self._write_row(row, entry)
        self.mirrored = entries

    def _body(self, num_old, fma):
        if self.fused is not None:
            self._body_fused(num_old)
            return
        numel = self.numel
        q = self.grad.neg()
        al = [None] * num_old
        for i in range(num_old - 1, -1, -1):
            al[i] = self.stps[i, :numel].dot(q) * self.ro[i]
            q = fma(q, self.dirs[i, :numel], al[i].neg())
        r = torch.mul(q, self.h_diag)
        for i in range(num_old):
            be_i = self.dirs[i, :numel].dot(r) * self.ro[i]
            r = fma(r, self.stps[i, :numel], al[i] - be_i)
        self.out.copy_(r)

    def _body_fused(self, num_old):
        """``_body`` with al = dot * rho, its negation, be = dot * rho and al - be inside the updates."""
        update_q, update_r = self.fused
        numel = self.numel
        q = self.grad.neg()
        dots = [None] * num_old
        for i in range(num_old - 1, -1, -1):
            dots[i] = self.stps[i, :numel].dot(q)
            q = update_q(q, self.dirs[i, :numel], dots[i], self.ro[i])
        r = torch.mul(q, self.h_diag)
        for i in range(num_old):
            r = update_r(r, self.stps[i, :numel], dots[i], self.dirs[i, :numel].dot(r), self.ro[i])
        self.out.copy_(r)

    def graph(self, num_old, fma):
        graph = self.graphs.get(num_old)
        if graph is None:
            if self.pool is None:
                # Warm up once on the capture stream (cuBLAS handle and workspace,
                # jiterator compile), as torch.cuda.graph requires before a capture.
                self.stream = torch.cuda.Stream(device=self.out.device)
                self.stream.wait_stream(torch.cuda.current_stream(self.out.device))
                with torch.cuda.stream(self.stream):
                    self._body(num_old, fma)
                torch.cuda.current_stream(self.out.device).wait_stream(self.stream)
                self.pool = torch.cuda.graph_pool_handle()
            graph = torch.cuda.CUDAGraph()
            with torch.cuda.graph(graph, pool=self.pool, stream=self.stream):
                self._body(num_old, fma)
            self.graphs[num_old] = graph
        return graph


def _two_loop(flat_grad, old_dirs, old_stps, ro, H_diag, num_old, al):
    """``_eager_two_loop`` through a replayed CUDA graph when it applies; the same values."""
    fma = _state["fma"]
    if (num_old == 0 or fma is None or not flat_grad.is_cuda
            or flat_grad.dtype not in (torch.float32, torch.float64)
            or not isinstance(H_diag, torch.Tensor) or flat_grad.dim() != 1):
        return _eager_two_loop(flat_grad, old_dirs, old_stps, ro, H_diag, num_old, al)
    key = (flat_grad.numel(), flat_grad.dtype, str(flat_grad.device), len(al))
    workspace = _workspaces.get(key)
    if workspace is None:
        workspace = _workspaces[key] = _TwoLoopWorkspace(
            flat_grad.numel(), flat_grad.dtype, flat_grad.device, len(al))
    if workspace.busy or workspace.broken:
        return _eager_two_loop(flat_grad, old_dirs, old_stps, ro, H_diag, num_old, al)
    workspace.busy = True
    try:
        workspace.sync(old_dirs, old_stps, ro, num_old)
        workspace.grad.copy_(flat_grad)
        workspace.h_diag.copy_(H_diag)
        try:
            graph = workspace.graph(num_old, fma)
        except Exception:  # capture failed: keep the original recursion for this shape
            workspace.broken = True
            return _eager_two_loop(flat_grad, old_dirs, old_stps, ro, H_diag, num_old, al)
        graph.replay()
        return workspace.out.clone()
    finally:
        workspace.busy = False


def graph_lbfgs_class():
    """The installed LBFGS with the graph recursion, or None when it cannot be built exactly."""
    if not _state["built"]:
        _state["built"] = True
        try:
            source = Path(_lbfgs_module.__file__).read_text(encoding="utf-8")
            fma = torch.cuda.jiterator._create_jit_fn(
                "template <typename T> T fma_update(T q, T x, T a) { return fma(a, x, q); }")
            fused = (torch.cuda.jiterator._create_jit_fn(_FUSED_Q_SOURCE),
                     torch.cuda.jiterator._create_jit_fn(_FUSED_R_SOURCE))
        except Exception:  # pragma: no cover - torch without the CUDA jiterator
            return None
        if source.count(_TWO_LOOP_SOURCE) != 1:
            return None
        namespace = {"__name__": "torch.optim.lbfgs_two_loop_graph", "__package__": "torch.optim",
                     "_two_loop": _two_loop}
        exec(compile(source.replace(_TWO_LOOP_SOURCE, _TWO_LOOP_REPLACEMENT),
                     _lbfgs_module.__file__, "exec"), namespace)
        _state["class"] = namespace["LBFGS"]
        _state["fma"] = fma
        _state["fused"] = fused
    return _state["class"]
