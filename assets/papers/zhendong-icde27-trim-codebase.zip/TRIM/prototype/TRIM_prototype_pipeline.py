# TRIM pipeline with hierarchical release construction integrated into search.

# Goal: given the original dataset and a downstream model, search for a release
# whose validation loss <= the level-0 validation baseline + tolerance.
# At iteration t, TRIM uses the current min-K and assigns rows
# at the finest K-safe snapshot in S0..St, suppressing only the residual rows.
#
# Model roles:
#   - estimator: performs first-stage LGA ranking and is refreshed after each
#     iteration. The default LGA implementation reads flat linear parameters.
#   - proxy: performs second-stage candidate certification and is retrained for
#     each evaluated release.
#   - downstream: defines the utility baselines and performs final evaluation.
#
# Pipeline outline:
# 0. Split train/val/test; encode at level-0 and max level; freeze a
#    standardizer; fit downstream on full level-0 train to get validation and
#    test baselines; sample a small S0 bootstrap.
# 1. Fit the estimator and proxy on S0.
# 2. Greedy loop: build an inclusion candidate for every remaining retention
#    class and a refine-and-swap candidate (plus its refine-and-evict
#    variants) for every finer QI level; rank them by LGA / privacy cost on the
#    estimator theta; retrain the proxy on the retained rows of the top-b
#    candidates of each pool to obtain their validation-loss gain;
#    score them by utility_gain / max(log(current_k/next_k), kappa) and commit
#    one positive-gain action. Finish the iteration by refitting the estimator
#    on the selected state. The selected action's validation loss becomes the
#    next search loss. Target-model validation of the mixed release confirms
#    stopping.
# 3. Final release: rebuild the selected iteration's mixed release, evaluate it
#    on the test split and persist it. Unmet validation constraints return
#    original D.

from __future__ import annotations

from dataclasses import dataclass, field, replace
from datetime import datetime
import heapq
import hashlib
import json
from pathlib import Path
import re
import time
from typing import Any
from uuid import uuid4
import math

import numpy as np
import torch

from .gpu_logistic import TorchLogisticRegression
from .gpu_math import (
    classification_log_loss_tensor,
    model_theta_tensor,
    resolve_device,
    resolve_dtype,
    to_device_tensor,
)
from .greedy_selection import SelectionState, calculate_leakage, _write_action_log
from .initialization import stratified_sample_row_ids
from .backend_training import fit_standardizer
from .privacy_metrics import individual_tail_risk_stats, original_equivalence_class_sizes
from .selection_cache import SelectionCache
from .enumeration_horizontal import (
    build_retention_class_groups,
    build_retention_class_position_index,
    build_retention_class_position_index_numpy,
    build_retention_class_row_groups_from_codes,
    select_encoded_attributes,
)
from .experiment_hooks import (
    ALL_ROWS_AT_MAX_GENERALIZATION,
    EVICT_LOW_K_POSTPROCESSING,
    FULL_SWAP_POSTPROCESSING,
    NO_VERTICAL_POSTPROCESSING,
    RETENTION_CLASS_ACTION,
    S0_INITIALIZATION,
    VERTICAL_REFINEMENT_ACTION,
    AblationActions,
    CandidateScorerRunContext,
    CandidateShortlistContext,
    CandidateStateScoreContext,
    FixedRowCandidateBuilderContext,
    FixedRowCandidatePlan,
    RankedCandidate,
    SelectionScoreContext,
    default_selection_score,
)


# TRIM defaults. Experiment runners may override these values.
DEFAULT_RANK_TOP_K = 7
DEFAULT_MAX_ITERATIONS = None
VERTICAL_SWAP_MAX_ITERATIONS = 3000
# The proxy check of a refine-and-evict variant: "retained" fits the proxy on
# its kept rows; "published_check" also fits it on the evicted rows where the
# mixed release publishes them (at the newest earlier snapshot where their
# class is K-safe), with the validation rows of those classes encoded at the
# same snapshot. The LGA ranking is the same in both.
EVICTION_SCORING_MODES = ("retained", "published_check")
# None gives refine-and-evict variants their own LGA top-b pool; "union" also
# proxy-checks the variants of every refinement in the refinements' top-b.
EVICTION_SHORTLIST_MODES = (None, "union")
# Stall rule: when a round finds no candidate with a positive estimated gain
# before the utility check passes, "widen" proxy-checks the top
# stall_widen_top_k (b-bar) candidates of each pool once more.
STALL_RULES = (None, "widen")


def _operation_privacy_cost(current_k, next_k, floor):
    """Return the cost max(Delta Leakage, kappa) and the exact change Delta Leakage in log risk."""
    if current_k < 1 or next_k < 1:
        raise ValueError("Privacy scoring requires positive current and candidate min-K.")
    delta = math.log(current_k / next_k)
    if floor is None or not math.isfinite(float(floor)) or float(floor) <= 0:
        raise ValueError("The privacy cost requires a finite positive privacy_cost_floor (kappa).")
    return max(delta, float(floor)), delta


def _same_release_part(left, right):
    """Exact equality of two model-input parts (tensors, frames or arrays)."""
    if type(left) is not type(right):
        return False
    if isinstance(left, torch.Tensor):
        return (left.shape == right.shape and left.dtype == right.dtype
                and left.device == right.device and bool(torch.equal(left, right)))
    if hasattr(left, "equals"):
        return bool(left.equals(right))
    return bool(np.array_equal(np.asarray(left), np.asarray(right)))


def _callable_name(callback):
    if callback is None:
        return None
    module = getattr(callback, "__module__", None)
    qualified_name = getattr(callback, "__qualname__", None)
    if qualified_name is None:
        qualified_name = callback.__class__.__qualname__
    return f"{module}.{qualified_name}" if module else qualified_name


def _loaded_input_sha256(X_raw, y) -> str:
    """Hash the exact loaded rows without persisting any raw record."""
    import pandas as pd

    frame = X_raw if isinstance(X_raw, pd.DataFrame) else pd.DataFrame(X_raw)
    target = pd.Series(y, index=frame.index, name="__target__")
    digest = hashlib.sha256()
    digest.update(
        json.dumps(
            {
                "columns": [str(column) for column in frame.columns],
                "dtypes": [str(dtype) for dtype in frame.dtypes],
                "row_count": len(frame),
            },
            sort_keys=True,
        ).encode("utf-8")
    )
    digest.update(
        pd.util.hash_pandas_object(frame, index=True, categorize=True)
        .to_numpy(dtype=np.uint64, copy=False)
        .tobytes()
    )
    digest.update(
        pd.util.hash_pandas_object(target, index=True, categorize=True)
        .to_numpy(dtype=np.uint64, copy=False)
        .tobytes()
    )
    return digest.hexdigest()


@dataclass
class TrimPipelineResult:
    task_type: str = "classification"
    loss_metric: str = "log_loss"
    selected_row_ids: list[Any] = field(default_factory=list)
    generalization_level: dict[str, int] = field(default_factory=dict)
    state: SelectionState | None = None
    initial_row_ids: list[Any] = field(default_factory=list)
    selected_retention_class_keys: list[Any] = field(default_factory=list)
    termination_condition: str | None = None
    final_actual_model_loss: float | None = None
    utility_constraint_met: bool | None = None
    validation_utility_constraint_met: bool | None = None
    baseline_val_loss: float | None = None
    loss_threshold_val: float | None = None
    baseline_test_loss: float | None = None
    loss_threshold_test: float | None = None
    original_leak_k: int | None = None
    original_leak_k_p1: float | None = None
    original_leak_k_p2: float | None = None
    original_leak_k_p3: float | None = None
    original_leak_k_p4: float | None = None
    original_leak_k_p5: float | None = None
    final_leak_k: int | None = None
    leak_k_p5: float | None = None
    tail_risk_p99: float | None = None
    final_leak_k_sorted: list[int] = field(default_factory=list)
    final_leak_k_95_percentile: int | None = None
    release_target_k: int | None = None
    release_assignment_counts: dict[int, int] = field(default_factory=dict)
    release_suppressed_row_ids: list[Any] = field(default_factory=list)
    release_snapshot_history: list[dict[str, Any]] = field(default_factory=list)
    infeasible: bool = False
    target_validation_loss: float | None = None
    test_evaluated: bool = True
    output_comparisons: dict[str, Any] = field(default_factory=dict)
    iteration_count: int = 0
    timings: dict[str, float] = field(default_factory=dict)
    run_dir: str | None = None


@dataclass
class _SwapEncodeCache:
    encoded: Any
    codes: Any
    row_ids: Any
    row_id_to_position: dict[Any, int]
    selected_attributes: tuple
    attribute_columns: dict[str, list]


def _leak_distribution_stats(encode):
    """min-K, 1..5 percentile min-K, 95 percentile, sorted per-record k."""
    group_sizes = [] if encode.empty else encode.value_counts(sort=False).values
    return _leak_distribution_stats_from_group_sizes(group_sizes)


def _per_record_equivalence_class_sizes(encode):
    """Return each encoded row's own equivalence-class size, indexed by row ID."""
    if encode.empty:
        return encode.index.to_series().iloc[0:0].astype(np.intp)
    if encode.shape[1] == 0:
        raise ValueError("Privacy encoding must contain at least one QI column.")
    return encode.groupby(
        list(encode.columns),
        sort=False,
        dropna=False,
        observed=True,
    ).transform("size").astype(np.intp)


def _individual_tail_risk_stats(original_per_record_k, current_encode):
    """Compute absolute individual log risk over D, the training split."""
    current_per_record_k = _per_record_equivalence_class_sizes(current_encode)
    return individual_tail_risk_stats(original_per_record_k.index, current_per_record_k)


def _empty_leak_distribution_stats():
    return {
        "leak_k": 0,
        "leak_k_p1": 0.0,
        "leak_k_p2": 0.0,
        "leak_k_p3": 0.0,
        "leak_k_p4": 0.0,
        "leak_k_p5": 0.0,
        "leak_k_sorted": [],
        "leak_k_95_percentile": None,
    }


def _leak_distribution_stats_from_group_sizes(group_sizes):
    group_sizes = np.asarray(group_sizes, dtype=np.intp)
    group_sizes = group_sizes[group_sizes > 0]
    if group_sizes.size == 0:
        return _empty_leak_distribution_stats()

    per_record_k = np.repeat(group_sizes, group_sizes)
    leak_k_sorted = sorted(int(v) for v in per_record_k.tolist())
    percentile_index = (95 * len(leak_k_sorted) + 99) // 100 - 1
    return {
        "leak_k": leak_k_sorted[0],
        "leak_k_p1": float(np.percentile(per_record_k, 1)),
        "leak_k_p2": float(np.percentile(per_record_k, 2)),
        "leak_k_p3": float(np.percentile(per_record_k, 3)),
        "leak_k_p4": float(np.percentile(per_record_k, 4)),
        "leak_k_p5": float(np.percentile(per_record_k, 5)),
        "leak_k_sorted": leak_k_sorted,
        "leak_k_95_percentile": leak_k_sorted[percentile_index],
    }


def _published_leak_snapshot(current_encode, selected_row_ids, position_index=None):
    """Published row count, leak statistics and class sizes of the retained state."""
    if position_index is not None:
        return _published_leak_snapshot_from_position_index(selected_row_ids, position_index)

    # Every selected record is published in the retained-state view.
    published_row_ids = list(dict.fromkeys(selected_row_ids))
    if published_row_ids:
        group_sizes = [
            int(v)
            for v in current_encode.loc[published_row_ids]
            .value_counts(sort=False)
            .values
        ]
    else:
        group_sizes = []
    return (
        len(published_row_ids),
        _leak_distribution_stats_from_group_sizes(group_sizes),
        group_sizes,
    )


def _published_leak_snapshot_from_position_index(selected_row_ids, position_index):
    counts = _class_counts_from_position_index(selected_row_ids, position_index)
    sizes = counts[counts > 0]
    return int(sizes.sum()), _leak_distribution_stats_from_group_sizes(sizes), sizes.tolist()


def _open_run_dir(results_dir, run_tag):
    run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    run_uuid = uuid4().hex[:8]
    safe_tag = ""
    if run_tag:
        safe_tag = "_" + re.sub(r"[^A-Za-z0-9_-]+", "_", str(run_tag)).strip("_")
    run_dir_name = f"run_{run_timestamp}_{run_uuid}{safe_tag}"
    run_dir = Path(results_dir) / run_dir_name if results_dir is not None else None
    if run_dir is not None:
        run_dir.mkdir(parents=True, exist_ok=True)
    action_log_path = None
    if run_dir is not None:
        action_log_path = run_dir / (
            f"pipeline_selection_actions_{run_timestamp}_{run_uuid}.jsonl"
        )
    return run_dir, action_log_path


def _dump_json(obj, path: Path):
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, default=str, sort_keys=True, indent=2)


def _concat_release_model_parts(parts, ordered_row_ids):
    """Combine per-snapshot model inputs and restore dataset row order."""
    if not parts:
        raise ValueError("TRIM release model input requires at least one row part.")

    first_encode = parts[0][1]
    try:
        from scipy import sparse
    except ImportError:
        sparse = None
    if sparse is not None and sparse.issparse(first_encode):
        expected_feature_count = int(first_encode.shape[1])
        matrices = []
        for _row_ids, encode in parts:
            if (
                not sparse.issparse(encode)
                or int(encode.shape[1]) != expected_feature_count
            ):
                raise ValueError(
                    "TRIM release snapshots produced incompatible model-input columns."
                )
            matrices.append(encode)
        combined = sparse.vstack(matrices, format="csr")
        source_row_ids = [
            row_id
            for row_ids, _encode in parts
            for row_id in row_ids
        ]
        source_position = {
            row_id: position
            for position, row_id in enumerate(source_row_ids)
        }
        return combined[[source_position[row_id] for row_id in ordered_row_ids]]

    if hasattr(first_encode, "columns"):
        import pandas as pd

        expected_columns = list(first_encode.columns)
        for _row_ids, encode in parts[1:]:
            if list(encode.columns) != expected_columns:
                raise ValueError(
                    "TRIM release snapshots produced incompatible model-input columns."
                )
        return pd.concat([encode for _row_ids, encode in parts], axis=0).loc[
            ordered_row_ids
        ]

    if isinstance(first_encode, np.ndarray):
        expected_feature_count = int(first_encode.shape[1])
        matrices = []
        source_row_ids = []
        for row_ids, encode in parts:
            if (
                not isinstance(encode, np.ndarray)
                or encode.ndim != 2
                or int(encode.shape[1]) != expected_feature_count
            ):
                raise ValueError(
                    "TRIM release snapshots produced incompatible model-input columns."
                )
            source_row_ids.extend(row_ids)
            matrices.append(encode)
        combined = np.concatenate(matrices, axis=0)
        source_position = {
            row_id: position
            for position, row_id in enumerate(source_row_ids)
        }
        return np.ascontiguousarray(
            combined[[source_position[row_id] for row_id in ordered_row_ids]]
        )

    source_row_ids = []
    tensors = []
    for row_ids, encode in parts:
        source_row_ids.extend(row_ids)
        tensors.append(encode)
    combined = torch.cat(tensors, dim=0)
    source_position = {
        row_id: position for position, row_id in enumerate(source_row_ids)
    }
    ordered_positions = torch.as_tensor(
        [source_position[row_id] for row_id in ordered_row_ids],
        device=combined.device,
        dtype=torch.long,
    )
    return combined.index_select(0, ordered_positions)


def run_trim_pipeline(
    data_loader,
    generalization_tree_path,
    *,
    tolerance=0.1,
    nrows=None,
    val_size=0.15,
    test_size=0.15,
    random_state=42,
    max_iterations=DEFAULT_MAX_ITERATIONS,
    model_max_iter=50,
    initial_sample_size=None,
    initial_sample_fraction=None,
    rank_top_k=DEFAULT_RANK_TOP_K,
    model_config=None,
    model_factory=None,
    proxy_model_factory=None,
    estimator_model_factory=None,
    results_dir=None,
    run_tag=None,
    device="cuda",
    dtype="float64",
    release_target_k=None,
    ablation_actions=None,
    fixed_row_candidate_builder=None,
    candidate_shortlist=None,
    candidate_state_scorer_factory=None,
    selection_score=None,
    stop_on_utility=True,
    record_iteration_test_metrics=False,
    validation_only=False,
    record_iteration_validation_metrics=False,
    privacy_cost_floor=None,
    candidate_experiment=None,
    influence_model_factory=None,
    selection_cache=True,
    stop_at_release_min_k=None,
    stop_unmet_at_release_min_k=None,
    refinement_eviction_ratios=None,
    stall_rule=None,
    stall_widen_top_k=None,
    eviction_scoring="retained",
    eviction_shortlist=None,
    max_privacy_step=None,
    exact_speedups=False,
):
    """Run TRIM with release utility integrated into search and publication.

    Each round offers one inclusion per remaining retention class and one
    refine-and-swap per finer level of each QI (``"<attribute>@<target level>"``),
    ranks them by LGA / privacy cost and proxy-checks the top ``rank_top_k``
    (the evaluation budget b) of each pool by retraining the proxy on the
    candidate's retained rows D_{t-1}+o. Publication, the utility stop and the
    per-round curves use the mixed release.

    ``selection_cache=True`` evaluates rules, encodings and privacy groups once
    per distinct raw value instead of once per row (``selection_cache.py``);
    every search decision and reported value is unchanged. ``metrics.json``
    records in ``fast_path_usage`` how often each fast path ran or fell back.

    ``refinement_eviction_ratios=[r, ...]`` adds, for every refinement target
    and ratio r > 1, the refine-and-evict variant that also evicts the
    post-swap retained classes smaller than ceil(current_k / r)
    (``"<id>~k<ceiling>"``). ``None`` offers the refine-and-swap only.
    ``eviction_scoring="published_check"`` (with ``refinement_eviction_ratios``)
    proxy-checks each refine-and-evict variant on its kept rows plus its evicted
    rows where the mixed release publishes them, at the newest earlier snapshot
    where their class is K-safe; the validation rows of those classes are
    encoded at that snapshot too. A committed variant is re-measured on its
    retained rows, so later rounds compare like with like. ``"retained"``
    proxy-checks variants on their kept rows only.
    ``eviction_shortlist="union"`` (with ``refinement_eviction_ratios``) also
    proxy-checks the variants of every refinement in the refinements' top
    ``rank_top_k``, besides the variants' own LGA top ``rank_top_k``.
    ``max_privacy_step=r`` (r > 1) prefers, among positive-gain candidates,
    those with ``next_k * r >= current_k``; the best score among them is
    committed, and a candidate outside the bound only when none is inside.
    ``stall_rule="widen"`` acts when a round finds no candidate with a positive
    estimated gain while the stop condition is unmet: the round proxy-checks
    the top ``stall_widen_top_k`` (b-bar) candidates of each pool, ranked and
    tie-ordered as in the top-b shortlist. The run ends when that also finds
    nothing. ``None`` ends the run at the first such round.

    ``stop_at_release_min_k=k`` ends a trajectory (``stop_on_utility=False``)
    after the first committed round whose mixed release has min-K <= k; the
    point of that round is kept. ``None`` runs until no action is available.
    ``stop_unmet_at_release_min_k=k`` (with ``stop_on_utility``) ends the
    search at the first round whose release has min-K <= k while the utility
    constraint is still unmet; TRIM then returns D, as when no candidate has a
    positive gain (a min-K 1 release protects no record, so later rounds cannot
    give a more private release that meets epsilon).
    ``stop_on_utility=True`` runs TRIM's final check (Section IV). In the
    initial state and after each committed round, the proxy's validation loss
    on D_t (the loss the search measured for D_t) is compared with that of the
    proxy fitted on the full level-0 training split. When this proxy Delta U is
    within the tolerance, the target model is retrained on the release of D_t
    and checked on validation; the run stops when that check passes, and
    otherwise the search continues. The proxy reference fit and the checks
    count as algorithm time. A run that ends before a check passes returns D.

    ``exact_speedups=True`` (needs ``selection_cache``) turns on code paths that
    compute the same values faster, so every output except the timings is
    identical: model encodings of training, validation and test rows are
    gathered on the device from the selection cache's value tables; each
    split's value codes are computed once; retention-class position indexes of
    refinement candidates are built with numpy; retention classes are grouped
    by the swap cache's integer codes and hold row ids (selection reads only
    their keys and row ids); and logistic models built here (proxy, estimator,
    target) replay their L-BFGS two-loop recursion as CUDA graphs
    (``gpu_logistic.TorchLogisticRegression`` ``lbfgs_graph``; CUDA
    float32/float64 only, else the plain optimizer).

    ``validation_only=True`` discards holdout objects behind an access guard.
    ``record_iteration_validation_metrics`` records the target model's
    validation result in every round; in a round without a final check it is an
    observation, and its time is excluded.
    ``release_target_k=None`` derives the release target from each current or
    candidate state's published min-K.
    ``None`` hooks and ``AblationActions()`` run the TRIM algorithm; the hooks
    and ``AblationActions`` define the ablation variants.
    ``record_iteration_test_metrics`` is an experiment-only observation and
    its downstream retraining time is kept outside algorithm timings.
    """
    from sklearn.model_selection import train_test_split
    from sklearn.utils import shuffle as shuffle_rows
    from .state_history import TestSplitGuard, append_state_record, retained_ids_sha256

    # Kappa is user-supplied; it is never tuned or defaulted here.
    _operation_privacy_cost(1, 1, privacy_cost_floor)
    if refinement_eviction_ratios is not None:
        if (isinstance(refinement_eviction_ratios, (str, bytes)) or not refinement_eviction_ratios
                or any(isinstance(r, bool) or not isinstance(r, (int, float))
                       or not math.isfinite(float(r)) or float(r) <= 1
                       for r in refinement_eviction_ratios)):
            raise ValueError("refinement_eviction_ratios must be a non-empty list of numbers > 1 or None.")
        if candidate_experiment is not None:
            raise ValueError("refinement_eviction_ratios is not supported with candidate experiments.")
        refinement_eviction_ratios = [float(r) for r in refinement_eviction_ratios]
    if stall_rule not in STALL_RULES:
        raise ValueError(f"stall_rule must be one of {STALL_RULES}.")
    if stall_rule is not None and candidate_experiment is not None:
        raise ValueError("stall_rule cannot be combined with candidate_experiment.")
    if stop_unmet_at_release_min_k is not None:
        if (isinstance(stop_unmet_at_release_min_k, bool) or not isinstance(stop_unmet_at_release_min_k, int)
                or stop_unmet_at_release_min_k < 1):
            raise ValueError("stop_unmet_at_release_min_k must be a positive integer or None.")
        if not stop_on_utility:
            raise ValueError("stop_unmet_at_release_min_k applies only with stop_on_utility=True.")
    if stall_rule == "widen":
        if (isinstance(stall_widen_top_k, bool) or not isinstance(stall_widen_top_k, int)
                or stall_widen_top_k <= rank_top_k):
            raise ValueError("stall_rule 'widen' requires an integer stall_widen_top_k larger than rank_top_k.")
    elif stall_widen_top_k is not None:
        raise ValueError("stall_widen_top_k requires stall_rule 'widen'.")
    if not isinstance(exact_speedups, bool):
        raise TypeError("exact_speedups must be bool.")
    if exact_speedups and not selection_cache:
        raise ValueError("exact_speedups requires selection_cache.")
    if eviction_scoring not in EVICTION_SCORING_MODES:
        raise ValueError(f"eviction_scoring must be one of {EVICTION_SCORING_MODES}.")
    if eviction_scoring != "retained" and refinement_eviction_ratios is None:
        raise ValueError("eviction_scoring other than 'retained' requires refinement_eviction_ratios.")
    if max_privacy_step is not None:
        if (isinstance(max_privacy_step, bool) or not isinstance(max_privacy_step, (int, float))
                or not math.isfinite(float(max_privacy_step)) or float(max_privacy_step) <= 1):
            raise ValueError("max_privacy_step must be a number > 1 or None.")
        max_privacy_step = float(max_privacy_step)
    if eviction_shortlist not in EVICTION_SHORTLIST_MODES:
        raise ValueError(f"eviction_shortlist must be one of {EVICTION_SHORTLIST_MODES}.")
    if eviction_shortlist is not None and (
            refinement_eviction_ratios is None or candidate_shortlist is not None
            or candidate_experiment is not None):
        raise ValueError("eviction_shortlist requires refinement_eviction_ratios and no "
                         "candidate_shortlist or candidate_experiment.")
    if stop_at_release_min_k is not None:
        if (isinstance(stop_at_release_min_k, bool) or not isinstance(stop_at_release_min_k, int)
                or stop_at_release_min_k < 1):
            raise ValueError("stop_at_release_min_k must be a positive integer or None.")
        if stop_on_utility:
            # A utility-stopped run would report reaching k as infeasibility.
            raise ValueError("stop_at_release_min_k applies only to trajectories (stop_on_utility=False).")
    for flag_name, flag in (("validation_only", validation_only),
                            ("record_iteration_validation_metrics", record_iteration_validation_metrics)):
        if not isinstance(flag, bool):
            raise TypeError(f"{flag_name} must be bool.")
    if validation_only and record_iteration_test_metrics:
        raise ValueError("validation_only cannot record iteration test metrics.")
    X_raw, y = data_loader.load(nrows=nrows)
    retained_ids_sha256(X_raw.index)  # Reject ambiguous artifact row IDs.
    input_data_sha256 = _loaded_input_sha256(X_raw, y)
    tree_artifact_path = Path(generalization_tree_path).expanduser().resolve()
    generalization_tree_sha256 = hashlib.sha256(
        tree_artifact_path.read_bytes()
    ).hexdigest()
    X_raw, y = shuffle_rows(X_raw, y, random_state=random_state)
    pipeline_start_time = time.perf_counter()
    if getattr(data_loader, "task_type", "classification") != "classification":
        raise ValueError("TRIM supports classification datasets only.")
    if release_target_k is not None and int(release_target_k) < 1:
        raise ValueError("release_target_k must be a positive integer or None.")
    if initial_sample_size is not None and initial_sample_fraction is not None:
        raise ValueError(
            "initial_sample_size and initial_sample_fraction are mutually exclusive."
        )
    if initial_sample_fraction is not None:
        initial_sample_fraction = float(initial_sample_fraction)
        if not 0.0 < initial_sample_fraction <= 1.0:
            raise ValueError("initial_sample_fraction must be in (0, 1].")
    if fixed_row_candidate_builder is not None and (
        initial_sample_size is not None or initial_sample_fraction is not None
    ):
        raise ValueError(
            "fixed_row_candidate_builder supplies its own initialization and "
            "cannot be combined with initial_sample_size or "
            "initial_sample_fraction."
        )
    if ablation_actions is None:
        ablation_actions = AblationActions()
    elif not isinstance(ablation_actions, AblationActions):
        raise TypeError("ablation_actions must be an AblationActions instance or None.")
    if not isinstance(stop_on_utility, bool):
        raise TypeError("stop_on_utility must be bool.")
    if not isinstance(record_iteration_test_metrics, bool):
        raise TypeError("record_iteration_test_metrics must be bool.")
    for callback_name, callback in (
        ("fixed_row_candidate_builder", fixed_row_candidate_builder),
        ("candidate_shortlist", candidate_shortlist),
        ("candidate_state_scorer_factory", candidate_state_scorer_factory),
        ("selection_score", selection_score),
    ):
        if callback is not None and not callable(callback):
            raise TypeError(f"{callback_name} must be callable or None.")
    enabled_action_types = frozenset(ablation_actions.enabled_action_types)
    loss_metric_name = "log_loss"
    classification_classes = np.unique(np.asarray(y))
    class_count = int(len(classification_classes))
    use_multiclass = class_count > 2

    # --- Split: hold out test, then carve val out of the remainder. ----------
    X_trainval_raw, X_test_raw, y_trainval, y_test = train_test_split(
        X_raw, y, test_size=test_size, random_state=random_state,
        stratify=y,
    )
    val_size_of_trainval = val_size / (1.0 - test_size) if (1.0 - test_size) > 0 else 0.0
    X_train_raw, X_val_raw, y_train, y_val = train_test_split(
        X_trainval_raw, y_trainval, test_size=val_size_of_trainval,
        random_state=random_state,
        stratify=y_trainval,
    )

    if validation_only:
        X_test_raw, y_test = TestSplitGuard(), TestSplitGuard()

    # --- Generalization encodes. --------------------------------------------
    from . import dataloader as dataloader_module

    original_generalization = dataloader_module.load_generalization_rules_from_file(
        file_path=generalization_tree_path, data_loader=data_loader,
        generalization_level={a: 0 for a in data_loader.feature_columns},
    )
    train_original_encode = original_generalization.encode(X_train_raw)
    val_original_encode = original_generalization.encode(X_val_raw)
    test_original_encode = None if validation_only else original_generalization.encode(X_test_raw)

    qi_attributes = getattr(data_loader, "qi_attributes", None)
    if qi_attributes is None:
        qi_attributes = data_loader.feature_columns
    qi_attributes = tuple(qi_attributes)
    # Retention classes group the training rows by their QI values.
    selected_attributes = qi_attributes
    run_selection_cache = None
    if selection_cache and isinstance(original_generalization, dataloader_module.DatasetGeneralization):
        run_selection_cache = SelectionCache(
            original_generalization, data_loader,
            [X_train_raw, X_val_raw] + ([] if validation_only else [X_test_raw]),
            qi_attributes,
        )
        original_generalization = run_selection_cache.wrap(original_generalization)
        run_selection_cache.memo_codes = exact_speedups
    # Each fast path switches itself off when its preconditions fail, without
    # changing any result; these counters make a silent fallback visible.
    fast_path_usage = {
        "selection_cache_active": run_selection_cache is not None,
        "release_rank_privacy": {"used": 0, "fallback": 0},
        "refinement_rank_privacy": {"used": 0, "fallback": 0},
        "selection_class_id_privacy": {"used": 0, "fallback": 0},
    }

    max_generalization_level = {}
    from .greedy_selection import _load_max_generalization_level
    max_generalization_level = _load_max_generalization_level(
        generalization_tree_path, qi_attributes,
    )
    fixed_row_candidate_plan = None
    fixed_row_candidate_build_time = 0.0
    if fixed_row_candidate_builder is not None:
        fixed_row_candidate_build_started_at = time.perf_counter()
        fixed_row_candidate_plan = fixed_row_candidate_builder(
            FixedRowCandidateBuilderContext(
                train_level0_encode=train_original_encode.copy(),
                selected_attributes=selected_attributes,
                random_state=int(random_state),
                max_generalization_level=dict(max_generalization_level),
            )
        )
        fixed_row_candidate_build_time = (
            time.perf_counter() - fixed_row_candidate_build_started_at
        )
        if not isinstance(fixed_row_candidate_plan, FixedRowCandidatePlan):
            raise TypeError(
                "fixed_row_candidate_builder must return FixedRowCandidatePlan."
            )
        if RETENTION_CLASS_ACTION not in enabled_action_types:
            raise ValueError(
                "A fixed row-candidate plan requires the retention-class "
                "action to be enabled."
            )
        if (
            VERTICAL_REFINEMENT_ACTION in enabled_action_types
            and ablation_actions.vertical_postprocessing
            != NO_VERTICAL_POSTPROCESSING
        ):
            raise ValueError(
                "A fixed row-candidate plan combined with vertical refinement "
                "must disable vertical postprocessing so the fixed partition "
                "remains intact."
            )
        if ablation_actions.initialization != S0_INITIALIZATION:
            raise ValueError(
                "A fixed row-candidate plan supplies its own initialization; "
                "AblationActions.initialization must remain 's0'."
            )
        expected_rows = list(train_original_encode.index)
        planned_rows = [
            row_id
            for _key, row_ids in fixed_row_candidate_plan.candidate_groups
            for row_id in row_ids
        ]
        if len(planned_rows) != len(set(planned_rows)):
            raise ValueError("Fixed row candidate groups must be disjoint.")
        if set(planned_rows) != set(expected_rows):
            missing = set(expected_rows) - set(planned_rows)
            extra = set(planned_rows) - set(expected_rows)
            raise ValueError(
                "Fixed row candidate groups must partition the training rows; "
                f"missing={len(missing)}, extra={len(extra)}."
            )
        if not set(fixed_row_candidate_plan.initial_row_ids).issubset(planned_rows):
            raise ValueError("Fixed-plan initial rows must belong to its groups.")
        if set(fixed_row_candidate_plan.generalization_level) != set(
            max_generalization_level
        ):
            raise ValueError(
                "Fixed-plan generalization_level must declare every QI attribute."
            )
        initial_generalization_level = dict(
            fixed_row_candidate_plan.generalization_level
        )
    else:
        initial_generalization_level = max_generalization_level
    current_generalization = dataloader_module.load_generalization_rules_from_file(
        file_path=generalization_tree_path, data_loader=data_loader,
        generalization_level=initial_generalization_level,
    )
    if run_selection_cache is not None:
        current_generalization = run_selection_cache.wrap(current_generalization)
    swap_encode_cache = _build_swap_encode_cache(
        current_generalization,
        X_train_raw,
        selected_attributes=selected_attributes,
    )
    initial_generalization_train_encode = swap_encode_cache.encoded

    # D is the training split being minimized. Original privacy uses its raw
    # QIs; level-0 model bins must not merge original privacy classes.
    original_dataset_encode = train_original_encode
    original_per_record_k = original_equivalence_class_sizes(X_train_raw, qi_attributes)
    original_group_sizes = X_train_raw.loc[:, list(qi_attributes)].value_counts(
        sort=False, dropna=False,
    ).to_numpy()
    original_leak_stats = _leak_distribution_stats_from_group_sizes(original_group_sizes)
    original_leak_k = original_leak_stats["leak_k"]
    original_leak_k_p1 = original_leak_stats["leak_k_p1"]
    original_leak_k_p2 = original_leak_stats["leak_k_p2"]
    original_leak_k_p3 = original_leak_stats["leak_k_p3"]
    original_leak_k_p4 = original_leak_stats["leak_k_p4"]
    original_leak_k_p5 = original_leak_stats["leak_k_p5"]
    # Optional per-iteration downstream test retrains are experiment
    # observations, not part of the TRIM algorithm timings.
    total_curve_metric_time = 0.0

    # --- Device tensors. ----------------------------------------------------
    train_original_tensor = to_device_tensor(train_original_encode, device=device, dtype=dtype)
    val_original_tensor = to_device_tensor(val_original_encode, device=train_original_tensor.device, dtype=train_original_tensor.dtype)
    test_original_tensor = (None if validation_only else to_device_tensor(
        test_original_encode, device=train_original_tensor.device, dtype=train_original_tensor.dtype))
    y_train_tensor = to_device_tensor(y_train, device=train_original_tensor.device, dtype=train_original_tensor.dtype).reshape(-1)
    y_val_tensor = to_device_tensor(y_val, device=train_original_tensor.device, dtype=train_original_tensor.dtype).reshape(-1)
    y_test_tensor = (None if validation_only else to_device_tensor(
        y_test, device=train_original_tensor.device, dtype=train_original_tensor.dtype).reshape(-1))

    # --- Standardizer (frozen on level-0 train). ----------------------------
    standardizer = fit_standardizer(train_original_encode, data_loader)

    # --- Model factories. ---------------------------------------------------
    # Target model for utility baselines and final evaluation.
    if model_factory is None:
        model_factory = lambda: TorchLogisticRegression(
            max_iter=model_max_iter, warm_start=True, device=device, dtype=dtype)
    downstream_factory = model_factory

    # Estimator for first-stage LGA ranking.
    if estimator_model_factory is not None:
        estimator_factory = estimator_model_factory
    else:
        estimator_factory = downstream_factory

    # For second-stage candidate certification. Fall back to the downstream
    # model factory when no proxy is configured.
    proxy_factory = proxy_model_factory if proxy_model_factory is not None else downstream_factory

    def _model_family(factory_or_model):
        family = getattr(factory_or_model, "model_family", None)
        if family is not None:
            return family
        if not callable(factory_or_model) and factory_or_model is not None:
            if factory_or_model.__class__.__name__ == "XGBoostGPUClassifier":
                return "xgboost"
        return None

    # XGBoost proxy and downstream models use leaf-space input encodings.
    proxy_uses_xgboost_input = _model_family(proxy_factory) == "xgboost"
    downstream_uses_xgboost_input = _model_family(downstream_factory) == "xgboost"

    def _prepare_model_for_task(model):
        if hasattr(model, "set_classes"):
            model.set_classes(classification_classes)
        if exact_speedups and hasattr(model, "lbfgs_graph"):
            # Exact: the replayed graph runs the same kernels on the same values.
            model.lbfgs_graph = True
        return model

    def _build_model(factory_or_model):
        model = factory_or_model() if callable(factory_or_model) else factory_or_model
        return _prepare_model_for_task(model)

    def _model_role_encode(use_xgboost_input, generalization, X_raw_subset, default_encode):
        if use_xgboost_input:
            return _xgboost_model_input(generalization, X_raw_subset)
        return default_encode

    def _standardized_level_encode(generalization, X_raw_subset, row_ids=None):
        encode = _encode_split_rows(
            generalization, X_raw_subset, row_ids,
            device=train_original_tensor.device, dtype=train_original_tensor.dtype,
            device_gather=exact_speedups)
        return standardizer.transform(encode)

    def _model_eval_encode(use_xgboost_input, generalization, X_raw_subset, row_ids=None):
        """Model input of ``X_raw_subset`` or, with ``row_ids``, of ``X_raw_subset.loc[row_ids]``."""
        if use_xgboost_input:
            return _xgboost_model_input(
                generalization, X_raw_subset if row_ids is None else X_raw_subset.loc[row_ids])
        return _standardized_level_encode(generalization, X_raw_subset, row_ids)

    def _model_loss(model, y_true_tensor, encode_for_model):
        return float(classification_log_loss_tensor(
            y_true_tensor, model.predict_proba_tensor(encode_for_model),
            classes=classification_classes, n_classes=class_count).detach().cpu())

    def _materialize_trim_release(
        snapshot_history,
        target_k,
        *,
        X_eval_raw,
        use_xgboost_input,
    ):
        """Build one mixed-level release without fitting an evaluation model."""
        import pandas as pd

        started_at = time.perf_counter()
        target_k = int(target_k)
        if target_k < 1:
            return {
                "status": "invalid_target_k",
                "target_k": target_k,
                "row_count": 0,
                "suppressed_row_count": int(len(X_train_raw)),
                "coverage_fraction": 0.0,
                "materialization_seconds": float(time.perf_counter() - started_at),
            }

        ordered_snapshots = sorted(
            snapshot_history,
            key=lambda snapshot: int(snapshot["iteration"]),
            reverse=True,
        )
        if not ordered_snapshots:
            raise ValueError("A TRIM release requires at least one generalization snapshot.")

        resolved_snapshots = []
        for snapshot in ordered_snapshots:
            generalization = snapshot.get("_generalization")
            if generalization is None:
                generalization = dataloader_module.load_generalization_rules_from_file(
                    file_path=generalization_tree_path,
                    data_loader=data_loader,
                    generalization_level=snapshot["generalization_level"],
                )
            resolved_snapshots.append((snapshot, generalization))

        # Rank columns group exactly like the encoded QI columns. One release
        # uses one representation, since its parts are concatenated.
        use_ranks = (
            run_selection_cache is not None
            and run_selection_cache.covers(X_train_raw)
            and run_selection_cache.covers(X_eval_raw)
            and all(run_selection_cache.supports_privacy(generalization, qi_attributes)
                    for _snapshot, generalization in resolved_snapshots)
        )
        fast_path_usage["release_rank_privacy"]["used" if use_ranks else "fallback"] += 1

        def _privacy_encode(generalization, X_raw_subset):
            if use_ranks:
                frame = generalization.privacy_frame(X_raw_subset, qi_attributes)
                if frame is None:
                    raise RuntimeError("Rank privacy columns became unavailable within one release.")
                return frame
            return select_encoded_attributes(generalization.encode(X_raw_subset), qi_attributes)

        remaining_ids = list(X_train_raw.index)
        privacy_parts = []
        train_model_parts = []
        accepted_groups = {}
        assignment_counts = {}
        assigned_snapshot_by_row_id = {}
        for snapshot, generalization in resolved_snapshots:
            iteration = int(snapshot["iteration"])
            if not remaining_ids:
                assignment_counts[iteration] = 0
                continue
            remaining_privacy_encode = _privacy_encode(
                generalization, X_train_raw.loc[remaining_ids])
            group_sizes = remaining_privacy_encode.groupby(
                list(remaining_privacy_encode.columns),
                sort=False,
                dropna=False,
                observed=True,
            ).transform("size")
            safe_ids = remaining_privacy_encode.index[
                group_sizes >= target_k
            ].tolist()
            assignment_counts[iteration] = len(safe_ids)
            if not safe_ids:
                continue

            safe_encode = remaining_privacy_encode.loc[safe_ids]
            privacy_parts.append(safe_encode)
            accepted_groups[iteration] = safe_encode.drop_duplicates().reset_index(
                drop=True
            )
            train_model_parts.append((
                safe_ids,
                _model_eval_encode(
                    use_xgboost_input,
                    generalization,
                    X_train_raw,
                    safe_ids,
                ),
            ))
            for row_id in safe_ids:
                assigned_snapshot_by_row_id[row_id] = iteration
            safe_id_set = set(safe_ids)
            remaining_ids = [
                row_id for row_id in remaining_ids if row_id not in safe_id_set
            ]

        if not privacy_parts:
            return {
                "status": "no_safe_groups",
                "target_k": target_k,
                "row_count": 0,
                "unique_row_count": 0,
                "suppressed_row_count": int(len(X_train_raw)),
                "coverage_fraction": 0.0,
                "full_release": False,
                "assignment_counts": assignment_counts,
                "assigned_row_ids": [],
                "suppressed_row_ids": [str(row_id) for row_id in remaining_ids],
                "materialization_seconds": float(time.perf_counter() - started_at),
            }

        assigned_id_set = set(X_train_raw.index) - set(remaining_ids)
        assigned_order = [
            row_id for row_id in X_train_raw.index if row_id in assigned_id_set
        ]
        release_privacy_encode = pd.concat(privacy_parts, axis=0).loc[
            assigned_order
        ]
        release_group_sizes = [
            int(value)
            for value in release_privacy_encode.value_counts(sort=False).values
        ]
        release_leak_stats = _leak_distribution_stats(release_privacy_encode)
        tail_risk_stats = _individual_tail_risk_stats(
            original_per_record_k,
            release_privacy_encode,
        )
        release_train_encode = _concat_release_model_parts(
            train_model_parts,
            assigned_order,
        )
        release_train_positions = [
            row_id_to_position[row_id] for row_id in assigned_order
        ]
        release_train_y = y_train_tensor[release_train_positions]

        remaining_eval_ids = list(X_eval_raw.index)
        eval_model_parts = []
        eval_assignment_counts = {}
        for snapshot, generalization in resolved_snapshots:
            iteration = int(snapshot["iteration"])
            groups = accepted_groups.get(iteration)
            if not remaining_eval_ids or groups is None or groups.empty:
                eval_assignment_counts[iteration] = 0
                continue
            candidate_privacy_encode = _privacy_encode(
                generalization, X_eval_raw.loc[remaining_eval_ids])
            candidate_keys = pd.MultiIndex.from_frame(candidate_privacy_encode)
            accepted_keys = pd.MultiIndex.from_frame(groups)
            matched_ids = candidate_privacy_encode.index[
                candidate_keys.isin(accepted_keys)
            ].tolist()
            eval_assignment_counts[iteration] = len(matched_ids)
            if not matched_ids:
                continue
            eval_model_parts.append((
                matched_ids,
                _model_eval_encode(
                    use_xgboost_input,
                    generalization,
                    X_eval_raw,
                    matched_ids,
                ),
            ))
            matched_id_set = set(matched_ids)
            remaining_eval_ids = [
                row_id
                for row_id in remaining_eval_ids
                if row_id not in matched_id_set
            ]

        coarsest_eval_row_count = len(remaining_eval_ids)
        if remaining_eval_ids:
            _snapshot, coarsest_generalization = resolved_snapshots[-1]
            eval_model_parts.append((
                list(remaining_eval_ids),
                _model_eval_encode(
                    use_xgboost_input,
                    coarsest_generalization,
                    X_eval_raw,
                    list(remaining_eval_ids),
                ),
            ))

        release_eval_encode = _concat_release_model_parts(
            eval_model_parts,
            list(X_eval_raw.index),
        )
        finest_eval_iteration = int(resolved_snapshots[0][0]["iteration"])
        finest_eval_row_count = eval_assignment_counts[finest_eval_iteration]
        coarser_eval_row_count = len(X_eval_raw) - finest_eval_row_count
        return {
            "status": "ok",
            "target_k": target_k,
            "min_k": int(release_leak_stats["leak_k"]),
            "leak_k_p1": release_leak_stats["leak_k_p1"],
            "leak_k_p2": release_leak_stats["leak_k_p2"],
            "leak_k_p3": release_leak_stats["leak_k_p3"],
            "leak_k_p4": release_leak_stats["leak_k_p4"],
            "leak_k_p5": release_leak_stats["leak_k_p5"],
            "leak_k_sorted": release_leak_stats["leak_k_sorted"],
            "leak_k_95_percentile": release_leak_stats[
                "leak_k_95_percentile"
            ],
            **tail_risk_stats,
            "privacy_constraint_met": (
                int(release_leak_stats["leak_k"]) >= target_k
            ),
            "row_count": int(len(assigned_order)),
            "unique_row_count": int(len(assigned_order)),
            "suppressed_row_count": int(len(remaining_ids)),
            "coverage_fraction": float(len(assigned_order) / len(X_train_raw)),
            "full_release": not remaining_ids,
            "assignment_counts": assignment_counts,
            "eval_assignment_counts": eval_assignment_counts,
            "eval_coarsest_release_row_count": int(coarsest_eval_row_count),
            "eval_population_size": int(len(X_eval_raw)),
            "eval_finest_snapshot_iteration": finest_eval_iteration,
            "eval_finest_snapshot_row_count": int(finest_eval_row_count),
            "eval_coarser_snapshot_row_count": int(coarser_eval_row_count),
            "eval_coarser_snapshot_fraction": float(coarser_eval_row_count / len(X_eval_raw)) if len(X_eval_raw) else 0.0,
            "eval_coarsest_release_fraction": float(coarsest_eval_row_count / len(X_eval_raw)) if len(X_eval_raw) else 0.0,
            "assigned_row_ids": [str(row_id) for row_id in assigned_order],
            "suppressed_row_ids": [str(row_id) for row_id in remaining_ids],
            "row_snapshot_assignments": {
                str(row_id): int(assigned_snapshot_by_row_id[row_id])
                for row_id in assigned_order
            },
            "materialization_seconds": float(time.perf_counter() - started_at),
            "_assigned_row_ids": assigned_order,
            "_suppressed_row_ids": list(remaining_ids),
            "_train_encode": release_train_encode,
            "_train_y": release_train_y,
            "_eval_encode": release_eval_encode,
            "_group_sizes": release_group_sizes,
        }

    def _evaluate_trim_release(
        snapshot_history,
        target_k,
        *,
        model_factory_for_release,
        use_xgboost_input,
        X_eval_raw,
        y_eval_tensor,
        eval_split,
        baseline_loss,
        loss_threshold,
        fitted_result=None,
    ):
        started_at = time.perf_counter()
        result = _materialize_trim_release(
            snapshot_history,
            target_k,
            X_eval_raw=X_eval_raw,
            use_xgboost_input=use_xgboost_input,
        )
        if result["status"] != "ok":
            result["evaluation_seconds"] = float(
                time.perf_counter() - started_at
            )
            return result

        # A model already fitted on exactly this training release (the same
        # round's target validation) is reused; refitting it would repeat the
        # same deterministic fit.
        if (fitted_result is not None and fitted_result.get("status") == "ok"
                and fitted_result.get("_model") is not None
                and _same_release_part(fitted_result["_train_encode"], result["_train_encode"])
                and _same_release_part(fitted_result["_train_y"], result["_train_y"])):
            release_model = fitted_result["_model"]
        else:
            release_model = _build_model(model_factory_for_release)
            release_model.fit(result["_train_encode"], result["_train_y"])
        release_loss = _model_loss(
            release_model,
            y_eval_tensor,
            result["_eval_encode"],
        )
        # Retain the fitted proxy for optional reference-model filtering in the
        # next iteration. Internal fields are excluded from persisted release
        # records by _public_release_result.
        result["_model"] = release_model
        result[f"{eval_split}_loss"] = float(release_loss)
        result["delta_u"] = float(release_loss - baseline_loss)
        result["delta_u_semantics"] = (
            f"{loss_metric_name}_minus_full_level0_{eval_split}_baseline"
        )
        result["utility_constraint_met"] = bool(
            release_loss <= loss_threshold
        )
        result["evaluation_seconds"] = float(time.perf_counter() - started_at)
        return result

    def _public_release_result(result):
        return {
            key: value
            for key, value in result.items()
            if not key.startswith("_")
        }

    # --- Baselines: downstream on full level-0 train. -----------------------
    threshold_model = _build_model(downstream_factory)
    threshold_train_encode = _model_role_encode(
        downstream_uses_xgboost_input, original_generalization, X_train_raw,
        standardizer.transform(train_original_tensor))
    threshold_val_encode = _model_role_encode(
        downstream_uses_xgboost_input, original_generalization, X_val_raw,
        standardizer.transform(val_original_tensor))
    threshold_test_encode = (None if validation_only else _model_role_encode(
        downstream_uses_xgboost_input, original_generalization, X_test_raw,
        standardizer.transform(test_original_tensor)))
    threshold_model.fit(threshold_train_encode, y_train_tensor)
    baseline_val_loss = _model_loss(
        threshold_model, y_val_tensor, threshold_val_encode)
    baseline_test_loss = (None if validation_only else
                          _model_loss(threshold_model, y_test_tensor, threshold_test_encode))
    loss_threshold_val = baseline_val_loss + tolerance
    loss_threshold_test = None if validation_only else baseline_test_loss + tolerance
    if candidate_experiment is not None:
        influence_model = threshold_model
        if influence_model_factory is not None:
            influence_model = _build_model(influence_model_factory)
            influence_model.fit(standardizer.transform(train_original_tensor), y_train_tensor)
        candidate_experiment.prepare_original(
            influence_model, standardizer.transform(train_original_tensor), y_train_tensor,
        )

    candidate_state_scorer = None
    candidate_state_scorer_setup_seconds = 0.0
    if candidate_state_scorer_factory is not None:
        scorer_setup_started_at = time.perf_counter()
        candidate_state_scorer = candidate_state_scorer_factory(
            CandidateScorerRunContext(
                train_original_encode=standardizer.transform(
                    train_original_tensor
                ),
                train_y=y_train_tensor,
            )
        )
        candidate_state_scorer_setup_seconds = float(
            time.perf_counter() - scorer_setup_started_at
        )
        if not callable(candidate_state_scorer):
            raise TypeError(
                "candidate_state_scorer_factory must return a callable scorer."
            )

    # --- S0 or fixed-plan bootstrap. ---------------------------------------
    train_row_ids = list(train_original_encode.index)
    if fixed_row_candidate_plan is not None:
        initial_row_ids = list(fixed_row_candidate_plan.initial_row_ids)
        initial_sample_size = len(initial_row_ids)
    else:
        if initial_sample_fraction is not None:
            initial_sample_size = max(
                1,
                int(len(train_row_ids) * initial_sample_fraction),
            )
        elif initial_sample_size is None:
            initial_sample_size = 1
        else:
            initial_sample_size = int(initial_sample_size)
        if initial_sample_size < 1:
            raise ValueError("initial_sample_size must be at least 1.")
        if initial_sample_size > len(train_row_ids):
            raise ValueError("initial_sample_size cannot exceed the training row count.")
        initial_row_ids = stratified_sample_row_ids(
            train_row_ids,
            y_train,
            initial_sample_size,
            random_state,
        )
    if not initial_row_ids:
        raise ValueError("initial_row_ids must contain at least one row.")
    # Seeds are ordinary retained records for risk accounting and exchanges.

    current_train_encode = initial_generalization_train_encode.copy()
    current_train_tensor = to_device_tensor(
        current_train_encode, device=train_original_tensor.device, dtype=train_original_tensor.dtype)
    row_id_to_position = {rid: pos for pos, rid in enumerate(current_train_encode.index)}

    # Every initialization row contributes to risk. The all-rows ablation
    # initializes the selected state at the maximum-generalization snapshot.
    initialization_row_ids = (
        list(fixed_row_candidate_plan.initial_row_ids)
        if fixed_row_candidate_plan is not None
        else (
            list(train_row_ids)
            if ablation_actions.initialization == ALL_ROWS_AT_MAX_GENERALIZATION
            else list(initial_row_ids)
        )
    )
    initialization_row_id_set = set(initialization_row_ids)

    # Fit the estimator and proxy on the initial sample. Candidate certification
    # then updates the validation-loss signal after each selected release; the
    # downstream model is reserved for final utility evaluation.
    initial_positions = [
        row_id_to_position[rid] for rid in initialization_row_ids
    ]
    initial_fit_encode = standardizer.transform(current_train_tensor[initial_positions])
    initial_fit_y = y_train_tensor[initial_positions]

    initial_model_fit_started = time.perf_counter()
    backend_model = _build_model(estimator_factory)
    if hasattr(backend_model, "warm_start"):
        backend_model.warm_start = True
    backend_model.fit(initial_fit_encode, initial_fit_y)

    proxy_model = _build_model(proxy_factory)
    initial_proxy_fit_encode = _model_role_encode(
        proxy_uses_xgboost_input, current_generalization,
        X_train_raw.loc[initialization_row_ids], initial_fit_encode)
    proxy_val_encode = _model_eval_encode(
        proxy_uses_xgboost_input, current_generalization, X_val_raw)
    proxy_model.fit(initial_proxy_fit_encode, initial_fit_y)
    proxy_model_loss = _model_loss(proxy_model, y_val_tensor, proxy_val_encode)
    initial_model_fit_seconds = time.perf_counter() - initial_model_fit_started

    # --- Running timing totals. ---------------------------------------------
    total_enumeration_time = 0.0
    total_selection_time = 0.0
    total_privacy_accounting_time = 0.0
    total_retraining_time = initial_model_fit_seconds  # estimator and proxy fits on D_0
    total_target_validation_time = 0.0

    # --- Initial retention classes (max level, minus selected rows). --------
    initial_enumeration_started_at = time.perf_counter()
    if RETENTION_CLASS_ACTION not in enabled_action_types:
        remaining_retention_classes = []
    elif fixed_row_candidate_plan is not None:
        remaining_retention_classes = []
        selected_initial_set = set(initialization_row_ids)
        for group_key, group_row_ids in fixed_row_candidate_plan.candidate_groups:
            remaining_index = [
                row_id
                for row_id in group_row_ids
                if row_id not in selected_initial_set
            ]
            if remaining_index:
                remaining_retention_classes.append(
                    (group_key, current_train_encode.loc[remaining_index].copy())
                )
    elif _can_use_position_index_leakage(swap_encode_cache):
        initial_position_index = _swap_position_index_from_cache(swap_encode_cache)
        remaining_retention_classes = (
            _retention_class_index_groups_from_position_index(
                initial_position_index,
                excluded_row_ids=initialization_row_id_set,
            )
        )
    else:
        # exact_speedups: the same classes, keys and order from the swap cache's
        # per-attribute codes, holding row ids instead of frame copies (selection
        # reads only a class's key and row ids).
        code_groups = (build_retention_class_row_groups_from_codes(
            initial_generalization_train_encode, swap_encode_cache.codes,
            list(initial_generalization_train_encode.index), selected_attributes)
            if exact_speedups else None)
        if code_groups is not None:
            remaining_retention_classes = []
            for rc_key, rc_row_ids in code_groups:
                remaining_index = [rid for rid in rc_row_ids if rid not in initialization_row_id_set]
                if remaining_index:
                    remaining_retention_classes.append((rc_key, remaining_index))
        else:
            retention_classes = build_retention_class_groups(
                initial_generalization_train_encode,
                selected_attributes=selected_attributes)
            remaining_retention_classes = []
            for rc_key, rc in retention_classes.items():
                remaining_index = [
                    rid for rid in rc.index
                    if rid not in initialization_row_id_set
                ]
                if remaining_index:
                    remaining_retention_classes.append(
                        (rc_key, rc.loc[remaining_index].copy()))
    initial_retention_class_build_time = (
        fixed_row_candidate_build_time
        + time.perf_counter()
        - initial_enumeration_started_at
    )
    next_iteration_enumeration_time = 0.0

    # --- Run directory + action log. ---------------------------------------
    run_dir, action_log_path = _open_run_dir(results_dir, run_tag)
    if action_log_path is not None:
        with Path(action_log_path).open("a", encoding="utf-8") as log_file:
            log_file.write(json.dumps({
                "event": "pipeline_original_dataset",
                "privacy_cost_floor": privacy_cost_floor,
                "seed_row_count": len(initial_row_ids),
                "seed_min_k": int(calculate_leakage(select_encoded_attributes(
                    current_train_encode.loc[initialization_row_ids], qi_attributes,
                ))),
                "seed_leak": -math.log(int(calculate_leakage(select_encoded_attributes(
                    current_train_encode.loc[initialization_row_ids], qi_attributes,
                )))),
                "original_row_count": len(original_dataset_encode),
                "original_leak_k": original_leak_k,
                "original_leak_k_p1": original_leak_k_p1,
                "original_leak_k_p2": original_leak_k_p2,
                "original_leak_k_p3": original_leak_k_p3,
                "original_leak_k_p4": original_leak_k_p4,
                "original_leak_k_p5": original_leak_k_p5,
            }, default=str, sort_keys=True))
            log_file.write("\n")

    state = SelectionState(
        predicted_model_loss=proxy_model_loss,
        actual_model_loss=proxy_model_loss,
        current_generalization=current_generalization,
        selected_row_ids=list(initialization_row_ids),
        current_train_encode=current_train_encode,
        current_train_tensor=current_train_tensor,
        action_log_path=str(action_log_path) if action_log_path is not None else None,
    )

    selected_retention_class_keys = []
    iteration_count = 0
    termination_condition = None
    release_snapshot_history = [{
        "iteration": -1,
        "generalization_level": dict(
            current_generalization.generalization_level
        ),
        "_generalization": current_generalization,
    }]
    trim_iteration_results = []

    def _evaluate_candidate_retained(candidate_generalization, candidate_min_k, candidate_row_ids, *, role="proxy"):
        """Fit on the candidate's retained rows at its levels; score on validation."""
        started_at = time.perf_counter()
        row_ids = list(candidate_row_ids)
        result = {
            "status": "ok", "evaluation_scope": "retained",
            "target_k": int(release_target_k) if release_target_k is not None else int(candidate_min_k),
            "min_k": int(candidate_min_k), "row_count": len(row_ids),
            "suppressed_row_count": int(len(X_train_raw) - len(row_ids)),
            "coverage_fraction": float(len(row_ids) / len(X_train_raw)),
        }
        if not row_ids:
            result.update(status="empty_retained_set",
                          evaluation_seconds=float(time.perf_counter() - started_at))
            return result
        use_xgboost_input = (proxy_uses_xgboost_input if role == "proxy"
                             else downstream_uses_xgboost_input)
        model = _build_model(proxy_factory if role == "proxy" else downstream_factory)
        model.fit(
            _model_eval_encode(use_xgboost_input, candidate_generalization, X_train_raw, row_ids),
            y_train_tensor[[row_id_to_position[row_id] for row_id in row_ids]],
        )
        loss = _model_loss(model, y_val_tensor, _model_eval_encode(
            use_xgboost_input, candidate_generalization, X_val_raw))
        result.update({
            "_model": model, "validation_loss": float(loss),
            "delta_u": float(loss - baseline_val_loss),
            "delta_u_semantics": f"{loss_metric_name}_minus_full_level0_validation_baseline",
            "utility_constraint_met": bool(loss <= loss_threshold_val),
            "evaluation_seconds": float(time.perf_counter() - started_at),
        })
        return result

    def _evaluate_eviction_published(candidate_generalization, candidate_min_k, kept_row_ids,
                                     evicted_row_ids):
        """Fit the proxy on the kept rows plus the pooled evicted rows; score on the release's validation mapping."""
        started_at = time.perf_counter()
        target_k = int(release_target_k) if release_target_k is not None else int(candidate_min_k)
        train_parts, suppressed_ids, val_parts = _published_eviction_layout(
            candidate_generalization, list(kept_row_ids), list(evicted_row_ids), target_k,
            _distinct_snapshot_generalizations(release_snapshot_history),
            X_train_raw, X_val_raw, qi_attributes,
        )
        row_ids = [rid for ids, _generalization in train_parts for rid in ids]
        result = {
            "status": "ok", "evaluation_scope": "published_eviction", "target_k": target_k,
            "min_k": int(candidate_min_k), "row_count": len(row_ids),
            "pooled_row_count": len(row_ids) - len(kept_row_ids),
            "suppressed_row_count": int(len(X_train_raw) - len(row_ids)),
            "coverage_fraction": float(len(row_ids) / len(X_train_raw)),
        }
        if not row_ids:
            result.update(status="empty_retained_set",
                          evaluation_seconds=float(time.perf_counter() - started_at))
            return result
        model = _build_model(proxy_factory)
        model.fit(
            _concat_release_model_parts(
                [(ids, _model_eval_encode(proxy_uses_xgboost_input, generalization, X_train_raw, ids))
                 for ids, generalization in train_parts if ids],
                row_ids),
            y_train_tensor[[row_id_to_position[row_id] for row_id in row_ids]],
        )
        loss = _model_loss(model, y_val_tensor, _concat_release_model_parts(
            [(ids, _model_eval_encode(proxy_uses_xgboost_input, generalization, X_val_raw, ids))
             for ids, generalization in val_parts if ids],
            list(X_val_raw.index)))
        result.update({
            "_model": model, "validation_loss": float(loss),
            "delta_u": float(loss - baseline_val_loss),
            "delta_u_semantics": f"{loss_metric_name}_minus_full_level0_validation_baseline",
            "utility_constraint_met": bool(loss <= loss_threshold_val),
            "evaluation_seconds": float(time.perf_counter() - started_at),
        })
        return result

    def pipeline_leakage(encode):
        # Risk is computed on all selected rows, including the initial seed.
        nonlocal total_privacy_accounting_time
        t0 = time.perf_counter()
        try:
            privacy_encode = select_encoded_attributes(encode, qi_attributes)
            if privacy_encode.empty:
                return 0
            return calculate_leakage(privacy_encode)
        finally:
            total_privacy_accounting_time += time.perf_counter() - t0

    # =========================================================================
    # Greedy loop.
    # =========================================================================
    initial_release_k = (
        int(release_target_k) if release_target_k is not None
        else int(pipeline_leakage(state.current_train_encode.loc[state.selected_row_ids]))
    )
    initial_proxy_started = time.perf_counter()
    initial_proxy_release = _evaluate_trim_release(
        release_snapshot_history, initial_release_k,
        model_factory_for_release=proxy_factory,
        use_xgboost_input=proxy_uses_xgboost_input,
        X_eval_raw=X_val_raw, y_eval_tensor=y_val_tensor,
        eval_split="validation", baseline_loss=baseline_val_loss,
        loss_threshold=loss_threshold_val,
    )
    initial_proxy_seconds = time.perf_counter() - initial_proxy_started
    if initial_proxy_release["status"] != "ok":
        raise ValueError("The initial search release cannot be evaluated by the proxy.")
    # The mixed release above is only reported; gains are measured from D_0.
    total_curve_metric_time += initial_proxy_seconds
    initial_scoring_started = time.perf_counter()
    initial_scoring = _evaluate_candidate_retained(
        state.current_generalization, initial_release_k, state.selected_row_ids)
    initial_scoring_seconds = time.perf_counter() - initial_scoring_started
    total_retraining_time += initial_scoring_seconds
    if initial_scoring["status"] != "ok":
        raise ValueError("The initial retained set cannot be evaluated by the proxy.")
    state.actual_model_loss = float(initial_scoring["validation_loss"])
    state.predicted_model_loss = state.actual_model_loss
    target_validation_constraint_met = False
    target_validation_loss = None
    target_validation_result = None
    # Final check (stop_on_utility): when the proxy's validation Delta U on D_t, measured against the proxy fitted
    # on the full level-0 training split, is within the tolerance, the target model is retrained on the release of
    # D_t and checked on validation.
    final_check_passed = False
    initial_stop_check_seconds = 0.0
    baseline_proxy_val_loss = None
    proxy_reference_seconds = 0.0
    if stop_on_utility:
        proxy_reference_started = time.perf_counter()
        proxy_reference = _evaluate_candidate_retained(
            original_generalization, int(original_leak_k), list(train_original_encode.index))
        proxy_reference_seconds = time.perf_counter() - proxy_reference_started
        total_retraining_time += proxy_reference_seconds
        if proxy_reference["status"] != "ok":
            raise ValueError("The proxy cannot be fitted on the full training split.")
        baseline_proxy_val_loss = float(proxy_reference["validation_loss"])

    def _proxy_delta_u():
        """The proxy's validation Delta U on the current D_t (None without the proxy reference)."""
        return None if baseline_proxy_val_loss is None else float(state.actual_model_loss) - baseline_proxy_val_loss

    initial_final_check = bool(stop_on_utility and _proxy_delta_u() <= tolerance)
    if initial_final_check or record_iteration_validation_metrics:
        initial_target_started = time.perf_counter()
        target_validation_result = _evaluate_trim_release(
            release_snapshot_history, initial_release_k,
            model_factory_for_release=downstream_factory,
            use_xgboost_input=downstream_uses_xgboost_input,
            X_eval_raw=X_val_raw, y_eval_tensor=y_val_tensor,
            eval_split="validation", baseline_loss=baseline_val_loss,
            loss_threshold=loss_threshold_val,
        )
        initial_target_seconds = time.perf_counter() - initial_target_started
        total_target_validation_time += initial_target_seconds
        if initial_final_check:
            total_retraining_time += initial_target_seconds
            initial_stop_check_seconds += initial_target_seconds
        else:
            total_curve_metric_time += initial_target_seconds
        target_validation_loss = target_validation_result.get("validation_loss")
        target_validation_constraint_met = bool(target_validation_result.get("utility_constraint_met", False))
    final_check_passed = initial_final_check and target_validation_constraint_met
    state_history_path = None if run_dir is None else run_dir / "state_history.jsonl"
    append_state_record(state_history_path, {
        "schema_version": "trim_state_history.v1", "round": 0, "iteration": -1,
        "operation": "initialization",
        "retained_row_ids": sorted(str(rid) for rid in state.selected_row_ids),
        "bootstrap_row_ids": sorted(str(rid) for rid in initial_row_ids),
        "generalization_level": dict(state.current_generalization.generalization_level),
        "retained_count": len(state.selected_row_ids),
        "min_k": int(pipeline_leakage(state.current_train_encode.loc[state.selected_row_ids])),
        "retained_ids_sha256": retained_ids_sha256(state.selected_row_ids),
        "target_validation_loss": target_validation_loss,
        "target_validation_delta_u": (None if target_validation_loss is None
                                      else target_validation_loss - baseline_val_loss),
        "proxy_delta_u": _proxy_delta_u(), "final_check": initial_final_check,
        "target_validation_utility_constraint_met": target_validation_constraint_met,
        "mixed_min_k": initial_proxy_release.get("min_k"),
        "mixed_tail_risk_p99": initial_proxy_release.get("tail_risk_p99"),
        "test_evaluated": False,
    })
    stall_stage = 0  # 1 while the stall rule re-selects the round with the widened shortlist
    stall_rule_rounds = []
    while not (stop_on_utility and final_check_passed):
        if max_iterations is not None and iteration_count >= max_iterations:
            termination_condition = "max_iterations_reached"
            break

        iter_enumeration_time = next_iteration_enumeration_time
        next_iteration_enumeration_time = 0.0
        iter_selection_time_start = total_selection_time
        iter_privacy_time_start = total_privacy_accounting_time
        iter_retraining_time_start = total_retraining_time
        privacy_before_selection = total_privacy_accounting_time

        # Mutable accumulators shared with _greedy_select so its LGA / proxy /
        # leakage / ranking timings fold into the running totals in place.
        selection_timing = {
            # The caller removes privacy-accounting time from selection time below.
            "selection": 0.0,
            "lga": 0.0, "proxy_retrain": 0.0, "leakage": 0.0, "ranking": 0.0,
        }
        # When non-QI features exist, _can_use_position_index_leakage is false
        # and every admission candidate would recount min-K with value_counts
        # over all retained rows. The cached per-QI codes give the same classes
        # when they cover exactly the QI columns that pipeline_leakage groups
        # by and no QI value is NaN (value_counts drops NaN rows; the codes
        # keep them as a class), so selection may count classes by id instead.
        qi_code_columns = (
            [column for attribute in qi_attributes
             for column in swap_encode_cache.attribute_columns.get(attribute, ())]
            if swap_encode_cache is not None
            and set(swap_encode_cache.selected_attributes) == set(qi_attributes)
            and set(qi_attributes) <= set(swap_encode_cache.codes.columns)
            else []
        )
        count_privacy_by_class = bool(
            qi_code_columns
            and qi_code_columns == select_encoded_attributes(
                swap_encode_cache.encoded.iloc[:0], qi_attributes).columns.tolist()
            and not any(swap_encode_cache.encoded[column].isna().any()
                        for column in qi_code_columns)
        )
        selected_action = _greedy_select(
            state,
            remaining_retention_classes=remaining_retention_classes,
            X_train_raw=X_train_raw, X_val_raw=X_val_raw,
            backend_model=backend_model,
            leakage_func=pipeline_leakage,
            # The widened stall stage proxy-checks the top stall_widen_top_k of each pool.
            rank_top_k=stall_widen_top_k if stall_stage else rank_top_k,
            standardizer=standardizer,
            row_id_to_position=row_id_to_position,
            train_y_tensor=y_train_tensor,
            val_y_tensor=y_val_tensor,
            selection_timing=selection_timing,
            action_log_path=action_log_path,
            iteration_count=iteration_count,
            current_train_level_encode=swap_encode_cache.encoded,
            swap_encode_cache=swap_encode_cache,
            count_privacy_by_class=count_privacy_by_class,
            candidate_release_evaluator=_evaluate_candidate_retained,
            privacy_cost_floor=privacy_cost_floor,
            candidate_experiment=candidate_experiment,
            enabled_action_types=enabled_action_types,
            vertical_postprocessing=ablation_actions.vertical_postprocessing,
            move_out_threshold=ablation_actions.move_out_threshold,
            candidate_shortlist=candidate_shortlist,
            candidate_state_scorer=candidate_state_scorer,
            selection_score=selection_score,
            fast_path_usage=fast_path_usage,
            refinement_eviction_ratios=refinement_eviction_ratios,
            eviction_shortlist=eviction_shortlist,
            max_privacy_step=max_privacy_step,
            exact_speedups=exact_speedups,
            eviction_release_evaluator=(_evaluate_eviction_published
                                        if eviction_scoring == "published_check" else None),
        )
        # pipeline_leakage and the optimized class-id leakage path both credit
        # privacy time during selection; selection-exclusive time is the rest of
        # the selection wall clock.
        total_privacy_accounting_time += selection_timing.get("optimized_privacy", 0.0)
        privacy_inside_selection = total_privacy_accounting_time - privacy_before_selection
        total_selection_time += max(0.0, selection_timing["selection"] - privacy_inside_selection)

        if selected_action["action"] is None:
            if stall_rule == "widen" and not stall_stage:
                # Stall rule: log this attempt's candidates under their own event
                # and select this round again with the widened shortlist.
                if selected_action["candidates"]:
                    _write_action_log(
                        action_log_path=action_log_path, iteration=iteration_count,
                        current_state=state, candidates=selected_action["candidates"],
                        best_candidate=None, event="candidate_evaluation_before_stall_stage",
                    )
                stall_stage += 1
                continue
            if selected_action["candidates"]:
                _write_action_log(
                    action_log_path=action_log_path, iteration=iteration_count,
                    current_state=state, candidates=selected_action["candidates"],
                    best_candidate=None,
                )
            if stall_stage:
                stall_rule_rounds.append({"iteration": int(iteration_count),
                                          "stage": int(stall_stage), "action": None})
            termination_condition = "no_action_available"
            break
        if stall_stage:
            stall_rule_rounds.append({"iteration": int(iteration_count), "stage": int(stall_stage),
                                      "action": selected_action["action"],
                                      "attribute": selected_action.get("attribute")})
            stall_stage = 0

        candidates = selected_action["candidates"]
        _write_action_log(
            action_log_path=action_log_path, iteration=iteration_count,
            current_state=state, candidates=candidates,
            best_candidate=candidates[selected_action["selected_candidate_position"]])

        previous_selected = set(state.selected_row_ids)
        state = selected_action["state"]
        state.action_log_path = str(action_log_path) if action_log_path is not None else None
        current_level_encode_for_reenum = None
        snapshot_position_index = selected_action.get("position_index")

        if selected_action["action"] == "retention_class":
            rc_key = selected_action["retention_class_key"]
            if rc_key not in selected_retention_class_keys:
                selected_retention_class_keys.append(rc_key)
        elif selected_action["action"] == "vertical_refinement":
            swap_stats = selected_action.get("swap_stats")
            current_selected = set(state.selected_row_ids)
            swap_level_encode = selected_action.get("swap_level_encode")
            swap_codes = selected_action.get("swap_codes")
            if (
                swap_encode_cache is not None
                and swap_level_encode is not None
                and swap_codes is not None
            ):
                swap_encode_cache.encoded = swap_level_encode
                swap_encode_cache.codes = swap_codes
                current_level_encode_for_reenum = swap_encode_cache.encoded
            else:
                current_level_encode_for_reenum = _update_swap_encode_cache(
                    swap_encode_cache, state.current_generalization,
                    X_train_raw, selected_action.get("attribute"))
            if action_log_path is not None and swap_stats is not None:
                with Path(action_log_path).open("a", encoding="utf-8") as log_file:
                    log_file.write(json.dumps({
                        "event": "swap_timing", "iteration": iteration_count,
                        "action": selected_action["action"],
                        "attribute": selected_action.get("attribute"),
                        "swap_iterations": swap_stats["swap_iterations"],
                        "elapsed_seconds": swap_stats["elapsed_seconds"],
                        "encode_time_seconds": swap_stats["encode_time_seconds"],
                        "position_index_time_seconds": swap_stats["position_index_time_seconds"],
                        "loop_time_seconds": swap_stats["loop_time_seconds"],
                        "sync_time_seconds": swap_stats["sync_time_seconds"],
                        "break_reason": swap_stats["break_reason"],
                        "cap_hit": swap_stats["break_reason"] == "max_iterations",
                        "seed_evicted_count": len(
                            (previous_selected - current_selected) & set(initial_row_ids)
                        ),
                        "selected_row_count": swap_stats["selected_row_count"],
                        "candidate_row_count": swap_stats["candidate_row_count"],
                        "postprocessing_policy": swap_stats.get(
                            "postprocessing_policy"
                        ),
                        "move_out_threshold": swap_stats.get(
                            "move_out_threshold"
                        ),
                        "move_out_row_count": swap_stats.get(
                            "move_out_row_count", 0
                        ),
                        "move_in_row_count": swap_stats.get(
                            "move_in_row_count", 0
                        ),
                        "extra_swap_in_count": swap_stats.get(
                            "extra_swap_in_count", 0
                        ),
                    }, default=str, sort_keys=True))
                    log_file.write("\n")

        iteration_count += 1

        # --- Refit the estimator for the next iteration's LGA ranking. ------
        selected_positions = [row_id_to_position[rid] for rid in state.selected_row_ids]
        t0 = time.perf_counter()
        selected_fit_encode = standardizer.transform(
            state.current_train_tensor[selected_positions])
        selected_fit_y = y_train_tensor[selected_positions]

        backend_model = _build_model(estimator_factory)
        if hasattr(backend_model, "warm_start"):
            backend_model.warm_start = True
        backend_model.fit(selected_fit_encode, selected_fit_y)
        total_retraining_time += time.perf_counter() - t0

        # --- Per-iteration action log + leak snapshot. ----------------------
        iter_selection_time = total_selection_time - iter_selection_time_start
        iter_privacy_time = total_privacy_accounting_time - iter_privacy_time_start
        iter_retraining_time = total_retraining_time - iter_retraining_time_start

        if (
            snapshot_position_index is None
            and _can_use_position_index_leakage(swap_encode_cache)
        ):
            snapshot_position_index = _swap_position_index_from_cache(swap_encode_cache)
        # exact_speedups: the selection cache's rank columns group exactly like
        # the encoded QI columns, so value_counts gives the same class sizes.
        snapshot_ranks = (
            state.current_generalization.privacy_frame(X_train_raw, qi_attributes)
            if exact_speedups and snapshot_position_index is None
            and hasattr(state.current_generalization, "privacy_frame") else None)
        published_row_count, leak_stats, _ = _published_leak_snapshot(
            snapshot_ranks if snapshot_ranks is not None else select_encoded_attributes(
                state.current_train_encode,
                qi_attributes,
            ),
            state.selected_row_ids,
            position_index=snapshot_position_index,
        )
        scoring_result = selected_action.get("release_result")
        if scoring_result is None or scoring_result.get("status") != "ok":
            raise RuntimeError(
                "The selected action does not have a valid proxy evaluation."
            )
        expected_release_target_k = (
            int(release_target_k)
            if release_target_k is not None
            else int(leak_stats["leak_k"])
        )
        if int(scoring_result["target_k"]) != expected_release_target_k:
            raise RuntimeError(
                "The selected release target disagrees with the published min-K."
            )
        snapshot_iteration = iteration_count - 1
        release_snapshot_history.append({
            "iteration": int(snapshot_iteration),
            "generalization_level": dict(
                state.current_generalization.generalization_level
            ),
            "_generalization": state.current_generalization,
        })
        proxy_model_loss = float(scoring_result["validation_loss"])
        state.predicted_model_loss = proxy_model_loss
        state.actual_model_loss = proxy_model_loss
        # The search scored D_t; evaluate the committed mixed release once
        # for the reported curve.
        committed_release_started = time.perf_counter()
        release_result = _evaluate_trim_release(
            release_snapshot_history, int(scoring_result["target_k"]),
            model_factory_for_release=proxy_factory,
            use_xgboost_input=proxy_uses_xgboost_input,
            X_eval_raw=X_val_raw, y_eval_tensor=y_val_tensor,
            eval_split="validation", baseline_loss=baseline_val_loss,
            loss_threshold=loss_threshold_val,
        )
        total_curve_metric_time += time.perf_counter() - committed_release_started
        if release_result.get("status") != "ok":
            raise RuntimeError("The committed mixed release cannot be evaluated.")
        release_validation_loss = float(release_result["validation_loss"])
        round_final_check = bool(stop_on_utility and _proxy_delta_u() <= tolerance)
        target_validation_result = None
        target_validation_loss = None
        target_validation_constraint_met = False
        if round_final_check or record_iteration_validation_metrics:
            target_validation_started = time.perf_counter()
            target_validation_result = _evaluate_trim_release(
                release_snapshot_history, int(release_result["target_k"]),
                model_factory_for_release=downstream_factory,
                use_xgboost_input=downstream_uses_xgboost_input,
                X_eval_raw=X_val_raw, y_eval_tensor=y_val_tensor,
                eval_split="validation", baseline_loss=baseline_val_loss,
                loss_threshold=loss_threshold_val,
            )
            target_validation_seconds = time.perf_counter() - target_validation_started
            total_target_validation_time += target_validation_seconds
            if round_final_check:
                total_retraining_time += target_validation_seconds
                iter_retraining_time += target_validation_seconds
            else:
                total_curve_metric_time += target_validation_seconds
            target_validation_loss = target_validation_result.get("validation_loss")
            target_validation_constraint_met = bool(
                target_validation_result.get("utility_constraint_met", False)
            )
        final_check_passed = round_final_check and target_validation_constraint_met
        trim_iteration_record = {
            "target_validation_loss": target_validation_loss,
            "target_validation_delta_u": (None if target_validation_loss is None
                                          else target_validation_loss - baseline_val_loss),
            "target_validation_utility_constraint_met": target_validation_constraint_met,
            "search_proxy_delta_u": _proxy_delta_u(),
            "final_check": round_final_check,
            "iteration": int(snapshot_iteration),
            "action": selected_action["action"],
            "attribute": selected_action.get("attribute"),
            "search_proxy_validation_loss": proxy_model_loss,
            "original_leak_k": original_leak_k,
            "original_leak_k_p1": original_leak_k_p1,
            "original_leak_k_p2": original_leak_k_p2,
            "original_leak_k_p3": original_leak_k_p3,
            "original_leak_k_p4": original_leak_k_p4,
            "original_leak_k_p5": original_leak_k_p5,
            "ordinary_min_k": int(leak_stats["leak_k"]),
            "ordinary_published_row_count": int(published_row_count),
            "iter_enumeration_time": float(iter_enumeration_time),
            "iter_selection_time": float(iter_selection_time),
            "iter_privacy_time": float(iter_privacy_time),
            "iter_retraining_time": float(iter_retraining_time),
            "snapshot_history": [
                {
                    "iteration": int(snapshot["iteration"]),
                    "generalization_level": dict(
                        snapshot["generalization_level"]
                    ),
                }
                for snapshot in release_snapshot_history
            ],
            **_public_release_result(release_result),
        }
        if record_iteration_test_metrics:
            observation_started_at = time.perf_counter()
            try:
                iteration_test_result = _evaluate_trim_release(
                    release_snapshot_history,
                    int(release_result["target_k"]),
                    model_factory_for_release=downstream_factory,
                    use_xgboost_input=downstream_uses_xgboost_input,
                    X_eval_raw=X_test_raw,
                    y_eval_tensor=y_test_tensor,
                    eval_split="test",
                    baseline_loss=baseline_test_loss,
                    loss_threshold=loss_threshold_test,
                    fitted_result=target_validation_result,
                )
            finally:
                observation_seconds = (
                    time.perf_counter() - observation_started_at
                )
                total_curve_metric_time += observation_seconds
            trim_iteration_record.update({
                "test_status": iteration_test_result.get("status"),
                "test_loss": (
                    float(iteration_test_result["test_loss"])
                    if iteration_test_result.get("status") == "ok"
                    else None
                ),
                "test_delta_u": (
                    float(iteration_test_result["delta_u"])
                    if iteration_test_result.get("status") == "ok"
                    else None
                ),
                "test_utility_constraint_met": (
                    bool(iteration_test_result["utility_constraint_met"])
                    if iteration_test_result.get("status") == "ok"
                    else None
                ),
                "test_observation_seconds": float(observation_seconds),
            })
        else:
            trim_iteration_record.update({
                "test_status": "not_recorded",
                "test_loss": None,
                "test_delta_u": None,
                "test_utility_constraint_met": None,
                "test_observation_seconds": 0.0,
            })
        trim_iteration_results.append(trim_iteration_record)
        current_selected = set(state.selected_row_ids)
        committed = candidates[selected_action["selected_candidate_position"]]
        committed_swap = selected_action.get("swap_stats") or {}
        append_state_record(state_history_path, {
            "schema_version": "trim_state_history.v1", "round": iteration_count,
            "iteration": snapshot_iteration, "operation": selected_action["action"],
            "attribute": selected_action.get("attribute"),
            "generalization_level": dict(state.current_generalization.generalization_level),
            "admitted_row_ids": sorted(str(rid) for rid in current_selected - previous_selected),
            "evicted_row_ids": sorted(str(rid) for rid in previous_selected - current_selected),
            "retained_count": len(current_selected), "min_k": int(leak_stats["leak_k"]),
            "previous_retained_ids_sha256": retained_ids_sha256(previous_selected),
            "retained_ids_sha256": retained_ids_sha256(current_selected),
            "current_k": int(committed["current_k"]), "next_k": int(committed["next_k"]),
            "privacy_cost": float(committed["privacy_cost"]),
            "utility_gain": float(committed["utility_gain"]), "score": float(committed["score"]),
            "swap_break_reason": committed_swap.get("break_reason"),
            "swap_iterations": committed_swap.get("swap_iterations"),
            "swap_cap_hit": committed_swap.get("break_reason") == "max_iterations",
            "swap_iteration_cap": VERTICAL_SWAP_MAX_ITERATIONS,
            "target_validation_loss": target_validation_loss,
            "target_validation_delta_u": (None if target_validation_loss is None
                                          else target_validation_loss - baseline_val_loss),
            "mixed_min_k": release_result.get("min_k"),
            "mixed_tail_risk_p99": release_result.get("tail_risk_p99"),
            "test_evaluated": bool(record_iteration_test_metrics),
            **({"eviction_ceiling": int(committed["eviction_ceiling"]),
                "ceiling_evicted_row_ids": sorted(
                    str(rid) for rid in committed["ceiling_evicted_row_ids"])}
               if committed.get("eviction_ceiling") is not None else {}),
        })

        if action_log_path is not None:
            with Path(action_log_path).open("a", encoding="utf-8") as log_file:
                log_file.write(json.dumps({
                    "event": "pipeline_iteration_state",
                    "iteration": iteration_count - 1,
                    "action": selected_action["action"],
                    "attribute": selected_action.get("attribute"),
                    "selected_row_count": len(state.selected_row_ids),
                    "published_row_count": published_row_count,
                    "generalization_level": dict(state.current_generalization.generalization_level),
                    "leak_k": leak_stats["leak_k"],
                    "leak_k_p1": leak_stats["leak_k_p1"],
                    "leak_k_p2": leak_stats["leak_k_p2"],
                    "leak_k_p3": leak_stats["leak_k_p3"],
                    "leak_k_p4": leak_stats["leak_k_p4"],
                    "leak_k_p5": leak_stats["leak_k_p5"],
                    "loss_metric": loss_metric_name,
                    "proxy_val_loss": proxy_model_loss,
                    "release_validation_loss": release_validation_loss,
                    "release_target_k": release_result["target_k"],
                    "release_row_count": release_result["row_count"],
                    "release_suppressed_row_count": release_result[
                        "suppressed_row_count"
                    ],
                    "release_coverage_fraction": release_result[
                        "coverage_fraction"
                    ],
                    "release_utility_constraint_met": release_result[
                        "utility_constraint_met"
                    ],
                    "iter_selection_time": iter_selection_time,
                    "iter_enumeration_time": iter_enumeration_time,
                    "iter_privacy_time": iter_privacy_time,
                    "iter_retraining_time": iter_retraining_time,
                }, default=str, sort_keys=True))
                log_file.write("\n")

        # A release with min-K 1 protects no record, so later rounds add no
        # privacy-utility point; this round's point is already recorded.
        if (stop_at_release_min_k is not None and release_result.get("min_k") is not None
                and int(release_result["min_k"]) <= stop_at_release_min_k):
            termination_condition = "release_min_k_reached"
            break
        if (stop_unmet_at_release_min_k is not None and not final_check_passed
                and release_result.get("min_k") is not None
                and int(release_result["min_k"]) <= stop_unmet_at_release_min_k):
            termination_condition = "release_min_k_reached_unmet"
            break

        # --- Re-enumerate retention classes for the next iteration. ---------
        selected_set = set(state.selected_row_ids)
        remaining_row_ids = [rid for rid in train_original_encode.index if rid not in selected_set]
        if RETENTION_CLASS_ACTION not in enabled_action_types:
            remaining_retention_classes = []
        elif fixed_row_candidate_plan is not None:
            t0 = time.perf_counter()
            remaining_retention_classes = []
            for group_key, group_row_ids in fixed_row_candidate_plan.candidate_groups:
                remaining_index = [
                    row_id
                    for row_id in group_row_ids
                    if row_id not in selected_set
                ]
                if remaining_index:
                    remaining_retention_classes.append(
                        (
                            group_key,
                            state.current_train_encode.loc[
                                remaining_index
                            ].copy(),
                        )
                    )
            next_iteration_enumeration_time = time.perf_counter() - t0
            total_enumeration_time += next_iteration_enumeration_time
        elif remaining_row_ids:
            t0 = time.perf_counter()
            if _can_use_position_index_leakage(swap_encode_cache):
                reenum_position_index = snapshot_position_index
                if reenum_position_index is None:
                    reenum_position_index = _swap_position_index_from_cache(
                        swap_encode_cache)
                remaining_retention_classes = (
                    _retention_class_index_groups_from_position_index(
                        reenum_position_index,
                        excluded_row_ids=selected_set,
                    )
                )
            else:
                if current_level_encode_for_reenum is not None:
                    current_level_encode = current_level_encode_for_reenum
                elif swap_encode_cache is not None:
                    current_level_encode = swap_encode_cache.encoded
                else:
                    current_level_encode = state.current_generalization.encode(
                        X_train_raw)
                code_groups = (build_retention_class_row_groups_from_codes(
                    current_level_encode, swap_encode_cache.codes, remaining_row_ids,
                    selected_attributes)
                    if exact_speedups and swap_encode_cache is not None
                    and current_level_encode is swap_encode_cache.encoded else None)
                if code_groups is not None:
                    remaining_retention_classes = code_groups
                else:
                    retention_classes = build_retention_class_groups(
                        current_level_encode.loc[remaining_row_ids],
                        selected_attributes=selected_attributes)
                    remaining_retention_classes = list(retention_classes.items())
            next_iteration_enumeration_time = time.perf_counter() - t0
            total_enumeration_time += next_iteration_enumeration_time
        else:
            remaining_retention_classes = []

    if termination_condition is None:
        termination_condition = "loss_threshold_met"

    # =========================================================================
    # Final publication + verification.
    # =========================================================================
    # No post-search admissions: every retained row belongs to a committed state.
    ordinary_final_selected_row_ids = list(state.selected_row_ids)
    final_state_k = int(pipeline_leakage(
        state.current_train_encode.loc[state.selected_row_ids]
    ))
    final_release_target_k = (
        int(release_target_k) if release_target_k is not None else final_state_k
    )
    if target_validation_result is None:  # no target validation of the final state yet
        target_validation_started = time.perf_counter()
        target_validation_result = _evaluate_trim_release(
            release_snapshot_history, final_release_target_k,
            model_factory_for_release=downstream_factory,
            use_xgboost_input=downstream_uses_xgboost_input,
            X_eval_raw=X_val_raw, y_eval_tensor=y_val_tensor,
            eval_split="validation", baseline_loss=baseline_val_loss,
            loss_threshold=loss_threshold_val,
        )
        target_validation_seconds = time.perf_counter() - target_validation_started
        total_target_validation_time += target_validation_seconds
        total_curve_metric_time += target_validation_seconds  # reported only; never a stop decision
    target_validation_loss = target_validation_result.get("validation_loss")
    target_validation_constraint_met = bool(
        target_validation_result.get("utility_constraint_met", False)
    )
    # TRIM returns D when its search ends before a final check passes.
    infeasible = bool(stop_on_utility and not final_check_passed)
    publication_history = release_snapshot_history
    if infeasible:
        # D is the original TRAINING split; validation/test records are never published.
        publication_history = [{
            "iteration": -1, "generalization_level": dict(original_generalization.generalization_level),
            "_generalization": original_generalization,
        }]
        final_release_target_k = 1

    # Final downstream evaluation uses validation or test as configured.
    final_verification_time = 0.0
    t0 = time.perf_counter()
    final_release_result = _evaluate_trim_release(
        publication_history, final_release_target_k,
        model_factory_for_release=downstream_factory,
        use_xgboost_input=downstream_uses_xgboost_input,
        X_eval_raw=X_val_raw if validation_only else X_test_raw,
        y_eval_tensor=y_val_tensor if validation_only else y_test_tensor,
        eval_split="validation" if validation_only else "test",
        baseline_loss=baseline_val_loss if validation_only else baseline_test_loss,
        loss_threshold=loss_threshold_val if validation_only else loss_threshold_test,
    )
    final_release_result["infeasible"] = infeasible
    final_release_result["fallback_original_training_data"] = infeasible
    if infeasible:
        final_release_result.update(original_leak_stats)
        final_release_result["min_k"] = int(original_leak_k)
        final_release_result["_group_sizes"] = original_group_sizes.tolist()
        final_release_result.update(individual_tail_risk_stats(
            original_per_record_k.index, original_per_record_k,
        ))
    final_verification_time += time.perf_counter() - t0
    if final_release_result.get("status") == "ok":
        final_actual_model_loss = (None if validation_only else float(final_release_result["test_loss"]))
        selected_row_ids = list(final_release_result["_assigned_row_ids"])
        release_suppressed_row_ids = list(
            final_release_result["_suppressed_row_ids"]
        )
        final_group_sizes = list(final_release_result["_group_sizes"])
    else:
        final_actual_model_loss = None if validation_only else float("inf")
        selected_row_ids = []
        release_suppressed_row_ids = list(X_train_raw.index)
        final_group_sizes = []
    utility_constraint_met = (None if validation_only else final_actual_model_loss <= loss_threshold_test)
    published_validation_loss = (
        final_release_result.get("validation_loss") if validation_only
        else (baseline_val_loss if infeasible else target_validation_loss)
    )
    validation_utility_constraint_met = (published_validation_loss is not None
                                        and published_validation_loss <= loss_threshold_val)

    # Final privacy metrics describe the materialized release, not the internal
    # selected-state encoding.
    final_leak_k = int(final_release_result.get("min_k", 0))
    leak_k_p1 = float(final_release_result.get("leak_k_p1", 0.0))
    leak_k_p2 = float(final_release_result.get("leak_k_p2", 0.0))
    leak_k_p3 = float(final_release_result.get("leak_k_p3", 0.0))
    leak_k_p4 = float(final_release_result.get("leak_k_p4", 0.0))
    leak_k_p5 = float(final_release_result.get("leak_k_p5", 0.0))
    tail_risk_p99 = final_release_result.get("tail_risk_p99")
    if tail_risk_p99 is not None:
        tail_risk_p99 = float(tail_risk_p99)
    final_leak_k_sorted = list(
        final_release_result.get("leak_k_sorted", [])
    )
    final_leak_k_95_percentile = final_release_result.get(
        "leak_k_95_percentile"
    )
    public_release_snapshot_history = [
        {
            "iteration": int(snapshot["iteration"]),
            "generalization_level": dict(snapshot["generalization_level"]),
        }
        for snapshot in publication_history
    ]
    final_release_public = _public_release_result(final_release_result)
    final_release_public.update({
        "publication_mode": "mixed",
        "original_leak_k": original_leak_k,
        "original_leak_k_p1": original_leak_k_p1,
        "original_leak_k_p2": original_leak_k_p2,
        "original_leak_k_p3": original_leak_k_p3,
        "original_leak_k_p4": original_leak_k_p4,
        "original_leak_k_p5": original_leak_k_p5,
        "test_evaluated": not validation_only,
        "utility_split": "validation" if validation_only else "test",
        "validation_loss": published_validation_loss,
        "validation_delta_u": (None if published_validation_loss is None
                               else published_validation_loss - baseline_val_loss),
        "search_validation_utility_constraint_met": target_validation_constraint_met,
        "search_target_validation_loss": target_validation_loss,
        "proxy_validation_loss": float(state.actual_model_loss),
        "infeasible": infeasible,
        "validation_utility_constraint_met": (
            validation_utility_constraint_met
        ),
        "snapshot_history": public_release_snapshot_history,
    })

    output_comparisons = {"mixed": final_release_public}
    if run_dir is not None:
        _dump_json(output_comparisons, run_dir / "output_comparisons.json")

    timings = {
        "target_validation_time_seconds": total_target_validation_time,
        "enumeration_time_seconds": total_enumeration_time,
        "initial_retention_class_build_time_seconds": (
            initial_retention_class_build_time
        ),
        # Parts of the retraining total outside every round: the estimator and proxy fits on D_0, the initial proxy
        # scoring of D_0 and, when the run stops on utility, the proxy fit on the full training split (final-check
        # reference) and the initial final check.
        "initial_model_fit_time_seconds": initial_model_fit_seconds,
        "initial_scoring_time_seconds": initial_scoring_seconds,
        "proxy_reference_fit_time_seconds": proxy_reference_seconds,
        "initial_stop_check_time_seconds": initial_stop_check_seconds,
        "candidate_enumeration_total_time_seconds": (
            initial_retention_class_build_time + total_enumeration_time
        ),
        "selection_time_seconds": total_selection_time,
        "privacy_accounting_time_seconds": total_privacy_accounting_time,
        "backend_retraining_certification_time_seconds": total_retraining_time,
        "final_verification_time_seconds": final_verification_time,
        "curve_metric_time_seconds": total_curve_metric_time,
        "experiment_observation_time_seconds": total_curve_metric_time,
        "candidate_state_scorer_setup_time_seconds": (
            candidate_state_scorer_setup_seconds
        ),
        "pipeline_wall_time_seconds": time.perf_counter() - pipeline_start_time,
    }
    if action_log_path is not None:
        with Path(action_log_path).open("a", encoding="utf-8") as log_file:
            log_file.write(json.dumps({
                "event": "pipeline_summary",
                "task_type": "classification",
                "loss_metric": loss_metric_name,
                "termination_condition": termination_condition,
                "selected_row_count": len(selected_row_ids),
                "ordinary_selected_row_count": len(
                    ordinary_final_selected_row_ids
                ),
                "initial_row_count": len(initial_row_ids),
                "initialization_row_count": len(initialization_row_ids),
                "ablation_actions": ablation_actions.as_dict(),
                "fixed_row_candidate_plan": (
                    fixed_row_candidate_plan.as_dict()
                    if fixed_row_candidate_plan is not None
                    else None
                ),
                "stop_on_utility": stop_on_utility,
                "record_iteration_test_metrics": (
                    record_iteration_test_metrics
                ),
                "generalization_level": dict(state.current_generalization.generalization_level),
                "baseline_val_loss": baseline_val_loss,
                "baseline_proxy_val_loss": baseline_proxy_val_loss,
                "loss_threshold_val": loss_threshold_val,
                "baseline_test_loss": baseline_test_loss,
                "loss_threshold_test": loss_threshold_test,
                "final_actual_model_loss": final_actual_model_loss,
                "utility_constraint_met": utility_constraint_met,
                "validation_utility_constraint_met": (
                    validation_utility_constraint_met
                ),
                "release_target_k": final_release_target_k,
                "release_row_count": len(selected_row_ids),
                "release_suppressed_row_count": len(
                    release_suppressed_row_ids
                ),
                "original_leak_k": original_leak_k,
                "original_leak_k_p1": original_leak_k_p1,
                "original_leak_k_p2": original_leak_k_p2,
                "original_leak_k_p3": original_leak_k_p3,
                "original_leak_k_p4": original_leak_k_p4,
                "original_leak_k_p5": original_leak_k_p5,
                "final_leak_k": final_leak_k,
                "final_leak_k_p1": leak_k_p1,
                "final_leak_k_p2": leak_k_p2,
                "final_leak_k_p3": leak_k_p3,
                "final_leak_k_p4": leak_k_p4,
                "final_leak_k_p5": leak_k_p5,
                "tail_risk_p99": tail_risk_p99,
                "tail_risk_semantics": final_release_result.get("tail_risk_semantics"),
                "tail_risk_population": final_release_result.get("tail_risk_population"),
                "tail_risk_population_size": final_release_result.get("tail_risk_population_size"),
                "tail_risk_percentile_method": final_release_result.get("tail_risk_percentile_method"),
                "final_leak_k_95_percentile": final_leak_k_95_percentile,
                "timings": timings,
            }, default=str, sort_keys=True))
            log_file.write("\n")

    if run_dir is not None:
        from collections import Counter
        if final_group_sizes:
            leak_distribution = {
                str(k): c for k, c in sorted(Counter(final_group_sizes).items())
            }
        else:
            leak_distribution = {}
        _dump_json({
            "generalization_tree_path": str(tree_artifact_path),
            "generalization_tree_sha256": generalization_tree_sha256,
            "input_data_sha256": input_data_sha256,
            "effective_loaded_row_count": len(X_raw),
            "privacy_population": "training_split",
            "privacy_population_size": len(X_train_raw),
            "preprocessing": getattr(data_loader, "preprocessing_metadata", {}),
            "nrows": nrows, "val_size": val_size, "test_size": test_size,
            "random_state": random_state, "tolerance": tolerance,
            "rank_top_k": rank_top_k,
            "max_iterations": max_iterations, "model_max_iter": model_max_iter,
            "model": model_config, "initial_sample_size": initial_sample_size,
            "initial_sample_fraction": initial_sample_fraction,
            "device": device, "dtype": dtype, "run_tag": run_tag,
            "task_type": "classification", "loss_metric": loss_metric_name,
            "ablation_actions": ablation_actions.as_dict(),
            "fixed_row_candidate_builder": _callable_name(
                fixed_row_candidate_builder
            ),
            "fixed_row_candidate_plan": (
                fixed_row_candidate_plan.as_dict()
                if fixed_row_candidate_plan is not None
                else None
            ),
            "candidate_shortlist": _callable_name(candidate_shortlist),
            "candidate_state_scorer_factory": _callable_name(
                candidate_state_scorer_factory
            ),
            "selection_score": _callable_name(selection_score),
            "stop_on_utility": stop_on_utility,
            "privacy_cost_floor": privacy_cost_floor,
            "selection_cache": bool(selection_cache),
            # Every refine-and-swap may move a QI to any finer level.
            "refinement_step": "multi_level",
            "stop_at_release_min_k": stop_at_release_min_k,
            **({"refinement_eviction_ratios": refinement_eviction_ratios}
               if refinement_eviction_ratios is not None else {}),
            **({"stall_rule": stall_rule, "stall_rule_rounds": stall_rule_rounds}
               if stall_rule is not None else {}),
            **({"stall_widen_top_k": stall_widen_top_k} if stall_widen_top_k is not None else {}),
            **({"stop_unmet_at_release_min_k": stop_unmet_at_release_min_k}
               if stop_unmet_at_release_min_k is not None else {}),
            **({"eviction_scoring": eviction_scoring} if eviction_scoring != "retained" else {}),
            **({"eviction_shortlist": eviction_shortlist} if eviction_shortlist is not None else {}),
            **({"max_privacy_step": max_privacy_step} if max_privacy_step is not None else {}),
            **({"exact_speedups": True} if exact_speedups else {}),
            "record_iteration_test_metrics": record_iteration_test_metrics,
            "validation_only": validation_only,
            "test_evaluated": not validation_only,
            "record_iteration_validation_metrics": record_iteration_validation_metrics,
            "action_log_path": None if action_log_path is None else str(action_log_path),
            "selected_attributes": list(selected_attributes),
            "qi_attributes": list(qi_attributes),
            "release_target_k": (
                None if release_target_k is None else int(release_target_k)
            ),
            "release_target_semantics": (
                "candidate_ordinary_min_k"
                if release_target_k is None
                else "fixed_k"
            ),
            "search_utility_split": "validation",
            "final_utility_split": "validation" if validation_only else "test",
        }, run_dir / "config.json")
        _dump_json({
            "termination_condition": termination_condition,
            "test_evaluated": not validation_only,
            "final_utility_split": "validation" if validation_only else "test",
            "infeasible": infeasible,
            "target_validation_loss": target_validation_loss,
            "output_comparisons": output_comparisons,
            "iteration_count": iteration_count,
            "selected_row_count": len(selected_row_ids),
            "ordinary_selected_row_count": len(
                ordinary_final_selected_row_ids
            ),
            "initial_row_count": len(initial_row_ids),
            "initialization_row_count": len(initialization_row_ids),
            "baseline_val_loss": baseline_val_loss,
            "baseline_proxy_val_loss": baseline_proxy_val_loss,
            "loss_threshold_val": loss_threshold_val,
            "baseline_test_loss": baseline_test_loss,
            "loss_threshold_test": loss_threshold_test,
            "final_actual_model_loss": final_actual_model_loss,
            "utility_constraint_met": utility_constraint_met,
            "validation_utility_constraint_met": (
                validation_utility_constraint_met
            ),
            "release_target_k": final_release_target_k,
            "release_suppressed_row_count": len(
                release_suppressed_row_ids
            ),
            "original_leak_k": original_leak_k,
            "original_leak_k_p1": original_leak_k_p1,
            "original_leak_k_p2": original_leak_k_p2,
            "original_leak_k_p3": original_leak_k_p3,
            "original_leak_k_p4": original_leak_k_p4,
            "original_leak_k_p5": original_leak_k_p5,
            "final_leak_k": final_leak_k,
            "final_leak_k_p5": leak_k_p5,
            "tail_risk_p99": tail_risk_p99,
            "tail_risk_semantics": final_release_result.get("tail_risk_semantics"),
            "tail_risk_population": final_release_result.get("tail_risk_population"),
            "tail_risk_population_size": final_release_result.get("tail_risk_population_size"),
            "tail_risk_percentile_method": final_release_result.get("tail_risk_percentile_method"),
            "final_leak_k_95_percentile": final_leak_k_95_percentile,
            "timings": timings,
            "fast_path_usage": {
                **fast_path_usage,
                "all_fast": bool(fast_path_usage["selection_cache_active"] and not any(
                    counts["fallback"] for counts in fast_path_usage.values()
                    if isinstance(counts, dict))),
            },
        }, run_dir / "metrics.json")
        _dump_json({"selected_row_ids": [str(rid) for rid in selected_row_ids]},
                   run_dir / "selected_row_ids.json")
        _dump_json({
            "ordinary_selected_row_ids": [
                str(row_id) for row_id in ordinary_final_selected_row_ids
            ]
        }, run_dir / "ordinary_selected_row_ids.json")
        _dump_json({
            "generalization_level": dict(
                original_generalization.generalization_level if infeasible
                else state.current_generalization.generalization_level
            ),
            "search_generalization_level": dict(state.current_generalization.generalization_level),
        }, run_dir / "generalization_level.json")
        _dump_json({"leak_distribution": leak_distribution},
                   run_dir / "leak_distribution.json")
        _dump_json({
            "iterations": trim_iteration_results,
        }, run_dir / "trim_iterations.json")
        _dump_json(final_release_public, run_dir / "trim_release.json")

    return TrimPipelineResult(
        task_type="classification", loss_metric=loss_metric_name,
        selected_row_ids=selected_row_ids,
        generalization_level=dict(
            original_generalization.generalization_level if infeasible
            else state.current_generalization.generalization_level
        ),
        state=state, initial_row_ids=initial_row_ids,
        selected_retention_class_keys=selected_retention_class_keys,
        termination_condition=termination_condition,
        final_actual_model_loss=final_actual_model_loss,
        utility_constraint_met=utility_constraint_met,
        validation_utility_constraint_met=validation_utility_constraint_met,
        baseline_val_loss=baseline_val_loss,
        loss_threshold_val=loss_threshold_val,
        baseline_test_loss=baseline_test_loss,
        loss_threshold_test=loss_threshold_test,
        original_leak_k=original_leak_k,
        original_leak_k_p1=original_leak_k_p1,
        original_leak_k_p2=original_leak_k_p2,
        original_leak_k_p3=original_leak_k_p3,
        original_leak_k_p4=original_leak_k_p4,
        original_leak_k_p5=original_leak_k_p5,
        final_leak_k=final_leak_k, leak_k_p5=leak_k_p5,
        tail_risk_p99=tail_risk_p99,
        final_leak_k_sorted=final_leak_k_sorted,
        final_leak_k_95_percentile=final_leak_k_95_percentile,
        release_target_k=final_release_target_k,
        release_assignment_counts=dict(
            final_release_result.get("assignment_counts", {})
        ),
        release_suppressed_row_ids=release_suppressed_row_ids,
        release_snapshot_history=public_release_snapshot_history,
        infeasible=infeasible,
        test_evaluated=not validation_only,
        target_validation_loss=target_validation_loss,
        output_comparisons=output_comparisons,
        iteration_count=iteration_count, timings=timings,
        run_dir=str(run_dir) if run_dir is not None else None,
    )


# =========================================================================
# Helpers.
# =========================================================================
def _swap_generalization_attributes(generalization):
    numeric = tuple(getattr(generalization, "numeric_attributes", ()) or ())
    categorical = tuple(getattr(generalization, "categorical_attributes", ()) or ())
    attributes = numeric + categorical
    if attributes:
        return attributes
    return tuple(getattr(generalization, "generalization_level", {}) or ())


def _swap_attribute_columns(encoded, attribute):
    if attribute in encoded.columns:
        return [attribute]
    return [
        column
        for column in encoded.columns
        if isinstance(column, str) and column.startswith(f"{attribute}=")
    ]


def _swap_factorize_frame(frame):
    import pandas as pd

    if frame.shape[1] == 1:
        codes, _ = pd.factorize(
            frame.iloc[:, 0],
            sort=False,
            use_na_sentinel=False,
        )
    else:
        codes, _ = pd.factorize(
            pd.MultiIndex.from_frame(frame),
            sort=False,
            use_na_sentinel=False,
        )
    return codes.astype(np.intp, copy=False)


def _swap_categorical_frame_and_code(generalization, X_train_raw, attribute):
    import pandas as pd

    category_maps = getattr(generalization, "category_maps", {})
    categories = category_maps.get(attribute)
    if categories is None:
        frame = generalization._generalized_categorical_frame(
            X_train_raw, attribute)
        return frame, _swap_factorize_frame(frame)

    rules = getattr(generalization, "generalization_rules", {}).get(attribute, {})
    columns = [f"{attribute}={category}" for category in categories]
    sentinel = object()
    value_to_vector = {}
    vector_to_code = {}
    rows = []
    codes = np.empty(len(X_train_raw), dtype=np.intp)
    cache_key_func = getattr(
        generalization,
        "_categorical_cache_key",
        lambda value: value,
    )
    one_hot_func = getattr(generalization, "_one_hot_vector", None)

    for position, value in enumerate(X_train_raw[attribute]):
        cache_key = cache_key_func(value)
        vector = value_to_vector.get(cache_key)
        if vector is None:
            try:
                raw_vector = rules.get(value, sentinel)
            except TypeError:
                raw_vector = sentinel
            if raw_vector is sentinel:
                if one_hot_func is not None:
                    raw_vector = one_hot_func(attribute, value)
                else:
                    raw_vector = [0.0] * len(categories)
                    if value in categories:
                        raw_vector[categories[value]] = 1.0
            vector = tuple(raw_vector)
            value_to_vector[cache_key] = vector

        code = vector_to_code.get(vector)
        if code is None:
            code = len(vector_to_code)
            vector_to_code[vector] = code
        rows.append(vector)
        codes[position] = code

    return pd.DataFrame(rows, columns=columns, index=X_train_raw.index), codes


def _swap_attribute_frame_and_code(generalization, X_train_raw, attribute):
    import pandas as pd

    numeric_attributes = tuple(
        getattr(generalization, "numeric_attributes", ()) or ())
    categorical_attributes = tuple(
        getattr(generalization, "categorical_attributes", ()) or ())
    rules_by_attribute = getattr(generalization, "generalization_rules", {})

    if (
        attribute in numeric_attributes
        and hasattr(generalization, "_generalized_numeric_series")
    ):
        series = generalization._generalized_numeric_series(
            X_train_raw,
            attribute,
            rules_by_attribute.get(attribute, {}),
        )
        frame = pd.DataFrame({attribute: series}, index=X_train_raw.index)
        return frame, _swap_factorize_frame(frame)

    if (
        attribute in categorical_attributes
        and hasattr(generalization, "_generalized_categorical_frame")
    ):
        return _swap_categorical_frame_and_code(
            generalization, X_train_raw, attribute)

    full_encode = generalization.encode(X_train_raw)
    columns = _swap_attribute_columns(full_encode, attribute)
    if not columns:
        raise KeyError(f"Cannot find encoded columns for attribute {attribute!r}")
    frame = full_encode.loc[:, columns]
    return frame, _swap_factorize_frame(frame)


def _build_swap_encode_cache(generalization, X_train_raw, selected_attributes):
    import pandas as pd

    selected_attributes = tuple(selected_attributes)
    frames = []
    code_columns = {}
    attribute_columns = {}
    for attribute in _swap_generalization_attributes(generalization):
        frame, codes = _swap_attribute_frame_and_code(
            generalization, X_train_raw, attribute)
        frames.append(frame)
        attribute_columns[attribute] = list(frame.columns)
        if attribute in selected_attributes:
            code_columns[attribute] = codes

    if frames:
        encoded = pd.concat(frames, axis=1)
    else:
        encoded = generalization.encode(X_train_raw)

    for attribute in selected_attributes:
        if attribute in code_columns:
            continue
        columns = _swap_attribute_columns(encoded, attribute)
        if not columns:
            raise KeyError(
                f"Cannot find encoded columns for selected attribute {attribute!r}")
        frame = encoded.loc[:, columns]
        attribute_columns[attribute] = list(frame.columns)
        code_columns[attribute] = _swap_factorize_frame(frame)

    codes = pd.DataFrame(code_columns, index=X_train_raw.index)
    row_ids = np.asarray(list(encoded.index), dtype=object)
    row_id_to_position = {
        row_id: position
        for position, row_id in enumerate(row_ids)
    }
    return _SwapEncodeCache(
        encoded=encoded,
        codes=codes,
        row_ids=row_ids,
        row_id_to_position=row_id_to_position,
        selected_attributes=selected_attributes,
        attribute_columns=attribute_columns,
    )


def _update_swap_encode_cache(cache, generalization, X_train_raw, attribute):
    frame, codes = _swap_attribute_frame_and_code(
        generalization, X_train_raw, attribute)
    expected_columns = cache.attribute_columns.get(attribute)
    if expected_columns is None or expected_columns != list(frame.columns):
        rebuilt = _build_swap_encode_cache(
            generalization, X_train_raw, cache.selected_attributes)
        cache.encoded = rebuilt.encoded
        cache.codes = rebuilt.codes
        cache.row_ids = rebuilt.row_ids
        cache.row_id_to_position = rebuilt.row_id_to_position
        cache.attribute_columns = rebuilt.attribute_columns
        return cache.encoded

    cache.encoded.loc[:, expected_columns] = frame.to_numpy()
    if attribute in cache.codes.columns:
        cache.codes.loc[:, attribute] = codes
    return cache.encoded


def _swap_position_index_from_cache(cache):
    row_count = len(cache.row_ids)
    if row_count == 0:
        row_class_ids = np.empty(0, dtype=np.intp)
        class_member_positions = []
        class_total_sizes = np.empty(0, dtype=np.intp)
    elif cache.codes.shape[1] == 0:
        row_class_ids = np.zeros(row_count, dtype=np.intp)
        class_member_positions = [np.arange(row_count, dtype=np.intp)]
        class_total_sizes = np.asarray([row_count], dtype=np.intp)
    else:
        row_class_ids = cache.codes.groupby(
            list(cache.codes.columns),
            sort=False,
            dropna=False,
        ).ngroup().to_numpy(dtype=np.intp)
        class_total_sizes = np.bincount(row_class_ids)
        ordered_positions = np.argsort(row_class_ids, kind="stable")
        class_member_positions = np.split(
            ordered_positions,
            np.cumsum(class_total_sizes)[:-1],
        )

    return {
        "row_ids": cache.row_ids,
        "row_id_to_position": cache.row_id_to_position,
        "row_class_ids": row_class_ids,
        "class_member_positions": class_member_positions,
        "class_total_sizes": class_total_sizes,
    }


def _retention_class_index_groups_from_position_index(
    position_index,
    excluded_row_ids=None,
):
    excluded_row_ids = set(excluded_row_ids or ())
    row_ids = position_index["row_ids"]
    class_keys = position_index.get("class_keys")
    groups = []
    for class_id, class_positions in enumerate(
        position_index["class_member_positions"]
    ):
        class_row_ids = []
        for position in class_positions:
            row_id = row_ids[int(position)]
            if row_id not in excluded_row_ids:
                class_row_ids.append(row_id)
        if class_row_ids:
            class_key = class_keys[class_id] if class_keys is not None else class_id
            groups.append((class_key, class_row_ids))
    return groups


def _can_use_position_index_leakage(cache):
    if cache is None:
        return False
    return set(cache.selected_attributes) == set(cache.attribute_columns)


def _class_counts_from_position_index(row_ids, position_index):
    row_id_to_position = position_index["row_id_to_position"]
    row_class_ids = position_index["row_class_ids"]
    class_count = len(position_index["class_total_sizes"])
    positions = np.fromiter(
        (
            row_id_to_position[row_id]
            for row_id in row_ids
        ),
        dtype=np.intp,
    )
    if positions.size == 0:
        return np.zeros(class_count, dtype=np.intp)
    return np.bincount(row_class_ids[positions], minlength=class_count)


def _leakage_from_class_counts(counts):
    positive_counts = counts[counts > 0]
    if positive_counts.size == 0:
        return 0
    return int(positive_counts.min())


def _build_model(factory_or_model):
    return factory_or_model() if callable(factory_or_model) else factory_or_model


def _xgboost_model_input(generalization, X_raw_subset):
    if hasattr(generalization, "encode_xgboost_leaf_space"):
        encoded = generalization.encode_xgboost_leaf_space(X_raw_subset)
        try:
            from scipy import sparse
        except ImportError:
            sparse = None
        if sparse is not None and sparse.issparse(encoded):
            encoded = encoded.toarray()
        return np.ascontiguousarray(np.asarray(encoded), dtype=np.float32)
    if hasattr(generalization, "encode_xgboost_model_input"):
        return generalization.encode_xgboost_model_input(X_raw_subset)
    return generalization.encode(X_raw_subset)


def _encode_device_tensor(generalization, X_raw_subset, *, device, dtype):
    """``to_device_tensor(generalization.encode(X_raw_subset))``.

    A cached generalization fills the array from its value tables directly;
    the values equal those of the encoded frame, so only the pandas frame
    construction and consolidation are skipped.
    """
    array_builder = getattr(generalization, "encode_array", None)
    array = None if array_builder is None else array_builder(
        X_raw_subset,
        np.float64 if resolve_dtype(dtype) == torch.float64 else np.float32,
    )
    return to_device_tensor(
        generalization.encode(X_raw_subset) if array is None else array,
        device=device, dtype=dtype,
    )


def _encode_frame_from_tables(generalization, X_raw):
    """``generalization.encode(X_raw)`` as one float64 block built from the value tables.

    ``encode_array(X, float64)`` holds exactly the values of ``encode(X)``
    (tests/test_selection_cache.py); the frame gets the same index and columns,
    and every column is float64 as in ``encode``. Without a cached
    generalization, or when ``encode_array`` declines, ``encode`` runs instead.
    """
    import pandas as pd

    array_builder = getattr(generalization, "encode_array", None)
    array = None if array_builder is None else array_builder(X_raw, np.float64)
    if array is None:
        return generalization.encode(X_raw)
    columns = generalization.encode(X_raw.iloc[:1]).columns
    if len(columns) != array.shape[1]:
        return generalization.encode(X_raw)
    return pd.DataFrame(array, index=X_raw.index, columns=columns, copy=False)


def _encode_split_rows(generalization, X_split, row_ids=None, *, positions=None, device, dtype,
                       device_gather=False):
    """``_encode_device_tensor`` of ``X_split.loc[row_ids]``, ``X_split.iloc[positions]`` or ``X_split``.

    With ``device_gather`` (``exact_speedups``) a cached generalization gathers
    the rows on the device from its value tables when the selection cache
    indexed ``X_split`` (``CachedGeneralization.encode_rows_tensor``: the same
    values, bitwise). Otherwise, or when it declines, the rows are selected
    with pandas and encoded.
    """
    if row_ids is not None and positions is not None:
        raise ValueError("Pass row_ids or positions, not both.")
    if device_gather:
        builder = getattr(generalization, "encode_rows_tensor", None)
        if builder is not None and (row_ids is None or X_split.index.is_unique):
            gathered = builder(
                X_split,
                X_split.index.get_indexer(row_ids) if row_ids is not None else positions,
                device=resolve_device(device), dtype=resolve_dtype(dtype),
            )
            if gathered is not None:
                return gathered
    subset = (X_split.loc[row_ids] if row_ids is not None
              else X_split.iloc[positions] if positions is not None else X_split)
    return _encode_device_tensor(generalization, subset, device=device, dtype=dtype)


def _privacy_keys(generalization, frames, qi_attributes):
    """Class keys of each frame: rows share values exactly when they share a class.

    All frames use one representation (rank columns, else encoded QI columns),
    so keys of training and validation rows can be compared.
    """
    builder = getattr(generalization, "privacy_frame", None)
    if builder is not None:
        keys = [builder(frame, qi_attributes) for frame in frames]
        if all(key is not None for key in keys):
            return keys
    return [select_encoded_attributes(generalization.encode(frame), qi_attributes) for frame in frames]


def _distinct_snapshot_generalizations(snapshot_history):
    """Generalizations of the committed snapshots, newest first, one per level set."""
    seen, ordered = set(), []
    for snapshot in sorted(snapshot_history, key=lambda item: int(item["iteration"]), reverse=True):
        key = tuple(sorted(snapshot["generalization_level"].items()))
        if key not in seen:
            seen.add(key)
            ordered.append(snapshot["_generalization"])
    return ordered


def _published_eviction_layout(candidate_generalization, kept_ids, evicted_ids, target_k,
                               older_generalizations, X_train_raw, X_val_raw, qi_attributes):
    """Where a refine-and-evict move publishes its rows, and how validation rows follow.

    The kept rows stay at the candidate's levels. As in the mixed release, an
    evicted row goes to the newest earlier snapshot (``older_generalizations``,
    newest first) at which its class among the evicted rows not yet placed has
    at least ``target_k`` rows; the rest are suppressed. A validation row whose
    class at the candidate's levels is a kept class stays there; one that
    matches a pooled class moves to that snapshot; any other row stays at the
    candidate's levels, as retained scoring encodes it.

    Returns ``(train_parts, suppressed_ids, val_parts)``; a part is
    ``(row_ids, generalization)`` and the first part is the candidate's.
    """
    import pandas as pd

    train_parts = [(list(kept_ids), candidate_generalization)]
    remaining = list(evicted_ids)
    pooled = []
    for generalization in older_generalizations:
        if not remaining:
            break
        keys, val_keys = _privacy_keys(generalization, (X_train_raw.loc[remaining], X_val_raw), qi_attributes)
        sizes = keys.groupby(list(keys.columns), sort=False, dropna=False, observed=True).transform("size")
        if isinstance(sizes, pd.DataFrame):
            sizes = sizes.iloc[:, 0]
        safe = keys.index[sizes.to_numpy() >= int(target_k)].tolist()
        if not safe:
            continue
        train_parts.append((safe, generalization))
        pooled.append((val_keys, keys.loc[safe].drop_duplicates(), generalization))
        safe_set = set(safe)
        remaining = [rid for rid in remaining if rid not in safe_set]

    moved_parts = []
    if pooled:
        val_keys, kept_keys = _privacy_keys(
            candidate_generalization, (X_val_raw, X_train_raw.loc[list(kept_ids)]), qi_attributes)
        in_kept = pd.MultiIndex.from_frame(val_keys).isin(
            pd.MultiIndex.from_frame(kept_keys.drop_duplicates()))
        open_ids = val_keys.index[~in_kept].tolist()
        for snapshot_val_keys, accepted, generalization in pooled:
            if not open_ids:
                break
            keys = snapshot_val_keys.loc[open_ids]
            matched = keys.index[pd.MultiIndex.from_frame(keys).isin(
                pd.MultiIndex.from_frame(accepted))].tolist()
            if matched:
                moved_parts.append((matched, generalization))
                matched_set = set(matched)
                open_ids = [rid for rid in open_ids if rid not in matched_set]
    moved = {rid for ids, _generalization in moved_parts for rid in ids}
    val_parts = [([rid for rid in X_val_raw.index if rid not in moved], candidate_generalization),
                 *moved_parts]
    return train_parts, remaining, val_parts


def _lga_theta(backend_model):
    return model_theta_tensor(backend_model)


def _retention_class_row_ids(retention_class):
    index = getattr(retention_class, "index", None)
    if index is not None and not callable(index):
        return list(index)
    if hasattr(retention_class, "tolist"):
        return list(retention_class.tolist())
    return list(retention_class)


def _apply_vertical_swap_inplace(
    state, X_train_raw, selected_attributes, *,
    swap_level_encode=None, swap_position_index=None, swap_codes=None,
):
    """Apply post-vertical swap to a candidate state without global bookkeeping.

    Seed records are retained records like any other, so the swap may exchange them.
    """
    from .enumeration_horizontal import build_retention_class_position_index

    swap_t0 = time.perf_counter()
    swap_iterations = 0
    swap_move_out_row_count = 0
    swap_move_in_row_count = 0
    swap_break_reason = "max_iterations"
    if len(state.selected_row_ids) >= len(X_train_raw):
        return {
            "swap_iterations": swap_iterations,
            "elapsed_seconds": time.perf_counter() - swap_t0,
            "encode_time_seconds": 0.0,
            "position_index_time_seconds": 0.0,
            "loop_time_seconds": 0.0,
            "sync_time_seconds": 0.0,
            "break_reason": "no_candidates",
            "selected_row_count": len(state.selected_row_ids),
            "candidate_row_count": 0,
            "move_out_row_count": 0,
            "move_in_row_count": 0,
            "swap_level_encode": (
                swap_level_encode
                if swap_level_encode is not None
                else state.current_train_encode
            ),
            "swap_position_index": swap_position_index,
            "swap_codes": swap_codes,
        }
    swap_encode_t0 = time.perf_counter()
    # A candidate state without an encoding (selection with rank columns) is
    # not synced, so the encoding is only needed to build a missing index.
    if swap_level_encode is None and (
        swap_position_index is None or state.current_train_encode is not None
    ):
        swap_level_encode = state.current_generalization.encode(X_train_raw)
    swap_encode_time = time.perf_counter() - swap_encode_t0
    swap_position_index_t0 = time.perf_counter()
    if swap_position_index is None:
        swap_position_index = build_retention_class_position_index(
            swap_level_encode, selected_attributes=selected_attributes,
            sort_keys=False)
    swap_position_index_time = time.perf_counter() - swap_position_index_t0
    swap_row_ids = swap_position_index["row_ids"]
    swap_row_id_to_position = swap_position_index["row_id_to_position"]
    swap_row_class_ids = swap_position_index["row_class_ids"]
    swap_class_member_positions = swap_position_index["class_member_positions"]
    swap_class_total_sizes = swap_position_index["class_total_sizes"]
    swap_class_count = len(swap_class_total_sizes)
    swap_row_count = len(swap_row_ids)
    swap_selected_positions = np.fromiter(
        (swap_row_id_to_position[rid] for rid in state.selected_row_ids),
        dtype=np.intp, count=len(state.selected_row_ids))
    swap_selected_mask = np.zeros(swap_row_count, dtype=bool)
    swap_selected_mask[swap_selected_positions] = True
    swap_selected_order = np.full(swap_row_count, -1, dtype=np.int64)
    swap_selected_order[swap_selected_positions] = np.arange(
        len(swap_selected_positions), dtype=np.int64)
    swap_next_order = int(len(swap_selected_positions))
    swap_selected_count = int(len(swap_selected_positions))
    swap_member_arrays = [
        np.asarray(positions, dtype=np.intp)
        for positions in swap_class_member_positions
    ]
    swap_swappable_sizes = np.zeros(swap_class_count, dtype=np.intp)
    swap_candidate_sizes = np.zeros(swap_class_count, dtype=np.intp)
    swap_swappable_first_order = np.full(swap_class_count, -1, dtype=np.int64)
    swap_candidate_first_position = np.full(swap_class_count, -1, dtype=np.int64)

    swap_swappable_heap = []
    swap_candidate_heap = []

    if swap_class_count:
        selected_class_ids = swap_row_class_ids[swap_selected_positions]
        selected_counts = np.bincount(
            selected_class_ids, minlength=swap_class_count)
        swap_candidate_sizes[:] = swap_class_total_sizes - selected_counts

        swap_candidate_positions = np.flatnonzero(~swap_selected_mask)
        if len(swap_candidate_positions):
            candidate_class_ids = swap_row_class_ids[swap_candidate_positions]
            first_positions = np.full(
                swap_class_count, swap_row_count, dtype=np.int64)
            np.minimum.at(
                first_positions, candidate_class_ids,
                swap_candidate_positions)
            candidate_first_mask = first_positions != swap_row_count
            swap_candidate_first_position[candidate_first_mask] = (
                first_positions[candidate_first_mask])

        swap_swappable_positions = swap_selected_positions
        if len(swap_swappable_positions):
            swappable_class_ids = swap_row_class_ids[swap_swappable_positions]
            swap_swappable_sizes[:] = np.bincount(
                swappable_class_ids, minlength=swap_class_count)
            first_orders = np.full(
                swap_class_count, swap_row_count, dtype=np.int64)
            np.minimum.at(
                first_orders, swappable_class_ids,
                swap_selected_order[swap_swappable_positions])
            swappable_first_mask = first_orders != swap_row_count
            swap_swappable_first_order[swappable_first_mask] = (
                first_orders[swappable_first_mask])

    def _recompute_swap_class(swap_class_id):
        swap_positions = swap_member_arrays[swap_class_id]
        if swap_positions.size == 0:
            swap_swappable_sizes[swap_class_id] = 0
            swap_candidate_sizes[swap_class_id] = 0
            swap_swappable_first_order[swap_class_id] = -1
            swap_candidate_first_position[swap_class_id] = -1
            return
        swap_selected = swap_selected_mask[swap_positions]
        swap_swappable_positions = swap_positions[swap_selected]
        swap_swappable_sizes[swap_class_id] = len(swap_swappable_positions)
        if len(swap_swappable_positions):
            swap_swappable_first_order[swap_class_id] = int(
                swap_selected_order[swap_swappable_positions].min())
        else:
            swap_swappable_first_order[swap_class_id] = -1
        swap_candidate_positions = swap_positions[~swap_selected]
        swap_candidate_sizes[swap_class_id] = len(swap_candidate_positions)
        if len(swap_candidate_positions):
            swap_candidate_first_position[swap_class_id] = int(
                swap_candidate_positions[0])
        else:
            swap_candidate_first_position[swap_class_id] = -1

    def _push_swappable_class(swap_class_id):
        swap_size = int(swap_swappable_sizes[swap_class_id])
        swap_first_order = int(swap_swappable_first_order[swap_class_id])
        if swap_size > 0 and swap_first_order >= 0:
            heapq.heappush(
                swap_swappable_heap,
                (swap_size, swap_first_order, swap_class_id),
            )

    def _push_candidate_class(swap_class_id):
        swap_size = int(swap_candidate_sizes[swap_class_id])
        swap_first_position = int(swap_candidate_first_position[swap_class_id])
        if swap_size > 0 and swap_first_position >= 0:
            heapq.heappush(
                swap_candidate_heap,
                (-swap_size, swap_first_position, swap_class_id),
            )

    def _peek_swappable_class():
        while swap_swappable_heap:
            swap_size, swap_first_order, swap_class_id = swap_swappable_heap[0]
            if (
                int(swap_swappable_sizes[swap_class_id]) == swap_size
                and int(swap_swappable_first_order[swap_class_id])
                == swap_first_order
                and swap_size > 0
            ):
                return swap_size, swap_class_id
            heapq.heappop(swap_swappable_heap)
        return None

    def _peek_candidate_class():
        while swap_candidate_heap:
            swap_negative_size, swap_first_position, swap_class_id = (
                swap_candidate_heap[0]
            )
            if (
                int(swap_candidate_sizes[swap_class_id]) == -swap_negative_size
                and int(swap_candidate_first_position[swap_class_id])
                == swap_first_position
                and swap_negative_size < 0
            ):
                return -swap_negative_size, swap_class_id
            heapq.heappop(swap_candidate_heap)
        return None

    swap_swappable_heap = [
        (
            int(swap_swappable_sizes[swap_class_id]),
            int(swap_swappable_first_order[swap_class_id]),
            int(swap_class_id),
        )
        for swap_class_id in np.flatnonzero(
            (swap_swappable_sizes > 0)
            & (swap_swappable_first_order >= 0))
    ]
    heapq.heapify(swap_swappable_heap)
    swap_candidate_heap = [
        (
            -int(swap_candidate_sizes[swap_class_id]),
            int(swap_candidate_first_position[swap_class_id]),
            int(swap_class_id),
        )
        for swap_class_id in np.flatnonzero(
            (swap_candidate_sizes > 0)
            & (swap_candidate_first_position >= 0))
    ]
    heapq.heapify(swap_candidate_heap)

    swap_sync_time = 0.0
    swap_sync_position_list = []
    swap_loop_t0 = time.perf_counter()
    for _ in range(VERTICAL_SWAP_MAX_ITERATIONS):
        if swap_selected_count >= swap_row_count:
            swap_break_reason = "no_candidates"
            break
        if swap_selected_count == 0 or swap_class_count == 0:
            swap_break_reason = "no_selected_groups"
            break
        swap_swappable_top = _peek_swappable_class()
        if swap_swappable_top is None:
            swap_break_reason = "no_swappable_selected_groups"
            break
        swap_candidate_top = _peek_candidate_class()
        if swap_candidate_top is None:
            swap_break_reason = "no_candidate_groups"
            break
        a = int(swap_swappable_top[0])
        b, b_class_id = swap_candidate_top
        b = int(b)
        b_class_id = int(b_class_id)
        if not (a < b):
            swap_break_reason = "converged"
            break
        swap_chosen_class_ids = []
        swap_move_out_total = 0
        while True:
            swap_next_swappable = _peek_swappable_class()
            if swap_next_swappable is None:
                break
            swap_size, swap_class_id = swap_next_swappable
            swap_size = int(swap_size)
            swap_class_id = int(swap_class_id)
            if swap_move_out_total + swap_size <= b:
                heapq.heappop(swap_swappable_heap)
                swap_chosen_class_ids.append(swap_class_id)
                swap_move_out_total += swap_size
            else:
                break
        if not swap_chosen_class_ids:
            swap_break_reason = "smallest_selected_exceeds_candidate"
            break
        swap_touched_class_ids = set(swap_chosen_class_ids)
        swap_touched_class_ids.add(b_class_id)
        swap_move_out_parts = []
        for swap_class_id in swap_chosen_class_ids:
            swap_class_positions = swap_member_arrays[swap_class_id]
            swap_class_selected_positions = swap_class_positions[
                swap_selected_mask[swap_class_positions]]
            if len(swap_class_selected_positions):
                swap_move_out_parts.append(swap_class_selected_positions)
        if not swap_move_out_parts:
            swap_break_reason = "no_move_out"
            break
        swap_move_out_positions = np.concatenate(swap_move_out_parts)
        swap_candidate_class_positions = swap_member_arrays[b_class_id]
        swap_move_in_positions = swap_candidate_class_positions[
            ~swap_selected_mask[swap_candidate_class_positions]]
        if len(swap_move_in_positions) == 0:
            swap_break_reason = "no_move_in"
            break
        swap_selected_mask[swap_move_out_positions] = False
        swap_selected_order[swap_move_out_positions] = -1
        swap_selected_mask[swap_move_in_positions] = True
        swap_selected_order[swap_move_in_positions] = np.arange(
            swap_next_order,
            swap_next_order + len(swap_move_in_positions),
            dtype=np.int64)
        swap_next_order += int(len(swap_move_in_positions))
        swap_selected_count += int(
            len(swap_move_in_positions) - len(swap_move_out_positions))
        swap_move_out_row_count += int(len(swap_move_out_positions))
        swap_move_in_row_count += int(len(swap_move_in_positions))
        for swap_class_id in swap_touched_class_ids:
            _recompute_swap_class(swap_class_id)
            _push_swappable_class(swap_class_id)
            _push_candidate_class(swap_class_id)
        swap_sync_position_list.extend(
            int(position) for position in swap_move_in_positions.tolist())
        swap_iterations += 1
    swap_loop_time = max(0.0, time.perf_counter() - swap_loop_t0)
    if swap_sync_position_list and state.current_train_encode is not None:
        swap_sync_t0 = time.perf_counter()
        swap_sync_positions = list(dict.fromkeys(swap_sync_position_list))
        state.current_train_encode.iloc[swap_sync_positions, :] = (
            swap_level_encode.iloc[swap_sync_positions, :].to_numpy())
        state.current_train_tensor[swap_sync_positions] = to_device_tensor(
            swap_level_encode.iloc[swap_sync_positions, :],
            device=state.current_train_tensor.device,
            dtype=state.current_train_tensor.dtype)
        swap_sync_time += time.perf_counter() - swap_sync_t0
    swap_final_positions = np.flatnonzero(swap_selected_mask)
    swap_final_positions = swap_final_positions[
        np.argsort(swap_selected_order[swap_final_positions], kind="stable")]
    state.selected_row_ids = np.asarray(
        swap_row_ids, dtype=object)[swap_final_positions].tolist()
    return {
        "swap_iterations": swap_iterations,
        "elapsed_seconds": time.perf_counter() - swap_t0,
        "encode_time_seconds": swap_encode_time,
        "position_index_time_seconds": swap_position_index_time,
        "loop_time_seconds": swap_loop_time,
        "sync_time_seconds": swap_sync_time,
        "break_reason": swap_break_reason,
        "selected_row_count": len(state.selected_row_ids),
        "candidate_row_count": len(swap_row_ids) - len(state.selected_row_ids),
        "move_out_row_count": swap_move_out_row_count,
        "move_in_row_count": swap_move_in_row_count,
        "swap_level_encode": swap_level_encode,
        "swap_position_index": swap_position_index,
        "swap_codes": swap_codes,
    }


def _apply_vertical_postprocessing_inplace(
    state,
    X_train_raw,
    selected_attributes,
    *,
    policy,
    move_out_threshold=None,
    swap_level_encode=None,
    swap_position_index=None,
    swap_codes=None,
):
    """Apply the configured vertical postprocessing policy in place."""

    if policy == FULL_SWAP_POSTPROCESSING:
        stats = _apply_vertical_swap_inplace(
            state,
            X_train_raw,
            selected_attributes,
            swap_level_encode=swap_level_encode,
            swap_position_index=swap_position_index,
            swap_codes=swap_codes,
        )
        stats.update({
            "postprocessing_policy": policy,
            "move_out_threshold": None,
            "extra_swap_in_count": 0,
        })
        return stats

    postprocessing_started_at = time.perf_counter()
    encode_started_at = time.perf_counter()
    if swap_level_encode is None and swap_position_index is None:
        swap_level_encode = state.current_generalization.encode(X_train_raw)
    encode_time = time.perf_counter() - encode_started_at

    position_index_started_at = time.perf_counter()
    if swap_position_index is None:
        swap_position_index = build_retention_class_position_index(
            swap_level_encode,
            selected_attributes=selected_attributes,
            sort_keys=False,
        )
    position_index_time = time.perf_counter() - position_index_started_at

    loop_started_at = time.perf_counter()
    move_out_row_count = 0
    affected_class_count = 0
    break_reason = "postprocessing_disabled"
    if policy == EVICT_LOW_K_POSTPROCESSING:
        row_ids = swap_position_index["row_ids"]
        row_id_to_position = swap_position_index["row_id_to_position"]
        row_class_ids = swap_position_index["row_class_ids"]
        class_count = len(swap_position_index["class_total_sizes"])
        selected_positions = np.fromiter(
            (row_id_to_position[row_id] for row_id in state.selected_row_ids),
            dtype=np.intp,
            count=len(state.selected_row_ids),
        )
        # Seed records are evicted like any other retained record.
        movable_positions = selected_positions
        movable_class_sizes = np.zeros(class_count, dtype=np.intp)
        if len(movable_positions):
            movable_class_sizes = np.bincount(
                row_class_ids[movable_positions],
                minlength=class_count,
            )
        evicted_class_ids = np.flatnonzero(
            (movable_class_sizes > 0)
            & (movable_class_sizes < int(move_out_threshold))
        )
        affected_class_count = int(len(evicted_class_ids))
        if affected_class_count:
            evicted_class_id_set = set(evicted_class_ids.tolist())
            evicted_row_ids = {
                row_ids[position]
                for position in movable_positions
                if int(row_class_ids[position]) in evicted_class_id_set
            }
            move_out_row_count = len(evicted_row_ids)
            state.selected_row_ids = [
                row_id
                for row_id in state.selected_row_ids
                if row_id not in evicted_row_ids
            ]
            break_reason = "low_k_groups_evicted"
        else:
            break_reason = "no_low_k_groups"
    loop_time = time.perf_counter() - loop_started_at

    return {
        "swap_iterations": affected_class_count,
        "elapsed_seconds": time.perf_counter() - postprocessing_started_at,
        "encode_time_seconds": encode_time,
        "position_index_time_seconds": position_index_time,
        "loop_time_seconds": loop_time,
        "sync_time_seconds": 0.0,
        "break_reason": break_reason,
        "selected_row_count": len(state.selected_row_ids),
        "candidate_row_count": len(X_train_raw) - len(state.selected_row_ids),
        "move_out_row_count": move_out_row_count,
        "move_in_row_count": 0,
        "extra_swap_in_count": 0,
        "postprocessing_policy": policy,
        "move_out_threshold": move_out_threshold,
        "swap_level_encode": swap_level_encode,
        "swap_position_index": swap_position_index,
        "swap_codes": swap_codes,
    }


def _greedy_select(
    state, *, remaining_retention_classes, X_train_raw, X_val_raw, backend_model,
    leakage_func, rank_top_k, standardizer, row_id_to_position,
    train_y_tensor, val_y_tensor, selection_timing, action_log_path, iteration_count, current_train_level_encode=None,
    swap_encode_cache=None, count_privacy_by_class=False,
    candidate_release_evaluator=None, enabled_action_types=None,
    vertical_postprocessing=FULL_SWAP_POSTPROCESSING, move_out_threshold=None,
    candidate_shortlist=None, candidate_state_scorer=None, selection_score=None,
    privacy_cost_floor=None,
    candidate_experiment=None, fast_path_usage=None,
    refinement_eviction_ratios=None, eviction_release_evaluator=None,
    eviction_shortlist=None, max_privacy_step=None, exact_speedups=False,
):
    """Rank complete operations by LGA/cost, then proxy-check the top-k of each pool.

    ``eviction_release_evaluator`` (``eviction_scoring="published_check"``)
    proxy-checks refine-and-evict variants with their published evicted rows.
    ``exact_speedups`` gathers encodings on the device and builds refinement
    candidates' class indexes with numpy (same values; see run_trim_pipeline).
    """
    from .lga import cal_lga, cal_lga_batch

    started = time.perf_counter()
    timings = {name: 0.0 for name in (
        "lga", "proxy_retrain", "leakage", "ranking", "optimized_privacy",
    )}
    if candidate_release_evaluator is None:
        raise ValueError("candidate_release_evaluator is required.")
    selected_ids = list(state.selected_row_ids)
    selected_set = set(selected_ids)
    selected_positions = [row_id_to_position[rid] for rid in selected_ids]
    current_generalization = state.current_generalization
    current_level = dict(current_generalization.generalization_level)
    qi_attributes = tuple(current_level)
    current_encode = (
        current_train_level_encode if current_train_level_encode is not None
        else current_generalization.encode(X_train_raw)
    )
    current_index = (
        _swap_position_index_from_cache(swap_encode_cache)
        if count_privacy_by_class or _can_use_position_index_leakage(swap_encode_cache)
        else None
    )
    if fast_path_usage is not None:
        fast_path_usage["selection_class_id_privacy"][
            "used" if current_index is not None else "fallback"] += 1
    privacy_started = time.perf_counter()
    if current_index is not None:
        current_counts = _class_counts_from_position_index(selected_ids, current_index)
        current_k = _leakage_from_class_counts(current_counts)
        timings["optimized_privacy"] += time.perf_counter() - privacy_started
    else:
        current_k = int(leakage_func(current_encode.loc[selected_ids]))
    current_size_frequencies = (
        dict(zip(*np.unique(current_counts[current_counts > 0], return_counts=True)))
        if current_index is not None else {}
    )
    if current_k < 1:
        raise ValueError("The selected state, including its seed, must have positive min-K.")

    current_score_encode = standardizer.transform(state.current_train_tensor[selected_positions])
    current_y = train_y_tensor[selected_positions]
    current_val_encode = standardizer.transform(_encode_split_rows(
        current_generalization, X_val_raw,
        device=state.current_train_tensor.device, dtype=state.current_train_tensor.dtype,
        device_gather=exact_speedups,
    ))
    if candidate_experiment is not None:
        current_target = candidate_release_evaluator(
            current_generalization, current_k, selected_ids, role="downstream",
        )
        candidate_experiment.begin_iteration(
            iteration=iteration_count, estimator_model=backend_model,
            current_encode=current_score_encode, current_y=current_y,
            validation_encode=current_val_encode, validation_y=val_y_tensor,
            current_proxy_validation_loss=state.actual_model_loss,
            current_downstream_validation_loss=current_target["validation_loss"],
        )

    items = (
        list(remaining_retention_classes.items())
        if hasattr(remaining_retention_classes, "items") else list(remaining_retention_classes)
    )
    enabled = frozenset(enabled_action_types or (
        RETENTION_CLASS_ACTION, VERTICAL_REFINEMENT_ACTION,
    ))
    if RETENTION_CLASS_ACTION not in enabled:
        items = []
    retention = []
    for position, (key, group) in enumerate(items):
        admitted = [rid for rid in _retention_class_row_ids(group) if rid not in selected_set]
        if not admitted:
            continue
        positions = [row_id_to_position[rid] for rid in admitted]
        privacy_started = time.perf_counter()
        if current_index is not None:
            changed_classes, additions = np.unique(
                current_index["row_class_ids"][positions], return_counts=True,
            )
            old_sizes = current_counts[changed_classes]
            removed_frequencies = {}
            for size in old_sizes[old_sizes > 0]:
                removed_frequencies[int(size)] = removed_frequencies.get(int(size), 0) + 1
            untouched_min = next((
                size for size in sorted(current_size_frequencies)
                if current_size_frequencies[size] > removed_frequencies.get(int(size), 0)
            ), float("inf"))
            next_k = int(min(untouched_min, int((old_sizes + additions).min())))
            timings["optimized_privacy"] += time.perf_counter() - privacy_started
        else:
            next_k = int(leakage_func(current_encode.loc[selected_ids + admitted]))
        cost, delta = _operation_privacy_cost(
            current_k, next_k, privacy_cost_floor,
        )
        retention.append({
            "action": RETENTION_CLASS_ACTION, "candidate_type": RETENTION_CLASS_ACTION,
            "retention_class_position": position, "retention_class_key": key,
            "rank_candidate_id": key, "attribute": None,
            "admitted_ids": admitted,
            "admitted_positions": positions, "next_generalization": current_generalization,
            "next_k": next_k, "privacy_cost": cost, "leakage_delta": delta,
        })
    if retention:
        lga_started = time.perf_counter()
        if candidate_experiment is None:
            theta = _lga_theta(backend_model)
            scores = cal_lga_batch(
                train_original_encode=current_score_encode,
                val_original_encode=current_val_encode,
                train_y=current_y, val_y=val_y_tensor,
                train_current_encode=current_score_encode, backend_model=backend_model,
                candidate_changed_positions=[
                    torch.as_tensor(c["admitted_positions"], device=state.current_train_tensor.device)
                    for c in retention
                ],
                # One row lookup for all candidates instead of one per class;
                # the standardizer works row by row and cal_lga_batch only
                # reads these tensors, so the split views hold the same values.
                candidate_next_changed_encodes=list(torch.split(
                    standardizer.transform(to_device_tensor(
                        current_encode.loc[[rid for c in retention for rid in c["admitted_ids"]]],
                        device=state.current_train_tensor.device, dtype=state.current_train_tensor.dtype,
                    )),
                    [len(c["admitted_ids"]) for c in retention],
                )),
                candidate_admitted_labels=[train_y_tensor[c["admitted_positions"]] for c in retention],
                precomputed_theta=theta,
            )
            for candidate, score in zip(retention, scores):
                candidate["lga_score"] = float(score)
        else:
            for candidate in retention:
                measured = candidate_experiment.score_admission(
                    candidate_type=RETENTION_CLASS_ACTION,
                    candidate_id=candidate["rank_candidate_id"],
                    admitted_encode=standardizer.transform(to_device_tensor(
                        current_encode.loc[candidate["admitted_ids"]],
                        device=state.current_train_tensor.device, dtype=state.current_train_tensor.dtype,
                    )),
                    admitted_y=train_y_tensor[candidate["admitted_positions"]],
                )
                candidate.update(measured)
                candidate["lga_score"] = float(measured["raw_lga_score"])
        timings["lga"] += time.perf_counter() - lga_started

    vertical = []
    # A refine-and-swap may move a QI to any finer level: child level first,
    # then finer levels (ties keep this order).
    refinement_targets = [
        (attribute, target_level)
        for attribute, level in (current_level.items()
                                 if VERTICAL_REFINEMENT_ACTION in enabled else ())
        if int(level) > 0
        for target_level in range(int(level) - 1, -1, -1)
    ]
    for attribute, target_level in refinement_targets:
        candidate_id = f"{attribute}@{target_level}"
        next_levels = {**current_level, attribute: target_level}
        generalization = current_generalization.change_level(next_levels)
        privacy_started = time.perf_counter()
        # Rank columns give the same classes, numbering and sizes as the
        # encoded QI columns at a fraction of the grouping cost.
        privacy_frame_builder = getattr(generalization, "privacy_frame", None)
        level_privacy = (privacy_frame_builder(X_train_raw, qi_attributes)
                         if privacy_frame_builder is not None else None)
        if fast_path_usage is not None:
            fast_path_usage["refinement_rank_privacy"][
                "used" if level_privacy is not None else "fallback"] += 1
        # With rank columns the swap reads no encoding (its in-place sync only
        # rewrites rows with the values they already hold), so the candidate
        # skips the full training encode, its copy and its device tensor. The
        # LGA inputs are encoded below for the kept rows only; encode works row
        # by row, so they are the same rows of the full encode.
        level_encode = (generalization.encode(X_train_raw)
                        if level_privacy is None else None)
        candidate_state = SelectionState(
            predicted_model_loss=state.actual_model_loss, actual_model_loss=state.actual_model_loss,
            current_generalization=generalization, selected_row_ids=list(selected_ids),
            current_train_encode=None if level_encode is None else level_encode.copy(),
            current_train_tensor=None if level_encode is None else to_device_tensor(
                level_encode, device=state.current_train_tensor.device,
                dtype=state.current_train_tensor.dtype,
            ), action_log_path=state.action_log_path,
        )
        swap_position_index = (
            # The swap and the eviction variants read neither class keys nor
            # write the row tables, so the index skips the keys and shares them.
            (build_retention_class_position_index_numpy(
                level_privacy, selected_attributes=qi_attributes,
                with_class_keys=False, share_row_tables=True)
             if exact_speedups else build_retention_class_position_index(
                 level_privacy, selected_attributes=qi_attributes, sort_keys=False))
            if level_privacy is not None else None
        )
        swap_stats = _apply_vertical_postprocessing_inplace(
            candidate_state, X_train_raw, qi_attributes, policy=vertical_postprocessing,
            move_out_threshold=move_out_threshold, swap_level_encode=level_encode,
            swap_position_index=swap_position_index,
        )
        # Candidate logs need counts and timings, not a full encoding per QI.
        swap_stats = {key: value for key, value in swap_stats.items()
                      if key not in {"swap_level_encode", "swap_position_index", "swap_codes"}}
        next_ids = list(candidate_state.selected_row_ids)
        if not next_ids:
            del candidate_state
            continue
        privacy_encode = level_privacy if level_privacy is not None else level_encode
        if exact_speedups and swap_position_index is not None:
            # The index's classes are the groups of the rank columns, so the
            # smallest class among the given rows is value_counts().min().
            row_position, row_class = (swap_position_index["row_id_to_position"],
                                       swap_position_index["row_class_ids"])
            before_k, next_k = (
                int(counts[counts > 0].min()) for counts in (
                    np.bincount(row_class[np.fromiter((row_position[rid] for rid in ids), dtype=np.intp,
                                                      count=len(ids))])
                    for ids in (selected_ids, next_ids)))
        else:
            before_k = int(calculate_leakage(select_encoded_attributes(
                privacy_encode.loc[selected_ids], qi_attributes,
            )))
            next_k = int(leakage_func(privacy_encode.loc[next_ids]))
        if vertical_postprocessing == FULL_SWAP_POSTPROCESSING:
            if len(next_ids) < len(selected_ids) or next_k < before_k:
                raise RuntimeError("Swap reduced retention or the minimum retained class size.")
        cost, delta = _operation_privacy_cost(
            current_k, next_k, privacy_cost_floor,
        )
        timings["leakage"] += time.perf_counter() - privacy_started
        if action_log_path is not None:
            with Path(action_log_path).open("a", encoding="utf-8") as handle:
                handle.write(json.dumps({
                    "event": "swap_candidate", "iteration": iteration_count,
                    "attribute": attribute, "swap_iterations": swap_stats["swap_iterations"],
                    "break_reason": swap_stats["break_reason"],
                    "cap_hit": swap_stats["break_reason"] == "max_iterations",
                    "evicted_row_count": len(set(state.selected_row_ids) - set(next_ids)),
                    # An attribute has one candidate per target level.
                    "candidate_id": candidate_id, "target_level": target_level,
                }) + "\n")
        next_positions = [row_id_to_position[rid] for rid in next_ids]
        next_score_encode = standardizer.transform(
            candidate_state.current_train_tensor[next_positions]
            if candidate_state.current_train_tensor is not None
            else _encode_split_rows(
                generalization, X_train_raw, positions=next_positions,
                device=state.current_train_tensor.device,
                dtype=state.current_train_tensor.dtype,
                device_gather=exact_speedups,
            )
        )
        next_y = train_y_tensor[next_positions]
        validation_encode = standardizer.transform(_encode_split_rows(
            generalization, X_val_raw, device=state.current_train_tensor.device,
            dtype=state.current_train_tensor.dtype, device_gather=exact_speedups,
        ))
        lga_started = time.perf_counter()
        candidate = {
            "action": VERTICAL_REFINEMENT_ACTION, "candidate_type": VERTICAL_REFINEMENT_ACTION,
            "attribute": attribute, "rank_candidate_id": candidate_id,
            "retention_class_position": None, "retention_class_key": None,
            "selected_row_ids": next_ids, "next_generalization": generalization,
            "next_k": next_k, "privacy_cost": cost, "leakage_delta": delta,
            "swap_stats": swap_stats,
        }
        if candidate_experiment is None:
            candidate["lga_score"] = float(cal_lga(
                train_original_encode=current_score_encode,
                val_original_encode=validation_encode, train_y=current_y, val_y=val_y_tensor,
                train_current_encode=current_score_encode, train_next_encode=next_score_encode,
                train_next_y=next_y, backend_model=backend_model,
            ))
        else:
            measured = candidate_experiment.score_transition(
                candidate_type=VERTICAL_REFINEMENT_ACTION, candidate_id=candidate_id,
                next_encode=next_score_encode, next_y=next_y, validation_encode=validation_encode,
            )
            candidate.update(measured)
            candidate["lga_score"] = float(measured["raw_lga_score"])
        timings["lga"] += time.perf_counter() - lga_started
        vertical.append(candidate)
        if refinement_eviction_ratios:
            # Sec. V refine-and-swap evicts the retained classes whose risk
            # exceeds the ceiling. Each ratio r offers the variant with ceiling
            # tau = ceil(current_k / r): the post-swap classes below tau leave
            # the retained set (the mixed release publishes them at an older
            # snapshot level), so this step lowers min-K by at most r.
            privacy_started = time.perf_counter()
            if swap_position_index is not None:
                class_ids = swap_position_index["row_class_ids"][[
                    swap_position_index["row_id_to_position"][rid] for rid in next_ids]]
            else:
                class_frame = select_encoded_attributes(privacy_encode.loc[next_ids], qi_attributes)
                class_ids = class_frame.groupby(
                    list(class_frame.columns), sort=False, dropna=False, observed=True,
                ).ngroup().to_numpy()
            row_class_sizes = np.bincount(class_ids)[class_ids]
            timings["leakage"] += time.perf_counter() - privacy_started
            ceilings = sorted({math.ceil(current_k / ratio) for ratio in refinement_eviction_ratios})
            for ceiling in ceilings:
                keep = row_class_sizes >= ceiling
                if ceiling <= next_k or not keep.any():
                    continue
                kept_ids = [rid for rid, kept in zip(next_ids, keep) if kept]
                variant_k = int(row_class_sizes[keep].min())
                variant_cost, variant_delta = _operation_privacy_cost(
                    current_k, variant_k, privacy_cost_floor,
                )
                keep_tensor = torch.as_tensor(keep, device=next_score_encode.device)
                lga_started = time.perf_counter()
                lga_next_encode, lga_next_y, lga_val_encode = (
                    next_score_encode[keep_tensor], next_y[keep_tensor], validation_encode)
                variant = {
                    **candidate, "rank_candidate_id": f"{candidate_id}~k{ceiling}",
                    "selected_row_ids": kept_ids, "next_k": variant_k,
                    "privacy_cost": variant_cost, "leakage_delta": variant_delta,
                    "eviction_ceiling": int(ceiling),
                    "ceiling_evicted_row_ids": [rid for rid, kept in zip(next_ids, keep) if not kept],
                    "lga_score": float(cal_lga(
                        train_original_encode=current_score_encode,
                        val_original_encode=lga_val_encode, train_y=current_y, val_y=val_y_tensor,
                        train_current_encode=current_score_encode,
                        train_next_encode=lga_next_encode,
                        train_next_y=lga_next_y, backend_model=backend_model,
                    )),
                }
                timings["lga"] += time.perf_counter() - lga_started
                vertical.append(variant)
        del candidate_state, next_score_encode

    ranked = retention + vertical
    # Refine-and-evict variants get their own top-k pool, so every refinement
    # that the refine-and-swap pool would proxy-check is still checked.
    unevicted = [c for c in vertical if c.get("eviction_ceiling") is None]
    vertical_pools = [unevicted]
    if refinement_eviction_ratios:
        vertical_pools.append([c for c in vertical if c.get("eviction_ceiling") is not None])
    for candidate in ranked:
        candidate["rank_score"] = candidate["lga_score"] / candidate["privacy_cost"]
        candidate["current_k"] = current_k
        candidate["candidate_published_min_k"] = candidate["next_k"]
    ranking_started = time.perf_counter()
    if candidate_experiment is not None:
        measured = []
        primary_keys = set()
        for pool in (retention, *vertical_pools):
            evaluation, keys = candidate_experiment.evaluation_candidates(pool, rank_top_k=rank_top_k)
            measured.extend(evaluation)
            primary_keys.update(keys)
    elif candidate_shortlist is not None:
        pool_of = {id(c): pool for pool, members in enumerate((retention, *vertical_pools))
                   for c in members}
        positions = tuple(candidate_shortlist(CandidateShortlistContext(
            iteration=int(iteration_count), rank_top_k=int(rank_top_k),
            candidates=tuple(RankedCandidate(
                position=i, candidate_type=c["action"], candidate_id=c["rank_candidate_id"],
                rank_score=c["rank_score"], lga_score=c["lga_score"],
                privacy_cost=c["privacy_cost"], leakage_delta=c["leakage_delta"],
                pool=pool_of.get(id(c)),
            ) for i, c in enumerate(ranked)),
        )))
        if len(set(positions)) != len(positions) or any(
            isinstance(i, bool) or not isinstance(i, int) or i < 0 or i >= len(ranked)
            for i in positions
        ):
            raise ValueError("candidate_shortlist must return unique valid integer positions.")
        measured = [ranked[i] for i in positions]
    else:
        measured = [
            candidate for pool in (retention, *vertical_pools)
            for candidate in sorted(pool, key=lambda c: c["rank_score"], reverse=True)[:rank_top_k]
        ]
        # "union": with refinement_eviction_ratios the eviction pool is the last
        # vertical pool; the variants of every checked refinement are checked too.
        if eviction_shortlist == "union" and refinement_eviction_ratios:
            parents = {c["rank_candidate_id"] for c in measured
                       if c["action"] == VERTICAL_REFINEMENT_ACTION and c.get("eviction_ceiling") is None}
            already = {id(c) for c in measured}
            measured += sorted(
                (c for c in vertical_pools[-1]
                 if id(c) not in already and c["rank_candidate_id"].rpartition("~k")[0] in parents),
                key=lambda c: c["rank_score"], reverse=True)
    timings["ranking"] = time.perf_counter() - ranking_started
    certified = []
    best = None
    best_state = None
    best_metadata = None
    reference_loss = state.actual_model_loss
    for candidate in measured:
        generalization = candidate["next_generalization"]
        next_ids = (selected_ids + candidate["admitted_ids"]
                    if candidate["action"] == RETENTION_CLASS_ACTION
                    else candidate["selected_row_ids"])
        primary = (candidate_experiment is None
                   or candidate["candidate_key"] in primary_keys)
        proxy_result = None
        if primary:
            fit_started = time.perf_counter()
            if eviction_release_evaluator is not None and candidate.get("eviction_ceiling") is not None:
                proxy_result = eviction_release_evaluator(
                    generalization, candidate["next_k"], next_ids,
                    candidate["ceiling_evicted_row_ids"],
                )
            else:
                proxy_result = candidate_release_evaluator(
                    generalization, candidate["next_k"], next_ids,
                )
            timings["proxy_retrain"] += time.perf_counter() - fit_started
        if candidate_experiment is not None:
            fit_started = time.perf_counter()
            target_result = candidate_release_evaluator(
                generalization, candidate["next_k"], next_ids, role="downstream",
            )
            target_seconds = time.perf_counter() - fit_started
            if candidate_experiment.mode == "ranking":
                candidate_experiment.record_retrain_attempt(target_seconds)
            if target_result["status"] == "ok":
                if candidate_experiment.mode == "ranking":
                    proxy_delta = None
                    if getattr(candidate_experiment, "record_proxy_ground_truth", False):
                        # Second ground truth: the proxy refit on this candidate, the check that TRIM's LGA
                        # ranking feeds. Outside TRIM's own Top-K the fit is extra measurement work: it is not
                        # timed as TRIM's proxy retraining and never enters the selection below.
                        oracle_proxy = proxy_result if primary else candidate_release_evaluator(
                            generalization, candidate["next_k"], next_ids, role="proxy",
                        )
                        proxy_delta = (float(state.actual_model_loss - float(oracle_proxy["validation_loss"]))
                                       if oracle_proxy is not None and oracle_proxy["status"] == "ok"
                                       else float("nan"))
                    candidate_experiment.observe(
                        candidate, exact_utility_delta=(
                            candidate_experiment.current_downstream_validation_loss
                            - target_result["validation_loss"]
                        ), retrain_time_seconds=target_seconds, count_retrain_time=False,
                        proxy_utility_delta=proxy_delta,
                    )
                else:
                    candidate_experiment.observe_estimation_candidate(
                        candidate, privacy_cost=candidate["privacy_cost"],
                        downstream_validation_loss=target_result["validation_loss"],
                        downstream_time_seconds=target_seconds,
                        proxy_validation_loss=(proxy_result.get("validation_loss")
                                               if proxy_result else None),
                        proxy_time_seconds=(proxy_result.get("evaluation_seconds", 0.0)
                                            if proxy_result else 0.0),
                    )
            if not primary:
                continue
        if proxy_result is None or proxy_result["status"] != "ok":
            continue
        loss = float(proxy_result["validation_loss"])
        gain = float(reference_loss - loss)
        # Only the committed candidate needs its training encode; it is built
        # after the loop unless a state scorer reads it here.
        level_encode = (generalization.encode(X_train_raw)
                        if candidate_state_scorer is not None else None)
        candidate_state = SelectionState(
            predicted_model_loss=loss, actual_model_loss=loss,
            current_generalization=generalization, selected_row_ids=list(next_ids),
            current_train_encode=level_encode,
            current_train_tensor=(None if level_encode is None else to_device_tensor(
                level_encode, device=state.current_train_tensor.device,
                dtype=state.current_train_tensor.dtype,
            )), action_log_path=state.action_log_path,
        )
        external_score = None
        if candidate_state_scorer is not None:
            positions = [row_id_to_position[rid] for rid in next_ids]
            external_score = float(candidate_state_scorer(CandidateStateScoreContext(
                iteration=int(iteration_count), candidate_type=candidate["action"],
                candidate_id=candidate["rank_candidate_id"],
                current_encode=current_score_encode, current_y=current_y,
                candidate_encode=standardizer.transform(candidate_state.current_train_tensor[positions]),
                candidate_y=train_y_tensor[positions],
                current_validation_encode=current_val_encode,
                candidate_validation_encode=standardizer.transform(to_device_tensor(
                    generalization.encode(X_val_raw), device=state.current_train_tensor.device,
                    dtype=state.current_train_tensor.dtype,
                )), validation_y=val_y_tensor,
            )))
            if not math.isfinite(external_score):
                raise ValueError("candidate_state_scorer must return a finite number.")
        context = SelectionScoreContext(
            iteration=int(iteration_count), candidate_type=candidate["action"],
            candidate_id=candidate["rank_candidate_id"], utility_gain=gain,
            current_k=current_k, next_k=int(candidate["next_k"]),
            privacy_cost=candidate["privacy_cost"],
            candidate_published_min_k=int(candidate["next_k"]),
            release_target_k=int(proxy_result["target_k"]), release_validation_loss=loss,
            release_row_count=int(proxy_result["row_count"]),
            release_suppressed_row_count=int(proxy_result["suppressed_row_count"]),
            release_coverage_fraction=float(proxy_result["coverage_fraction"]),
            candidate_state_score=external_score,
        )
        score = float(default_selection_score(context) if selection_score is None
                      else selection_score(context))
        if not math.isfinite(score):
            raise ValueError("selection_score must return a finite number.")
        record = {
            **{k: v for k, v in candidate.items() if k not in (
                "next_generalization", "swap_stats", "admitted_ids", "admitted_positions",
            )},
            "state": replace(candidate_state, current_train_encode=state.current_train_encode,
                             current_train_tensor=None),
            "utility_gain": gain, "candidate_state_score": external_score, "score": score,
            "rank_method": "lga_per_privacy_cost",
            "release_target_k": int(proxy_result["target_k"]), "release_validation_loss": loss,
            "release_row_count": int(proxy_result["row_count"]),
            "release_suppressed_row_count": int(proxy_result["suppressed_row_count"]),
            "release_coverage_fraction": float(proxy_result["coverage_fraction"]),
            "proxy_evaluation_scope": proxy_result["evaluation_scope"],
            "eligible": gain > 0.0,
        }
        within_step = max_privacy_step is None or int(candidate["next_k"]) * max_privacy_step >= current_k
        if max_privacy_step is not None:
            record["within_privacy_step"] = bool(within_step)
        certified.append(record)
        # A bounded step beats any unbounded one; the score decides within each group.
        if gain > 0.0 and (best is None or (within_step, score) > (
                best.get("within_privacy_step", True), best["score"])):
            best, best_state = record, candidate_state
            best_metadata = {
                "release_result": proxy_result, "position_index": None,
                "swap_stats": candidate.get("swap_stats"),
                "swap_level_encode": level_encode, "swap_codes": None,
            }
    if (eviction_release_evaluator is not None and best_state is not None
            and best.get("eviction_ceiling") is not None):
        # The variant was scored with its pooled rows; later rounds score
        # retained rows, so the committed state's loss (and the fitted proxy
        # that becomes the next estimator) come from its retained rows.
        fit_started = time.perf_counter()
        proxy_result = candidate_release_evaluator(
            best_state.current_generalization, int(best["next_k"]),
            list(best_state.selected_row_ids), role="proxy",
        )
        timings["proxy_retrain"] += time.perf_counter() - fit_started
        if proxy_result["status"] != "ok":
            raise RuntimeError("The committed eviction variant cannot be re-measured on its retained rows.")
        best_metadata["release_result"] = proxy_result
        best_state.predicted_model_loss = float(proxy_result["validation_loss"])
        best_state.actual_model_loss = float(proxy_result["validation_loss"])
        best["published_validation_loss"] = best["release_validation_loss"]
        best["release_validation_loss"] = float(proxy_result["validation_loss"])
    if best_state is not None and best_state.current_train_encode is None:
        level_encode = (_encode_frame_from_tables(best_state.current_generalization, X_train_raw)
                        if exact_speedups else best_state.current_generalization.encode(X_train_raw))
        best_state.current_train_encode = level_encode
        # np.asarray(encode(X), dtype) equals encode_array(X, dtype) bitwise
        # (tests/test_selection_cache.py), so the device gather gives the same tensor.
        best_state.current_train_tensor = (
            _encode_split_rows(
                best_state.current_generalization, X_train_raw,
                device=state.current_train_tensor.device, dtype=state.current_train_tensor.dtype,
                device_gather=True)
            if exact_speedups else to_device_tensor(
                level_encode, device=state.current_train_tensor.device,
                dtype=state.current_train_tensor.dtype,
            ))
        best_metadata["swap_level_encode"] = level_encode
    if candidate_experiment is not None and candidate_experiment.observations:
        selected_key = (best["action"], best["rank_candidate_id"]) if best else None
        candidate_experiment.finish_iteration(
            selected_key,
            **({"trim_estimated_utility_delta": best["utility_gain"],
                "trim_proxy_time_seconds": timings["proxy_retrain"]}
               if best and candidate_experiment.mode == "estimation" else {}),
        )
    selection_timing.update(timings)
    selection_timing["selection"] = max(0.0, time.perf_counter() - started)
    if best is None:
        return {"action": None, "state": state, "candidates": certified,
                "selected_candidate_position": None}
    return {**best, **best_metadata, "state": best_state, "candidates": certified,
            "selected_candidate_position": next(i for i, c in enumerate(certified) if c is best)}

